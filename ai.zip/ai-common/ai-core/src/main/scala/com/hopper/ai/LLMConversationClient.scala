package com.hopper.ai

import com.hopper.ai.model.ConversationCompletionChoices
import com.hopper.ai.model.ConversationMessage
import com.twitter.util.Future

/**
 * A generic client for a large language model (LLM) that can be prompted in conversational style using messages.
 */
trait LLMConversationClient {
  /**
   * Prompt the LLM using a series of messages that make up a conversion. The LLM will return a completion that
   * @return
   */
  def completions(messages: List[ConversationMessage]): Future[ConversationCompletionChoices]
}
