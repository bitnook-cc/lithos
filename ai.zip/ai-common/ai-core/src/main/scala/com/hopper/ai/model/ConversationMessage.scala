package com.hopper.ai.model

/**
 * A message is a part of a conversation with an llm.
 *
 * For example, the conversation might have a system message that tells the LLM what to do, and then a user message that gives the LLM the input data that needs to be completed upon.
 *
 * The LLM will then respond with an Assistant message. The whole series can then be re-fed back into the LLM to continue the conversation along with further system or user messages.
 */
sealed trait ConversationMessage

object ConversationMessage {
  /**
   * A system message is a message that is sent to the LLM to tell it what to do, isolated from any user input.
   */
  final case class SystemConversationMessage(message: String) extends ConversationMessage

  /**
   * The user message contains any external input into the LLM.
   */
  final case class UserConversationMessage(message: String) extends ConversationMessage

  /**
   * A message returned by the LLM.
   */
  final case class AssistantConversationMessage(message: String) extends ConversationMessage
}
