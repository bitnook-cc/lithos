import com.hopper.sbt.HopperDeps._
import explicitdeps.ExplicitDepsPlugin.autoImport.unusedCompileDependenciesFilter
import sbt.moduleFilter

// Formatting settings
addCommandAlias("fmt", "scalafmtAll;scalafmtSbt")

lazy val scala212 = "2.12.20"
lazy val scala213 = "2.13.18"
lazy val supportedScalaVersions = List(scala212, scala213)

// Do not update unless you are making a MAJOR breaking change, since this will require all clients to update their
// dependency on ai-common. If you do update here, you also need to update in
// .github/workflows/create-github-release, since the major version is hardcoded there currently.
ThisBuild / majorVersion := "1"

val localizationToolboxVersion = "4.3.0"

lazy val aiCommonBase = hopperBase ++ hopperScalafmt ++ Seq(
  /** SonarCloud configs */
  scalacOptions += "-Ywarn-unused:imports",
  coverageExcludedFiles := "^.*src_managed.*$",
  unusedCompileDependenciesFilter -= moduleFilter("org.scoverage", "scalac-scoverage-runtime"),
  unusedCompileDependenciesFilter -= moduleFilter("org.scoverage", "scalac-scoverage-domain"),
  unusedCompileDependenciesFilter -= moduleFilter("org.scoverage", "scalac-scoverage-reporter"),
  unusedCompileDependenciesFilter -= moduleFilter("org.scoverage", "scalac-scoverage-serializer"),
  unusedCompileDependenciesFilter -= moduleFilter("com.sksamuel.scapegoat", "scalac-scapegoat-plugin"),
  scapegoatConsoleOutput := false,
  (ThisBuild / scapegoatVersion) := "3.3.2",
  scalaVersion := scala212,
  crossScalaVersions := supportedScalaVersions,
)

lazy val all = Project(
  id = "ai-common",
  base = file("."),
)
  .settings(
    publish / skip := true,
    aiCommonBase,
    scalacOptions ++= HopperSettings.extraWarnings ::: HopperSettings.warningsAfterMacros,
  )
  .aggregate(
    core,
    azure,
  )

def aiCommonProject(id: String) = Project(
  id = s"ai-$id",
  base = file(s"ai-$id"),
)
  .enablePlugins(HelpersAlignedVersionPlugin)
  .settings(
    aiCommonBase,
    hopperLibrary,
  )
  // TODO: check if the warnings are valid or some strings needs to be localized
  .settings(disableStringScan := true)

lazy val core = aiCommonProject("core")
  .settings(
    libraryDependencies ++= Seq(
      helper("core"),
    ),
    // helper("core") is used for `Future` but is getting marked as unused.
    unusedCompileDependenciesFilter -= moduleFilter("com.hopper", "helpers-core"),
  )

lazy val azure = aiCommonProject("azure")
  .settings(
    libraryDependencies ++= Seq(
      helper("http"),
    ),
  ).dependsOn(core)


