# ai-common

Shared code for AI usecases.

Tooling exists in this project to ensure that a new release is built and published for every Helpers version. Thus a 
project that depends on Helpers and ai-common should always be able to pull in ai-common on the Helpers 
version that it is building against.

## Helpers Updates

Since the code is tightly-coupled to Helpers, we follow the "helpers-aligned library" pattern to automatically publish a new version whenever a new version of Helpers is published.
This ensures that any projects depending on both ai-common and Helpers will have the same version of Helpers in the classpath.

See [Helpers Aligned Libraries](https://hopper-jira.atlassian.net/wiki/spaces/ENG/pages/6040651638/Helpers-Aligned+Libraries) for more info on how this works.

### Breaking Helpers Change

If a breaking change is made in Helpers that breaks compilation, the automatic "bump-helpers" builds will fail until the issue is manually resolved.
This can be done by creating a PR that updates project/helpers.version to latest and resolves the breaking change.

### Using Local Helpers `SNAPSHOT` Build

Using a Helpers `SNAPSHOT` build can be done by manually changing the `project/helpers.sbt` file:

* In `Helpers`
  * `sbt> publishLocal`
    * this will publish version `1.0-SNAPSHOT` locally
* In `ai-common`
  * edit `project/helpers.version` and set the version to `1.0-SNAPSHOT`
  * `sbt> reload`
  * `sbt> publishLocal`
  * This will publish `ai-common` artifacts locally with version `1.0.0-SNAPSHOT`
* In your service that depends on `ai-common`:
  * Edit `project/plugins.sbt` and set the version of `sbt-hopper` to `1.0-SNAPSHOT`
  * Edit `build.sbt` and set `snapshot = true` for all `aiCommon("...", snapshot = true)` dependencies

Remember to do an `sbt reload` after you update the version if you have an active SBT session open

### Using Local ai-common `SNAPSHOT` build in another repo

This is similar to the steps for testing a local Helpers SNAPSHOT version, but simpler. 

1. set the Helpers version in `ai-common` to match the one in the consuming repo
1. `sbt publishLocal` on ai-common
1. `aiCommon("...", snapshot = true)` in consuming repo. See [Helpers][1] for where this method is defined.