import sbt._

object Helpers {

  lazy val helpersVersion = settingKey[String]("The version of helpers to use")

}
