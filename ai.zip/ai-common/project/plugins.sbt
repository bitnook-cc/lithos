import sbt.Defaults.sbtPluginExtra

// This is equivalent to addSbtPlugin(...) but allows referring to a settingKey, so we can read the helpers.version file
libraryDependencies += {
  val sbtVersion = (pluginCrossBuild / sbtBinaryVersion).value
  val scalaVersion = (update / scalaBinaryVersion).value
  val helpersV = IO.readLines(baseDirectory.value / "helpers.version").head.trim // baseDirectory is <repo>/project here

  // NOTE: to change the helpers version, update project/helpers.sbt
  val sbtHopperModuleId = "com.hopper" %% "sbt-hopper" % sys.env.getOrElse("HOPPER_HELPER_VERSION", helpersV)
  sbtPluginExtra(sbtHopperModuleId, sbtVersion, scalaVersion)
}

addSbtPlugin("org.scoverage" % "sbt-scoverage" % "2.4.2")
addSbtPlugin("com.sksamuel.scapegoat" %% "sbt-scapegoat" % "1.2.3")
addSbtPlugin("com.hopper" %% "rosetta-analysis" % "0.1.56")
