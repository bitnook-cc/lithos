package com.hopper.ai.azure.model

import com.hopper.common.json.JsFormat
import com.hopper.common.lang.AEnum
import com.hopper.common.lang.Deriving
import com.hopper.common.lang.Enum

sealed trait Role
object Role extends AEnum[Role] {
  case object System extends Role
  case object User extends Role
  case object Assistant extends Role
  case object Function extends Role

  override def namedValues: List[Enum.NamedValue[Role]] = Enum.values[Role]
  implicit lazy val fmt: JsFormat[Role] = JsFormat.enum(Role.camelCase)
}

case class GPTMessage(
  role: Role,
  content: Option[String],
  name: Option[String] = None,
)

object GPTMessage {
  implicit lazy val fmt: JsFormat[GPTMessage] = Deriving[JsFormat[GPTMessage]]
}
