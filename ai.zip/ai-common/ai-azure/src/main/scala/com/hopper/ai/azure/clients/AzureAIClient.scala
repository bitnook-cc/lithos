package com.hopper.ai.azure.clients

import com.hopper.ai.LLMConversationClient
import com.hopper.ai.azure.AzureAIMetrics
import com.hopper.ai.azure.model.ChatCompletionRequest
import com.hopper.ai.azure.model.ChatCompletionResponse
import com.hopper.ai.azure.model.ErrorResponse
import com.hopper.ai.azure.model.GPTMessage
import com.hopper.ai.azure.model.Role
import com.hopper.ai.model.ConversationCompletionChoices
import com.hopper.ai.model.ConversationMessage
import com.hopper.ai.model.ConversationMessage.AssistantConversationMessage
import com.hopper.common.json.Json
import com.hopper.common.logging.Logging
import com.twitter.finagle.Service
import com.twitter.finagle.http.Method
import com.twitter.finagle.http.Request
import com.twitter.finagle.http.Request.queryString
import com.twitter.finagle.http.Response
import com.twitter.finagle.stats.StatsReceiver
import com.twitter.util.Future
import com.twitter.util.Return
import com.twitter.util.Throw
import com.twitter.util.Try

object AzureAIClient extends Logging {
  def apply(
    client: Service[Request, Response],
    model: String,
    apiVersion: String,
    statsReceiver: StatsReceiver,
  ): LLMConversationClient = new LLMConversationClient {

    val metrics: AzureAIMetrics = AzureAIMetrics(statsReceiver)

    private def httpRequest(
      request: Request,
    ): Future[Response] = {
      client.apply(request)
    }

    override def completions(messages: List[ConversationMessage]): Future[ConversationCompletionChoices] = {
      val azureMessages = messages.map {
        case ConversationMessage.SystemConversationMessage(message) =>
          GPTMessage(
            role = Role.System,
            content = Some(message),
            name = None,
          )
        case ConversationMessage.UserConversationMessage(message) =>
          GPTMessage(
            role = Role.User,
            content = Some(message),
            name = None,
          )
        case ConversationMessage.AssistantConversationMessage(message) =>
          GPTMessage(
            role = Role.Assistant,
            content = Some(message),
            name = None,
          )
      }

      val requestBody = Json.stringify(Json.toJson(
        ChatCompletionRequest(azureMessages),
      ))
      val request = buildPostRequest(
        url = s"/openai/deployments/$model/chat/completions",
        body = requestBody,
        params = List("api-version" -> apiVersion),
      )
      metrics.total.incr()
      httpRequest(request).liftToTry.map {
        case Throw(e) =>
          metrics.error.get("unknown_error").incr()
          logger.error("Error from Completion API", e)
          throw e
        case Return(rawResponse) =>
          Try(Json.parse(rawResponse.contentString).jsAs[ChatCompletionResponse]) match {
            case Return(response: ChatCompletionResponse) =>
              metrics.success.get("total").incr()
              if (response.choices.headOption.flatMap(_.message.content).isEmpty) {
                metrics.error.get("empty_response").incr()
                logger.error(
                  s"Empty response from chat completion API, response: ${rawResponse.statusCode} - ${rawResponse.contentString}",
                )
              }
              ConversationCompletionChoices(
                response.choices.flatMap(_.message.content).map(AssistantConversationMessage),
              )
            case Throw(e) =>
              metrics.error.get("unknown_error").incr()
              Try(Json.parse(rawResponse.contentString).jsAs[ErrorResponse]) match {
                case Return(ErrorResponse(error)) =>
                  logger.error(
                    s"Error returned from chat completion API, statusCode ${error.code}, error: ${error.message}",
                  )
                  throw e
                case Throw(er) =>
                  logger.error(
                    s"Unknown error returned from chat completion API statusCode: ${rawResponse.statusCode}, response: ${rawResponse.contentString}",
                    er,
                  )
                  throw e
              }
          }
      }
    }
  }

  private def buildPostRequest(
    url: String,
    body: String,
    params: List[(String, String)],
  ): Request = {
    val request = Request(
      Method.Post,
      queryString(url, params: _*),
    )
    request.setContentTypeJson()
    request.setContentString(body)
    request
  }
}
