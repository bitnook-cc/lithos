package com.hopper.ai.azure.model

import com.hopper.common.json.JsFormat
import com.hopper.common.lang.Deriving

case class Choice(index: Int, finish_reason: String, message: GPTMessage)
object Choice {
  implicit lazy val entityFormat: JsFormat[Choice] = Deriving[JsFormat[Choice]]
}

case class Usage(prompt_tokens: Int, completion_tokens: Int, total_tokens: Int)
object Usage {
  implicit lazy val entityFormat: JsFormat[Usage] = Deriving[JsFormat[Usage]]
}

case class ChatCompletionResponse(
  id: String,
  `object`: String,
  created: Int,
  model: String,
  choices: List[Choice],
  usage: Usage,
)
object ChatCompletionResponse {
  implicit lazy val entityFormat: JsFormat[ChatCompletionResponse] = Deriving[JsFormat[ChatCompletionResponse]]
}
