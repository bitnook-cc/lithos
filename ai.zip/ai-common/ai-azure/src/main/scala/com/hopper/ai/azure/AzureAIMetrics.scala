package com.hopper.ai.azure

import com.hopper.common.cache.CaffeineProvider.UnboundedProvider.sync
import com.hopper.common.cache.SyncLoadingCache
import com.twitter.finagle.stats.Counter
import com.twitter.finagle.stats.StatsReceiver

case class AzureAIMetrics(componentStats: StatsReceiver) {
  private type CounterName = String
  private type ErrorName = String

  private lazy val azureAIStats = componentStats.scope("azure").scope("ai")

  lazy val total: Counter = azureAIStats.counter("total")

  lazy val success: SyncLoadingCache[CounterName, Counter] =
    sync[String, Counter](counterName => azureAIStats.scope("success").counter(counterName))

  lazy val error: SyncLoadingCache[ErrorName, Counter] =
    sync[String, Counter](errorName =>
      azureAIStats.scope("failure").counter(s"error=${errorName}"),
    )
}
