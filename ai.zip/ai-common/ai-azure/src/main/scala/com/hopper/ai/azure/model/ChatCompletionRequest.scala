package com.hopper.ai.azure.model

import com.hopper.common.json.JsFormat
import com.hopper.common.lang.Deriving

// https://learn.microsoft.com/en-us/azure/ai-services/openai/reference
case class ChatCompletionRequest(
  messages: List[GPTMessage],
  temperature: Option[BigDecimal] = Some(BigDecimal(0.2)),
  max_tokens: Option[Int] = None,
)

object ChatCompletionRequest {
  implicit lazy val fmt: JsFormat[ChatCompletionRequest] = Deriving[JsFormat[ChatCompletionRequest]]
}
