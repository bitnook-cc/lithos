package com.hopper.ai.azure

import com.hopper.ai.LLMConversationClient
import com.hopper.ai.azure.clients.AzureAIClient
import com.hopper.common.configuration.ConfigParser
import com.hopper.common.http.HttpServiceParser
import com.hopper.common.lang.Deriving
import com.hopper.common.logging.Logging
import com.twitter.finagle.Service
import com.twitter.finagle.SimpleFilter
import com.twitter.finagle.http.Request
import com.twitter.finagle.http.Response
import com.twitter.finagle.stats.StatsReceiver
import com.twitter.util.Future
import com.twitter.util.Managed

final case class AzureAIConfig(
  httpClient: HttpServiceParser.HttpServiceConfig,
  apiKey: String,
  model: String,
  apiVersion: String,
) extends Logging {
  def build(
    statsReceiver: StatsReceiver,
  ): Managed[LLMConversationClient] = {
    if (apiKey.startsWith("placeholder-key")) {
      logger.warn("Azure API key is not set")
    }

    // Removing any new lines or empty characters accidentally added to the key
    val trimmedApiKey = apiKey.trim

    for {
      client <- httpClient.managed()
    } yield {
      val authFilter: SimpleFilter[Request, Response] = new SimpleFilter[Request, Response] {
        final val ApiKeyHeaderName = "api-key"
        def apply(req: Request, service: Service[Request, Response]): Future[Response] = {
          req.headerMap.add(ApiKeyHeaderName, trimmedApiKey)
          service(req)
        }
      }
      AzureAIClient(
        client = authFilter andThen client,
        model = model,
        apiVersion = apiVersion,
        statsReceiver = statsReceiver,
      )
    }
  }
}

object AzureAIConfig {
  implicit lazy val parser: ConfigParser[AzureAIConfig] = Deriving[ConfigParser[AzureAIConfig]]
}

case class AzureAIClients(
  gpt: AzureAIConfig,
)

object AzureAIClients {
  implicit lazy val parser: ConfigParser[AzureAIClients] = Deriving[ConfigParser[AzureAIClients]]
}
