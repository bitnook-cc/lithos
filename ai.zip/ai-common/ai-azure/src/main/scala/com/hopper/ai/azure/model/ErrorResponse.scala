package com.hopper.ai.azure.model

import com.hopper.common.json.JsFormat
import com.hopper.common.lang.Deriving

case class Error(message: String, `type`: String, param: String, code: String)
object Error {
  implicit lazy val entityFormat: JsFormat[Error] = Deriving[JsFormat[Error]]
}

case class ErrorResponse(error: Error)
object ErrorResponse {
  implicit lazy val entityFormat: JsFormat[ErrorResponse] = Deriving[JsFormat[ErrorResponse]]
}
