package com.hopper.seocontent.gpt

import com.hopper.ai.azure.clients.AzureAIClient
import com.hopper.ai.azure.model.ChatCompletionResponse
import com.hopper.ai.azure.model.Choice
import com.hopper.ai.azure.model.Error
import com.hopper.ai.azure.model.ErrorResponse
import com.hopper.ai.azure.model.GPTMessage
import com.hopper.ai.azure.model.Role
import com.hopper.ai.azure.model.Usage
import com.hopper.ai.model.ConversationCompletionChoices
import com.hopper.ai.model.ConversationMessage.AssistantConversationMessage
import com.hopper.ai.model.ConversationMessage.UserConversationMessage
import com.hopper.common.json.Json
import com.twitter.finagle.Service
import com.twitter.finagle.http.Request
import com.twitter.finagle.http.Response
import com.twitter.finagle.stats.InMemoryStatsReceiver
import com.twitter.util.Await
import com.twitter.util.Future
import org.specs2.mock.Mockito
import org.specs2.mutable.Specification
import scala.collection.compat.immutable.ArraySeq

class AzureClientSpec extends Specification with Mockito {
  "AzureClient" should {
    "return a valid response" in {
      val serviceClientMock = new Service[Request, Response] {
        def apply(request: Request): Future[Response] = {
          val response = Response()
          response.contentString = Json.stringify(Json.toJson(ChatCompletionResponse(
            id = "",
            `object` = "",
            created = 0,
            model = "",
            choices = List(Choice(
              index = 0,
              finish_reason = "",
              message = GPTMessage(role = Role.System, content = Some("response"), name = None),
            )),
            usage = Usage(prompt_tokens = 0, completion_tokens = 0, total_tokens = 0),
          )))
          Future(response)
        }
      }

      mock[Service[Request, Response]]

      val mockStatsReceiver = new InMemoryStatsReceiver()

      val service = AzureAIClient(
        client = serviceClientMock,
        model = "",
        apiVersion = "",
        statsReceiver = mockStatsReceiver.scope("azure_content", "server"),
      )

      val userConversationMessage = UserConversationMessage("conversationId")

      val result = Await.result(service.completions(List(userConversationMessage)))

      mockStatsReceiver.counters.get(ArraySeq("azure_content", "server", "azure", "ai", "total")) shouldEqual Some(1)
      mockStatsReceiver.counters.get(
        ArraySeq("azure_content", "server", "azure", "ai", "success", "total"),
      ) shouldEqual Some(1)

      result.shouldEqual(ConversationCompletionChoices(List(AssistantConversationMessage("response"))))
    }

    "return an error response" in {
      val serviceClientMock = new Service[Request, Response] {
        def apply(request: Request): Future[Response] = {
          val response = Response()
          response.contentString =
            Json.stringify(Json.toJson(ErrorResponse(Error(message = "", `type` = "", param = "", code = ""))))
          Future(response)
        }
      }

      mock[Service[Request, Response]]

      val mockStatsReceiver = new InMemoryStatsReceiver()

      val service = AzureAIClient(
        client = serviceClientMock,
        model = "",
        apiVersion = "",
        statsReceiver = mockStatsReceiver.scope("azure_content", "server"),
      )

      val userConversationMessage = UserConversationMessage("conversationId")

      Await.result(service.completions(List(userConversationMessage))) must throwA[Exception]

      mockStatsReceiver.counters.get(ArraySeq("azure_content", "server", "azure", "ai", "total")) shouldEqual Some(1)
      mockStatsReceiver.counters.get(
        ArraySeq("azure_content", "server", "azure", "ai", "failure", "error=unknown_error"),
      ) shouldEqual Some(
        1,
      )
    }
  }
}
