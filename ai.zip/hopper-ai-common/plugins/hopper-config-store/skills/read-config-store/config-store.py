# /// script
# requires-python = ">=3.11"
# dependencies = ["google-cloud-bigquery"]
# ///
"""CLI for querying config-store data from BigQuery.

Usage: uv run config-store.py <command> [options]

config-store is Hopper's centralized configuration service (Spanner-backed).
A spanner-extract pipeline streams changes into BigQuery dataset
`config_store__raw_physical` in the platform GCP project.

Two tables, join on value_hash = data_hash:
  configuration_history — (tenant, service, id, ts, editor, value_hash)
  content_history       — (data_hash, data_value)

Latest config = row with the largest ts for a (tenant, service, id) triple.
Tenant-agnostic configs use tenant = 'all-tenants'.
"""

from __future__ import annotations

import argparse
import json
import sys

from google.cloud import bigquery

# ─── Environment → GCP project mapping ─────────────────────────────

ENV_PROJECTS: dict[str, str] = {
    "staging": "gcp-hopper-staging-platform",
    "production": "gcp-hopper-production-platform",
}

DATASET = "config_store__raw_physical"


def _project(env: str) -> str:
    if env not in ENV_PROJECTS:
        sys.exit(f"Unknown env: {env}. Use: {', '.join(ENV_PROJECTS)}")
    return ENV_PROJECTS[env]


def _table(env: str, table: str) -> str:
    return f"`{_project(env)}.{DATASET}.{table}`"


def _run(env: str, sql: str) -> list[dict]:
    client = bigquery.Client(project=_project(env))
    rows = client.query(sql).result()
    return [dict(r) for r in rows]


# ─── Commands ───────────────────────────────────────────────────────

def list_services(args: argparse.Namespace) -> None:
    """List distinct (service, id) pairs."""
    sql = f"""
    SELECT DISTINCT service, id
    FROM {_table(args.env, 'configuration_history')}
    ORDER BY service, id
    """
    for row in _run(args.env, sql):
        print(f"{row['service']:40s} {row['id']}")


def get_latest(args: argparse.Namespace) -> None:
    """Get the latest config value for a service/key, optionally filtered by tenant."""
    tenant_filter = f"AND tenant = '{args.tenant}'" if args.tenant else ""
    sql = f"""
    SELECT
      tenant,
      ts,
      SAFE_CONVERT_BYTES_TO_STRING(data_value) AS config_json
    FROM {_table(args.env, 'configuration_history')} AS conf
    LEFT JOIN {_table(args.env, 'content_history')} AS content
      ON content.data_hash = conf.value_hash
    WHERE
      service = '{args.service}'
      AND id = '{args.key_id}'
      {tenant_filter}
    QUALIFY ROW_NUMBER() OVER (PARTITION BY tenant ORDER BY ts DESC) = 1
    ORDER BY tenant
    """
    for row in _run(args.env, sql):
        tenant = row["tenant"]
        ts = row["ts"]
        config_json = row["config_json"]
        print(f"--- {tenant} (updated {ts}) ---")
        if config_json:
            try:
                parsed = json.loads(config_json)
                print(json.dumps(parsed, indent=2))
            except json.JSONDecodeError:
                print(config_json)
        else:
            print("(empty)")
        print()


def get_history(args: argparse.Namespace) -> None:
    """Get full write history for a service/key."""
    tenant_filter = f"AND tenant = '{args.tenant}'" if args.tenant else ""
    limit_clause = f"LIMIT {args.limit}" if args.limit else ""
    sql = f"""
    SELECT
      tenant,
      ts,
      editor,
      SAFE_CONVERT_BYTES_TO_STRING(data_value) AS config_json
    FROM {_table(args.env, 'configuration_history')} AS conf
    LEFT JOIN {_table(args.env, 'content_history')} AS content
      ON content.data_hash = conf.value_hash
    WHERE
      service = '{args.service}'
      AND id = '{args.key_id}'
      {tenant_filter}
    ORDER BY ts DESC
    {limit_clause}
    """
    for row in _run(args.env, sql):
        tenant = row["tenant"]
        ts = row["ts"]
        editor = row["editor"] or "unknown"
        config_json = row["config_json"]
        print(f"--- {tenant} @ {ts} by {editor} ---")
        if config_json and args.show_values:
            try:
                parsed = json.loads(config_json)
                print(json.dumps(parsed, indent=2))
            except json.JSONDecodeError:
                print(config_json)
        print()


def diff_tenants(args: argparse.Namespace) -> None:
    """Compare latest config between two tenants for a service/key."""
    sql = f"""
    SELECT
      tenant,
      SAFE_CONVERT_BYTES_TO_STRING(data_value) AS config_json
    FROM {_table(args.env, 'configuration_history')} AS conf
    LEFT JOIN {_table(args.env, 'content_history')} AS content
      ON content.data_hash = conf.value_hash
    WHERE
      service = '{args.service}'
      AND id = '{args.key_id}'
      AND tenant IN ('{args.tenant_a}', '{args.tenant_b}')
    QUALIFY ROW_NUMBER() OVER (PARTITION BY tenant ORDER BY ts DESC) = 1
    """
    results = {}
    for row in _run(args.env, sql):
        config_json = row["config_json"]
        try:
            results[row["tenant"]] = json.loads(config_json) if config_json else None
        except json.JSONDecodeError:
            results[row["tenant"]] = config_json

    for tenant in (args.tenant_a, args.tenant_b):
        if tenant not in results:
            print(f"No config found for tenant '{tenant}'")
            return

    print(f"Tenant A: {args.tenant_a}")
    print(json.dumps(results[args.tenant_a], indent=2, sort_keys=True))
    print(f"\nTenant B: {args.tenant_b}")
    print(json.dumps(results[args.tenant_b], indent=2, sort_keys=True))


# ─── Argument Parsing ───────────────────────────────────────────────

def main() -> None:
    parser = argparse.ArgumentParser(
        description="Query config-store data from BigQuery"
    )
    parser.add_argument(
        "--env", default="staging", choices=list(ENV_PROJECTS),
        help="Environment (default: staging)"
    )
    sub = parser.add_subparsers(dest="command", required=True)

    # list-services
    sub.add_parser("list-services", help="List distinct (service, id) pairs")

    # get-latest
    p = sub.add_parser("get-latest", help="Get latest config for a service/key")
    p.add_argument("service", help="Config-store service name")
    p.add_argument("key_id", help="Config key ID")
    p.add_argument("--tenant", help="Filter to a specific tenant")

    # get-history
    p = sub.add_parser("get-history", help="Get write history for a service/key")
    p.add_argument("service", help="Config-store service name")
    p.add_argument("key_id", help="Config key ID")
    p.add_argument("--tenant", help="Filter to a specific tenant")
    p.add_argument("--limit", type=int, default=20, help="Max rows (default: 20)")
    p.add_argument("--show-values", action="store_true", help="Include config JSON in output")

    # diff-tenants
    p = sub.add_parser("diff-tenants", help="Compare latest config between two tenants")
    p.add_argument("service", help="Config-store service name")
    p.add_argument("key_id", help="Config key ID")
    p.add_argument("tenant_a", help="First tenant")
    p.add_argument("tenant_b", help="Second tenant")

    args = parser.parse_args()
    cmd = {
        "list-services": list_services,
        "get-latest": get_latest,
        "get-history": get_history,
        "diff-tenants": diff_tenants,
    }
    cmd[args.command](args)


if __name__ == "__main__":
    main()
