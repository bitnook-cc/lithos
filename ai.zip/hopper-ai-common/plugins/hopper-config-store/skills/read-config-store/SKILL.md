---
name: read-config-store
description: >-
  Query config-store data from BigQuery. Triggers: "read config-store",
  "dump config", "config-store BQ", "spanner-extract config-store".
---

# Read Config-Store Data from BigQuery

config-store is Hopper's centralized configuration service (Spanner-backed). A spanner-extract pipeline streams changes into BigQuery dataset `config_store__raw_physical`. For full details, see the [config-store via BigQuery doc](https://github.com/hopper-org/config-store/blob/master/docs/config-store-via-BQ.md).

**Don't use this for:** writing config (`ConfigStoreAdminClient` or Retool) or runtime reads (`ConfigStoreClient`).

## CLI Tool

The `config-store.py` script in this skill directory provides all common queries. Run with `uv run <path-to-this-skill-dir>/config-store.py`.

All commands accept `--env` (default: `staging`). Production BQ access requires additional permissions.

### List all service/key pairs
```bash
uv run config-store.py list-services
uv run config-store.py list-services --env production
```
```
london                                   multiTenantConfiguration
london                                   tenantAgnosticConfiguration
southlake                                multiTenantConfiguration
```

### Get latest config
```bash
uv run config-store.py get-latest london multiTenantConfiguration
uv run config-store.py get-latest london multiTenantConfiguration --tenant hopper
```
```
--- hopper (updated 2026-05-15 14:23:11+00:00) ---
{
  "providers": [...],
  ...
}
```

### Get write history
```bash
uv run config-store.py get-history london tenantAgnosticConfiguration --limit 5
uv run config-store.py get-history london tenantAgnosticConfiguration --show-values
```

### Diff two tenants
```bash
uv run config-store.py diff-tenants flights-provider-facade integrationProviderMap hopper volaris
```

## Finding a Service's Keys

Each service registers its config-store keys in code. In Scala services, grep for `Service("` and `keyId` in files like `BaseConfigStoreClientApi.scala`.

## Pointers

- [config-store via BigQuery](https://github.com/hopper-org/config-store/blob/master/docs/config-store-via-BQ.md) — pipeline, schema, access, sqlmesh setup
- [config-store getting-started](https://github.com/hopper-org/config-store/blob/master/docs/getting-started.md)
- [Existing brz model — london multitenant_config](https://github.com/hopper-org/sqlmesh-projects/blob/main/projects/config_store/models/brz/multitenant_config.sql)
