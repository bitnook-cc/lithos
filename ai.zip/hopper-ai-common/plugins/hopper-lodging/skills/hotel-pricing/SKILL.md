---
name: hotel-pricing
description: Use when investigating hotel pricing issues, rate auction behavior, or price discrepancies. Covers required information, investigation approach, and common scenarios like "wrong price" or "price changed between search and booking".
---

# Hotel Pricing Investigation

## Overview

This skill provides guidance for investigating hotel pricing issues, including rate auction behavior, price discrepancies, and "wrong price" reports. Remember: users often frame "why did X happen?" as "X is broken."

## When to Use

- Reports of "wrong" pricing
- Price differences between search and booking
- Rate not updating as expected
- Partner rate not showing
- Rate auction behavior questions

## Required Information

### Mandatory (must have all)

| Field | Description | Example |
|-------|-------------|----------------------------------|
| **Tenant** | The app or platform where pricing was observed | `hopper-app`, `nubank` |
| **Lodging ID** | The hotel identifier (UUID) | `054520fd-d87c-4da0-b441-d955146887af` |
| **User ID** | Hopper user ID of the person who saw the price | `aa4940fe-be20-4f96-ab22-7707f5bd479e` |
| **Observation Date** | When the price was seen (date required, time optional) | `2026-02-10`, `2026-02-10 14:30 UTC` |

### Recommended (request if not provided)

| Field | Description | Example |
|-------|-------------|---------------------|
| **Rates Provider** | Source of the rates | `Ean`, `Budapest` |
| **Check-in Date** | Guest arrival date | `2026-03-15` |
| **Check-out Date** | Guest departure date | `2026-03-18` |
| **Rate Plan Code** | Specific rate plan identifier | `BAR`, `AAA`, `SENIOR` |
| **Room Type Code** | Room category code | `KNGN`, `DBLN`, `SUITE` |

## Investigation Approach

### Step 1: Verify the Context

Confirm you understand:
- What price they expected
- What price they saw
- Where they saw it (availability, shop, quote)
- When they saw it (critical for data lag)

### Step 2: Query Pricing Engine Traces

Use `h4r-common-lodging-bi-prd.lodging_pricing_engine__slv.fact_pricing_engine_traces` to understand:
- What rates competed in the auction
- Why a particular rate won
- What markups/discounts were applied
- Pricing decisions at each stage

Always filter by:
- `timestamp` (narrow window around observation)
- `lodging_id`
- `tenant`
- `user_id` (if available)
- `operation` (`availability`, `shop`, or `quote`)

### Step 3: Check Rate Auction Outcome

For "wrong price" investigations, the question is usually "why did this rate win the auction instead of the expected rate?"

Check:
- Which rates were eligible
- How rates were ranked
- What auction rules applied
- Whether the expected rate was even present

### Step 4: Investigate Common Causes

**Configuration issues**:
- Rate eligibility rules
- Tenant-specific pricing config
- Provider priority settings

**Rate availability**:
- Provider rate still available at quote time?
- Rate expired or sold out?
- Rate fencing applied?

**Auction re-run**:
- Time elapsed between search and booking
- Did rates refresh?
- Was auction re-run on booking attempt?

## Common Scenarios

### "The price is wrong"

**Translation**: "I expected a different price."

**Investigation focus**:
- What rates competed in the auction?
- Why did the displayed rate win?
- Was the expected rate present and eligible?

**Key tables**:
- `fact_pricing_engine_traces` — auction outcome
- `fact_lodging_rates_flat_traces` — rate availability

### "Price changed between search and booking"

**Investigation focus**:
- How much time elapsed?
- Did rates refresh between availability and quote?
- Was auction re-run on booking attempt?
- Did provider rates change?

**Key tables**:
- `fact_pricing_engine_traces` — pricing decisions at each stage
- `fact_lodging_rates_flat_traces` — rate changes over time

### "The rate didn't update"

**Investigation focus**:
- Caching behavior
- Rate refresh timing
- Provider update frequency

**Key tables**:
- `fact_lodging_rates_flat_traces` — when rates were last updated
- Provider-specific rate update logs

### "Partner rate not showing"

**Investigation focus**:
- Rate eligibility rules
- Tenant configuration
- Provider connectivity

**Key tables**:
- `provider_status_eval_observability` — provider enabled/disabled status
- `fact_lodging_rates_flat_traces` — rate availability
- Configuration database — eligibility rules

## Data Sources

| Table | Use For |
|-------|---------|
| `h4r-common-lodging-bi-prd.lodging_pricing_engine__slv.fact_pricing_engine_traces` | Rate auction decisions, pricing logic |
| `h4r-common-lodging-bi-prd.lodging_rates__slv.fact_lodging_rates_flat_traces` | Rate availability, rate changes |
| `gcp-hopper-etldata-production.hotels_foundation.paris-availability-processor-rate-changes` | Rate modifications at availability |
| `gcp-hopper-etldata-production.hotels_foundation.paris-shop-processor-rate-changes` | Rate modifications at shop |
| `gcp-hopper-app-production.lodging_configuration.provider_status_eval_observability` | Provider enabled/disabled status |

All queries should filter by `timestamp` to a narrow window (1-2 days). Data has up to 17 hours ingestion lag.

## Investigation Checklist

- [ ] Verified tenant, lodging ID, user ID, and observation date
- [ ] Understood expected vs actual price
- [ ] Identified pipeline stage (availability, shop, quote)
- [ ] Queried pricing engine traces (if issue > 17h old)
- [ ] Checked rate auction outcome
- [ ] Investigated root cause (config, availability, auction rules)
- [ ] Documented findings with SQL queries and results

## Tips

- **Framing matters**: "The price is wrong" usually means "why wasn't it the price I expected?" Focus on explaining auction behavior, not finding a bug.
- **Time matters**: Data lag is 17 hours. Recent issues can't be queried yet.
- **Context matters**: Availability pricing ≠ shop pricing ≠ quote pricing. The auction runs at each stage.
- **Correlation IDs matter**: Use `pricing_id` to trace a pricing decision across stages.
