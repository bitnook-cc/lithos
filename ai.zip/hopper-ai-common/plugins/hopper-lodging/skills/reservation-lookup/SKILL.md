---
name: reservation-lookup
description: Use when looking up a hotel reservation, PNR, booking, or confirmation number. Also use when investigating failed bookings, booking status, provider confirmations, rate plan details, local currency pricing, or booking XML/conversation logs.
---

# Reservation Lookup

## Overview

Look up lodging reservations across BigQuery tables using a tiered search strategy. Different tables hold different data — start broad, then enrich with provider-specific tables as needed.

Always bill queries to project `gcp-hopper-ds-research`.

## Booking Services

Paris is the orchestrator for hotel bookings. It delegates to one of two booking services — this matters when investigating failed bookings, as each has its own failed-bookings table.

- *`lodging-booking`* — the legacy booking service. Used by `hopper-app` on native mobile (iOS/Android). Shows as `booking_service = 'paris'` in BQ.
- *`lodging-shopping-cart`* — the newer unified booking service. Used by all B2B/partner tenants and Hopper web. Shows as `booking_service = 'shopping_cart'` in BQ.

## Lookup Strategy

```dot
digraph lookup {
  rankdir=TB;
  node [shape=box];

  start [label="User provides PNR / reservation ID" shape=doublecircle];
  step1 [label="1. Search lodging_bookings_with_revenue\nby reservation_id"];
  found1 [label="Found?" shape=diamond];
  step1b [label="1b. Search fact_lodging_booking_completed\n(fresher data, more fields)"];
  found1b [label="Found?" shape=diamond];
  step2 [label="2. Search lodging_reservations_no_pii\nacross ALL ID columns"];
  found2 [label="Found?" shape=diamond];
  step3 [label="3. Search failed bookings table\n(lodging-booking: fact_lodging_booking_failed\nshopping-cart: lodging_shopping_cart_failed_bookings)"];
  found3 [label="Found?" shape=diamond];
  step4 [label="4. Search budapest.bookings_unstructured\n(raw JSON — Budapest/direct bookings only)"];
  enrich [label="Enrich with provider tables\n(local currency, rate plan, conversation_id)"];
  notfound [label="Ask user to verify ID type,\ntenant, and platform"];

  start -> step1;
  step1 -> found1;
  found1 -> enrich [label="yes"];
  found1 -> step1b [label="no"];
  step1b -> found1b;
  found1b -> enrich [label="yes"];
  found1b -> step2 [label="no"];
  step2 -> found2;
  found2 -> enrich [label="yes"];
  found2 -> step3 [label="no"];
  step3 -> found3;
  found3 -> enrich [label="yes"];
  found3 -> step4 [label="no"];
  step4 -> enrich [label="found"];
  step4 -> notfound [label="not found"];
}
```

## Tables Reference

### Primary Booking Tables

| Table | Use For | Key Columns |
|-------|---------|-------------|
| `gcp-hopper-etldata-production.warehouse.lodging_bookings_with_revenue` | Confirmed bookings with revenue (golden path). Up to 17h ingestion lag. | `reservation_id`, `lodging_id`, `lodging_name`, `booking_dt`, `check_in_date`, `check_out_date`, `sell_price_excluding_taxes_and_fees`, `owed_now_taxes_and_fees`, `sell_gbv`, `reservation_status`, `platform`, `user_id`, `tenant_id`, `hotel_promotion_id`, `hotel_promotion_ids`, `booking_service` |
| `h4r-common-lodging-bi-prd.lodging_booking__slv.fact_lodging_booking_completed` | Completed bookings with pricing and conversation IDs. Fresher than warehouse. | `reservation_id`, `lodging_id`, `lodging_provider`, `booking_dt`, `check_in_date`, `check_out_date`, `sell_price_excluding_taxes_and_fees`, `owed_now_taxes_and_fees`, `sell_gbv`, `platform`, `booking_service`, `conversation_id`, `pricing_engine_pricing_id`, `provider_booking_id`, `commission_revenue`, `markup_revenue`, `refundable`, `pay_later` |
| `h4r-common-lodging-bi-prd.lodging_reservation_api__slv.lodging_reservations_no_pii` | Reservation API records (more ID fields for cross-referencing) | `hopper_reservation_id`, `customer_reservation_id`, `partner_reference_id`, `provider_booking_id`, `cart_order_id`, `conversation_id` |

### Failed Booking Tables

| Table | Booking Service | Key Columns |
|-------|----------------|-------------|
| `h4r-common-lodging-bi-prd.lodging_booking__slv.fact_lodging_booking_failed` | lodging-booking (`booking_service = 'paris'`) | `reservation_id`, `booking_session_id`, `conversation_id`, `lodging_id`, `lodging_provider`, `sell_gbv`, `hopper_revenue`, `error_codes`, `hotel_id`, `tenant` |
| `h4r-common-lodging-bi-prd.lodging_shopping_cart__slv.lodging_shopping_cart_failed_bookings` | lodging-shopping-cart (`booking_service = 'shopping_cart'`) | `customer_reservation_id`, `booking_service_session_id`, `is_book_success`, `metadata_not_found` |
| `h4r-common-lodging-bi-prd.lodging_shopping_cart__slv.fact_sc_bookings` | lodging-shopping-cart (incl. failures) | `reservation_id`, `hopper_reservation_id`, `provider_booking_id`, `shopping_cart_order_id`, `conversation_id` |

### Budapest Provider Tables (Direct Hotels)

| Table | Use For | Key Columns |
|-------|---------|-------------|
| `h4r-common-lodging-bi-prd.budapest__slv.fact_bookings` | Local currency pricing, conversation_id, daily rates, promotional discounts. Covers both successful and failed Budapest bookings. | `reservation_id`, `booking_date`, `check_in`, `check_out`, `hotel_id`, `local_currency`, `total_price_base`, `total_taxes`, `daily_rates`, `conversation_id`, `is_book_success`, `rate_plan_id`, `rate_plan_code`, `rate_plan_type`, `rate_plan_margin`, `promotional_discount`, `is_promotional` |
| `h4r-common-lodging-bi-prd.budapest__slv.dim_rate_plans` | Rate plan descriptions, derived rate plan parent info | `rate_plan_id`, `rate_plan_code`, `description`, `allowed_tenants`, `parent_rate_plan_id` |
| `h4r-common-lodging-bi-prd.budapest__slv.dim_hotels` | Hotel name, address, country, lodging_id | `hotel_id`, `lodging_id`, `hotel_city_code`, `hotel_google_place_id` |
| `gcp-hopper-etldata-production.budapest.bookings_unstructured` | Raw JSON Budapest bookings only (direct/ARI provider). Does NOT contain 3rd party provider bookings (EAN, Priceline, etc.). | JSON `value` column — extract with `STRING(value.reservationId)`, `STRING(value.hotelId)`, `BOOL(value.bookSuccess)`, etc. |

### Enrichment Tables

| Table | Use For |
|-------|---------|
| `h4r-common-lodging-bi-prd.wholeco__merchandising__gld.dim_promotions_scd` | Promotion name, discount %, audiences, date ranges |
| `gcp-hopper-etldata-production.ledger_source_data.ledger_hotels` | Financial verification (purchases, refunds, cancellations) |
| `gcp-hopper-etldata-production.forward_distribution_api.facts-fwd-book-observability` | Forward Distribution API booking records |

For pricing investigation (rate auctions, markups, discounts), see [hotel-pricing](hopper-lodging:hotel-pricing). Use `pricing_engine_pricing_id` from the booking record to correlate.

## Common Query Patterns

When the user provides a tenant, always include `tenant_id = '{TENANT}'` in the WHERE clause. When dates are provided, filter on `booking_dt`, `check_in_date`, or `check_out_date` as appropriate. This narrows scan size and avoids returning unrelated results.

### Basic reservation lookup

```sql
SELECT
  reservation_id, booking_dt, check_in_date, check_out_date,
  lodging_id, lodging_name, lodging_provider,
  sell_price_excluding_taxes_and_fees, owed_now_taxes_and_fees, sell_gbv,
  reservation_status, platform, refundable, pay_later,
  hotel_promotion_id, rate_type, booking_service, tenant_id
FROM `gcp-hopper-etldata-production.warehouse.lodging_bookings_with_revenue`
WHERE reservation_id = '{PNR}'
  -- AND tenant_id = '{TENANT}'  (add when tenant is known)
  -- AND booking_dt >= '{DATE}'  (add when date range is known)
```

### Reservation from completed bookings (fresher, more fields)

```sql
SELECT
  reservation_id, booking_dt, check_in_date, check_out_date,
  lodging_id, lodging_provider, booking_service, platform,
  sell_price_excluding_taxes_and_fees, owed_now_taxes_and_fees, sell_gbv,
  commission_revenue, markup_revenue, refundable, pay_later,
  provider_booking_id, conversation_id, pricing_engine_pricing_id,
  rate_type, provider_rate_category, booked_rooms, guests_adults, guests_children
FROM `h4r-common-lodging-bi-prd.lodging_booking__slv.fact_lodging_booking_completed`
WHERE reservation_id = '{PNR}'
```

### Reservation with local currency (JOIN Budapest)

```sql
SELECT
  bp.reservation_id, bp.booking_date, bp.check_in, bp.check_out,
  bk.lodging_name, bk.lodging_id,
  bp.rate_plan_code, bp.rate_plan_type, bp.rate_plan_margin,
  bp.local_currency,
  bp.total_price_base AS local_net_rate,
  bp.total_taxes AS local_taxes,
  bp.daily_rates AS local_daily_rates,
  bk.sell_price_excluding_taxes_and_fees AS sell_price_usd,
  bk.owed_now_taxes_and_fees AS taxes_fees_usd,
  bk.sell_gbv AS total_gbv_usd,
  bp.conversation_id
FROM `h4r-common-lodging-bi-prd.budapest__slv.fact_bookings` bp
INNER JOIN `gcp-hopper-etldata-production.warehouse.lodging_bookings_with_revenue` bk
  ON bp.reservation_id = bk.reservation_id
WHERE bp.reservation_id = '{PNR}'
```

### Search across all ID fields (when PNR not found in primary table)

```sql
SELECT *
FROM `h4r-common-lodging-bi-prd.lodging_reservation_api__slv.lodging_reservations_no_pii`
WHERE hopper_reservation_id = '{ID}'
   OR customer_reservation_id = '{ID}'
   OR partner_reference_id = '{ID}'
   OR provider_booking_id = '{ID}'
   OR cart_order_id = '{ID}'
```

### Find failed bookings (lodging-booking)

```sql
SELECT
  reservation_id, shop_date, tenant, booking_session_id,
  lodging_id, lodging_provider, check_in_date, check_out_date,
  sell_gbv, hopper_revenue, error_codes, conversation_id,
  hotel_id, provider_hotel_id, room_name
FROM `h4r-common-lodging-bi-prd.lodging_booking__slv.fact_lodging_booking_failed`
WHERE reservation_id = '{PNR}'
   OR booking_session_id = '{SESSION_ID}'
  -- AND tenant = '{TENANT}'
  -- AND shop_date >= '{DATE}'
```

### Find failed bookings (lodging-shopping-cart)

```sql
SELECT *
FROM `h4r-common-lodging-bi-prd.lodging_shopping_cart__slv.lodging_shopping_cart_failed_bookings`
WHERE customer_reservation_id = '{PNR}'
   OR booking_service_session_id = '{SESSION_ID}'
```

### Bookings by promotion

```sql
SELECT reservation_id, booking_dt, lodging_name, sell_gbv, hotel_promotion_id, tenant_id
FROM `gcp-hopper-etldata-production.warehouse.lodging_bookings_with_revenue`
WHERE (hotel_promotion_id = '{PROMOTION_ID}'
   OR '{PROMOTION_ID}' IN UNNEST(hotel_promotion_ids))
  -- AND tenant_id = '{TENANT}'
  -- AND booking_dt >= '{DATE}'
```

### Budapest raw JSON bookings (fallback — Budapest/direct provider only)

NOTE: This table only contains Budapest (direct/ARI) bookings. It will NOT have bookings from 3rd party providers like EAN, Priceline, BookingDotCom, etc.

```sql
SELECT
  STRING(value.reservationId)     AS reservation_id,
  STRING(value.hotelId)           AS hotel_id,
  STRING(value.bookingDate)       AS booking_date,
  STRING(value.checkIn)           AS check_in,
  STRING(value.checkOut)          AS check_out,
  BOOL(value.bookSuccess)         AS book_success,
  STRING(value.activeProvider)    AS active_provider,
  STRING(value.providerBookingId) AS provider_booking_id,
  STRING(value.conversationId)    AS conversation_id
FROM `gcp-hopper-etldata-production.budapest.bookings_unstructured`
WHERE STRING(value.reservationId) = '{PNR}'
   OR STRING(value.hotelId) = '{HOTEL_ID}'
  -- AND STRING(value.bookingDate) >= '{DATE}'
```

## Common Mistakes

| Mistake | Correct |
|---------|---------|
| Using `booking_status` column | Use `reservation_status` (values: `completed`, `active`, `cancelled`, `arrived`) |
| Using `property_id` / `property_name` | Use `lodging_id` / `lodging_name` |
| Using `tenant` column in warehouse table | Use `tenant_id` |
| Treating `total_price_base` as sell price | It's the NET rate (what Hopper pays the hotel). Sell price is `sell_price_excluding_taxes_and_fees` |
| Treating `rate_plan_margin` as promotion discount | It's Hopper's contracted margin %. Promotion discount is in `promotional_discount` column |
| Looking for local currency in `lodging_bookings_with_revenue` | Local currency is only in `budapest__slv.fact_bookings`. JOIN on `reservation_id` |
| Using `dashboard-production.portal.hopper.com` for secure logs | Use `dashboard-nopii.portal.hopper.com` |
| Searching only `reservation_id` when PNR not found | Search across ALL ID columns: `customer_reservation_id`, `partner_reference_id`, `provider_booking_id`, `cart_order_id` |
| Assuming a PNR not in bookings table doesn't exist | Check failed bookings tables — it may be a booking that never confirmed |
| Checking only one failed bookings table | lodging-booking failures are in `fact_lodging_booking_failed`; lodging-shopping-cart failures are in `lodging_shopping_cart_failed_bookings` |
| Not filtering by tenant or dates | Always add `tenant_id` and date filters when provided — reduces scan size and avoids wrong results |

## Calculating Promotion Discount Percentage

The `promotional_discount` column in `fact_bookings` is an absolute amount, not a percentage. Calculate:

```sql
ROUND(SAFE_DIVIDE(bp.promotional_discount,
  bp.total_price_base + bp.promotional_discount) * 100, 2
) AS promotion_discount_pct
```

## Getting Conversation Logs / XML

1. Get `conversation_id` from `budapest__slv.fact_bookings` or `fact_lodging_booking_completed`
2. Share secure-logs dashboard link: `https://dashboard-nopii.portal.hopper.com/#/securelog/{conversation_id}`

## Access Limitations

These datasets are restricted and cannot be queried directly:
- `secure_logs_private` — use the dashboard-nopii link instead
- `orange_lodging_booking_lodging_booking_private` — use `budapest__slv.fact_bookings` for conversation_id
- Spanner direct queries — use BQ tables instead

## Output Format

When returning reservation details in Slack (and no specific field was requested), use this format:

```
:hotel: *{Hotel Name}* — {Market}
`{PNR}` · :white_check_mark: {Status} · {Refundable/Non-refundable}

:calendar: *Stay*
{Check-in} – {Check-out} ({N} nights) · {Adults} adults · {Rooms} room(s)

:dollar: *Pricing ({Currency})*
Customer pays: ${sell_price} + ${taxes} tax = *${total}*
Net to hotel: ${net} (commission: ${commission} · markup: ${markup})
Promotion: {name + discount % or "none"}

:iphone: *Booking*
{Platform} · `{tenant_id}` · {booking_service}
Provider: {provider} ({rate_type}) · {Pay now/Pay later} · {Breakfast Y/N}

:link: *IDs*
Lodging: `{lodging_id}`
Provider booking: `{provider_booking_id}`
Session: `{booking_session_id}`
Conversation: `{conversation_id}`
```

Conditional additions:
- Add local currency line under Pricing when Budapest booking (from `fact_bookings`)
- Add CFAR/insurance line under Pricing when attached
- For cancelled bookings, add cancellation status and refund amount (from ledger)
- For failed bookings, replace status with `:x: Failed` and add `Error: {error_codes}`
