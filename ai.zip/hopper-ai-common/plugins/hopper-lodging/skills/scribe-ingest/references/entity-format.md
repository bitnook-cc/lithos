# Entity File Format Reference

## Frontmatter + Markdown Structure

```markdown
---
name: Entity Name
tags: [domain-tag, topic-tag]
sources:
  - type: github
    repo: owner/repo            # optional
    ref: {commit-sha}           # optional
    url: https://...            # optional
    table: project.dataset.tbl  # optional
    discovery_note: .discovery/{source-key}.md  # optional
# type-specific fields from .dev/types/{type}.yaml
---

Short one-sentence description of the entity.

Body content with [[wikilinks]] to related entities.

## Sections as appropriate for the entity type
```

**Important:** The first line of the markdown body must be a short one-sentence
description. This sentence is extracted by the sync pipeline for the `description`
column in Spanner (used by vector search) and by `INDEX.md` generation for the
entity summary line.

## File Organization

- Entity type = top-level directory: `service/`, `component/`, `issue/`, etc.
- Subdirectories are optional for organization: `issue/lodging/`, `table/localization/`
- Entity ID = filename without `.md`
- Type and ID are NOT in frontmatter (derived from path)

## Wikilink Syntax

- `[[entity-id]]` for unique IDs (most cases)
- `[[type/entity-id]]` when ID exists under multiple types
- `[[type/sub/entity-id]]` for deeply nested entities

## Type-Specific Fields

Check `.dev/types/{type}.yaml` for the JSON Schema defining required and optional
fields for each entity type. Common types: issue, action, service, component,
concept, table, dataset, tool.

## Changelog Format

Per-entity changelog at `{id}.changelog.md`:

```
## {ISO-timestamp}Z | {source-type}
{Summary of what changed}
Source: {source URL}
Agent: {agent identity}
```

Global log at `log.md`:

```
## {ISO-timestamp}Z | {ingest|discovery} | {source description}
{N} entities created, {N} updated.
Source: {repo} (at `{short-sha}`) - {path or description}
Agent: {agent identity}
```
