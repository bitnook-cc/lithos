---
name: scribe-ingest
description: >
  This skill should be used when ingesting knowledge into Hopper Scribe. Triggers include
  being pointed at a GitHub repo to discover services and components, receiving content
  (articles, investigation results, pasted text) to add, or being asked to "update Scribe",
  "add to knowledge base", "discover entities", "ingest into Scribe", or
  "update lodging-ops-ai knowledge".
---

# scribe-ingest

Ingest knowledge into Hopper Scribe via targeted updates or bulk discovery,
following a proposal-approval workflow.

## When to use

- Pointed at a GitHub repo to discover services, components, issues
- Given content (article, investigation result, pasted text) to add
- Asked to "update Scribe", "add to knowledge base", or "discover entities"
- Asked to "update lodging-ops-ai knowledge"

## Workflow

### 1. Source Block

Identify the source:
- **Source type:** github | content | article
- **Source locator:** repo URL, or "inline content"
- **Ingestion mode:** `targeted-update` or `discovery`

### 2. Lookup Block

Search existing knowledge in this order:
1. `explore_knowledge` MCP tool (if available)
2. Read `INDEX.md` at the Scribe repo root
3. Search entity files directly (glob + read)

List candidate entities that might be related or need updating.

### 3. Proposal Block

For each entity to create or update, present:
- File path (e.g. `component/budapest.md`)
- Action: CREATE or UPDATE
- Concise reason
- Wikilinks to add

Show the proposal as a diff/summary and wait for approval before proceeding.

### 4. Safety Block

Before writing, confirm:
- [ ] No secrets, tokens, or credentials in entity content
- [ ] Sensitive data summarized, not copied verbatim
- [ ] PII excluded

### 5. Write Block (post-approval only)

For each approved entity:

1. Write entity file (markdown + frontmatter) -- the first line of the markdown body must be a short one-sentence description of the entity (used by INDEX.md and vector search). See `references/entity-format.md` for the full format specification.
2. Append to per-entity changelog (`{id}.changelog.md`)
3. Append a single entry to global `log.md` (see below)

#### Global log.md

Append exactly one entry at the top of `log.md` per ingest run. Keep entries concise -- summarize what changed with entity counts, not descriptions of entity content.

Format:

```
## {ISO-timestamp}Z | {ingest|discovery} | {source description}
{N} entities created, {N} updated.
Source: {repo} (at `{short-sha}`) - {path or description}
Agent: {agent identity}
```

Do not include branch names, PR numbers, or other workflow metadata in log entries.

### 6. Output Block

- List of created/updated entities with file paths
- PR link or commit SHA

## GitHub Discovery Mode

When pointed at a GitHub repo:

1. Read `.discovery/{source-key}.md` if it exists (agent memory from prior runs)
2. Clone or browse the repo
3. Identify:
   - Services (from deployment config, README)
   - Components (from code structure, modules)
   - Issues (from known problem patterns, error handling)
   - Concepts (from domain logic, algorithms)
   - Endpoints (from route definitions, proto files)
4. Write discovery notes to `.discovery/{source-key}.md`
5. Follow the standard proposal -> approval -> write flow
