---
name: hotels-escalation-platform
description: Use when a hotels production incident requires help from Platform teams (platform-core, platform-infra, or platform-data). Covers how to page them via PagerDuty and post the alert link in the incident Slack channel.
---

# Hotels Platform Escalation

## Overview

Escalate production incidents to Platform teams via PagerDuty when the hotels team cannot resolve the issue alone.

## Hard Gate

An incident Slack channel MUST be available (from the user or conversation context) before proceeding. If not, ask the user for the incident channel link.

## Pre-Checks

Before escalating:
1. Confirm your team cannot handle the issue
2. Check `#dev-broadcast` and `#incidents` for known issues

## Which Team to Contact

Fetch the latest team routing from the [Getting Help From Platform](https://hopper-jira.atlassian.net/wiki/spaces/ENG/pages/5382472096/Getting+Help+From+Platform) Confluence page (page ID `5382472096`) using the Atlassian MCP `getConfluencePage` tool. The "Which team do I have to contact" section has the full list of topics, Slack channels, and PagerDuty services.

Summary for quick reference:

| Team | Scope | Slack | PagerDuty Service |
|------|-------|-------|-------------------|
| **Platform-Core** | Harness pipelines, Helm chart, common repos (Bifrost, Helpers, FortKnox, Karnak, etc.), dependency vulnerability automation | `#dev-platform-core` | Datadog Platform |
| **Platform-Infra** | GCP, Olympus/Terraform, terraform-modules, github-config, GitHub Actions, Arecibo/Datadog, K8s, networking, DNS, TLS, IP whitelisting | `#dev-platform-infra` | Datadog Platform |
| **Platform-Data** | BigQuery, Rotterdam, Mumbai, Experiments, LaunchDarkly, Amplitude, ETL | `#dev-platform-data` | Datadog DataPlatform |

## Escalation via PagerDuty MCP (Production)

Use the `create_incident` tool with:

| Field | Value |
|-------|-------|
| `service.id` | `PNY4MS3` (platform-core/infra — "Datadog Platform") or `PVC5LYJ` (platform-data — "Datadog DataPlatform") |
| `urgency` | `high` |
| `title` | Organizational impact (e.g., "hotel bookings failing for all tenants") |
| `body.details` | Include the incident Slack channel link |

After creating the PagerDuty incident, post the PagerDuty incident link to the incident Slack channel. Include a link to the [Getting Help From Platform](https://hopper-jira.atlassian.net/wiki/spaces/ENG/pages/5382472096/Getting+Help+From+Platform) Confluence page so engineers can follow the manual steps if needed.

**Never fill "Assign To"** when using the PagerDuty web UI — it overrides the oncall schedule.

## Non-Production Issues

For non-production issues, message the appropriate Slack channel during attended hours (08:00–22:00 UTC):

| Team | Channel |
|------|---------|
| Platform-Core | `#dev-platform-core` |
| Platform-Infra | `#dev-platform-infra` |
| Platform-Data | `#dev-platform-data` |
