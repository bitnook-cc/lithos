---
name: hotel-availability
description: >-
  Use when debugging why a hotel, rate, or provider is missing from search results.
  Covers missing hotels, missing provider rates, rate plan gaps, and inventory issues.
  Provides investigation methodology and scope boundaries (Distribution vs Supply).
---

# Hotel Availability Debugging

## Overview

Use this skill when investigating why a hotel, rate, or provider is not appearing in search results. This guide covers the investigation methodology, key data sources, and scope boundaries between Distribution and Supply teams.

## When to Use

- Hotel not showing in search results
- A provider's rates missing for a hotel (other providers work fine)
- A specific rate plan or room type not appearing
- A class of hotels (chain, brand) missing availability
- Rates missing for a specific tenant or channel

## Required Information

| Field | Required | Notes |
|-------|----------|-------|
| Tenant | Yes | e.g., `capone`, `hopper-app` |
| Lodging ID | Yes | The hotel not showing (UUID format) |
| Provider | Yes | Which provider's rates are missing (CamelCase) |
| Channel | Yes | Web, Mobile, MobileWeb |
| Check-in / Check-out | Yes | The dates searched |
| When observed | Yes | Needed to determine if rate traces are available |

## Investigation Methodology

### Step 1: Configuration Check

Check provider configuration for the affected tenant, hotel, and channel using the **Lodging Configuration Retool** tool or by querying the configuration database.

If the provider is disabled in configuration, the issue is a configuration rule — no further data investigation needed.

### Step 2: Rate Trace Analysis

**Only applicable if the issue was observed more than 17 hours ago** (data ingestion lag).

Query `h4r-common-lodging-bi-prd.lodging_rates__slv.fact_lodging_rates_flat_traces` to confirm whether rates were received from Hamburg API and whether they were dropped in post-processing.

#### Query Guidelines

- **Always filter by `timestamp`** to a narrow range (1-2 days around the observed issue). Queries without a tight timestamp filter will fail due to data volume.
- **Always include `lodging_id`** when available. Broad queries are expensive and will time out.
- **Always share the raw SQL queries you ran** in your analysis.
- If a query fails or returns no results, report that explicitly.

#### Check for Deleted Rates

```sql
SELECT changes
FROM `h4r-common-lodging-bi-prd.lodging_rates__slv.fact_lodging_rates_flat_traces`
WHERE timestamp >= TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 2 DAY)
  AND lodging_id = '{lodging_id}'
  AND tenant = '{tenant}'
  AND provider = '{provider}'
  AND operation = 'availability'
  AND EXISTS (SELECT 1 FROM UNNEST(changes) c WHERE c.kind = 'Delete')
LIMIT 10
```

Available filter columns (always include `timestamp`):

| Column | Notes |
|--------|-------|
| `timestamp` | **Required**. Always filter to a reasonable time range |
| `lodging_id` | The hotel being investigated |
| `tenant` | Tenant name |
| `provider` | Provider name |
| `operation` | Pipeline stage: `availability`, `shop`, or `quote` |
| `check_in` | Check-in date |
| `check_out` | Check-out date |

#### Interpreting Results

- **Rows with `kind = 'Delete'` in changes**: Rates were received but dropped in post-processing. Extract basic details from the `changes` array (what was deleted, any reason or processor info).
- **Rows exist but no deletes**: Rates were received and passed through lodging-rates successfully. The issue is downstream in Paris.
- **No rows at all**: Rates were never received from Hamburg API for this lodging/provider/date combination.

### Step 3: Rate Fencing Check

The most common cause of rates being deleted in post-processing is **rate fencing**. Fencing rules are documented in the Roadie techdocs for the `lodging-rate-fencing` component. Use the Roadie tool to look up fencing rules if rates are being deleted.

## Scope Boundary: Distribution vs Supply

Where the rate was lost determines which team owns the issue.

### Rates Deleted in lodging-rates (Fencing or Post-Processing)

**Out of scope for Distribution.** This is a Supply team issue.

- **Team**: Travel Tech Lodgings & Cars Supply
- **Slack**: [#lodging-cars-supply](https://hopchat.slack.com/archives/C0A0WMN6J48)

### Rates Confirmed Received by lodging-rates (Not Deleted)

**In scope for Distribution.** The rate passed through lodging-rates but is missing from search results, which means it was likely dropped in the Paris pipeline.

**Next step**: Check Paris observability tables:
- `gcp-hopper-etldata-production.hotels_foundation.paris-availability-processor-rate-changes`
- `gcp-hopper-etldata-production.hotels_foundation.paris-shop-processor-rate-changes`

These tables show which Paris processor dropped the rate and why.

### Rates Never Received from Hamburg

**Out of scope for Distribution.** This is a provider connectivity or upstream issue owned by Supply.

- **Team**: Travel Tech Lodgings & Cars Supply
- **Slack**: [#lodging-cars-supply](https://hopchat.slack.com/archives/C0A0WMN6J48)

### Issue Too Recent to Query (< 17 Hours)

Rate traces are not yet available. Continue investigation with configuration checks and Paris processor logs if available. Schedule a follow-up query once the 17-hour ingestion window has passed.

## Common Scenarios

### Hotel Completely Missing from Search Results

Usually means the provider is disabled for that tenant/channel or rates were never received. Check configuration first, then rate traces.

### One Provider Missing, Others Work Fine

Usually a provider-specific configuration rule or rate fencing. Check "Enabled Providers" config for rules targeting that provider. If enabled, check rate traces for deletions.

### Specific Rate Plan Not Showing

May be rate fencing targeting that rate plan. If the issue is recent (< 17h), gather all context for follow-up. If older, check rate traces filtered by the relevant dates.

### Rates Missing for an Entire Chain or Brand

Likely a configuration rule scoped to a chain or brand. Check the Lodging Configuration tool — rules can target chains and brands with wildcard matching.

## Investigation Checklist

- [ ] Verified tenant, lodging ID, provider, channel, and dates
- [ ] Checked provider configuration for the tenant/channel
- [ ] Queried rate traces (if issue > 17h old)
- [ ] Identified scope boundary (Distribution vs Supply)
- [ ] Documented findings with SQL queries and results
