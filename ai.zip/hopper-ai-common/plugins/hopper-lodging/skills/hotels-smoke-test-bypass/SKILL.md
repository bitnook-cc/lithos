---
name: hotels-smoke-test-bypass
description: Use when an oncall needs to skip or speed up the smoke test wait time in a hotels service deployment pipeline, whether to unblock a failing smoke test or to accelerate a deployment during an incident.
---

# Hotels Smoke Test Bypass

## Overview

The smoke test is a Kubernetes job (`dd-monitor-smoke-test`) that polls specified Datadog monitors for up to 5 minutes after staging deployment. If the monitors are muted, it exits immediately with success, skipping the wait.

## When to Use

- Deployment blocked on a failing smoke test during an incident
- Need to accelerate a hotfix deployment through the pipeline
- Smoke test timing out on a known-flaky monitor

## Bypass Procedure

### 1. Find the monitor ID

Look in the service repo's `deployment/workloads/smoke_test/BUILD` file. Find the `--monitor-ids` argument in the container args.

Example: `https://github.com/hopper-org/lodging-context-store/blob/master/deployment/workloads/smoke_test/BUILD`

### 2. Mute the monitor

Create a Datadog downtime/mute for that monitor. Monitor URL pattern: `https://us5.datadoghq.com/monitors/{monitor_id}`

### 3. Wait for smoke test to pass

The smoke test polls every 30 seconds (configurable via `--poll-interval`). It will detect the mute on next poll and exit immediately with success.

## Post-Incident

**Unmute the monitor** after the incident to restore the deployment safety gate. Forgetting this leaves the pipeline unprotected.

## Reference

- `dd-monitor-smoke-test` repo: `https://github.com/hopper-org/dd-monitor-smoke-test`
