---
name: hotels-escalation-rrt
description: Use when needing to cancel or modify hotel reservations in production, or when a hotels incident requires actioning affected bookings. Covers contacting Customer Support's Rapid Response Team (RRT).
---

# Hotels RRT Escalation

## Overview

Engage the Customer Support Rapid Response Team (RRT) when you need to cancel or modify hotel reservations in production, or when an incident requires actioning affected bookings.

## When to Use

- Canceling or modifying hotel reservations in production
- Actioning affected bookings during an incident
- Reaching out to affected users

## When NOT to Use

- **1-2 bookings**: Use the [Google Form](https://docs.google.com/forms/d/e/1FAIpQLSc85qQAV-l8KYcsV3lpwBOwUYBI00kAImIitopWPRYnwHSSjQ/viewform) instead
- **Capital One PNRs**: RRT does NOT handle these — escalate to the Cap One CS team

## Contact

Tag `@cs-rapid-response` in `#cs-airsupply` via the Slack MCP `slack_send_message` tool.

## Required Information

Provide all of the following when engaging RRT:

1. **Requested By** — main contact person for the project
2. **Type of bookings** — Air / Hotel / Car
3. **Google Sheet** with affected bookings containing:
   - User ID, Session ID (for bookings with no PNR), PNR, Departure Date, Booking Amount, Email Address
4. **Incident overview** — TLDR + incident number
5. **Urgency level:**

| Level | Meaning |
|-------|---------|
| **Low** | No user outreach, no cancellations |
| **Medium** | Cancellations per policy, no user outreach |
| **High** | Cancellations + timely user outreach needed |

6. **Specific action scenarios** — e.g., "if X do Y, if Z do W"

## What to Expect

RRT SM/TL acknowledges in thread, finalizes questions with POC, and tags POC when the project is complete.
