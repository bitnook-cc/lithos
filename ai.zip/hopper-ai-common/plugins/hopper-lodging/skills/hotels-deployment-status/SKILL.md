---
name: hotels-deployment-status
description: Use when checking what hotels services have been recently deployed, what's currently deploying, or whether a specific service version is in production. Covers reading the #hotels-deployments and #devops Slack channels.
---

# Hotels Deployment Status

## Overview

Check deployment status for hotels services by reading the `#hotels-deployments` and `#devops` Slack channels. This is the fastest way to determine what's deployed, what's in progress, and what failed.

## When to Use

- "What version of X is in production?"
- "Is anything currently deploying?"
- "Did the last deploy succeed?"
- "When was X last deployed?"
- "Who deployed X?"

## Channels

| Channel | Channel ID | Contents |
|---------|-----------|----------|
| `#hotels-deployments` | `C05JP52Q04F` | Hotels-specific deployments only |
| `#devops` | `C13E5T5AB` | All Hopper service deployments (including hotels) |

Start with `#hotels-deployments` for hotels-specific queries. Use `#devops` when you need to check non-hotels services or cross-reference broader deployment activity.

Each deployment message contains:
- Service name in backticks (e.g., `lodging_rates`)
- Version tag (e.g., `v2.21.0_v0.40.0-rendered`)
- Commit diff link
- Who merged the code

## Reading Deployment Threads

Use `slack_read_thread` on the parent message to see stage progression:

1. **development** — "Deployment started" → "Deployment complete" (with Datadog log link)
2. **staging** — "Deployment started" → "Deployment complete" (with Datadog log link)
3. **Approval gate** — "Pending approval" → "approved by {person}"
4. **production** — "Deployment started" → "Deployment complete" (with Datadog log link)
5. **Final message** — celebration emoji with pipeline link and rollback link

## Interpreting Status

| Signal | Meaning |
|--------|---------|
| :white_check_mark: reaction | Fully successful deployment |
| :x: reaction | Failed deployment |
| Thread without final celebration message | Deployment still in progress |
| "smoke_test failed" in thread | Blocked on smoke test — see `hopper-lodging:hotels-smoke-test-bypass` |
