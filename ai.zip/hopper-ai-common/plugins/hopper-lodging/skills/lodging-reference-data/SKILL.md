---
name: lodging-reference-data
description: Use when you need to look up tenant IDs, provider names, ID format validation, or domain taxonomy for hotels, homes, and cars. Contains canonical tenant/provider lists and aliases.
---

# Lodging Reference Data

## Overview

This skill provides reference data for working with lodging (hotels and homes) and car rental systems at Hopper. Use this when you need to normalize tenant names, validate IDs, or look up provider names.

## Tenant Reference

Tenant IDs are **always lowercase**. This is critical when constructing SQL queries — an uppercase tenant name will return zero results.

### Common Aliases

Normalize these before use in queries or configuration:

| User says | Canonical tenant ID |
|----------------------------------|---------------------|
| "Capital One" / "CapOne" / "C1" | `capone` |
| "Hopper" / "the app" | `hopper-app` |
| "Kayak" | `kayak` |
| "Uber" | `uber` |
| "Walmart" | `walmart` |
| "JetBlue" | `jetblue-site` |
| "Capital One Corporate" | `capone-corporate` |

### Known Tenants by Category

- **Core**: `hopper-app` (Hopper App), `capone` (Capital One), `kayak` (Kayak), `uber` (Uber), `walmart` (Walmart), `tripadvisor` (Tripadvisor), `yahoo` (Yahoo)
- **Banking/Financial**: `rbc` (RBC), `nubank` (Nubank), `banorte` (Banorte), `smcc` (Sumitomo Mitsui), `lotte` (Lotte Card), `commbank-au` (Commonwealth Bank AU), `hsbc-sg`, `hsbc-in`, `hsbc-uae`, `hsbc-qa` (HSBC regional), `lbg-lloyds`, `lbg-halifax`, `lbg-bos`, `lbg-mbna` (LBG brands)
- **Airlines/Travel**: `jetblue-site` (JetBlue), `volaris` (Volaris), `flair` (Flair), `virgin-au` (Virgin Australia)
- **B2B/Other**: `nequi` (Nequi), `perkspot` (Perkspot), `velocity-black` (Velocity Black), `hopper-for-biz` (Hopper For Business), `capone-corporate` (Capital One Corporate), `athotel` (athotel.com)
- **Vacation Clubs**: `hyatt-vc` (Hyatt), `marriott-vc` (Marriott)
- **Car Rentals**: `dollar` (Dollar), `fox` (Fox)
- **Forward Distribution**: tenants ending in `-01` (e.g., `nuitee-01`, `hotelbeds-01`, `capone-01`) — these are FD partner tenants
- **Test/Demo**: `b2b-sandbox`, `bootstrap`, `rate-shop-test`

### Canonical Source

The complete list is in GitHub: [`Tenant` object in Helpers/helpers-model](https://github.com/hopper-org/Helpers/blob/master/helpers-model/src/main/scala/com/hopper/common/model/Tenant.scala)

## Hotel Provider Reference

Hotel provider names are **always CamelCase**. Use the exact canonical name in queries and configuration.

### Common Aliases

Normalize these before use:

| User says | Canonical provider name |
|-----------|----------------------|
| "Expedia" / "EAN" | `Ean` |
| "Booking.com" / "Booking" | `BookingDotCom` |
| "Trip.com" | `Ctrip` |
| "Priceline" | `Priceline` |
| "Agoda" | `Agoda` |
| "VRBO" | `Vrbo` |

### Known Providers by Type

- **Retail**: `Ean` (Expedia), `BookingDotCom` (Booking.com), `Priceline`, `Agoda`
- **Direct**: `Budapest`, `Dhisco`, `FirstParty`, `Katanox`, `WyndhamKatanox`, `MgmDSG`
- **Wholesale**: `Hotelbeds`, `Getaroom`, `WebBeds`, `Nuitee`, `Dida`, `W2m`, `Bonotel`, `Hoteldo`, `HoteldoDC`, `Roibos`, `Pricetravel`, `Rtx`, `RtxJapan`, `EaseMyTrip`, `MakeMyTrip`, `Meituan`, `MgBedbank`, `Tiket`, `Yanojia`, `Traveloka`, `Xiwan`, `ChannelsPlus`, `HTS`
- **Scraping**: `Scrape`, `ScrapeV2`
- **GDS**: `Amadeus`, `AmadeusGDS`
- **TGX providers** (Travelgate aggregator): names ending in `TGX` (e.g., `OmnibeesTGX`, `RestelTGX`, `RateHawkTGX`, `TBOTGX`, `JalanTGX`). Multiple TGX providers exist — if you encounter a Travelgate partner, look for the matching `*TGX` name.
- **DSG providers** (Direct Supply Gateway): names ending in `DSG` (e.g., `IolDSG`, `PropertyConnectorDSG`, `JtbDSG`, `MarriottVCDSG`).

### Canonical Source

The complete list is in GitHub: [`Lodging.Provider` object in Helpers/helpers-model](https://github.com/hopper-org/Helpers/blob/master/helpers-model/src/main/scala/com/hopper/common/model/api/lodging/Lodging.scala)

## ID Format Validation

When validating Hopper-specific identifiers:

| ID Type | Format | Example |
|----------------|------------|----------------------------------------|
| **Lodging ID** | UUID v4 | `054520fd-d87c-4da0-b441-d955146887af` |
| **User ID** | UUID v4 | `aa4940fe-be20-4f96-ab22-7707f5bd479e` |
| **Tenant** | kebab-case | `hopper-app` |
| **Provider** | CamelCase | `BookingDotCom` |

If a provided ID does not match the expected format, it may be a provider-specific ID, a confirmation code, or another identifier type.

## Functional Domain Taxonomy

When categorizing issues or investigations:

| Domain | Keywords / Signals |
|------------------------|-------------------------------------------------------------------|
| **Pricing/Auctions** | rate, price, auction, bid, ranking, price sort, winner, margin |
| **Availability** | availability, inventory, sold out, open, closed, allotment |
| **Booking** | reservation, booking, confirmation, cancellation, modification |
| **Content** | property, hotel, room type, amenities, photos, descriptions |
| **Provider/Supplier** | API, integration, supplier, provider, connectivity, sync, mapping |
| **Data Pipeline** | ETL, BigQuery, pipeline, missing data, data sync, warehouse |

## Funnel Stages

When filtering by pipeline stage (e.g., in BigQuery `stage_name` or `stage_id` columns):

| Stage | System Name | User Language |
|-------------------|-----------------|-----------------------------------------------------------|
| **Availability** | `availability` | "hotel search", "hotel list", "search results" |
| **Shop** | `shop` | "room selection", "room browser", "room list" |
| **Quote** | `quote` | "final price", "checkout", "before booking confirmation" |

## Product Axis

When identifying which product line is involved:

| Product | Keywords / Signals | Notes |
|-------------|--------------------------------------------------------------|------------------------------|
| **Hotels** | hotel, property, room, lodging (often), HSP | Traditional hotel inventory |
| **Homes** | home, vacation rental, VR, VRBO, HomeAway, Expedia Group Homes | Vacation rental inventory |
| **Cars** | car, vehicle, rental car, CarRS | Car rental inventory |

**Note**: "Lodging" technically covers both Hotels and Homes, but is often used as a synonym for just Hotels. When in doubt, check context for home/VR-specific terms.
