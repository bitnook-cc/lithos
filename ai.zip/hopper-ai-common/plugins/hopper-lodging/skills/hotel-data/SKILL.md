---
name: hotel-data
description: Use when you need to identify which BigQuery tables contain hotel booking pipeline data — provides a reference of data sources across Availability, Shop, and Quote/Book stages
---

# Hotel Data Sources Reference

## Overview

This skill provides a quick reference to BigQuery tables across the hotel booking pipeline. Use this when investigating availability, pricing, or booking issues to identify which tables contain relevant data.

## Data Sources by Pipeline Stage

| Stage | Data Source | Table | Contains |
|-------|-------------|-------|----------|
| **Availability** | Searched Lodging IDs | `gcp-hopper-etldata-production.hotels_foundation.paris_requested_lodging_ids` | All lodging IDs searched in availability request |
| **Availability** | Pricing Engine Traces | `h4r-common-lodging-bi-prd.lodging_pricing_engine__slv.fact_pricing_engine_traces` | Rate selection, markups, discounts, pricing decisions |
| **Availability** | lodging-rates Trace | `h4r-common-lodging-bi-prd.lodging_rates__slv.fact_lodging_rates_flat_traces` | Rates from Hamburg API + post-processing changes |
| **Availability** | Rate Processor Changes | `gcp-hopper-etldata-production.hotels_foundation.paris-availability-processor-rate-changes` | How each processor modified rates at availability |
| **Availability** | Provider Status Evaluation | `gcp-hopper-app-production.lodging_configuration.provider_status_eval_observability` | Which rate providers were enabled/disabled |
| **Shop** | Shop Rate Dimensions | `h4r-common-lodging-bi-prd.paris__slv.dim_room_rate_dimensions` | Rate grouping dimensions (pay later, refundable, meal plan, etc.) |
| **Quote/Book** | Bookings with Revenue | `gcp-hopper-etldata-production.warehouse.lodging_bookings_with_revenue` | Final booking records with revenue breakdown |
| **Quote/Book** | Budapest Bookings | `h4r-common-lodging-bi-prd.budapest__slv.fact_bookings` | Direct provider bookings via Budapest (push model) |
| **Cross-Pipeline** | Forward Distribution API | `gcp-hopper-etldata-production.forward_distribution_api.facts-fwd-{book,cancel,failure}-observability` | Book/Cancel API requests/responses, failure tracking |
| **Cross-Pipeline** | Hotels Ledger | `gcp-hopper-etldata-production.ledger_source_data.ledger_hotels` | Financial accounting view (commissions, markups, discounts, tips, refunds) |

## Key Correlation IDs

Different tables use different IDs to trace data through the pipeline:

- **`hotel_funnel_session_id`** / **`avro_session_identifier`** — The booking session ID, used across most tables
- **`pricing_id`** — Thread ID for a pricing decision, links pricing engine traces through availability → shop → book
- **`conversation_id`** — Hamburg API conversation ID, links API calls and rate data
- **`availability_id`** — Unique ID for an availability request
- **`rate_id`** — Unique identifier for a rate at Hamburg level
- **`reservation_id`** — Final booking confirmation ID

## Data Freshness

Most tables have **up to 17 hours of ingestion lag**. Always filter by the table's timestamp column (`ts`, `timestamp`, `booking_dt`, `action_timestamp`, or `transaction_dt` depending on table) and use a tight date range.

## Querying Tips

- Always include a timestamp filter to narrow the query window
- Use correlation IDs to join across tables
- Start with `fact_lodging_rates_flat_traces` or `fact_pricing_engine_traces` for rate-level investigations
- Use `paris-availability-processor-rate-changes` or `paris-shop-processor-rate-changes` to identify where rates were dropped in Paris processing
