---
name: lodging-pricing-strategy-doc
description: >-
  Use when asked to explain, describe, or summarize the lodging pricing strategy
  or markup logic for a tenant. Triggers: "pricing strategy for X", "how do we
  price for X", "markup logic for X", "explain pricing for X", "what markups
  does X use".
---

# Lodging Pricing Strategy Explanation

## Overview

Produce a clear, concise, plain-English explanation of the lodging pricing strategy for a given tenant by reading the pricing engine source code.

## Glossary — Mandatory Terminology

**Before doing anything**, read the canonical glossary on Confluence:

> **https://hopper-jira.atlassian.net/wiki/spaces/H/pages/5992513740/Lodging+Rates+Pricing+Glossary**

All terms in your output **must** match the glossary definitions exactly.

**If the user uses a term incorrectly** (e.g., says "margin" when they mean "markup", or "cost" when they mean "breakeven"), you **must**:
1. Note the correct term per the glossary
2. Briefly explain the distinction
3. Use the correct term in your output

Do not silently adopt the user's incorrect terminology.

## Discovery Process

All pricing strategy code lives in the **`lodging-pricing-engine`** repository (`hopper-org/lodging-pricing-engine`). If the user hasn't provided a path to it, find or clone the repo before proceeding.

### Step 1: Identify the tenant's strategy

Read `StrategiesInventory.scala` in the `lodging-pricing-engine` repo:

```
pricing-service/src/main/scala/com/hopper/lodging/pricing/internal/StrategiesInventory.scala
```

Find the tenant in the `tenantStrategies` map. Note which strategy class it maps to (e.g., `standardBank`, `commerceBase`, `hopperApp`). Multiple tenants may share the same strategy — note that too.

If the tenant uses an `ExperimentalSwitchStrategy`, note the feature-toggle conditions and describe each variant separately.

### Step 2: Read the strategy definition

In the same file, find the strategy class (e.g., `CommerceBaseStrategy`, `StandardBankStrategy`). Read:

1. The **constructor parameters** — these are the configured percentages (chain markup, tax-inclusive/exclusive, etc.)
2. The **`markupStrategy` method** — this builds a `StandardMarkupStrategy` with an ordered list of `MarkupSupplier` instances
3. The **`fallbackMarkupPercentage`** — the percentage applied when no supplier in the chain matches
4. The **`enforceRangeRestrictions`** flag

### Step 3: Understand the supplier chain

The `StandardMarkupStrategy` evaluates suppliers **in order, first match wins**. For each supplier in the chain, read its Scaladoc (in the supplier's source file) to understand:

- **When it matches** (produces a markup)
- **When it skips** (passes to the next supplier)
- **What markup it produces**

Supplier source files are in:

```
pricing-service/src/main/scala/com/hopper/lodging/pricing/internal/markups/supplier/
```

Only read the suppliers that appear in the tenant's strategy chain. Do not read every supplier file.

### Step 4: Compose the explanation

Walk through the supplier chain top-to-bottom. For each supplier, write one plain-English line describing what happens to a rate when that supplier matches.

The explanation should read as a decision list: "first try X, then try Y, otherwise Z."

## Output Format

Write the explanation as a **short** bulleted list. Each bullet is one pricing rule in plain English. The order must match the supplier chain evaluation order.

### Example output (for the RBC tenant)

> - Don't touch pay-later rates
> - Use the commission for commissional rates
> - Price to the contracted price for direct rates that have one
> - Price to the reference price for rates that have one
> - Fixed markup:
>   - 25% if strategic chain
>   - 18% of the provider net if tax-exclusive
>   - 16% of the provider net if tax-inclusive

**Strict rules — follow exactly:**

- **Maximum brevity** — each bullet must be a single short sentence. No parenthetical elaborations. No formulas. No "i.e.", "e.g.", or "this means". If the bullet text is clear on its own, stop there.
- **No unsolicited commentary** — do NOT add: terminology disclaimers, markup-vs-margin notes, "range restrictions are enforced", fallback percentages (unless the chain has no catch-all), or any explanation the user did not ask for.
- **Do not enumerate strategic chains** — say "strategic chain", not the full list. Only list them if the user asks which ones qualify.
- **Use glossary terms** — "breakeven" not "cost", "markup" not "margin", "provider net" not "base price".
- **Group fixed-markup suppliers** — when the chain ends with ChainFixedMarkupSupplier + SupplierAndTaxTypeMarkupSupplier (or similar), present them as a single "Fixed markup" bullet with sub-items.
- **Skip internal machinery** — do not mention `FromShopMarkupSupplier` unless the user asks about shop-to-quote consistency.
- **Name the shared strategy** — if multiple tenants share the same strategy, mention which other tenants use it.

**Self-check before responding:** re-read the example output above. Your answer should be comparable in length and style — a handful of short bullets, nothing more.

## Common Mistakes

| Mistake | Correction |
|---------|------------|
| Listing `FromShopMarkupSupplier` as a pricing rule | This is internal quote-time plumbing — omit unless specifically asked |
| Saying "margin" when meaning "markup" | Check glossary — markup is on top of breakeven; margin is share of sell price |
| Listing every supplier with implementation details | Keep it short — one line per rule, plain English |
| Hardcoding percentages from memory | Always read the actual constructor parameters in the code |
| Ignoring `ExperimentalSwitchStrategy` | Describe each variant separately with its toggle condition |
| Using "cost" instead of "breakeven" | The glossary defines "breakeven" as the canonical term |

## Tips

- **Strategies change** — always read the code; never rely on cached knowledge of percentages or supplier chains.
- **The qualifying chain list** (`chainFixedMarkupQualifyingChainIds`) is defined in the `StrategiesInventory` companion object. Read it if the user asks which chains get the strategic-chain markup.
- **Capone strategies** use a different supplier model (`capone/` subdirectory) — read those supplier files separately.
- **Forward distribution** is the simplest strategy (flat percentage, no range restrictions) — the explanation is typically one line.
