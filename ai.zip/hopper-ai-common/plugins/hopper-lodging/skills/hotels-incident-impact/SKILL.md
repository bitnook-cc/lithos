---
name: hotels-incident-impact
description: Use when assessing the impact of a hotels production incident, determining which tenants and funnel stages (shop, quote, book) are affected, and recommending an incident severity level.
---

# Hotels Incident Impact Assessment

## Overview

Automate incident impact assessment by querying Datadog APM spans across key hotels services, classifying tenant impact per funnel stage, and recommending a severity level. The assessment is posted to the incident Slack channel.

## Hard Gate

An incident Slack channel MUST be in context before proceeding. If not available, ask the user for the incident channel link.

## Step 1: Query Impact Data

Use the Datadog MCP `aggregate_spans` tool. All queries filter for `env:production realm:common @span.kind:server`.

### Time Windows

- **Current:** `now-15m` to `now`
- **Baseline:** `now-4h15m` to `now-15m`

Run current and baseline queries in parallel across all services.

### Endpoints to Query

**Shop:**

| Service | Resource filter |
|---------|----------------|
| `paris-orchestrator` | `resource_name:"PUT /api/v1/shop"` |
| `lodging-distribution-api` | `resource_name:("PUT /api/lodging/v1/shop" OR "PUT /api/lodging/v1/shopFeed")` |
| `lodging-distribution-api-lodging-search-api` | `resource_name:(*ShopService/MultiShop OR *ShopService/Shop)` |
| `lodging-rates` | `resource_name:"PUT /api/v1/shop"` |

**Quote:**

| Service | Resource filter |
|---------|----------------|
| `paris-orchestrator` | `resource_name:"POST /api/v1/quote"` |
| `lodging-distribution-api` | `resource_name:"PUT /api/lodging/v1/quote"` |
| `lodging-rates` | `resource_name:"POST /api/v2/quote"` |
| `lodging-shopping-cart-grpc` | `resource_name:*ProductFulfillmentService/PriceQuote` |

**Book:**

| Service | Resource filter |
|---------|----------------|
| `paris-orchestrator` | `resource_name:"POST /api/v1/book"` |
| `lodging-distribution-api` | `resource_name:"POST /api/lodging/v1/book"` |
| `lodging-rates` | `resource_name:"POST /api/v1/book"` |
| `lodging-shopping-cart-grpc` | `resource_name:(*ProductFulfillmentService/PrepareFulfillment OR *ProductFulfillmentService/Fulfill)` |

### Query Structure

For each service/stage combination, run two queries:

1. **Total traffic + latency:** computes `COUNT(*)`, `P95(duration)`, and `P99(duration)`, grouped by tenant tag
2. **Errors only:** append `status:error` to the query, compute `COUNT(*)`, grouped by tenant tag

Error rate = error count / total count per tenant.

**Tenant tag by service:**
- `@tenant` — `paris-orchestrator`, `lodging-rates`, `lodging-shopping-cart-grpc`, `lodging-distribution-api-lodging-search-api`
- `@metadata.tenant` — `lodging-distribution-api`

Only include tenants that had traffic in the baseline period.

### Known Service Timeouts

When p99 (or p95) latency is at or near a service's timeout ceiling, those requests are effectively errors — long-running shop and availability calls are practically failures from the client's perspective. These may not appear as `status:error` spans in the origin service, but you can verify by checking the corresponding client-side spans for timeout errors. **Latency at timeout = silent outage.**

| Service | Timeout |
|---------|---------|
| `paris-orchestrator` (shop/quote/book) | ~15s |
| `lodging-distribution-api-lodging-search-api` (MultiShop) | ~15s |
| `lodging-distribution-api-lodging-search-api` (Availability endpoints) | ~50s |

## Step 2: Classify Impact

### Tenant Classification

- Tenants ending in `-01` → **Forward Distribution (FD)** — wholesale partner tenants
- All others → **Commerce** — direct customer-facing tenants

### Impact Levels

For each tenant on each stage, classify using the worst signal across services:

| Level | Criteria |
|-------|----------|
| **Out** | Error rate >=50% OR volume dropped >90% vs baseline OR p99 at service timeout ceiling OR p95 >10x baseline |
| **Degraded** | Error rate 10–50% OR volume dropped 30–90% vs baseline OR p95 >3x baseline OR p99 >5x baseline |
| **Healthy** | Error rate <10% AND volume within normal range AND latency within normal range |

> **Important:** When both p95 and p99 are pegged at the service timeout ceiling, classify as **Out** regardless of error rate — the service is functionally down even if errors aren't being reported.

Include the signal that drove each tenant's classification in parentheses (e.g., `hopper-app ⛔ OUT (p99 at 15s timeout + 33% error rate)`).

## Step 3: Recommend Severity

Fetch the severity rubric from Confluence using the Atlassian MCP `getConfluencePage` tool:
- **Cloud ID:** `hopper-jira.atlassian.net`
- **Page ID:** `2259453036`
- **Content format:** `markdown`

Apply these heuristics (commerce tenants take priority over FD):

| Scenario | Severity |
|----------|----------|
| Any commerce tenant **out** on any stage (shop, quote, or book) | **SEV-1** |
| Multiple commerce tenants **degraded** on any stage | **SEV-2** |
| FD tenants **out** on any stage | **SEV-2** |
| FD tenants **degraded**, or single commerce tenant **degraded** | **SEV-3** |

> **Funnel starvation:** If shop is out long enough that downstream quote/book volume drops >90% vs baseline, this is a full-funnel outage — escalate to SEV-1 even if quote/book services are technically healthy.

The Confluence rubric is authoritative — use it to validate or adjust the heuristic recommendation.

## Step 4: Post to Incident Channel

Post via `slack_send_message` to the incident channel. Include:

**1. Impact summary table:**

```
Hotels Incident Impact Assessment

SHOP:
  Commerce:
    hopper-app ⛔ OUT (p99 at 15s timeout + 33% error rate)
    capone ⚠️ DEGRADED (p99 5.2x baseline)
    kayak ✅ HEALTHY
  Forward Distribution:
    nuitee-01 ⛔ OUT (80% error rate + timeout)
    hotelbeds-01 ⛔ OUT (79% error rate + timeout)

QUOTE:
  Commerce: ...
  Forward Distribution: ...

BOOK:
  Commerce: ...
  Forward Distribution: ...
```

**2. Severity recommendation** with brief reasoning referencing the rubric.

**3. Review note:**

> Review this assessment before changing the incident severity. Tag @lodging-cars-escalation to escalate if needed.