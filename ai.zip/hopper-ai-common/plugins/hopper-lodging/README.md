# hopper-lodging

Skills for the Travel Tech Lodgings & Cars Distribution team. Covers hotel data sources, reference data (tenants, providers, IDs), availability debugging, and pricing investigation.

## Skills

| Skill | Description |
|-------|-------------|
| `hotel-data` | BigQuery table reference for hotel pipeline stages (Availability → Shop → Quote/Book) |
| `lodging-reference-data` | Reference data for tenants, providers, ID formats, and domain taxonomy |
| `hotel-availability` | Debugging guide for missing hotels, rates, or providers in search results |
| `hotel-pricing` | Pricing investigation methodology and common scenarios |
