---
name: exercise-monitoring
description: >
  Use when analyzing daily fintech exercise anomaly detection, exercise monitoring,
  exercise trends, or preparing daily exercise summaries. Detects unusual exercise cost,
  count, and CPE patterns across product environments using z-score analysis against
  the universal_report in BigQuery.
---

# Fintech Exercise Monitoring

Use this skill when users ask about daily exercise monitoring, anomaly detection,
exercise trends, or preparing daily exercise summaries.

## Data Source

All monitoring data comes from the Universal Report:

`h4r-common-fintech-bi-prd.reports.universal_report`

## Core Query

This query computes daily exercise metrics per product_environment, calculates
rolling 21-day z-scores, and flags anomalies at a 3.0 z-score threshold:

```sql
with exercise_data as (
  select
    date(exercise_time) as exercise_date,
    business_unit,
    product_environment,
    sum(payout_usd) as exercise_cost,
    sum(exercised_ind) as exercise_count,
    safe_divide(sum(payout_usd), sum(exercised_ind)) as cpe
  from `h4r-common-fintech-bi-prd.reports.universal_report`
  group by 1, 2, 3
)

, averages as (
  select
    *,
    round(avg(exercise_cost) over (partition by product_environment order by exercise_date rows between 21 preceding and 1 preceding)) as cost_avg,
    round(avg(exercise_count) over (partition by product_environment order by exercise_date rows between 21 preceding and 1 preceding)) as count_avg,
    round(avg(cpe) over (partition by product_environment order by exercise_date rows between 21 preceding and 1 preceding)) as cpe_avg,
    round(stddev(exercise_cost) over (partition by product_environment order by exercise_date rows between 21 preceding and 1 preceding), 3) as cost_std,
    round(stddev(exercise_count) over (partition by product_environment order by exercise_date rows between 21 preceding and 1 preceding), 3) as count_std,
    round(stddev(cpe) over (partition by product_environment order by exercise_date rows between 21 preceding and 1 preceding), 3) as cpe_std
  from exercise_data
)

, thresholds as (
  select 3.0 as z_thresh
)

, zscores as (
  select
    *,
    (exercise_cost - cost_avg) / nullif(cost_std, 0) as cost_zscore,
    (exercise_count - count_avg) / nullif(count_std, 0) as count_zscore,
    (cpe - cpe_avg) / nullif(cpe_std, 0) as cpe_zscore,
    (select z_thresh from thresholds) as z_thresh
  from averages
)

, bounds as (
  select
    *,
    cost_avg + cost_std * z_thresh as cost_bound_upper,
    greatest(0, cost_avg - cost_std * z_thresh) as cost_bound_lower,
    count_avg + count_std * z_thresh as count_bound_upper,
    greatest(0, count_avg - count_std * z_thresh) as count_bound_lower,
    cpe_avg + cpe_std * z_thresh as cpe_bound_upper,
    greatest(0, cpe_avg - cpe_std * z_thresh) as cpe_bound_lower
  from zscores
)

, anomalies as (
  select
    * except (business_unit),
    case when cost_zscore < -z_thresh or cost_zscore > z_thresh then 1 else 0 end as cost_anomaly,
    case when count_zscore < -z_thresh or count_zscore > z_thresh then 1 else 0 end as count_anomaly,
    case when cpe_zscore < -z_thresh or cpe_zscore > z_thresh then 1 else 0 end as cpe_anomaly,
    business_unit
  from bounds
)

select *
from anomalies
where exercise_date between date_add(current_date(), interval -120 day) and date_add(current_date(), interval -1 day)
order by 1 desc, 2, 3
```

### Key Definitions

- **product_environment**: Composite key of `TENANT/PRODUCT/LOB` (e.g., `HOPPER-APP/CFAR/AIR`, `CAPONE/DELAY_PROTECTION/AIR`)
- **exercise_cost**: Total payout USD for exercises on that day
- **exercise_count**: Number of exercises on that day
- **CPE (Cost Per Exercise)**: Average payout per exercise event
- **z-score**: How many standard deviations the day's value is from the 21-day trailing average (excluding current day)
- **z_thresh = 3.0**: Anomaly flag triggers when |z-score| > 3.0

## Preparing the Daily Summary

When asked to prepare the daily exercise monitoring summary:

### Step 1: Run the core query filtered to yesterday

Filter the core query to `exercise_date = date_add(current_date(), interval -1 day)` and check for any rows where `cost_anomaly = 1`, `count_anomaly = 1`, or `cpe_anomaly = 1`.

### Step 2: Also check for multi-day trends

Run a second query looking at the last 5 days to identify sustained directional moves that haven't yet breached the z-score threshold but may warrant attention. A product_environment with 4+ consecutive days where z-scores are all >1.5 or all <-1.5 in the same direction is a "trending" signal.

### Step 3: Interpret the results

If anomalies were detected, report which product environments are anomalous and what the anomaly means. If no anomalies, note that all product environments are within normal bounds and mention any trending signals worth watching.

### Interpretation Guidelines

When describing anomalies, explain what the combination of metrics suggests:

- *High Cost + Normal Count + High CPE* — Individual exercises more expensive, possible pricing/severity issue
- *High Cost + High Count + Normal CPE* — More exercises than usual at normal cost, volume spike (event-driven?)
- *Normal Cost + High Count + Low CPE* — Many small exercises, possible process/system issue
- *High Cost + High Count + High CPE* — Both more exercises and more expensive, investigate urgently
- *Low Cost + Low Count + Normal CPE* — Quiet day, may be data lag or legitimate low volume

### Dashboard Link

Reference dashboard: https://docs.google.com/spreadsheets/d/1nHX5N8QHTKlbkmhLQglkutXPzTx34U9cl_BPjJNW_lY/edit?gid=1007903965#gid=1007903965

## Additional Monitoring Insights

Beyond the daily z-score check, highlight these when relevant:

### 1. Multi-Day Trends (Actionable by Pricing)

Flag product environments where z-scores have been consistently elevated (>1.5) or depressed (<-1.5) for 3+ consecutive days, even if no single day breaches the 3.0 threshold. A sustained shift in CPE or exercise rate often indicates a pricing model drift or a change in the underlying risk environment that the pricing team should evaluate.

### 2. Week-over-Week Comparison (Actionable by Product)

Compare the current week's total exercise cost and count to the prior week for each product environment. A >30% WoW increase in cost without a corresponding count increase suggests individual claim severity is rising — the product team should investigate whether coverage terms or customer behavior have changed.

### 3. Zero-Exercise Days (Actionable by Engineering/Product)

Flag product environments that normally have daily exercises (trailing 21-day average count > 5) but recorded zero exercises yesterday. This can indicate a data pipeline issue, a product outage, or a policy change that halted exercises.

### 4. Month-to-Date Pacing (Actionable by Finance/Pricing)

Compare MTD exercise cost to the same point in the prior month. If MTD cost is running >20% above prior month pace, flag for awareness — this affects margin forecasts and may require pricing adjustments.

### 5. New Product Environments

Flag any product_environment that appears in the data for the first time (no trailing average available). New products or tenant launches should be called out for visibility.
