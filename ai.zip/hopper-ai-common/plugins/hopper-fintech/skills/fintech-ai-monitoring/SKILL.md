---
name: fintech-ai-monitoring
description: >
  Use when monitoring the fintech-ai service health, investigating fintech-ai
  variants (e.g. advance-days-copy, control-clone), checking fintech-ai APM
  traces, logs, errors, or RUM, or preparing a fintech-ai service health
  summary. Covers per-variant latency and error comparison, log analysis,
  error tracking, and RUM for service:fintech-ai in Datadog.
---

# Fintech AI Service Monitoring

Use this skill when users ask about fintech-ai service health, variant
performance, APM traces, logs, errors, or RUM for `service:fintech-ai`.

> This skill covers `service:fintech-ai` only. Do NOT include `fintech-portal`
> data in any analysis.

## Service Overview

- **Service**: `fintech-ai`
- **APM query**: `service:fintech-ai`
- **RUM query**: `@type:view service:fintech-ai` or `@type:error service:fintech-ai`
- **Variants**: Dynamically discovered from APM resource names (not hardcoded)

## Step 1: Discover Active Variants

Variants are A/B test routes served by fintech-ai. Discover them dynamically
by aggregating `resource_name` values matching the route pattern.

Use the Datadog `aggregate_spans` tool:

```
query: service:fintech-ai resource_name:"render route (app) /air/*"
from: now-1h (or the user's requested time range)
computes:
  - { field: "*", aggregation: "COUNT", output: "request_count" }
group_by:
  fields: ["resource_name"]
```

This returns the list of active variants (e.g. `render route (app) /air/advance-days-copy`,
`render route (app) /air/control-clone`). Use this list for all subsequent per-variant
breakdowns.

## Step 2: Per-Variant APM Comparison

For each variant discovered in Step 1, compare request volume, error rate,
and latency distribution.

### Request Count and Error Rate

Use `aggregate_spans`:

```
query: service:fintech-ai resource_name:"render route (app) /air/*"
from: now-1h
computes:
  - { field: "*", aggregation: "COUNT", output: "total_requests" }
group_by:
  fields: ["resource_name", "status"]
```

Calculate error rate per variant: `error_count / total_count * 100`.

### Latency (p50, p95, p99)

Use `aggregate_spans`:

```
query: service:fintech-ai resource_name:"render route (app) /air/*"
from: now-1h
computes:
  - { field: "duration", aggregation: "P50", output: "p50_latency" }
  - { field: "duration", aggregation: "P95", output: "p95_latency" }
  - { field: "duration", aggregation: "P99", output: "p99_latency" }
group_by:
  fields: ["resource_name"]
```

Duration is in nanoseconds. Convert to milliseconds for display (divide by 1,000,000).

### Latency Over Time

To check for latency regressions, add a time-based histogram:

```
query: service:fintech-ai resource_name:"render route (app) /air/*"
from: now-1h
computes:
  - { field: "duration", aggregation: "P95", output: "p95_latency" }
group_by:
  fields: ["resource_name"]
  interval: 300000  (5-minute buckets)
```

### Interpretation

- Compare variants side-by-side. A new variant should have similar or better
  latency/error rate vs. established ones.
- A sudden spike in p99 for one variant may indicate a regression.
- If one variant has significantly higher error rate, investigate its error
  spans (see Step 5).

## Step 3: Log Health Check

Check for error and warning logs on the fintech-ai service, broken down by variant.

### Error/Warning Logs

Use `search_datadog_logs`:

```
query: service:fintech-ai status:(error OR warn)
from: now-1h
```

### Log Volume by Level

Use `analyze_datadog_logs`:

```
filter: service:fintech-ai
sql_query: SELECT status, count(*) FROM logs GROUP BY status ORDER BY count(*) DESC
from: now-1h
```

### Per-Variant Log Patterns

Use `search_datadog_logs` with `use_log_patterns: true`:

```
query: service:fintech-ai
from: now-1h
use_log_patterns: true
clustering_pattern_field: message
```

### Interpretation

- Zero error logs is the healthy baseline.
- New error patterns appearing after a variant launch warrant investigation.
- Info-level logs like "Computed AdvanceDaysCopy bucket" are expected operational logs.

## Step 4: Error Tracking

Check for error tracking issues grouped against fintech-ai.

Use `search_datadog_error_tracking_issues`:

```
query: service:fintech-ai
from: now-1d
states: ["FOR_REVIEW"]
```

For each issue found, use `get_datadog_error_tracking_issue` with the `issue_id`
to get full details including stack traces and affected variants.

## Step 5: RUM (Real User Monitoring)

Check RUM data for `service:fintech-ai` specifically. Do NOT query fintech-portal.

### RUM Views

Use `search_datadog_rum_events`:

```
query: @type:view service:fintech-ai
from: now-1h
```

### RUM Errors

Use `search_datadog_rum_events`:

```
query: @type:error service:fintech-ai
from: now-1h
```

### RUM Error Count Over Time

Use `aggregate_rum_events`:

```
query: @type:error service:fintech-ai
from: now-1h
computes:
  - { field: "*", aggregation: "COUNT", output: "error_count" }
group_by:
  interval: 300000  (5-minute buckets)
```

### RUM Session Count

Use `aggregate_rum_events`:

```
query: @type:session service:fintech-ai
from: now-1h
computes:
  - { field: "*", aggregation: "COUNT", output: "session_count" }
```

### Interpretation

- RUM errors on `service:fintech-ai` indicate client-side issues in the
  fintech-ai frontend.
- Correlate RUM error spikes with APM error spikes to determine if the issue
  is backend or frontend.
- Ignore `fintech-portal` RUM data entirely — it is a separate service.

## Step 6: Downstream Dependencies

Check for errors in downstream services called by fintech-ai. Dependencies
should be discovered dynamically — do not rely on a hardcoded list.

### Discover Downstream Services

Use `aggregate_spans` to find all downstream services fintech-ai calls:

```
query: service:fintech-ai @span.kind:client
from: now-1h
computes:
  - { field: "*", aggregation: "COUNT", output: "request_count" }
group_by:
  fields: ["@peer.service", "resource_name"]
```

This returns the full list of downstream dependencies with their gRPC
resource names and call volumes.

### Downstream Error Check

Aggregate downstream errors by peer service and resource:

```
query: service:fintech-ai @span.kind:client status:error
from: now-1h
computes:
  - { field: "*", aggregation: "COUNT", output: "error_count" }
group_by:
  fields: ["@peer.service", "resource_name"]
```

### Downstream Latency

Check if any downstream service is slow:

```
query: service:fintech-ai @span.kind:client
from: now-1h
computes:
  - { field: "duration", aggregation: "P95", output: "p95_latency" }
  - { field: "duration", aggregation: "P99", output: "p99_latency" }
group_by:
  fields: ["@peer.service", "resource_name"]
```

### Inspect Specific Downstream Errors

For any downstream dependency showing errors, inspect individual error spans:

```
query: service:fintech-ai @span.kind:client status:error @peer.service:<service_name>
from: now-1h
```

### Interpretation

- If a downstream service has a high error rate, the issue is likely not
  in fintech-ai itself — escalate to the owning team.
- High downstream latency can cause fintech-ai variant responses to slow
  down — correlate with per-variant p95/p99 from Step 2.
- A newly appearing downstream dependency may indicate a recent code change.

## Step 7: Overall Service Health Summary

After completing Steps 1-6, compile a summary:

1. **Active variants**: List discovered variants with request counts
2. **Per-variant comparison**: Table of request count, error rate, p50/p95/p99
3. **Log health**: Any error/warn logs, new patterns
4. **Error tracking**: Open issues count and severity
5. **RUM health**: RUM error count, any new error types
6. **Downstream health**: Any dependency errors
7. **Verdict**: Overall assessment (healthy / degraded / investigate)

### Example Summary Format

```
*fintech-ai Service Health — {date}*

*Active Variants*
- `/air/advance-days-copy` — {N} reqs/hr
- `/air/control-clone` — {N} reqs/hr

*Per-Variant Comparison*
| Variant | Requests | Error Rate | p50 | p95 | p99 |
|---------|----------|-----------|-----|-----|-----|
| advance-days-copy | ... | ... | ... | ... | ... |
| control-clone | ... | ... | ... | ... | ... |

*Logs*: {N} error logs, {N} warn logs
*Error Tracking*: {N} open issues
*RUM*: {N} errors on service:fintech-ai
*Downstream*: {status}

*Verdict*: {assessment}
```
