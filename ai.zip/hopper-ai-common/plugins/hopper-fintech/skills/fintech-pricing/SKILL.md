---
name: fintech-pricing
description: >
  Use when analyzing fintech product metrics, attach rates, exercise rates, pricing, revenue,
  margin, or profitability for CFAR, disruption protection, or travel insurance. Use when
  querying universal_report, fintech KPIs, or product-level metrics in BigQuery.
---

# Fintech Pricing Analytics

Use this skill when users ask about fintech product metrics, attach rates, exercise rates,
pricing, revenue, margin, or profitability for our travel fintech products.

## Products

### Cancel for Any Reason (CFAR)

Allows users to cancel their flight or hotel stay for a refund within the cancellation window.

- **Coverage**: Typically 80% to 100% of the booking value
- **Window**: Often up to 48 hours before departure
- **Risk**: We assume the risk and provision against expected exercise
- **Key metrics**: Attach rate, exercise rate, margin, GPPO

### Disruption Protection

Covers travel delays (typically 2-3+ hours) and cancellations.

- **Options**: Rebook (up to cap, typically 5x original price) or refund
- **Trigger**: Flight delay/cancellation event from FlightStats or similar
- **Key fields**: `disruption_disrupted_ind`, `disruption_rebook_cost_usd`, `disruption_compensation_cost_usd`

### Travel Insurance

Traditional policies covering medical emergencies, lost luggage, etc.

- **Model**: We resell policies from third-party insurers for commission
- **Risk**: No direct risk assumption (unlike CFAR/disruption)
- **Revenue**: Commission-based

## Data Sources

### Primary Table: Universal Report

`h4r-common-fintech-bi-prd.reports.universal_report`

The main fact table with one row per opportunity (presentation). Contains:
- Offer details: price, product type, tenant, line of business
- Attach/exercise outcomes
- Revenue, payout, gross profit
- Provisioning estimates

**Always start here** for fintech product questions.

### Supporting Tables

| Table | Description |
|-------|-------------|
| `h4r-common-fintech-bi-prd.reports.provisions_detail` | Daily risk provisioning per attached policy |
| `gcp-hopper-etldata-production.fintech_models.request_log` | Raw prediction API requests |
| `gcp-hopper-etldata-production.fintech_models.prediction_log` | Model predictions |
| `gcp-hopper-etldata-production.fintech_analytics.events` | Funnel events (see [analytics-events](hopper-fintech:analytics-events)) |

**Note**: Ignore tables with `_sqlmesh_` or `_physical` in the name.

## Terminology Glossary

### Product Organization

| Term | Description |
|------|-------------|
| **Tenant** | Partner/channel we're selling through (e.g., Spirit, Cap1, App) |
| **LoB** (Line of Business) | Underlying travel product: air, hotel, car |
| **BU** (Business Unit) | hopper-app, htsfa (airline partners), hts-portals |
| **GBV** | Gross Booking Value - amount paid for travel booking (excludes fintech) |
| **Realm** | Data separation for some tenants (e.g., cap-one) |

### Product Lifecycle

| Term | Description |
|------|-------------|
| **Opportunity** | Event where we can choose to make an offer or not |
| **Offer** | Priced offer presented to consumer |
| **Attach** | Purchase of fintech product with underlying travel booking |
| **Exercise** | Consumer uses the option (e.g., cancellation refund, disruption claim) |
| **Knockout** | We decline to make an offer when we could have |
| **Expiration** | Coverage ends, risk becomes zero |
| **Expired** | `current_date() > policy_expiration_date` |
| **Concluded** | Policy reached terminal state (cancelled, lapsed, or exercised) |

### Financial Terms

| Term | Description |
|------|-------------|
| **Premium** | Price as fraction of GBV |
| **Revenue** | USD collected during purchase |
| **Payout** | USD paid to customer on exercise (cash, carrots, FTC) |
| **Provision** | Estimate of future cost while product is active |
| **COGS** | Cost of goods sold (expected/actual liability) |
| **Gross Profit** | Revenue minus COGS |
| **Margin** | Gross profit as % of revenue. See variants below. |
| **Estimated Margin** | `estimated_gross_profit_usd / revenue_usd` — Default. Works for all policies (blends actual + modeled). |
| **Actual Margin** | `gross_profit_usd / revenue_usd` — Only reliable for expired policies. Use for historical analysis. |
| **Provisioned Margin** | `(revenue - provisioned_payout - other_costs) / revenue` — Pure model prediction for forecasting. |
| **Exposure** | Maximum potential loss |

*When users ask for "margin", use Estimated Margin unless they specify expired-only analysis.*

### Aggregated Metrics

| Metric | Description |
|--------|-------------|
| **GPPT** | Gross Profit Per Transaction |
| **GPPO** | Gross Profit Per Offer |
| **GRPT** | Gross Revenue Per Transaction |
| **Attach Rate** | Purchases / underlying travel transactions |
| **Eligibility Rate** | Offers / opportunities |
| **Exercise Rate** | Exercises / attaches |
| **CPE** | Cost Per Exercise |
| **VaR** | Value at Risk (portfolio risk measure) |

## Metric Calculations

Standard formulas using Universal Report fields:

| Metric | Calculation |
|--------|-------------|
| # of bookings | `SUM(booked_ind)` |
| # of policies sold | `SUM(attached_ind)` with product filter |
| Attach Rate (Overall) | `SUM(attached_ind) / SUM(booked_ind)` |
| Attach Rate (Offered) | `SUM(attached_ind) / SUM(offered_ind)` |
| Gross Revenue | `SUM(revenue_usd)` |
| Revenue per Policy | `SUM(revenue_usd) / SUM(attached_ind)` — avg revenue per policy sold |
| Revenue per Transaction (RPT) | `SUM(revenue_usd) / SUM(booked_ind)` — avg revenue per travel booking, independent of attach |
| Revenue per Offer (RPO) | `SUM(revenue_usd) / SUM(offered_ind)` — avg revenue per offer; fallback for RPT when `booked_ind` is unreliable |
| Exercise Rate | `SUM(exercised_ind) / SUM(attached_ind)` |
| Exercise Cost | `SUM(payout_usd)` |
| Cost per Exercise | `SUM(payout_usd) / SUM(exercised_ind)` |
| Gross Profit | `SUM(gross_profit_usd)` |
| GRPT | `AVG(revenue_usd)` |
| GPPT | `AVG(gross_profit_usd)` |
| Margin (Estimated) | `SUM(estimated_gross_profit_usd) / SUM(revenue_usd)` — Default for most questions |
| Margin (Actual) | `SUM(gross_profit_usd) / SUM(revenue_usd)` — Requires `WHERE expired = true` |
| Margin (Provisioned) | `SUM(revenue_usd - provisioned_payout_usd - other_costs_usd) / SUM(revenue_usd)` — Pure model prediction |
| Eligible % | `SUM(offered_ind) / SUM(booked_ind)` |

## Date Column Guidance

**For topline metrics** (revenue, attach rates, volume):
- Group by `booking_time` or `attach_time`
- Use `*_time_week` fields for weekly views

**For bottomline metrics** (profit, exercise, margin):
- Group by `concluded_time` or `exercise_time`
- Policies must have concluded for accurate profit

## Cohort Guidance

### Running + Expired (All policies)
- Includes all bookings regardless of expiration
- Use with `booking_time` for topline metrics
- Good for: volume trends, attach rate trends, revenue

### Expired Only
- Policies that have passed their expiration date
- Use with `concluded_time` for bottomline metrics
- Good for: actual profit, exercise rates, margin
- Filter: `WHERE expired = true`

### Expiration Maturity

For CFAR and similar products, profit isn't final until expiration:

| % Expired | Reliability |
|-----------|-------------|
| 95-100% | Highly reliable actual data |
| 85-95% | Fairly reliable |
| 65-85% | Still maturing, use caution |
| <65% | Too early for profit conclusions |

**Always check expiration maturity** before drawing profit conclusions on recent cohorts.

## Common Query Patterns

### Attach Rate by Tenant (Monthly)

```sql
SELECT
  DATE_TRUNC(DATE(booking_time), MONTH) AS month,
  tenant_id,
  SUM(offered_ind) AS offers,
  SUM(attached_ind) AS attaches,
  ROUND(SUM(attached_ind) / NULLIF(SUM(offered_ind), 0) * 100, 2) AS attach_rate_pct
FROM `h4r-common-fintech-bi-prd.reports.universal_report`
WHERE product = 'cfar'
  AND DATE(booking_time) >= DATE_SUB(CURRENT_DATE(), INTERVAL 6 MONTH)
GROUP BY month, tenant_id
ORDER BY month DESC, attaches DESC
```

### Exercise Rate by Product (Expired Only)

```sql
SELECT
  product,
  SUM(attached_ind) AS attaches,
  SUM(exercised_ind) AS exercises,
  ROUND(SUM(exercised_ind) / NULLIF(SUM(attached_ind), 0) * 100, 2) AS exercise_rate_pct,
  ROUND(SUM(payout_usd) / NULLIF(SUM(exercised_ind), 0), 2) AS cost_per_exercise
FROM `h4r-common-fintech-bi-prd.reports.universal_report`
WHERE expired = true
  AND DATE(concluded_time) >= DATE_SUB(CURRENT_DATE(), INTERVAL 3 MONTH)
GROUP BY product
ORDER BY attaches DESC
```

### GPPO Trend with Maturity Check

```sql
WITH monthly_metrics AS (
  SELECT
    DATE_TRUNC(DATE(offer_time), MONTH) AS month,
    SUM(offered_ind) AS offers,
    SUM(attached_ind) AS attaches,
    COUNT(CASE WHEN attached_ind = 1 AND expired = true THEN 1 END) AS expired_attaches,
    SUM(CASE WHEN attached_ind = 1 THEN estimated_gross_profit_usd END) AS estimated_gp,
    SUM(CASE WHEN attached_ind = 1 AND expired = true THEN gross_profit_usd END) AS actual_gp
  FROM `h4r-common-fintech-bi-prd.reports.universal_report`
  WHERE product = 'cfar'
    AND tenant_id = 'air_canada'
  GROUP BY month
)
SELECT
  month,
  offers,
  attaches,
  ROUND(expired_attaches / NULLIF(attaches, 0) * 100, 1) AS pct_expired,
  ROUND(estimated_gp / NULLIF(offers, 0), 4) AS estimated_gppo,
  ROUND(actual_gp / NULLIF(expired_attaches, 0) * (attaches / NULLIF(offers, 0)), 4) AS actual_gppo_prorated
FROM monthly_metrics
ORDER BY month DESC
```

### Margin by Tenant (Estimated)

Uses `estimated_gross_profit_usd` so results include running policies. For expired-only analysis, filter `WHERE expired = true` and use `gross_profit_usd` instead.

```sql
SELECT
  tenant_id,
  SUM(attached_ind) AS policies,
  ROUND(SUM(estimated_gross_profit_usd) / NULLIF(SUM(revenue_usd), 0) * 100, 1) AS margin_pct,
  ROUND(SUM(estimated_gross_profit_usd), 0) AS gross_profit,
  ROUND(SUM(revenue_usd), 0) AS revenue
FROM `h4r-common-fintech-bi-prd.reports.universal_report`
WHERE product = 'cfar'
  AND DATE(attach_time) >= DATE_SUB(CURRENT_DATE(), INTERVAL 3 MONTH)
GROUP BY tenant_id
ORDER BY revenue DESC
```

## Assumptions and Gotchas

1. **Expired vs non-expired**: Use `expired = true` for accurate exercise/profit metrics on historical data
2. **Estimated vs actual**: `estimated_gross_profit_usd` available for all; `gross_profit_usd` only reliable when expired
3. **Profit per offer vs per attach**: GPPO is the better metric when attach rates change (captures full business value)
4. **Date column selection**: Don't mix date columns in the same cohort analysis
5. **Large tables**: Always add date filters; use LIMIT during exploration
6. **Disruption-specific fields**: `disruption_*` fields only apply to disruption product
7. **Margin defaults to estimated**: When users ask about "margin" without specifying, use `estimated_gross_profit_usd` which blends actual outcomes (for expired policies) with model predictions (for running policies). Only use `gross_profit_usd` when analyzing fully-expired cohorts. Call out which variant you're using in your response.
8. **Price Elasticity Analysis (Adverse Selection)**: When analyzing price elasticity, be wary of using raw data across all segments. High-risk segments often have both high prices and high attach rates, creating a false positive correlation (upward sloping demand curve). Always filter for specific risk segments (e.g., `predicted_exercise` buckets) or use randomized exploration data (e.g., `pricing_model LIKE '%exploration%'`) to see the true negative correlation.
9. **Disruption Product Grouping**: `delay_protection` and `missed_connection` (especially on Capital One) are effectively the same "Disruption" product, differentiated only by itinerary type (connection vs. non-stop). Unless the user asks for a specific breakdown, group them together as 'Disruption' to avoid artificial distinctions.
10. **Hotel CFAR Analysis**: Always include `cfar_negative` in the product filter when analyzing Hotel CFAR performance. This product variant is critical for accurate profitability analysis, especially for the Hopper App and TripAdvisor. Excluding it can lead to significantly understated margins (e.g., -15% vs +10%).
