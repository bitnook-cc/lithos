---
name: media
description: >
  Use when analyzing HTS Media ad campaign performance, spend pacing, budgets, impressions,
  clicks, conversions, ROAS, offer metrics, or ad serving funnel diagnostics in BigQuery.
  Covers campaign health checks, spend anomalies, budget pacing, and FlatRate delivery tracking.
---

# HTS Media Reporting

## Overview

HTS Media campaign data lives in BigQuery under the `h4r-common-bi-prd` project. The data follows a medallion architecture: bronze (raw), silver (enriched), gold (consumer-ready). Prefer **gold fact tables** and **silver dimension tables** for queries.

**Billing project for queries**: `gcp-hopper-ds-research`

## Quick Reference: Key Tables

### Gold Fact Tables (primary query targets)

All in dataset `h4r-common-bi-prd.ads_campaign_manager__gld`.

| Table | Grain | Key Metrics | Notes |
|-------|-------|-------------|-------|
| `fact_daily_ad_record` | date / campaign / ad_set / ad / channel / zone | impressions_total, clicks_total, opportunities_total, spend_total | Primary daily performance table |
| `fact_hourly_ad_record` | hour / campaign / ad_set / ad / channel / zone | Same as daily but hourly | For intra-day analysis |
| `fact_lifetime_ad_record` | campaign / ad_set / ad / channel / zone | Same metrics, lifetime aggregated | Rebuilt hourly; equals SUM of daily records exactly |
| `fact_daily_ad_conversion_record` | date / campaign / ad_set / ad / channel / zone | hotel/flight x click/impression conversions, prices, room_nights, passenger_count | For ROAS and conversion analysis |
| `fact_daily_advertiser_conversion_record` | date / advertiser / channel / publisher | hotel/flight conversions and prices | Advertiser-level (not campaign-level) conversions |
| `fact_daily_campaign_offer_record` | date / campaign / offer / publisher / channel | claimed_offer_count, redeemed_offer_count, redeemed_amount_usd_total | Offer claim and redemption metrics |

### Silver Dimension Tables (for enrichment/joins)

All in dataset `h4r-common-bi-prd.ads_campaign_manager__slv`.

| Table | Key Columns | Use For |
|-------|-------------|---------|
| `dim_campaign` | campaign_id, advertiser_id, name, start_date_time, end_date_time, is_paused, slug, lifetime_budget_usd, daily_budget_usd, target_roas | Campaign metadata and budgets |
| `dim_advertiser` | advertiser_id, name, advertiser_type, short_name | Advertiser names (canonical name resolved) |
| `dim_ad_set` | ad_set_id, campaign_id, ad_type, name, start_date_time, end_date_time, lifetime_budget_usd, rate_type, rate_amount_usd, daily_budget_usd, is_paused, distribution (JSON) | Ad set config, pricing, budgets |
| `dim_ad` | ad_id, ad_set_id, campaign_id, advertiser_id, advertiser_name, campaign_slug, ad_set_name, name, ad_type | Unified ad dimension with full hierarchy |
| `dim_zone` | publisher_id, publisher_name, channel_id, channel_name, zone_id, zone_name, ad_type | Publisher > Channel > Zone hierarchy |
| `dim_offer` | offer_id, offer_slug, advertiser_id, campaign_id, offer_type | Offer metadata |

### Silver Fact Tables (for deeper analysis)

| Table | Use For |
|-------|---------|
| `fact_served_ad_outcome` | Ad serving funnel: request -> served -> impression -> click |
| `fact_ad_requests` | Raw ad request data with targeting context |
| `fact_daily_offer_record` | Ad-level offer metrics (finer grain than gold campaign-level offer table) |
| `fact_daily_zone_record` | Zone-level opportunity (ad request) counts |
| `fact_hourly_zone_record` | Hourly zone-level opportunity counts |

## Column Value Reference

### `channel` column (in fact tables) = `channel_id` in dim_zone

| channel value | Human-readable name | Publisher |
|---------------|-------------------|-----------|
| `HopperApp` | Hopper App | Hopper |
| `HopperWeb` | Hopper Web | Hopper |
| `capone-web` | Capital One Web | Capital One |
| `vio-web` | Vio Web | Vio |

### `zone` column (in fact tables) = placement = `zone_id` in dim_zone

The team prefers the term **"placement"** but the column is called `zone` in all tables.

Common values: `Homescreen`, `DealsPage`, `FlightSearch`, `FlightSearchPage`, `FlightSponsoredListing`, `HotelSearch`, `HotelSearchPage`, `HotelsSearchSuggestionAdPlacement`, `RotatingBannerDisplayAdPlacement`, `PushNotification`, `Microsite`, `FlashSale`, `Meta`

### `ad_type` values (in fact tables)

`DealTile`, `Banner`, `FlightInline`, `FlightSponsoredListing`, `HotelInline`, `ManagedOffer`, `AudienceExtensionAd`, `FlightSearchSuggestion`, `HotelSearchSuggestion`, `PushNotification`, `Email`, `FlashSale`, `Video`

Note: `dim_ad_set` uses `AudienceExtension` while fact tables use `AudienceExtensionAd`.

### `rate_type` values (on dim_ad_set)

| rate_type | Meaning | Spend calculation |
|-----------|---------|-------------------|
| `CPC` | Cost Per Click | rate_amount_usd per click |
| `CPM` | Cost Per Mille | rate_amount_usd / 1000 per impression |
| `Flat` | FlatRate — fixed fee for a deliverable target (impressions or clicks) | Pipeline records $0 spend (billed externally). Track `deliverable_target_type` and `deliverable_target_value` instead. |

### Attribution terminology (VTA / CTA)

- **VTA** (View-Through Attribution): A booking attributed because an ad impression occurred within 30 days before the booking.
- **CTA** (Click-Through Attribution): A booking attributed because an ad click occurred within 30 days before the booking.
- **Advertiser conversions** (`fact_daily_advertiser_conversion_record`): All bookings matching campaign geography, regardless of impression/click.

**Critical nuance**: The data model is click-preferred. If a booking has both an impression and a click, it is counted as CTA only — the `hotel_impression_*` / `flight_impression_*` columns exclude it. This means:
- `impression_*` columns = impression-only attributions (no click)
- `click_*` columns = click attributions
- **True total VTA = impression_* + click_*** (since every click implies a view)

Default to showing **combined (impression + click)** for total conversions and ROAS. When showing VTA/CTA separately, note that VTA-only numbers exclude any bookings that also had a click.

Revenue for ROAS uses `base_price` columns (not `total_price`).

## Key Join Patterns

### Campaign spend with advertiser name

```sql
SELECT
  a.name AS advertiser_name,
  c.slug AS campaign_slug,
  c.lifetime_budget_usd,
  ROUND(SUM(f.spend_total), 2) AS total_spend
FROM `h4r-common-bi-prd.ads_campaign_manager__gld.fact_daily_ad_record` f
JOIN `h4r-common-bi-prd.ads_campaign_manager__slv.dim_campaign` c USING (campaign_id)
JOIN `h4r-common-bi-prd.ads_campaign_manager__slv.dim_advertiser` a ON c.advertiser_id = a.advertiser_id
WHERE f.date_utc >= '2026-01-01'
GROUP BY 1, 2, 3
```

### Enrich with human-readable channel/zone names

The `channel` and `zone` columns in fact tables are IDs. Join to `dim_zone` for names:

```sql
JOIN `h4r-common-bi-prd.ads_campaign_manager__slv.dim_zone` z
  ON f.channel = z.channel_id AND f.zone = z.zone_id AND f.ad_type = z.ad_type
```

### Ad serving funnel (request -> serve -> impression -> click)

Use `fact_served_ad_outcome` which already joins the full funnel:

```sql
SELECT
  z.channel_name,
  z.zone_name,
  DATE(sao.received_at) AS date_utc,
  COUNT(*) AS served_ads,
  COUNTIF(sao.impression_occurred_at IS NOT NULL) AS impressions,
  COUNTIF(sao.impression_occurred_at IS NULL) AS missing_impressions,
  COUNTIF(sao.click_occurred_at IS NOT NULL) AS clicks,
  ROUND(SAFE_DIVIDE(COUNTIF(sao.impression_occurred_at IS NOT NULL), COUNT(*)) * 100, 1) AS impression_rate_pct
FROM `h4r-common-bi-prd.ads_campaign_manager__slv.fact_served_ad_outcome` sao
JOIN `h4r-common-bi-prd.ads_campaign_manager__slv.dim_zone` z
  ON sao.channel_id = z.channel_id AND sao.zone_id = z.zone_id AND sao.ad_type = z.ad_type
GROUP BY 1, 2, 3
```

## Common Query Patterns

### Identifying "active" campaigns and ad sets

A campaign is active when it has started, has not ended, and is not paused. `dim_campaign` already filters out deleted campaigns. Ad sets have their own date ranges and pause state that may differ from the parent campaign.

```sql
-- Active campaigns
WHERE c.start_date_time <= CURRENT_TIMESTAMP()
  AND (c.end_date_time IS NULL OR c.end_date_time > CURRENT_TIMESTAMP())
  AND NOT c.is_paused

-- Active ad sets (may have narrower date ranges than campaign)
WHERE s.start_date_time <= CURRENT_TIMESTAMP()
  AND (s.end_date_time IS NULL OR s.end_date_time > CURRENT_TIMESTAMP())
  AND NOT s.is_paused
```

### Campaign slug

The `slug` on `dim_campaign` (also `campaign_slug` on `dim_ad`) is the primary human-readable campaign identifier. Format: `Ads-Campaign-{advertiser_type}-{advertiser_name}-{campaign_name}-{yyyyMM}`.

Examples: `Ads-Campaign-DMO-Visit-Florida-Febuary-202602`, `Ads-Campaign-Airline-Alaska-Airlines-Cap-One-Mangaed-Offers-Alaska-Airlines-202601`

### Campaign/ad set spend pacing

"Off pace" means spend is tracking to either exhaust budget early or not finish budget by end date. The goal is linear spend across the campaign/ad set duration. Exclude FlatRate ad sets (they show $0 spend).

**Ad set level pacing** (preferred, since budgets are set at ad set level):

```sql
WITH ad_set_pacing AS (
  SELECT
    c.slug AS campaign_slug,
    a.name AS advertiser_name,
    s.ad_set_id,
    s.name AS ad_set_name,
    s.rate_type,
    s.lifetime_budget_usd AS ad_set_budget,
    s.start_date_time AS ad_set_start,
    s.end_date_time AS ad_set_end,
    ROUND(SUM(f.spend_total), 2) AS lifetime_spend,
    DATE_DIFF(DATE(s.end_date_time), DATE(s.start_date_time), DAY) AS total_days,
    DATE_DIFF(CURRENT_DATE(), DATE(s.start_date_time), DAY) AS days_elapsed,
    ROUND(SAFE_DIVIDE(SUM(f.spend_total), COUNT(DISTINCT f.date_utc)), 2) AS avg_daily_spend
  FROM `h4r-common-bi-prd.ads_campaign_manager__gld.fact_daily_ad_record` f
  JOIN `h4r-common-bi-prd.ads_campaign_manager__slv.dim_ad_set` s ON f.ad_set_id = s.ad_set_id
  JOIN `h4r-common-bi-prd.ads_campaign_manager__slv.dim_campaign` c ON s.campaign_id = c.campaign_id
  JOIN `h4r-common-bi-prd.ads_campaign_manager__slv.dim_advertiser` a ON c.advertiser_id = a.advertiser_id
  WHERE s.start_date_time <= CURRENT_TIMESTAMP()
    AND (s.end_date_time IS NULL OR s.end_date_time > CURRENT_TIMESTAMP())
    AND NOT s.is_paused
    AND s.rate_type != 'Flat'
  GROUP BY 1, 2, 3, 4, 5, 6, 7, 8
)
SELECT
  *,
  ROUND(SAFE_DIVIDE(ad_set_budget, total_days), 2) AS expected_daily_spend,
  ROUND(SAFE_DIVIDE(avg_daily_spend, SAFE_DIVIDE(ad_set_budget, total_days)), 2) AS pacing_ratio,
  ROUND(ad_set_budget - lifetime_spend, 2) AS budget_remaining
FROM ad_set_pacing
WHERE ad_set_budget > 0
ORDER BY pacing_ratio ASC
```

### Lifetime spend vs budget

Use `fact_lifetime_ad_record` for accurate lifetime totals:

```sql
SELECT
  a.name AS advertiser_name,
  c.slug AS campaign_slug,
  c.lifetime_budget_usd,
  ROUND(SUM(f.spend_total), 2) AS lifetime_spend,
  ROUND(c.lifetime_budget_usd - SUM(f.spend_total), 2) AS budget_remaining,
  ROUND(SAFE_DIVIDE(SUM(f.spend_total), c.lifetime_budget_usd) * 100, 1) AS pct_budget_used
FROM `h4r-common-bi-prd.ads_campaign_manager__gld.fact_lifetime_ad_record` f
JOIN `h4r-common-bi-prd.ads_campaign_manager__slv.dim_campaign` c USING (campaign_id)
JOIN `h4r-common-bi-prd.ads_campaign_manager__slv.dim_advertiser` a ON c.advertiser_id = a.advertiser_id
GROUP BY 1, 2, 3
```

### Spend anomaly detection (daily avg comparison)

```sql
WITH campaign_daily AS (
  SELECT
    campaign_id,
    date_utc,
    SUM(spend_total) AS daily_spend
  FROM `h4r-common-bi-prd.ads_campaign_manager__gld.fact_daily_ad_record`
  WHERE date_utc >= DATE_SUB(CURRENT_DATE(), INTERVAL 14 DAY)
  GROUP BY 1, 2
),
with_avg AS (
  SELECT
    campaign_id,
    date_utc,
    daily_spend,
    AVG(daily_spend) OVER (
      PARTITION BY campaign_id
      ORDER BY date_utc
      ROWS BETWEEN 7 PRECEDING AND 1 PRECEDING
    ) AS trailing_7d_avg
  FROM campaign_daily
)
SELECT
  a.name AS advertiser_name,
  c.slug AS campaign_slug,
  wa.date_utc,
  ROUND(wa.daily_spend, 2) AS daily_spend,
  ROUND(wa.trailing_7d_avg, 2) AS trailing_7d_avg,
  ROUND(SAFE_DIVIDE(wa.daily_spend - wa.trailing_7d_avg, wa.trailing_7d_avg) * 100, 1) AS pct_change
FROM with_avg wa
JOIN `h4r-common-bi-prd.ads_campaign_manager__slv.dim_campaign` c USING (campaign_id)
JOIN `h4r-common-bi-prd.ads_campaign_manager__slv.dim_advertiser` a ON c.advertiser_id = a.advertiser_id
WHERE wa.date_utc = DATE_SUB(CURRENT_DATE(), INTERVAL 1 DAY)
  AND ABS(SAFE_DIVIDE(wa.daily_spend - wa.trailing_7d_avg, wa.trailing_7d_avg)) > 0.5
ORDER BY ABS(pct_change) DESC
```

### ROAS calculation

Revenue for ROAS uses `base_price` columns. Default to combined (VTA + CTA) since the click-preferred attribution model means CTA is a strict subset of VTA. Note this in your response when showing ROAS.

```sql
SELECT
  a.name AS advertiser_name,
  c.slug AS campaign_slug,
  ROUND(SUM(spend.spend_total), 2) AS total_spend,
  SUM(conv.hotel_click_conversions_total + conv.hotel_impression_conversions_total
    + conv.flight_click_conversions_total + conv.flight_impression_conversions_total) AS total_conversions,
  ROUND(SUM(conv.hotel_click_base_price_total + conv.hotel_impression_base_price_total
    + conv.flight_click_base_price_total + conv.flight_impression_base_price_total), 2) AS total_conversion_revenue,
  ROUND(SAFE_DIVIDE(
    SUM(conv.hotel_click_base_price_total + conv.hotel_impression_base_price_total
      + conv.flight_click_base_price_total + conv.flight_impression_base_price_total),
    SUM(spend.spend_total)), 2) AS roas
FROM `h4r-common-bi-prd.ads_campaign_manager__gld.fact_daily_ad_record` spend
JOIN `h4r-common-bi-prd.ads_campaign_manager__gld.fact_daily_ad_conversion_record` conv
  USING (date_utc, campaign_id, ad_set_id, ad_id, zone)
JOIN `h4r-common-bi-prd.ads_campaign_manager__slv.dim_campaign` c ON spend.campaign_id = c.campaign_id
JOIN `h4r-common-bi-prd.ads_campaign_manager__slv.dim_advertiser` a ON c.advertiser_id = a.advertiser_id
WHERE spend.date_utc >= DATE_SUB(CURRENT_DATE(), INTERVAL 30 DAY)
GROUP BY 1, 2
HAVING total_spend > 0
ORDER BY roas DESC
```

### FlatRate delivery tracking

FlatRate ad sets show $0 spend because billing is handled externally. Track delivery against the contracted target:

```sql
SELECT
  s.ad_set_id,
  s.name AS ad_set_name,
  s.deliverable_target_type,
  s.deliverable_target_value AS target,
  CASE
    WHEN s.deliverable_target_type = 'Impressions' THEN SUM(f.impressions_total)
    WHEN s.deliverable_target_type = 'Clicks' THEN SUM(f.clicks_total)
  END AS actual_delivered,
  ROUND(SAFE_DIVIDE(
    CASE
      WHEN s.deliverable_target_type = 'Impressions' THEN SUM(f.impressions_total)
      WHEN s.deliverable_target_type = 'Clicks' THEN SUM(f.clicks_total)
    END,
    s.deliverable_target_value) * 100, 1) AS pct_delivered
FROM `h4r-common-bi-prd.ads_campaign_manager__gld.fact_daily_ad_record` f
JOIN `h4r-common-bi-prd.ads_campaign_manager__slv.dim_ad_set` s USING (ad_set_id)
WHERE s.rate_type = 'Flat'
GROUP BY 1, 2, 3, 4
```

## Important Gotchas

1. **`daily_budget_usd` is generally NULL** at the campaign level. Budgets are primarily set at the `dim_ad_set` level as `lifetime_budget_usd`. The orchestrator uses `daily_budget_usd` for daily pacing — each day the remaining budget is spread over remaining days with buffer, so actual daily pacing is adaptive (not strictly linear).

2. **FlatRate ad sets show $0 spend** in the pipeline because billing is handled externally. They have `deliverable_target_type` and `deliverable_target_value` instead.

3. **When an ad set's budget is exhausted, its ads stop serving**. Budget enforcement is at the ad set level — a campaign can contain multiple ad sets (different formats/channels) and each has its own `lifetime_budget_usd`. Campaign `lifetime_budget_usd >= SUM(ad set budgets)`. In the pipeline, `fact_hourly_ad_record` caps spend using a running sum — events after the cap show `spend_total = 0` but impressions/clicks are still counted.

4. **Push notifications are "opportunities" not "impressions"**. Push sends appear in `opportunities_total`, not `impressions_total`, because a send does not guarantee the notification was seen.

5. **Today's data is partial**. Always use `DATE_SUB(CURRENT_DATE(), INTERVAL 1 DAY)` for "yesterday" and avoid treating today's data as complete.

6. **`fact_lifetime_ad_record`** is rebuilt hourly and exactly equals `SUM(fact_daily_ad_record)`. It is the most reliable lifetime spend source. The `dim_campaign_lifetime_metrics` comes from Spanner snapshots and may be NULL or stale.

7. **`channel` column = `channel_id`**, not the human-readable name. Map with: `HopperApp` = "Hopper App", `HopperWeb` = "Hopper Web", `vio-web` = "Vio Web", `capone-web` = "Capital One Web".

8. **Conversion records join to spend records** on `(date_utc, campaign_id, ad_set_id, ad_id, zone)`. Note: conversion records use `channel_id` while ad records use `channel`.

9. **Scale context**: ~350-370 active campaigns per day, ~$20-30k total daily spend, ~1.5-2M daily impressions across all campaigns.

## Audience & Reporting Context

The primary users are **campaign managers and ops** who monitor campaign performance, pacing, and report data back to advertisers. **Sales** uses this data to position for future advertiser sales.

When answering questions:
- Always include `campaign_slug` (or `slug`) as the primary campaign identifier — it's more useful than campaign name
- Include `advertiser_name` for context
- Advertiser types are: DMO (destination marketing org), Hotel, Airline, Airport
- Default to excluding FlatRate ad sets from spend/pacing analysis
- For ROAS, default to combined VTA+CTA and note the click-preferred attribution model
- "Placement" = `zone` column in tables
