---
name: seat-upgrades-booking-investigation
description: >
  Use when investigating, debugging, or looking up a seat upgrades booking by bookingId or PNR.
  Covers end-to-end lifecycle: booking details, flight segments, inventory, offer rules, offers,
  orders, seat selections, transactions, and Datadog log analysis for the seat-upgrades service.
  Triggers: "investigate booking", "debug PNR", "check offer", "booking 360",
  "seat upgrade investigation", "why no offer", "offer eligibility", "check PNR",
  "look up booking", "upgrade status", "seat upgrade debug", "offer not created".
---

# Seat Upgrades Booking Investigation

## When to Use This Skill

Invoke this skill when:
- Investigating a seat upgrades booking by PNR or bookingId
- Debugging why offers were or were not created for a booking
- Checking the status of orders, payments, or fulfillment
- Analyzing segment eligibility for cabin upgrades
- Tracing the offer creation pipeline in Datadog logs
- Understanding pricing (reference price, bid range, offer rules)
- Verifying email notifications were sent for a booking

## Inputs

| Parameter | Required | Description |
|-----------|----------|-------------|
| `identifier` | Yes | A bookingId (UUID) or PNR (alphanumeric string) |
| `environment` | Yes | `staging` or `production` |

## Data Sources

- **BigQuery**: Dataset `seat_upgrades__raw_physical` in GCP project `gcp-hopper-app-{environment}`
- **BQ Runner Project**: Use `gcp-hopper-ds-research` as the `--project_id` for running queries
- **Datadog**: Logs from `service:seat-upgrades` filtered by bookingId or PNR

## Investigation Steps

### Step 0 — Resolve the Booking

If the user provides a **PNR**, first resolve it to a bookingId:

```sql
SELECT id AS booking_id, tenant, pnr_reference, created_date_time
FROM `gcp-hopper-app-{env}.seat_upgrades__raw_physical.booking`
WHERE pnr_reference = '{PNR}'
ORDER BY created_date_time DESC
LIMIT 1
```

If the user provides a **bookingId** (UUID), use it directly. Also fetch the tenant:

```sql
SELECT id AS booking_id, tenant, pnr_reference, created_date_time
FROM `gcp-hopper-app-{env}.seat_upgrades__raw_physical.booking`
WHERE id = '{bookingId}'
```

---

### Step 1 — Booking Details

Retrieve the **latest booking snapshot** with all related data. Do NOT include passenger details.

#### 1a. Latest Booking Snapshot

```sql
SELECT
  bs.id AS snapshot_id,
  bs.tenant,
  bs.booking_id,
  bs.eligible,
  bs.ineligibility_reasons,
  bs.total_price,
  bs.currency,
  bs.nb_passengers,
  bs.created_date_time AS snapshot_date
FROM `gcp-hopper-app-{env}.seat_upgrades__raw_physical.booking_snapshot` bs
WHERE bs.booking_id = '{bookingId}'
ORDER BY bs.created_date_time DESC
LIMIT 1
```

#### 1b. Slices & Segments

```sql
SELECT
  sl.id AS slice_id,
  sl.booking_snapshot_id,
  seg.id AS segment_id,
  seg.pss_reference,
  seg.origin_airport_code AS origin,
  seg.destination_airport_code AS destination,
  seg.cabin,
  seg.rbd,
  seg.fare_brand,
  seg.departure_datetime_local,
  seg.arrival_datetime_local,
  seg.marketing_carrier_code,
  seg.marketing_flight_number,
  seg.segment_inventory_snapshot_id
FROM `gcp-hopper-app-{env}.seat_upgrades__raw_physical.slice` sl
JOIN `gcp-hopper-app-{env}.seat_upgrades__raw_physical.segment` seg ON seg.slice_id = sl.id
WHERE sl.booking_snapshot_id = '{snapshotId}'
ORDER BY sl.id, seg.departure_datetime_local
```

#### 1c. Inventory per Segment

For each segment that has a `segment_inventory_snapshot_id`:

```sql
SELECT
  sis.id AS inventory_id,
  sis.aircraft_type,
  sis.configuration_type,
  sis.capacity,
  sis.total_seats_for_sale AS tsfs,
  sis.seats_sold AS ss,
  sis.remaining_seats_for_sale AS rsfs,
  sis.booked_load_factor AS blf,
  cis.cabin_type,
  cis.cabin_code,
  cis.capacity AS cabin_capacity,
  cis.total_seats_for_sale AS cabin_tsfs,
  cis.seats_sold AS cabin_ss,
  cis.remaining_seats_for_sale AS cabin_rsfs,
  cis.booked_load_factor AS cabin_blf,
  cis.bid_price AS cabin_bid_price,
  cis.bid_price_currency AS cabin_bid_currency
FROM `gcp-hopper-app-{env}.seat_upgrades__raw_physical.segment_inventory_snapshot` sis
JOIN `gcp-hopper-app-{env}.seat_upgrades__raw_physical.cabin_inventory_snapshot` cis
  ON cis.segment_inventory_snapshot_id = sis.id
WHERE sis.id IN ({segmentInventorySnapshotIds})
ORDER BY sis.id, cis.cabin_type
```

#### 1d. Partner / PSS

The `tenant` field identifies the partner. Map tenant to PSS:
- `upg-corsair` → Amadeus
- `upg-allegiant` → Navitaire
- `upg-mock` → Mock PSS

#### 1e. Booking History (All Snapshots)

Retrieve ALL booking snapshots to show the full booking lifecycle:

```sql
SELECT
  bs.id AS snapshot_id,
  bs.eligible,
  bs.ineligibility_reasons,
  bs.total_price,
  bs.currency,
  bs.nb_passengers,
  bs.created_date_time AS snapshot_date
FROM `gcp-hopper-app-{env}.seat_upgrades__raw_physical.booking_snapshot` bs
WHERE bs.booking_id = '{bookingId}'
ORDER BY bs.created_date_time ASC
```

#### Present as:

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📋 *BOOKING DETAILS*
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 PNR:          {pnr}
 Tenant:       {tenant}
 PSS:          {pss_name} (derived from tenant)
 Total Price:  {currency} {total_price}
 Eligible:     {eligible} {ineligibility_reasons if not eligible}
 Snapshot:     {snapshot_date}
 Passengers:   {nb_passengers}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
✈️ *FLIGHT SEGMENTS*
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

*Slice 1:*
`{flight_number}  {origin} → {destination}  {departure_date_time_local}`
Cabin: {cabin}  ·  RBD: {rbd}  ·  Fare Brand: {fare_brand}

Inventory:
• *TOTAL* ({config}):  Cap {cap} · TSFS {tsfs} · SS {ss} · RSFS {rsfs} · BLF {blf}
• business ({code}):  Cap {cap} · TSFS {tsfs} · SS {ss} · RSFS {rsfs} · BLF {blf}
• premium_eco ({code}):  Cap {cap} · TSFS {tsfs} · SS {ss} · RSFS {rsfs} · BLF {blf}
• economy ({code}):  Cap {cap} · TSFS {tsfs} · SS {ss} · RSFS {rsfs} · BLF {blf}

(Repeat for each slice)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📜 *BOOKING HISTORY* ({count} snapshots)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Present as a concise timeline showing the evolution of the booking across snapshots:

{HH:MM UTC} — Snapshot #{n}  ·  Eligible: {yes/no}  ·  {currency} {total_price}  ·  {nb_passengers} pax
{HH:MM UTC} — Snapshot #{n}  ·  Eligible: {yes/no}  ·  {currency} {total_price}  ·  {nb_passengers} pax {ineligibility_reasons if any}
                               ↑ Latest snapshot (used for investigation)

If there is only 1 snapshot, show a single line. Only show if multiple snapshots exist or if explicitly requested.

---

### Step 2 — Offer Rules

Using the `pricing_rule_id` found on the offers (Step 3), retrieve the rule details.
If no offers exist yet, skip this step.

First, get the offerRuleId from the offers:

```sql
SELECT DISTINCT offer_rule_id, pricing_rule_id AS rule_name
FROM `gcp-hopper-app-{env}.seat_upgrades__raw_physical.offer`
WHERE booking_snapshot_id = '{snapshotId}'
AND offer_rule_id IS NOT NULL
```

Then for each offer_rule_id:

#### 2a. Rule Details (Conditions/Inputs)

```sql
SELECT
  orv.id AS version_id,
  orv.product,
  orv.published_by,
  orv.published_date_time,
  orl.id AS rule_id,
  orl.name AS rule_name,
  orl.description AS rule_description,
  orl.type AS rule_type,
  orl.enabled,
  orl.origin,
  orl.destination,
  orl.vice_versa,
  orl.availability_start_value,
  orl.availability_start_unit,
  orl.availability_end_value,
  orl.availability_end_unit,
  orl.product_variants
FROM `gcp-hopper-app-{env}.seat_upgrades__raw_physical.offer_rule` orl
JOIN `gcp-hopper-app-{env}.seat_upgrades__raw_physical.offer_rules_version` orv
  ON orv.id = orl.offer_rules_version_id
WHERE orl.id = '{offerRuleId}'
```

#### 2b. Rule Criteria

```sql
SELECT
  criterion,
  operator,
  value,
  compartment
FROM `gcp-hopper-app-{env}.seat_upgrades__raw_physical.offer_rule_criterion`
WHERE offer_rule_id = '{offerRuleId}'
```

#### 2c. Rule Outputs (Pricing/Variants)

```sql
SELECT
  variant_name,
  exposure,
  pricing_strategy_type,
  bidding_enabled,
  instant_purchase_enabled,
  bid_start_fixed_price,
  bid_start_index,
  bid_start_min_index,
  bid_start_max_index,
  bid_end_fixed_price,
  bid_end_use_reference_price,
  bid_end_index,
  bid_end_min_index,
  bid_end_max_index,
  currency
FROM `gcp-hopper-app-{env}.seat_upgrades__raw_physical.offer_rule_output_variant`
WHERE offer_rule_id = '{offerRuleId}'
```

#### Present as:

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📐 *OFFER RULE — {rule_name}*
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 Description:  {rule_description}
 Type:         {rule_type}  ·  Enabled: {enabled}
 Product:      {product}
 Published by: {published_by} on {published_date_time}

*Flight Context:*
  Route:        {origin} → {destination} {vice_versa ? "(& vice versa)" : ""}
  Availability: {start_value} {start_unit} → {end_value} {end_unit} before departure
  Variants:     {product_variants}

*Criteria (Conditions):*
• {criterion} {operator} {value} (compartment: {comp})
• ...

*Output (Pricing):*
• *{variant_name}* — Exposure: {exp}%  ·  {Bidding/Instant/Dual}  ·  {strategy}
    Bid Start: {currency} {start_price}  ·  Bid End: {currency} {end_price}
• ...

---

### Step 3 — Offers

#### 3a. Active Offers (current snapshot)

```sql
SELECT
  o.id AS offer_id,
  o.booking_snapshot_id,
  o.slice_id,
  o.segment_id,
  o.product,
  o.product_variant,
  o.pricing_rule_id AS offer_rule_id,
  o.pricing_variant_id,
  o.reference_price,
  o.instant_purchase_price,
  o.minimum_bid AS bid_start_price,
  o.maximum_bid AS bid_end_price,
  o.recommended_bid,
  o.entry_point,
  o.purchasable,
  o.nb_passengers,
  o.currency,
  o.created_date_time,
  o.expired_date_time,
  seg.origin_airport_code AS origin,
  seg.destination_airport_code AS destination,
  seg.cabin,
  seg.departure_datetime_local
FROM `gcp-hopper-app-{env}.seat_upgrades__raw_physical.offer` o
JOIN `gcp-hopper-app-{env}.seat_upgrades__raw_physical.segment` seg ON seg.id = o.segment_id
WHERE o.booking_snapshot_id = '{snapshotId}'
  AND o.expired_date_time IS NULL
ORDER BY o.created_date_time DESC
```

#### 3b. Offer History (all offers including expired)

```sql
SELECT
  o.id AS offer_id,
  o.booking_snapshot_id,
  o.product_variant,
  o.created_date_time,
  o.expired_date_time,
  seg.origin_airport_code AS origin,
  seg.destination_airport_code AS destination
FROM `gcp-hopper-app-{env}.seat_upgrades__raw_physical.offer` o
JOIN `gcp-hopper-app-{env}.seat_upgrades__raw_physical.segment` seg ON seg.id = o.segment_id
JOIN `gcp-hopper-app-{env}.seat_upgrades__raw_physical.slice` sl ON sl.id = o.slice_id
JOIN `gcp-hopper-app-{env}.seat_upgrades__raw_physical.booking_snapshot` bs ON bs.id = o.booking_snapshot_id
WHERE bs.booking_id = '{bookingId}'
ORDER BY o.created_date_time ASC
```

#### Present as:

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🏷️ *ACTIVE OFFERS ({count} total)*
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

*Offer 1:*
`{origin} → {destination}  ({departure_date_time_local})`
 Cabin:              {cabin}
 Product Variant:    {product_variant} (e.g. Economy → Premium Economy)
 Offer Type:         {Dual/Bidding/Instant}
 Entry Point:        {entry_point}
 Pricing Rule:       {pricing_rule_id}
 Pricing Variant:    {pricing_variant_id}

 _Pricing:_
  Reference Price:        {currency} {reference_price}
  Bid Start Price:        {currency} {bid_start_price}
  Bid End Price:          {currency} {bid_end_price}
  Recommended Bid:        {currency} {recommended_bid}
  Instant Purchase Price: {currency} {instant_purchase_price}

 _Status:_
  Created:  {created_date_time}
  Expires:  {expired_date_time}
  Status:   {Created/Expired based on dates}

(Repeat for each active offer)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📜 *OFFER HISTORY* ({total_count} offers — {active_count} active, {expired_count} expired)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Present as a concise timeline of ALL offers (active and expired) across all snapshots:

{HH:MM UTC} — ✅ {origin}→{destination} {product_variant}  ·  Created (snapshot #{n})
{HH:MM UTC} — ❌ {origin}→{destination} {product_variant}  ·  Expired (superseded by new snapshot)
{HH:MM UTC} — ✅ {origin}→{destination} {product_variant}  ·  Created (snapshot #{n})
                                                            ↑ Current active offers

If there are no expired offers (only 1 snapshot), skip the history timeline.

---

### Step 4 — Orders

#### 4a. Active Orders

```sql
SELECT
  ord.id AS order_id,
  ord.offer_id,
  ord.type AS order_type,
  ord.amount,
  ord.total_amount,
  ord.total_taxes,
  ord.currency,
  ord.nb_passengers,
  ord.ordered_units,
  ord.previous_order_id,
  ord.created_date_time,
  ord.confirmed_date_time,
  ord.fulfilled_date_time,
  ord.failed_date_time,
  ord.failure_type,
  ord.failure_reason,
  ord.canceled_date_time,
  ord.expired_date_time,
  ord.voided_date_time,
  ord.queued_date_time,
  ord.pss_id AS order_pss_id
FROM `gcp-hopper-app-{env}.seat_upgrades__raw_physical.order` ord
WHERE ord.booking_id = '{bookingId}'
  AND ord.expired_date_time IS NULL
  AND ord.canceled_date_time IS NULL
ORDER BY ord.created_date_time DESC
```

#### 4b. Order History (all orders including expired/canceled)

```sql
SELECT
  ord.id AS order_id,
  ord.offer_id,
  ord.type AS order_type,
  ord.amount,
  ord.currency,
  ord.previous_order_id,
  ord.created_date_time,
  ord.confirmed_date_time,
  ord.fulfilled_date_time,
  ord.failed_date_time,
  ord.failure_type,
  ord.canceled_date_time,
  ord.expired_date_time,
  o.product_variant,
  seg.origin_airport_code AS origin,
  seg.destination_airport_code AS destination
FROM `gcp-hopper-app-{env}.seat_upgrades__raw_physical.order` ord
LEFT JOIN `gcp-hopper-app-{env}.seat_upgrades__raw_physical.offer` o ON o.id = ord.offer_id
LEFT JOIN `gcp-hopper-app-{env}.seat_upgrades__raw_physical.segment` seg ON seg.id = o.segment_id
WHERE ord.booking_id = '{bookingId}'
ORDER BY ord.created_date_time ASC
```

Also get seat selections for each order:

```sql
SELECT
  ss.order_id,
  ss.passenger_id,
  ss.seat_number,
  ss.pss_id
FROM `gcp-hopper-app-{env}.seat_upgrades__raw_physical.seat_selection` ss
WHERE ss.order_id IN ({orderIds})
```

For **fulfilled orders only**, also get transactions:

```sql
SELECT
  t.order_id,
  t.amount,
  t.currency,
  t.vendor,
  t.reference,
  t.form_of_payment_id,
  t.pending_authorization_date_time,
  t.authorized_date_time,
  t.pending_capture_date_time,
  t.captured_date_time,
  t.canceled_date_time,
  t.refunded_date_time,
  t.failed_date_time
FROM `gcp-hopper-app-{env}.seat_upgrades__raw_physical.transaction` t
WHERE t.order_id IN ({fulfilledOrderIds})
ORDER BY t.authorized_date_time
```

#### Present as:

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🛒 *ORDERS ({count} total)*
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

*Order 1:*
 Order Type:     {Bidding/Instant Purchase}
 Amount:         {currency} {amount}

 _Status & Timeline:_
  Created:    {created_date_time}
  Confirmed:  {confirmed_date_time or "-"}
  Fulfilled:  {fulfilled_date_time or "-"}
  Failed:     {failed_date_time or "-"} → {failure_type}: {failure_reason}
  Canceled:   {canceled_date_time or "-"}
  Status:     {derive from dates: Created → Confirmed → Fulfilled / Failed / Canceled}

 _Seat Selections:_  {seat_number} (PSS ID: {pss_id}), ...
 _Transactions:_  {currency} {amount} via {vendor}  ·  Authorized: {date}  ·  Captured: {date}  ·  Status: {status}

(Repeat for each active order)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📜 *ORDER HISTORY* ({total_count} orders — {active_count} active, {expired_count} expired, {canceled_count} canceled)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Present as a concise timeline of ALL orders across the booking lifecycle.
Derive status from date fields: created → confirmed → fulfilled / failed / canceled / expired.

{HH:MM UTC} — ✅ {type} {currency} {amount} {origin}→{destination} {product_variant}  ·  Created
{HH:MM UTC} — ❌ {type} {currency} {amount} {origin}→{destination} {product_variant}  ·  Expired (bid modified)
{HH:MM UTC} — ✅ {type} {currency} {amount} {origin}→{destination} {product_variant}  ·  Created (new bid)
{HH:MM UTC} — 🎉 {type} {currency} {amount} {origin}→{destination} {product_variant}  ·  Fulfilled
                                                                                        ↑ Current active orders

Status icons: ✅ Created/Confirmed  ·  🎉 Fulfilled  ·  ❌ Expired  ·  🚫 Canceled  ·  ⚠️ Failed

If there are no expired/canceled orders (only 1 order ever), skip the history timeline.

---

### Step 5 — Email Notifications

Check if emails were sent for this booking:

```sql
SELECT
  pnl.id,
  pnl.booking_id,
  pnl.pnr_reference,
  pnl.status,
  pnl.skip_reason,
  pnl.push_notification_rule_id,
  pnl.schedule_segment_id,
  pnl.processed_at
FROM `gcp-hopper-app-{env}.seat_upgrades__raw_physical.push_notification_log` pnl
WHERE pnl.booking_id = '{bookingId}'
ORDER BY pnl.processed_at DESC
```

#### Present as:

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📧 *EMAIL NOTIFICATIONS ({count} total)*
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

• {processed_at}  ·  {status}  ·  {skip_reason or "-"}
• ...

(Status values: EMAIL_SENT, SKIPPED, etc.)

---

### Step 6 — Segment Eligibility Analysis

For each segment in the booking, analyze why it did or did not receive an offer.
Compare the list of segments (from Step 1b) with the list of offers (from Step 3).

For segments **without an offer**, investigate possible reasons:

1. **No matching offer rule**: The segment's route (origin/destination) may not match any enabled offer rule
2. **Availability window**: The departure date may be outside the offer rule's availability window (e.g., too far or too close to departure)
3. **Cabin already highest**: The passenger is already in the highest cabin class (e.g., business) — no upgrade possible
4. **Inventory constraints**: The target cabin may have no remaining seats for sale (RSFS = 0)
5. **Offer rule criteria not met**: Criteria like booked load factor thresholds may not be satisfied
6. **Product variant not configured**: No product variant exists for the cabin transition (e.g., economy → business may not be configured)

Cross-reference with:
- Offer rules (Step 2) to check route and availability window matching
- Inventory data (Step 1c) to check target cabin availability
- Datadog logs (Step 7) for `[ProcessRules]` logs that show which rules were evaluated and why segments were skipped

#### Present as:

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🔍 *SEGMENT ELIGIBILITY ANALYSIS*
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

*Segment 1: {origin} → {destination} ({departure_datetime_local})*
Current Cabin:  {cabin}
Offers Created: ✅ Yes ({count} — {list of product variants}) / ❌ No
Target Cabins:  {cabin_type} ({code}: {rsfs} RSFS) — {ample/limited/none} availability
{If no offer: Reason: {explanation}}

*Segment 2: {origin} → {destination} ({departure_datetime_local})*
Current Cabin:  {cabin}
Offers Created: ✅ Yes ({count} — {list of product variants}) / ❌ No
Target Cabins:  {cabin_type} ({code}: {rsfs} RSFS) — {ample/limited/none} availability

---

### Step 7 — Log Analysis (Datadog)

Search Datadog logs for the booking lifecycle. Use the bookingId and/or PNR.

#### 7a. Search for all logs related to this booking

Use the Datadog MCP tools:

```
Query: service:seat-upgrades @data.jsonPayload.booking_id:{bookingId}
Time range: based on booking created_date_time (from step 0), extend +/- 24h
```

If PNR is known, also search:
```
Query: service:seat-upgrades @data.jsonPayload.pnr:{pnr}
```

#### 7b. Analyze the logs

Focus on:

1. **Booking Retrieval Flow**
   - Partner PSS call to fetch booking (Navitaire/Allegiant/Amadeus)
   - Duration of the call
   - Any errors or retries

2. **Eligibility Check**
   - Was the booking deemed eligible?
   - If not, what were the ineligibility reasons?

3. **Offer Creation**
   - When were offers created?
   - Which offer rules were evaluated?
   - Reference price retrieval timing

4. **Order Processing** (if applicable)
   - Order creation, payment, confirmation
   - PSS fulfillment call
   - Any failures or timeouts

5. **Error Detection**
   - Look for `status:error` or `status:warn` logs
   - Timeout patterns
   - Partner API failures

#### 7c. Extract Datadog Links

From the Datadog MCP response metadata, extract:
- **Logs Explorer URL**: The `logs_explorer_url` or equivalent link from the search response. This is the direct link to view the matching logs in Datadog UI.
- **APM Trace IDs**: Extract `trace_id` values from log attributes (usually in `dd.trace_id` or `trace_id` field). Build APM links as: `https://app.us5.datadoghq.com/apm/traces?query=trace_id%3A{trace_id}`

#### Present as:

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📊 *LOG ANALYSIS*
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🔗 *Datadog Links:*
• <{logs_explorer_url}|View in Logs Explorer>
• APM Traces:
  • <{apm_trace_url_1}|Trace: {operation_1} ({timestamp_1})>
  • <{apm_trace_url_2}|Trace: {operation_2} ({timestamp_2})>

*Timeline:*
{timestamp} — Booking retrieval started (PSS call to {partner})
{timestamp} — Booking retrieved ({duration}ms)
{timestamp} — Eligibility check: {result}
{timestamp} — Offer creation started
{timestamp} — Reference price fetched ({duration}ms)
{timestamp} — {N} offers created
{timestamp} — Order created (type: {type})
{timestamp} — Payment processed ({duration}ms)
{timestamp} — Order confirmed / failed: {reason}

*API Call Timings:*
• PSS Booking Retrieval:  {ms}ms  ·  {ok/err}
• Reference Price Fetch:  {ms}ms  ·  {ok/err}
• PSS Fulfillment:  {ms}ms  ·  {ok/err}
• Payment Processing:  {ms}ms  ·  {ok/err}

*Issues Detected:*
• {List any errors, timeouts, unusual patterns}
• {Or "No issues detected — booking lifecycle completed normally"}

---

## Output Format

Post the investigation report using `mcp__slack__slack_send_message` with Slack mrkdwn formatting.

**Slack mrkdwn rules — MUST follow:**
- Bold: `*text*` (NOT `**text**`)
- Italic: `_text_`
- NEVER use markdown tables (pipe `|` syntax) — use bullet lists with `·` separators instead
- NEVER use triple backtick code fences — use indented plain text or bullet lists
- Section dividers: `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`
- Links: `<https://url|display text>`

Present the full investigation as a structured report with all sections:
1. Booking Details (with booking history timeline if multiple snapshots)
2. Offer Rules (with criteria and pricing outputs)
3. Offers (active offers detail + offer history timeline if expired offers exist)
4. Orders (with seat selections and transactions)
5. Email Notifications
6. Segment Eligibility Analysis
7. Log Analysis (with Datadog explorer link and APM trace links)

If any section has no data (e.g., no orders yet), clearly state it:
_No orders found for this booking._

## Assumptions and Gotchas

### Offer Lifecycle
1. **Offer expired = new offer created on top**: When a new booking snapshot triggers offer creation, previous offers are expired and replaced by new ones. An expired offer does not mean it timed out — it was superseded.
2. **No `status` column on `offer` table**: Active vs expired is determined by `expired_date_time IS NULL`. There is no explicit status field.
3. **`booking_id` is NULL in the `offer` table**: Always use `booking_snapshot_id` to join offers to a booking, not `booking_id`.
4. **`pricing_rule_id` contains the rule NAME, not a UUID**: e.g. `"ORYPTP Eco to J Exception pricing"`. The actual UUID for joining with `offer_rule.id` is in `offer_rule_id`. Always use `offer_rule_id` for JOINs and `pricing_rule_id` for display.
5. **Filter offers by snapshot AND expiration**: Use `booking_snapshot_id = '{latestSnapshotId}' AND expired_date_time IS NULL` to get current active offers. Otherwise you'll see offers from all previous snapshots.

### Order Lifecycle
6. **Order canceled = two scenarios**: Either the user canceled an order in `created`/`confirmed` status, or a `confirmed` order was modified — the old order is canceled and a new order is created with a new offer.

### Pricing
8. **`reference_price` = 0 or None = fixed/absolute pricing**: When the offer rule uses `manual_pricing` (fixed prices), the reference price is not used. It will be `0` (legacy) or `None` (upcoming). A real reference price only exists for Auto-Pilot rules that compute prices dynamically.

### Booking Snapshots
9. **Multiple booking snapshots can exist**: Each time the booking is re-processed (e.g., new email trigger, schedule change), a new snapshot is created. Always use the latest one (`ORDER BY created_date_time DESC LIMIT 1`).

## Important Notes

- Always start by resolving the bookingId and tenant
- The BQ dataset is `seat_upgrades__raw_physical` in project `gcp-hopper-app-{environment}`
- Use `gcp-hopper-ds-research` as the `--project_id` for running BQ queries
- Use the **latest** booking snapshot (most recent `created_date_time`)
- For Datadog, the service name is `seat-upgrades`
- Offer rules link: offer has `offer_rule_id` (UUID) and `pricing_rule_id` (rule name)
- Do NOT show passenger personal data (names, emails) — only count
- Tenant is critical for multi-tenant isolation — always include it
