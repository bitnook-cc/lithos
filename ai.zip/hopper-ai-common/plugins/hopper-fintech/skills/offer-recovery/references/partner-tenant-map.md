# Partner Tenant Map — Offer Recovery

Mapping of airline partners to their BQ tenant codes for offer/contract lookups.

## Airlines with CFAR + DG

| Partner | Tenant | Carrier | Primary Currency | Offer ID in PNR? |
|---------|--------|---------|-----------------|-------------------|
| Flyadeal | `fa-flyadeal` | F3 | SAR | Yes |
| Frontier | `fa-frontier` | F9 | USD | No |
| Flair | `fa-flair` | F8 | CAD | No |
| HK Express | `fa-hk-express` | UO | HKD | No |
| Volaris | `fa-volaris` | Y4 | MXN, USD | No |
| Oman Air | `fa-omanair` | WY | OMR, USD | No |

## Airlines with DG (Disruption Guarantee)

| Partner | Tenant | Carrier | Primary Currency | Offer ID in PNR? |
|---------|--------|---------|-----------------|-------------------|
| Porter Airlines | `fa-porter` | PD | CAD | No |
| Wizz Air | `fa-wizz` | W6 | EUR (varies) | No |

## Airlines with CFAR Only

| Partner | Tenant | Carrier | Primary Currency | Offer ID in PNR? |
|---------|--------|---------|-----------------|-------------------|
| Air Canada | `fa-air-canada` | AC | CAD | No |
| AirAsia | `fa-air-asia` | AK | Multiple (21) | No |
| Virgin Australia | `fa-virgin-aus` | VA | AUD | No |
| Jazeera Airways | `fa-jazeera` | J9 | Multiple (18) | No |
| Westjet | `fa-westjet` | WS | CAD | No |
| Travix | `fa-travix` | — | Multiple | No |

## Non-Airline Partners

| Partner | Tenant | Notes |
|---------|--------|-------|
| Capital One | `capone` | Hotels CFAR |
| Capital One Corporate | `capone-corporate` | Hotels CFAR |
| Serko | `fa-serko` | Hotels CFAR |
| Cloudbeds | `fa-cloud-beds` | Hotels CFAR |

## Notes

- Tenant codes are used in `session.tenant` (fintech_analytics.events) and `Tenant` (disruption tables)
- The `fa-` prefix indicates a Fintech Ancillaries partner
- Flyadeal is the only partner confirmed to store the HTS offer ID directly in the PNR
- For Wizz Air, offer discovery requires itinerary search — no offer ID in PNR
