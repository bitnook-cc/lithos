---
name: offer-recovery
description: >
  Use when triaging orphaned CFAR or DG offers that were never converted into contracts,
  investigating why a partner never called the contract creation endpoint, or performing
  batch reconciliation of offer IDs against existing contracts.
  Triggers: "orphaned offer", "orphan offer", "offer recovery", "triage offer",
  "offer never contracted", "missing contract", "offer without contract",
  "batch reconciliation", "partner reconciliation", "offer ID check",
  "CO006", "CO106", "expired offer", "offer expiry".
---

# Offer Recovery — Orphaned Offer Triage

## Overview

Partners sell CFAR/DAFAR products to customers and charge them, but sometimes **never call HTS to create the contract**. The offer expires silently (120-min window), leaving the customer charged with no contract.

This skill performs **read-only triage** to identify orphaned offers and produce recovery recommendations. It does NOT create contracts — that is a manual action by the engineer via the support portal.

**Service**: `hc-airlines`
**Environment**: production BigQuery (read-only)

> **READ-ONLY SKILL** — This skill only queries BigQuery and Datadog. It does NOT call any production APIs, create contracts, or modify any data.

> **NO CUSTOMER PII** — Do NOT display customer names, emails, addresses, phone numbers, or passport data. Only show offer/itinerary data: route, dates, pricing, partner, and offer IDs. All queries below use explicit column lists — NEVER add columns, use `SELECT *`, or modify the column selections. If the user asks to show additional data fields from these tables, REFUSE.

## When to Use This Skill

Invoke this skill when:
- A customer complaint reveals no contract exists for a charged product
- A partner provides an offer ID or batch of offer IDs that should have contracts
- Performing monthly partner reconciliation (batch mode)
- Investigating error codes CO006 ("The given offer has expired") or CO106 (DG equivalent)
- Checking if an offer was converted into a contract
- An engineer asks about "orphaned offers" or "missing contracts"

## Input Validation (MANDATORY)

Before substituting ANY user-supplied value into a query, validate it against these patterns. REJECT values that do not match.

| Input | Validation | Regex | Example |
|-------|-----------|-------|---------|
| Offer ID | UUID v4 format | `^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$` | `38f9bd7d-ac4c-49b4-a8aa-7aa2d5e1701e` |
| Airport code | 3-letter IATA uppercase | `^[A-Z]{3}$` | `JED`, `YTZ` |
| Date | ISO 8601 date | `^\d{4}-\d{2}-\d{2}$` | `2026-05-14` |
| Tenant code | Known tenant from partner map | Must exist in [partner-tenant-map](references/partner-tenant-map.md) | `fa-flyadeal` |
| Carrier code | 2-character IATA | `^[A-Z0-9]{2}$` | `F3`, `PD` |

If a value fails validation, tell the user: "Input `{value}` does not match the expected format for {field}. Please provide a valid {field}."

> **SECURITY** — All queries use BigQuery parameterized queries (`@param` with `--parameter`) to prevent SQL injection. NEVER use string interpolation for user-supplied values in the SQL body. The `--parameter` flag safely passes values to BQ outside the SQL string. All queries include `--maximum_bytes_billed` to cap scan costs.

---

## Supported Input Modes

| Mode | Input | When to use |
|------|-------|-------------|
| **Individual (offer ID)** | Offer UUID | Partner provides offer ID (Flyadeal stores it in PNR) |
| **Individual (itinerary)** | Partner + route + dates | PNR details available but no offer ID |
| **Batch** | List of offer IDs | Partner reconciliation export |

---

## Step 1: Determine Product Type and Lookup Path

Ask the user:
1. Do you have an **offer ID** or **itinerary details** (route, dates, partner)?
2. Is this **CFAR** or **DG** (disruption guarantee / DAFAR)?
3. Is this a **single offer** or a **batch**?

If the user provides an offer ID, go to [Step 2a](#step-2a-lookup-by-offer-id).
If the user provides itinerary details, go to [Step 2b](#step-2b-lookup-by-itinerary).
If the user provides a list of offer IDs, go to [Step 2c](#step-2c-batch-lookup).

---

## Step 2a: Lookup by Offer ID

### CFAR Offer Lookup

Run this BQ query to find the offer event and check if a contract was created:

```sql
bq query --project_id=gcp-hopper-ds-research --use_legacy_sql=false --format=prettyjson \
  --maximum_bytes_billed=5000000000 \
  --parameter='offer_id:STRING:{OFFER_ID}' "
WITH offer_events AS (
  SELECT
    occurred_at,
    session.tenant AS tenant,
    session.partner_name AS partner,
    session.id AS session_id,
    JSON_EXTRACT_SCALAR(data, '$.offer.id') AS offer_id,
    JSON_EXTRACT_SCALAR(data, '$.offer.purchase_options[0].premium_amount_total.local_amount') AS premium_local,
    JSON_EXTRACT_SCALAR(data, '$.offer.purchase_options[0].premium_amount_total.usd_amount') AS premium_usd,
    JSON_EXTRACT_SCALAR(data, '$.offer.purchase_options[0].coverage_amount_total.local_amount') AS coverage_local,
    JSON_EXTRACT_SCALAR(data, '$.offer.purchase_options[0].coverage_amount_total.usd_amount') AS coverage_usd,
    JSON_EXTRACT_SCALAR(data, '$.offer.purchase_options[0].coverage_percentage') AS coverage_pct,
    JSON_EXTRACT_SCALAR(data, '$.fare.price.total.local_currency') AS currency,
    JSON_EXTRACT_SCALAR(data, '$.fare.trip.departure_date') AS departure_date,
    JSON_EXTRACT_SCALAR(data, '$.fare.trip.type') AS trip_type,
    JSON_EXTRACT_SCALAR(data, '$.fare.trip.slices[0].origin_airport') AS origin,
    JSON_EXTRACT_SCALAR(data, '$.fare.trip.slices[0].destination_airport') AS destination,
    JSON_EXTRACT_SCALAR(data, '$.fare.trip.slices[0].segments[0].marketing_carrier_code') AS carrier,
    JSON_EXTRACT_SCALAR(data, '$.fare.passenger_count') AS pax_count
  FROM \`gcp-hopper-etldata-production.fintech_analytics.events\`
  WHERE type = 'offer_success'
    AND JSON_EXTRACT_SCALAR(data, '$.offer.id') = @offer_id
    AND occurred_at >= TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 90 DAY)
),
contract_events AS (
  SELECT
    JSON_EXTRACT_SCALAR(data, '$.offer.offer_id') AS offer_id,
    JSON_EXTRACT_SCALAR(data, '$.contract.contract_id') AS contract_id,
    occurred_at AS contract_created_at
  FROM \`gcp-hopper-etldata-production.fintech_analytics.events\`
  WHERE type IN ('contract_request_success', 'contract_purchase_success')
    AND JSON_EXTRACT_SCALAR(data, '$.offer.offer_id') = @offer_id
    AND occurred_at >= TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 90 DAY)
)
SELECT
  o.*,
  c.contract_id,
  c.contract_created_at,
  CASE WHEN c.contract_id IS NULL THEN 'ORPHANED' ELSE 'HAS_CONTRACT' END AS status,
  TIMESTAMP_DIFF(CURRENT_TIMESTAMP(), o.occurred_at, HOUR) AS offer_age_hours
FROM offer_events o
LEFT JOIN contract_events c ON TRUE
LIMIT 1
"
```

Replace `{OFFER_ID}` with the validated offer UUID (must match UUID regex).

### Also check the CFAR contract table directly

```sql
bq query --project_id=gcp-hopper-ds-research --use_legacy_sql=false --format=prettyjson \
  --maximum_bytes_billed=5000000000 \
  --parameter='offer_id:STRING:{OFFER_ID}' "
SELECT contract_id, tenant, state, premium_amount_usd, coverage_amount_usd,
       currency, purchase_ts
FROM \`gcp-hopper-etldata-production.cfar_air.contract\`
WHERE contract_id = @offer_id
"
```

> In the CFAR system, `contract_id` shares the same ID as the companion quote/offer. If this query returns no rows, no contract was created from this offer.

### DG Offer Lookup

For DG (disruption guarantee) offers, query the dedicated offers table:

```sql
bq query --project_id=gcp-hopper-ds-research --use_legacy_sql=false --format=prettyjson \
  --maximum_bytes_billed=5000000000 \
  --parameter='offer_id:STRING:{OFFER_ID}' "
SELECT
  OfferId,
  Tenant,
  Owner,
  ProductType,
  PremiumAmount,
  PremiumAmountUsd,
  BookingAmountUsd,
  MaxLiabilityAmountUsd,
  Currency,
  Members,
  OfferedTime,
  ExpirationTime,
  DraftContractId,
  TripDetails,
  TIMESTAMP_DIFF(CURRENT_TIMESTAMP(), OfferedTime, HOUR) AS offer_age_hours,
  CASE WHEN DraftContractId IS NULL THEN 'ORPHANED' ELSE 'HAS_CONTRACT' END AS status
FROM \`gcp-hopper-etldata-production.disruption_offers.GeneratedQuoteTable\`
WHERE OfferId = @offer_id
"
```

If `DraftContractId` is NULL, the offer is orphaned. If populated, verify the contract exists:

```sql
bq query --project_id=gcp-hopper-ds-research --use_legacy_sql=false --format=prettyjson \
  --maximum_bytes_billed=5000000000 \
  --parameter='contract_id:STRING:{CONTRACT_ID}' "
SELECT ContractId, Tenant, ContractState, PremiumAmountUsd, BookingAmountUsd,
       Currency, PurchasedTime
FROM \`gcp-hopper-etldata-production.disruption_contract.ContractTable\`
WHERE ContractId = @contract_id
"
```

---

## Step 2b: Lookup by Itinerary

When no offer ID is available, search by itinerary attributes. Requires at minimum: **partner/tenant** + **route** (origin + destination) + **approximate date range**.

### CFAR Itinerary Search

```sql
bq query --project_id=gcp-hopper-ds-research --use_legacy_sql=false --format=prettyjson \
  --maximum_bytes_billed=5000000000 \
  --parameter='tenant:STRING:{TENANT}' \
  --parameter='start_date:STRING:{START_DATE}' \
  --parameter='end_date:STRING:{END_DATE}' \
  --parameter='origin:STRING:{ORIGIN}' \
  --parameter='destination:STRING:{DESTINATION}' "
WITH offers AS (
  SELECT
    occurred_at,
    session.tenant AS tenant,
    session.partner_name AS partner,
    session.id AS session_id,
    JSON_EXTRACT_SCALAR(data, '$.offer.id') AS offer_id,
    JSON_EXTRACT_SCALAR(data, '$.offer.purchase_options[0].premium_amount_total.local_amount') AS premium_local,
    JSON_EXTRACT_SCALAR(data, '$.offer.purchase_options[0].premium_amount_total.usd_amount') AS premium_usd,
    JSON_EXTRACT_SCALAR(data, '$.offer.purchase_options[0].coverage_amount_total.local_amount') AS coverage_local,
    JSON_EXTRACT_SCALAR(data, '$.offer.purchase_options[0].coverage_amount_total.usd_amount') AS coverage_usd,
    JSON_EXTRACT_SCALAR(data, '$.fare.price.total.local_currency') AS currency,
    JSON_EXTRACT_SCALAR(data, '$.fare.trip.departure_date') AS departure_date,
    JSON_EXTRACT_SCALAR(data, '$.fare.trip.slices[0].origin_airport') AS origin,
    JSON_EXTRACT_SCALAR(data, '$.fare.trip.slices[0].destination_airport') AS destination,
    JSON_EXTRACT_SCALAR(data, '$.fare.trip.slices[0].segments[0].marketing_carrier_code') AS carrier
  FROM \`gcp-hopper-etldata-production.fintech_analytics.events\`
  WHERE type = 'offer_success'
    AND session.tenant = @tenant
    AND occurred_at >= TIMESTAMP(@start_date)
    AND occurred_at <= TIMESTAMP(@end_date)
),
contracts AS (
  SELECT contract_id
  FROM \`gcp-hopper-etldata-production.cfar_air.contract\`
  WHERE tenant = @tenant
)
SELECT
  o.*,
  CASE WHEN c.contract_id IS NULL THEN 'ORPHANED' ELSE 'HAS_CONTRACT' END AS status,
  TIMESTAMP_DIFF(CURRENT_TIMESTAMP(), o.occurred_at, HOUR) AS offer_age_hours
FROM offers o
LEFT JOIN contracts c ON o.offer_id = c.contract_id
WHERE o.origin = @origin
  AND o.destination = @destination
ORDER BY o.occurred_at DESC
LIMIT 20
"
```

Replace (all values validated before substitution — see Input Validation):
- `{TENANT}` — e.g., `fa-flyadeal`, `fa-wizz` (see [Partner Tenant Map](references/partner-tenant-map.md))
- `{ORIGIN}`, `{DESTINATION}` — 3-letter IATA airport codes (uppercase)
- `{START_DATE}`, `{END_DATE}` — ISO 8601 dates (e.g., `2026-05-01`, `2026-05-15`)

If multiple orphaned offers match, narrow by premium amount, carrier, or creation timestamp. Ask the user which one matches.

### DG Itinerary Search

```sql
bq query --project_id=gcp-hopper-ds-research --use_legacy_sql=false --format=prettyjson \
  --maximum_bytes_billed=5000000000 \
  --parameter='tenant:STRING:{TENANT}' \
  --parameter='start_date:STRING:{START_DATE}' \
  --parameter='end_date:STRING:{END_DATE}' \
  --parameter='origin:STRING:{ORIGIN}' \
  --parameter='destination:STRING:{DESTINATION}' "
SELECT
  OfferId,
  Tenant,
  ProductType,
  PremiumAmount,
  PremiumAmountUsd,
  Currency,
  OfferedTime,
  ExpirationTime,
  DraftContractId,
  TripDetails,
  CASE WHEN DraftContractId IS NULL THEN 'ORPHANED' ELSE 'HAS_CONTRACT' END AS status,
  TIMESTAMP_DIFF(CURRENT_TIMESTAMP(), OfferedTime, HOUR) AS offer_age_hours
FROM \`gcp-hopper-etldata-production.disruption_offers.GeneratedQuoteTable\`
WHERE Tenant = @tenant
  AND OfferedTime >= TIMESTAMP(@start_date)
  AND OfferedTime <= TIMESTAMP(@end_date)
  AND TripDetails LIKE CONCAT('%', @origin, '%')
  AND TripDetails LIKE CONCAT('%', @destination, '%')
ORDER BY OfferedTime DESC
LIMIT 20
"
```

---

## Step 2c: Batch Lookup

For a list of offer IDs (e.g., from a partner reconciliation export), check each against contracts.

> **BATCH SIZE LIMIT** — Maximum 50 offer IDs per batch query. If the user provides more than 50, split into multiple batches of 50 and run sequentially. This prevents unbounded BQ scan costs. Each offer ID MUST pass UUID validation before inclusion.

### CFAR Batch

```sql
bq query --project_id=gcp-hopper-ds-research --use_legacy_sql=false --format=prettyjson \
  --maximum_bytes_billed=10000000000 "
WITH offer_ids AS (
  SELECT offer_id FROM UNNEST([
    '{OFFER_ID_1}',
    '{OFFER_ID_2}',
    '{OFFER_ID_3}'
  ]) AS offer_id
),
contracts AS (
  SELECT contract_id
  FROM \`gcp-hopper-etldata-production.cfar_air.contract\`
  WHERE contract_id IN (
    '{OFFER_ID_1}',
    '{OFFER_ID_2}',
    '{OFFER_ID_3}'
  )
),
offer_events AS (
  SELECT
    JSON_EXTRACT_SCALAR(data, '$.offer.id') AS offer_id,
    session.tenant AS tenant,
    JSON_EXTRACT_SCALAR(data, '$.offer.purchase_options[0].premium_amount_total.usd_amount') AS premium_usd,
    JSON_EXTRACT_SCALAR(data, '$.fare.price.total.local_currency') AS currency,
    JSON_EXTRACT_SCALAR(data, '$.fare.trip.slices[0].origin_airport') AS origin,
    JSON_EXTRACT_SCALAR(data, '$.fare.trip.slices[0].destination_airport') AS destination,
    JSON_EXTRACT_SCALAR(data, '$.fare.trip.departure_date') AS departure_date,
    occurred_at,
    TIMESTAMP_DIFF(CURRENT_TIMESTAMP(), occurred_at, HOUR) AS offer_age_hours
  FROM \`gcp-hopper-etldata-production.fintech_analytics.events\`
  WHERE type = 'offer_success'
    AND JSON_EXTRACT_SCALAR(data, '$.offer.id') IN (
      '{OFFER_ID_1}',
      '{OFFER_ID_2}',
      '{OFFER_ID_3}'
    )
    AND occurred_at >= TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 90 DAY)
)
SELECT
  oi.offer_id,
  oe.tenant,
  oe.premium_usd,
  oe.currency,
  oe.origin,
  oe.destination,
  oe.departure_date,
  oe.offer_age_hours,
  CASE WHEN c.contract_id IS NOT NULL THEN 'HAS_CONTRACT'
       WHEN oe.offer_id IS NULL THEN 'NOT_FOUND'
       ELSE 'ORPHANED' END AS status
FROM offer_ids oi
LEFT JOIN offer_events oe ON oi.offer_id = oe.offer_id
LEFT JOIN contracts c ON oi.offer_id = c.contract_id
ORDER BY status, oi.offer_id
"
```

> Each `{OFFER_ID_N}` must pass UUID validation. Max 50 IDs per query — split larger batches.

### DG Batch

```sql
bq query --project_id=gcp-hopper-ds-research --use_legacy_sql=false --format=prettyjson \
  --maximum_bytes_billed=10000000000 "
SELECT
  OfferId,
  Tenant,
  ProductType,
  PremiumAmountUsd,
  Currency,
  OfferedTime,
  DraftContractId,
  TIMESTAMP_DIFF(CURRENT_TIMESTAMP(), OfferedTime, HOUR) AS offer_age_hours,
  CASE WHEN DraftContractId IS NULL THEN 'ORPHANED' ELSE 'HAS_CONTRACT' END AS status
FROM \`gcp-hopper-etldata-production.disruption_offers.GeneratedQuoteTable\`
WHERE OfferId IN (
  '{OFFER_ID_1}',
  '{OFFER_ID_2}',
  '{OFFER_ID_3}'
)
ORDER BY status, OfferId
"
```

> Each `{OFFER_ID_N}` must pass UUID validation. Max 50 IDs per query — split larger batches.

---

## Step 3: Check Datadog for Contract Creation Attempts

If an offer is orphaned, check whether the partner *attempted* to create a contract but failed:

```
Search Datadog logs using mcp__datadog__search_datadog_logs:
  query: "service:hc-airlines {OFFER_ID}"
  timeframe: last 7 days (or adjust to offer creation window)
```

Look for:
- **CO006** — "The given offer has expired" (CFAR). Means the partner called too late.
- **CO106** — DG equivalent of CO006.
- **Contract creation request** — any log showing the partner attempted `POST /contracts`.
- **No logs at all** — the partner never called HTS.

Report what you find:
- "Partner attempted contract creation but got CO006 (expired)" — timing issue
- "No contract creation attempt found in logs" — partner never called

---

## Step 4: Produce Triage Report

Format the output as a clear Slack-formatted report. Use this template:

### Individual Offer Report

```
*Offer Triage Report*

*Offer ID:* `{offer_id}`
*Partner:* {partner} ({tenant})
*Product:* CFAR / DG
*Premium:* {premium} {currency} (${premium_usd} USD)
*Coverage:* {coverage} {currency} (${coverage_usd} USD)
*Route:* {origin} -> {destination} | {carrier}
*Departure:* {departure_date}
*Trip type:* {trip_type}
*Passengers:* {pax_count}

*Offer created:* {occurred_at} ({offer_age_hours}h ago)
*Offer expired:* {expiry_status}
*Contract:* {ORPHANED / HAS_CONTRACT with contract_id}

*Contract creation attempts:* {Datadog findings}

---

*Recommendation:*
{see recommendation logic below}

*Email suppression:*
{see email suppression guidance below}

*To create the contract:*
Open the Support Portal form and fill in the required fields:
- CFAR: https://cloud.portal.hopper.com/airline/cfar/offers/{offer_id}/create-contract
- DG: https://cloud.portal.hopper.com/airline/dg/offers/{offer_id}/create-contract

Form fields:
- *Offer ID*: `{offer_id}` (pre-populated from URL)
- *PNR Reference*: (ask partner/customer for PNR)
- *Product*: CFAR or DG
- *Suppress Email*: {true/false recommendation}
- *Price Override*: (if partner-charged amount differs from offer)
- *Reason*: orphaned_offer

The developer does NOT call the API directly — the portal form handles submission.
```

### Batch Report

```
*Batch Triage Report — {partner}*

*Summary:* {X} of {Y} offers have contracts. {Z} orphaned.

| # | Offer ID | Product | Premium | Route | Dep Date | Age | Status |
|---|----------|---------|---------|-------|----------|-----|--------|
| 1 | {id}...  | CFAR    | ${amt}  | {rte} | {date}   | {h}h | ORPHANED |
| 2 | {id}...  | DG      | ${amt}  | {rte} | {date}   | {h}h | HAS_CONTRACT |
...

*Orphaned offers ({Z} total):*
All > 24h old — confirmation emails auto-suppressed.

*Recovery links:*
For each orphaned offer, provide a direct Support Portal link:
- CFAR: https://cloud.portal.hopper.com/airline/cfar/offers/{offer_id}/create-contract
- DG: https://cloud.portal.hopper.com/airline/dg/offers/{offer_id}/create-contract

*Notes:*
- DG PostBooking callbacks will fire on confirmation
- Consider partner communication before bulk recovery
```

### Recommendation Logic

| Condition | Recommendation |
|-----------|---------------|
| Orphaned, no contract creation attempts | "Recoverable. Partner never called contract creation endpoint." |
| Orphaned, CO006/CO106 in logs | "Recoverable. Partner attempted but offer had expired (120-min window)." |
| Has contract | "No action needed — contract {id} exists." |
| Offer not found in BQ | "Offer ID not found. Check if the ID is correct, or if it's older than 90 days (BQ retention)." |

### Email Suppression Guidance

| Offer Age | Recommendation |
|-----------|---------------|
| < 24 hours | "Email WILL be sent on confirmation. Set `suppressEmail: true` if not desired." |
| >= 24 hours | "Email will be AUTO-SUPPRESSED (offer age exceeds threshold)." |
| Any age with `priceOverride` | "CFAR: auto-suppressed (PartnerBackfill source). DG: check age or set `suppressEmail: true`." |

---

## Per-Partner Runbooks

### Flyadeal (`fa-flyadeal`)

- **Offer ID source**: Stored directly in the booking PNR
- **Lookup**: Direct offer ID query (Step 2a)
- **Products**: CFAR + DG
- **Currency**: SAR
- **Routes**: Saudi domestic (JED, RUH, DMM, etc.)

### Wizz Air (`fa-wizz`)

- **Offer ID source**: NOT stored in PNR — use itinerary search (Step 2b)
- **Lookup**: Search by route + dates + premium match
- **Products**: DG (primarily)
- **Currency**: EUR (varies by route)
- **Notes**: Batch reconciliation common. Monthly extracts may contain many orphans. Pricing discrepancies common — use `priceOverride`.

### Porter Airlines (`fa-porter`)

- **Offer ID source**: NOT stored in PNR — use itinerary search (Step 2b)
- **Lookup**: Search by route + dates + premium match
- **Products**: DG
- **Currency**: CAD
- **Routes**: Canadian domestic (YTZ, YOW, YUL, YHZ, etc.)
- **Notes**: Recently launched DG partner. No offer ID in PNR — always use itinerary-based lookup.

### AirAsia (`fa-air-asia`)

- **Offer ID source**: May or may not be available
- **Lookup**: Offer ID if available, otherwise itinerary search
- **Products**: CFAR + DG
- **Currency**: Multiple (21 currencies)

### Other Partners

For any partner not listed above:
1. Check [Partner Tenant Map](references/partner-tenant-map.md) for the tenant code
2. Use offer ID if available, otherwise itinerary search
3. Check per-partner DG callback behavior before recovery

---

## Data Source Reference

| Table | Dataset | Key Fields | Purpose |
|-------|---------|------------|---------|
| `events` | `fintech_analytics` | `type`, `data` (JSON), `session.tenant`, `occurred_at` | Offer and contract lifecycle events |
| `contract` | `cfar_air` | `contract_id`, `tenant`, `state`, `premium_amount_usd` | CFAR contract existence check |
| `contract` | `cfar_core` | `contract_id`, `tenant`, `state` | Cross-domain CFAR check |
| `GeneratedQuoteTable` | `disruption_offers` | `OfferId`, `Tenant`, `DraftContractId`, `TripDetails` | DG offer lookup + orphan check |
| `ContractTable` | `disruption_contract` | `ContractId`, `Tenant`, `ContractState` | DG contract existence check |

All tables in project `gcp-hopper-etldata-production`.
BQ billing project: `gcp-hopper-ds-research`.

---

## Cross-References

- [cfar-qa](hopper-fintech:cfar-qa) — CFAR contract investigation, partner credentials, API sequences
- [dafar-qa](hopper-fintech:dafar-qa) — DG contract investigation, exercise triage
- [analytics-events](hopper-fintech:analytics-events) — Event timeline exploration, session lookups
- [cfar-fraud-review](hopper-fintech:cfar-fraud-review) — Fraud signal review if recovery is suspicious

## Related

- **RFC**: [Offer Recovery Tool — Contract Creation for Orphaned Offers](https://hopper-jira.atlassian.net/wiki/spaces/HAAS/pages/8676737077)
- **Jira**: [HTSFA-4382](https://hopper-jira.atlassian.net/browse/HTSFA-4382)
- **Error codes**: CO006 (CFAR offer expired), CO106 (DG offer expired)
- **Offer expiry**: 120 minutes (`OfferValidity = Duration.ofMinutes(120)`)
- **Support Portal** (contract creation form):
  - CFAR: `https://cloud.portal.hopper.com/airline/cfar/offers/{offerId}/create-contract`
  - DG: `https://cloud.portal.hopper.com/airline/dg/offers/{offerId}/create-contract`
