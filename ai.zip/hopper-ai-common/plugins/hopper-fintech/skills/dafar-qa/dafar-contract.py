#!/usr/bin/env python3
# /// script
# requires-python = ">=3.11"
# dependencies = []
# ///
"""DAFAR Contract QA Helper

Quick CLI for common DAFAR contract queries and analysis.

Usage:
    uv run dafar-contract.py datadog {contract_id} [--env staging]
    uv run dafar-contract.py bq-events {session_id} [--env staging]
    uv run dafar-contract.py trace-links {trace_id}

Examples:
    uv run dafar-contract.py datadog 1f129120-b123-6618-9eaf-210438752fcd
    uv run dafar-contract.py bq-events 995ca711-7ff6-4dea-8294-a5c4cf9bda7a
    uv run dafar-contract.py trace-links 44744553554486329
"""

import argparse
import sys


def datadog_query(contract_id: str, env: str = "staging") -> str:
    """Generate Datadog log search query for a contract."""
    return f"service:hc-airlines env:{env} {contract_id}"


def bq_events_query(session_id: str, env: str = "staging") -> str:
    """Generate BigQuery query for session events."""
    project = f"gcp-hopper-etldata-{env}"
    return f"""
SELECT
  occurred_at,
  type,
  JSON_EXTRACT_SCALAR(data, '$.dg_contract_id') as contract_id,
  JSON_EXTRACT_SCALAR(data, '$.type') as event_data_type,
  session.partner_name,
  data
FROM `{project}.hc_analytics.events_v2`
WHERE session.id = '{session_id}'
  AND occurred_at > TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 7 DAY)
ORDER BY occurred_at
LIMIT 100
""".strip()


def bq_contract_query(contract_id: str, env: str = "staging") -> str:
    """Generate BigQuery query for contract events."""
    project = f"gcp-hopper-etldata-{env}"
    return f"""
SELECT
  occurred_at,
  type,
  entity_id,
  session.id as session_id,
  session.partner_name,
  data
FROM `{project}.hc_analytics.events_v2`
WHERE occurred_at > TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 7 DAY)
  AND (
    entity_id = '{contract_id}'
    OR JSON_EXTRACT_SCALAR(data, '$.dg_contract_id') = '{contract_id}'
  )
ORDER BY occurred_at
LIMIT 100
""".strip()


def trace_link(trace_id: str, site: str = "us5.datadoghq.com") -> str:
    """Generate Datadog APM trace link."""
    return f"https://app.{site}/apm/traces?query=trace_id:{trace_id}"


def cmd_datadog(args: argparse.Namespace) -> None:
    """Print Datadog query for contract."""
    query = datadog_query(args.contract_id, args.env)
    print(f"Datadog Query:")
    print(f"  {query}")
    print()
    print(f"Direct link:")
    print(f"  https://app.us5.datadoghq.com/logs?query={query.replace(' ', '%20')}")


def cmd_bq_events(args: argparse.Namespace) -> None:
    """Print BigQuery query for session events."""
    query = bq_events_query(args.session_id, args.env)
    print("BigQuery Query (session events):")
    print(query)
    print()
    print("Run with:")
    print(f"  bq query --project_id=gcp-hopper-ds-research --use_legacy_sql=false '{query}'")


def cmd_bq_contract(args: argparse.Namespace) -> None:
    """Print BigQuery query for contract events."""
    query = bq_contract_query(args.contract_id, args.env)
    print("BigQuery Query (contract events):")
    print(query)
    print()
    print("Run with:")
    print(f"  bq query --project_id=gcp-hopper-ds-research --use_legacy_sql=false '{query}'")


def cmd_trace_links(args: argparse.Namespace) -> None:
    """Print APM trace link."""
    link = trace_link(args.trace_id, args.site)
    print(f"Datadog APM Trace:")
    print(f"  {link}")


def main() -> None:
    parser = argparse.ArgumentParser(description="DAFAR Contract QA Helper")
    parser.add_argument("--env", default="staging", choices=["staging", "production"],
                        help="Environment (default: staging)")
    parser.add_argument("--site", default="us5.datadoghq.com",
                        help="Datadog site (default: us5.datadoghq.com)")

    sub = parser.add_subparsers(dest="command", required=True)

    # datadog command
    p = sub.add_parser("datadog", help="Generate Datadog log query for contract")
    p.add_argument("contract_id", help="Contract UUID")
    p.set_defaults(func=cmd_datadog)

    # bq-events command
    p = sub.add_parser("bq-events", help="Generate BigQuery query for session events")
    p.add_argument("session_id", help="Session UUID")
    p.set_defaults(func=cmd_bq_events)

    # bq-contract command
    p = sub.add_parser("bq-contract", help="Generate BigQuery query for contract events")
    p.add_argument("contract_id", help="Contract UUID")
    p.set_defaults(func=cmd_bq_contract)

    # trace-links command
    p = sub.add_parser("trace-links", help="Generate Datadog APM trace link")
    p.add_argument("trace_id", help="Datadog trace ID")
    p.set_defaults(func=cmd_trace_links)

    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
