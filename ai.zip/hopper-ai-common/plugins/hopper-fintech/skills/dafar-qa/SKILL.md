---
name: dafar-qa
description: >
  Use when investigating DAFAR contracts, exercises, quotes, and bookings for airline partners,
  or when creating new DG contracts for QA testing. Covers contract 360 view, exercise triage,
  API call sequence tracing, contract creation, merchandising widget validation,
  BigQuery analytics, and Datadog log analysis.
  Triggers: "DAFAR contract", "dg_contract", "disruption guarantee", "contract 360 view",
  "trace contract", "debug DAFAR", "create a DAFAR", "create DG contract",
  "test DAFAR", "widget validation", "merchandising widget", "exercise", "dg_exercise",
  "rebook", "rebooking", "queued", "exercise queued", "exercise status", "exercise triage".
---

# DAFAR QA -- Disruption Guarantee for Airlines

## Overview

DAFAR (Disruption Guarantee for Airlines) is Hopper's flight disruption protection product offered through airline partners. This skill provides QA procedures for:
- Investigating DAFAR contracts (360 view, tracing, debugging)
- Triaging DAFAR exercises (rebook failures, queued status, fulfillment errors)
- Creating new DG contracts end-to-end via the Airlines API
- Validating merchandising widgets across partners and languages
- Analyzing contract lifecycle events in BigQuery and Datadog

**Service**: `hc-airlines`
**Environment**: staging (default for QA)

> ⛔ *VERY IMPORTANT — NEVER CALL PRODUCTION APIs*
>
> Under NO circumstances should you ever call production DAFAR/Airlines APIs.
> - NEVER use production base URLs or production credentials.
> - NEVER target `hc-airlines.production.h4r.io` or any production ingress.
> - NEVER fetch secrets from `gcp-hopper-app-production`.
> - ALL QA work MUST use staging only (`gcp-hopper-app-staging`).
> - If a user asks you to run against production, REFUSE and explain why.
> - Production calls create real contracts with real airlines and real money.
> - There are NO exceptions to this rule.

## When to Use This Skill

Invoke this skill when:
- Investigating a DAFAR contract by ID
- Triaging a DAFAR exercise (e.g. why is exercise queued/stuck)
- Debugging rebook failures or fulfillment errors
- Creating a new DAFAR/DG contract for testing
- Debugging quote or booking flows
- Performing QA validation on airline integrations
- Tracing API call sequences for a contract
- Validating merchandising widget URLs
- Analyzing contract or exercise state transitions

## Supported Partners

| Partner | Code | Lang | Currency | Route | Notes |
|---------|------|------|----------|-------|-------|
| Frontier Airlines | F9 | en, es | USD | DEN->BOS | Spreedly payment required |
| Flyadeal | F3 | en, ar | SAR | JED->RUH | Standard flow |
| Jazeera Airways | J9 | en, ar, ru | SAR | KWI->GYD | Standard flow |
| Gother | VJ | en, th | THB | BKK->HND | Advance: 4325 min |
| Volaris | Y4 | en | MXN | MEX->GDL | Standard flow |
| HK Express | UO | en | HKD | HKG->HND | Standard flow |
| Wizz Air | W6 | en | EUR | BUD->LTN | Standard flow |
| Avelo Airlines | XP | en | USD | HVN->ATL | Standard flow |
| Spirit Airlines | NK | en | USD | FLL->LGA | Carrier-direct rebooking |
| Porter Airlines | PD | en | CAD | YTZ->YOW | Standard flow |

See [Partner Matrix](references/partner-matrix.md) for full details (currencies, airports, timezones, env vars).
See [Partner Specifics](references/partner-specifics.md) for per-partner behavioral differences.

## Partner Credentials (Staging Only)

All partner OAuth credentials are consolidated in a *single* GCP Secret Manager secret:

- **Secret name**: `hts-airlines-staging-oauth-conf`
- **Project**: `gcp-hopper-app-staging`

The secret is a JSON object with keys following the pattern `{partner}-id` and `{partner}-secret`.

**Available credential keys**:

| Partner | Client ID Key | Client Secret Key |
|---------|---------------|-------------------|
| Air Canada | `air-canada-id` | `air-canada-secret` |
| Air Asia | `air-asia-id` | `air-asia-secret` |
| Flyadeal | `flyadeal-id` | `flyadeal-secret` |
| Spirit | `spirit-id` | `spirit-secret` |
| Virgin Australia | `virgin-australia-id` | `virgin-australia-secret` |
| Viva Aerobus | `viva-aerobus-id` | `viva-aerobus-secret` |
| Volaris | `volaris-id` | `volaris-secret` |
| Wizz Air | `wizz-air-id` | `wizz-air-secret` |
| Avelo Airlines | `avelo-airlines-id` | `avelo-airlines-secret` |
| Porter Airlines | `porter-id` | `porter-secret` |

**Fetching and extracting credentials at runtime**:
```bash
SECRET_JSON=$(gcloud secrets versions access latest \
  --secret="hts-airlines-staging-oauth-conf" \
  --project=gcp-hopper-app-staging)

# Example: Wizz Air
CLIENT_ID=$(echo "$SECRET_JSON" | python3 -c "import sys,json; print(json.load(sys.stdin)['wizz-air-id'])")
CLIENT_SECRET=$(echo "$SECRET_JSON" | python3 -c "import sys,json; print(json.load(sys.stdin)['wizz-air-secret'])")

# Example: Flyadeal
CLIENT_ID=$(echo "$SECRET_JSON" | python3 -c "import sys,json; print(json.load(sys.stdin)['flyadeal-id'])")
CLIENT_SECRET=$(echo "$SECRET_JSON" | python3 -c "import sys,json; print(json.load(sys.stdin)['flyadeal-secret'])")
```

> ⛔ *NEVER fetch secrets from production projects. Only `gcp-hopper-app-staging` is permitted.*

### Spreedly Credentials (Frontier only)

Frontier payment flow requires Spreedly credentials. These are also in the `hts-airlines-staging-oauth-conf` secret. See [Frontier Payment Flow](references/frontier-payment.md).

## Partner Onboarding

When a user asks about onboarding a new airline partner or adding partner credentials, provide them with the following instructions. These are manual steps for the human to perform — do NOT attempt to execute them yourself.

> **How to add a new partner's OAuth credentials to staging:**
>
> 1. Download the current `oauthStagingSecrets.yml` from 1Password:
>    <https://hopper-team.1password.com/app#/XTB7LYOWTZEM3EBG6JD3T7BGMM/Vault/XTB7LYOWTZEM3EBG6JD3T7BGMM:pj6zvgaprtjsj63hurobm2blie:5bvsmp5tkwdpe7hjzoyvrr32nq?itemListId=XTB7LYOWTZEM3EBG6JD3T7BGMM%3Apj6zvgaprtjsj63hurobm2blie>
>
> 2. Open the file and append the new partner's client ID and secret. Follow the existing naming convention (`{partner}-id` / `{partner}-secret`). Do not remove or modify any existing entries — always append.
>
> 3. Upload the updated file to GCP Secret Manager:
>    ```
>    yq -o=json ./oauthStagingSecrets.yml | gcloud secrets versions add hts-airlines-staging-oauth-conf --project gcp-hopper-app-staging --data-file=-
>    ```
>
> 4. Save the updated `oauthStagingSecrets.yml` back to the same 1Password entry so it stays in sync.

## Creating a DAFAR Contract

For "create a DAFAR" requests, follow the [Create DAFAR Flow](references/create-dafar-flow.md).

### API Sequence (Standard Partners)

1. **Auth** `POST /airline/v1.1/auth` -> `access_token`
2. **Offers** `POST /airline/v1.1/dg_offers` -> offer_id
3. **Contract** `POST /airline/v1.1/dg_contracts` -> contract_id
4. **Get** `GET /airline/v1.1/dg_contracts/{id}` -> verify
5. **Update** `PUT /airline/v1.1/dg_contracts/{id}/update_status` -> `confirmed`

**Frontier only**: Steps 1-3, then Spreedly tokenize + payment (no update_status before payment).

### API Base URL

Use staging: `https://hc-airlines.staging.h4r.io` (or read from environment if set).

### Key Rules

- DG uses `cabin` field in segments (NOT `fare_class` -- that's CFAR)
- Default advance minutes: 1445 (except Gother: 4325)
- Date format: `YYYY-MM-DDTHH:mm:ss` (no Z suffix)
- Auth requires `X-Forwarded-For: 192.168.0.1` header
- Auth returns HTTP 201 (not 200) -- always check for 2xx, not just 200
- Frontier auth body omits `audience` and `grant_type`; all others include both
- Pricing must be realistic for the currency -- see [Partner Specifics: Realistic Pricing](references/partner-specifics.md#realistic-pricing-by-currency-of033-prevention). Using HKD-scale values (e.g. "20000") for SAR, EUR, etc. causes OF033 errors
- Always confirm the contract (update_status -> confirmed) unless user says otherwise
- After DG offers, always extract and display the `merchandising_url` from the offer response
- After completion, display both the merchandising URL and the cloud portal URL:
  `https://cloud.portal.staging.hopper.com/airline/dg/{contractId}?&advanced=true`
- **Merchandising URL display**: Always present the merchandising URL inside a code block (`` ``` ``), NEVER as a Slack `<url|text>` link. The `offerData` query parameter contains a long base64-encoded payload that Slack link formatting corrupts, causing `SyntaxError: Expected ',' or '}'` in the widget. The cloud portal URL (short) can safely use Slack link format.

### Execution

Use a single `python3` script for the full API sequence. See reference files for request/response schemas:
- [Standard Flow](references/standard-flow.md)
- [Frontier Payment](references/frontier-payment.md)
- [DG Offers Schema](references/dg-offers-schema.md)
- [DG Contracts Schema](references/dg-contracts-schema.md)
- [DG Update Schema](references/dg-update-schema.md)

### Email for Confirmation

Resolve confirmation email using this priority:
1. Use trigger user email from Slack context (`Email` field)
2. Use a generated test email (`dg.<timestamp>@example.com`) if unavailable

## Merchandising Widget Validation

When testing widgets, run DG offers for each partner/language combo and validate that `merchandising_url` is returned and accessible.

See [Widget Combos](references/widget-combos.md) for the full 12-combination test matrix.

Test with `-x-invis` suffix on point_of_sale for invisible widget tracking (e.g., `US-x-invis`).

## Contract Investigation (360 View)

When given a contract ID, provide a comprehensive view.

### Data Sources

#### 1. Datadog Logs
**Service**: `hc-airlines`
**Environment**: `staging` (default)

Prefer the Datadog MCP server tools (`mcp__datadog__*`) when available. The `hopper-fintech` plugin declares a Datadog MCP server in `.mcp.json`.

If Datadog MCP tools are not loaded, fall back to the Datadog REST API via curl:
- API base URL: `https://api.${DD_SITE}` -- always use `$DD_SITE`, never hardcode
- Auth headers: `DD-API-KEY: $DD_API_KEY` and `DD-APPLICATION-KEY: $DD_APP_KEY`

```bash
curl -s -X POST "https://api.${DD_SITE}/api/v2/logs/events/search" \
  -H "Content-Type: application/json" \
  -H "DD-API-KEY: $DD_API_KEY" \
  -H "DD-APPLICATION-KEY: $DD_APP_KEY" \
  -d '{
    "filter": {
      "query": "service:hc-airlines env:staging {contract_id}",
      "from": "now-30d",
      "to": "now"
    },
    "sort": "timestamp",
    "page": { "limit": 50 }
  }'
```

#### 2. BigQuery Analytics Events
**Table**: `gcp-hopper-etldata-staging.hc_analytics.events_v2`

**Important**: DAFAR contract IDs are NOT in `entity_id`. They are embedded in the `data` JSON payload. Use `TO_JSON_STRING(data) LIKE '%{contract_id}%'` or extract via `JSON_EXTRACT_SCALAR(data, '$.dgEventProperties.dgPurchaseProperties.contractId')`.

**Known DAFAR event types** (in lifecycle order):

*Contract events:*
1. `cfar_offers_eligible_partner` -- session init / partner eligibility
2. `dg_offers_request` -- offer/quote requested
3. `dg_contract_request` -- contract creation requested
4. `dg_complete_buy` -- contract purchased
5. `booking_confirmed` -- booking confirmed with PNR
6. `dg_purchase_email_sent` -- confirmation email sent

*Exercise events:*
7. `cfar_exercise_eligible_partner` -- exercise session init / partner eligibility
8. `dg_exercise_request` -- exercise initiated (result: `eligible` or `ineligible`)
9. `fa_exercise_initiated` -- exercise created successfully
10. `dg_exercise_verification_sent` -- verification code sent to customer
11. `dg_exercise_verification_complete` -- customer verified identity
12. `dg_rebooking_alternatives` -- rebooking alternatives loaded for customer
13. `dg_rebooking_request` -- customer submitted rebook choice (check `choiceType`: `rebook` or `cash_refund`)
14. `dg_rebooking_complete` -- rebooking confirmed with new PNR

**Tip**: If the last event is `dg_rebooking_request` with no `dg_rebooking_complete`, the exercise is stuck — check Datadog for fulfillment errors.

**Sample query -- find events by contract ID**:
```sql
SELECT
  occurred_at,
  type,
  session.id as session_id,
  session.tenant,
  JSON_EXTRACT_SCALAR(data, '$.dgEventProperties.dgPurchaseProperties.contractId') as contract_id,
  data
FROM `gcp-hopper-etldata-staging.hc_analytics.events_v2`
WHERE occurred_at > TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 7 DAY)
  AND session.tenant = '{tenant}'
  AND TO_JSON_STRING(data) LIKE '%{contract_id}%'
ORDER BY occurred_at
```

**Sample query -- find all events in a session**:
```sql
SELECT
  occurred_at,
  type,
  session.id as session_id,
  session.tenant,
  JSON_EXTRACT_SCALAR(data, '$.dgEventProperties.dgPurchaseProperties.contractId') as contract_id,
  data
FROM `gcp-hopper-etldata-staging.hc_analytics.events_v2`
WHERE occurred_at > TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 7 DAY)
  AND session.id = '{session_id}'
ORDER BY occurred_at
```

### 360 View Procedure

When given a contract ID:

1. **Overview**: Contract ID, reference, PNR, partner, environment, status, session ID
2. **API Call Sequence Timeline**: Trace full lifecycle (offer -> contract -> confirmation -> events)
3. **Flight Itinerary**: Routes, flight numbers, times, cabin class
4. **Coverage & Pricing**: Base fare, ancillaries, premium, coverage %, cap
5. **Passengers**: Count, type, references
6. **Ancillaries**: Price per type
7. **Product Terms**: Max hours before departure, min delay, expiry
8. **Infrastructure & Traces**: Service version, Datadog trace IDs with APM links

### Output Format

Use **Slack mrkdwn** (NOT GitHub markdown):
```
*360 View: Contract `{contract_id}`*

*Overview*
- *Contract ID*: `{contract_id}`
- *Reference*: `{reference}`
- *PNR*: `{pnr}`
- *Partner*: {partner_name} (`{tenant}`)
- *Status*: {status}

*API Call Sequence*
*0. Offer Creation* (HH:MM:SS UTC)
...

*Datadog Traces*
- <https://${DD_SITE}/apm/traces?query=trace_id:{trace_id}|Contract Creation>
```

## Exercise Investigation (Triage)

When given an exercise ID (or asked why an exercise is stuck/queued), follow this procedure:

### Step 1: Find the exercise in Datadog

Search for the exercise ID across all log messages:
```
service:hc-airlines env:staging {exercise_id}
```
From the results, extract:
- Contract ID, PNR, partner/tenant, session ID
- Exercise status (`created`, `queued`, `confirmed`)
- Whether it was a rebook or cash refund (`choiceType`)

### Step 2: Check BigQuery for the last recorded event

```sql
SELECT
  occurred_at,
  type,
  session.id as session_id,
  JSON_EXTRACT_SCALAR(data, '$.dgEventProperties.dgExerciseProperties.choiceType') as choice_type,
  JSON_EXTRACT_SCALAR(data, '$.dgEventProperties.dgRebookingProperties.id') as rebooking_id,
  JSON_EXTRACT_SCALAR(data, '$.dgEventProperties.dgRebookingProperties.sliceValidatingCarrier') as rebook_carrier,
  JSON_EXTRACT_SCALAR(data, '$.result.type') as result_type
FROM `gcp-hopper-etldata-staging.hc_analytics.events_v2`
WHERE occurred_at > TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 7 DAY)
  AND TO_JSON_STRING(data) LIKE '%{exercise_id}%'
ORDER BY occurred_at
```

**Key diagnostic**: Compare the last event to the expected lifecycle. If `dg_rebooking_request` exists but `dg_rebooking_complete` does not, the rebooking failed or is still processing.

### Step 3: Search for the rebooking error

If the exercise is `queued` after a rebook attempt, search for the automated rebooking error:
```
service:hc-airlines env:staging "Error occurred when performing automated rebooking" OR "Could not process automated rebooking"
```
Filter by the time window from Step 1. The error stack trace will contain a fulfillment error code (e.g., `FU008`).

Also search for the auto-rebook decision logs:
```
service:hc-airlines env:staging "Routing booking to Lexington" OR "manual rebooking" OR "Preparing quote for automated rebooking"
```

### Exercise Status Reference

| Status | Meaning | How it gets there |
|--------|---------|-------------------|
| `created` | Exercise initiated, disruption verified | Customer starts exercise flow |
| `queued` | Waiting for manual CS rebooking | Automated rebooking failed (see error codes below), or auto-rebook not eligible |
| `confirmed` | Rebooking completed successfully | Automated: Pub/Sub `Ticketed` event received. Manual: CS agent confirmed via support API |

### Automated vs Manual Rebooking

When a customer chooses to rebook, `isAutomatedRebookingEligible()` in `DgExerciseService.scala` evaluates:

| Condition | Auto-rebook? | Notes |
|-----------|-------------|-------|
| `autoRebookingEnabled` flag off | No → `queued` | LaunchDarkly feature flag per partner |
| Customer has checked bags | No → `queued` | Unless same-airline + free bags exception applies |
| Unsupported travel document type | No → `queued` | Only passport and national ID supported |
| Alternative is Ryanair (FR) | No → `queued` | Hardcoded in `airlinesFallbackToManualRebooking` |
| Health SSR on disrupted slice | No → `queued` | Partner config: `requireManualRebookingForHealthSsr` |
| All checks pass | Yes → Lexington | Routes to automated fulfillment pipeline |

If automated rebooking is attempted but fails (exception in `processAutomatedRebooking`), the `recoverWith` block sets status to `queued` and sends a rebooking request email for CS manual handling.

### Fulfillment Error Codes

When automated rebooking fails, the error code appears in the stack trace. See [Exercise Error Codes](references/exercise-error-codes.md).

### Rebooking Architecture

- **Lexington**: Standard HTSFA booking pipeline (quote → discount → fulfill). Async — completion arrives via Pub/Sub `BookingStatus.Ticketed` event through `AirBookingStatusChangeStream`
- **Spirit**: Carrier-direct API (`modifyJourney`). Synchronous — confirmed immediately

Cross-carrier rebooks (e.g., W6→KL) go through Lexington and are more likely to fail with fulfillment errors in staging.

### Output Format

When presenting exercise triage results, always include links to help the user dig deeper:

**Datadog Logs link**: The Datadog MCP tools return a `logs_explorer_url` in their metadata. Always include this in the output so the user can view the full log stream. If using the REST API fallback, construct the link manually:
```
https://us5.datadoghq.com/logs?query=service%3Ahc-airlines+env%3Astaging+{exercise_id}&from_ts={from_epoch_ms}&to_ts={to_epoch_ms}
```

**Source code links**: When the root cause maps to a specific code path, include a GitHub link to the relevant file and line in `hopper-cloud-airlines`. Key files:

| Scenario | File | What to link |
|----------|------|--------------|
| Auto-rebook eligibility | `hc-airlines-core/.../service/dg/DgExerciseService.scala` | `isAutomatedRebookingEligible` method |
| Auto-rebook failure/recovery | `hc-airlines-core/.../service/dg/DgExerciseService.scala` | `processAutomatedRebooking` method and `recoverWith` block |
| Fulfillment error (FU007–FU012) | `hc-airlines-core/.../service/commerce/AirlinesFulfillService.scala` | `pollFulfill` method |
| Lexington booking routing | `hc-airlines-core/.../service/commerce/RebookingService.scala` | `processLexingtonRebooking` method |

Format code links as:
```
https://github.com/hopper-org/hopper-cloud-airlines/blob/master/{path}
```

**Cloud Portal link**: Always include the portal link for the contract:
```
https://cloud.portal.staging.hopper.com/airline/dg/{contractId}?&advanced=true
```

**Example output structure** (Slack mrkdwn):
```
*Exercise Triage: `{exercise_id}`*

*Summary*
- *Status*: `queued` — automated rebooking failed with `FU008` (Fulfillment Aborted)
- *Contract*: `{contract_id}` | *PNR*: `{pnr}` | *Partner*: Wizz Air (`fa-wizz`)
- *Choice*: rebook (W6→KL, cross-carrier)

*Timeline*
...

*Root Cause*
...

*Links*
- <{datadog_logs_url}|Datadog Logs>
- <{github_code_url}|Source: DgExerciseService.scala (processAutomatedRebooking)>
- <{cloud_portal_url}|Cloud Portal>
```

## Contract Lifecycle

See [Status Transitions](references/status-transitions.md) and [Portal URLs](references/portal-urls.md).

## Self-Healing

When testing reveals discrepancies between documented behavior and actual API responses:
1. Create a branch from `master` named `fix/dafar-qa-{short-description}`
2. Update the relevant files under `plugins/hopper-fintech/skills/dafar-qa/` (SKILL.md or references)
3. Open a draft PR to `hopper-ai-common` with evidence of what changed
4. Do NOT merge -- a human must review

Only self-heal for confirmed, reproducible discrepancies. Do not speculate.

## Debugging Tips

### Missing Logs
1. Verify the contract ID is correct
2. Check the environment (staging vs production)
3. Expand time window
4. Try searching by reference number or session ID

### Missing BigQuery Events
1. Events may lag by several minutes
2. Query by `session.id` instead of contract ID for pre-purchase events
3. Search `TO_JSON_STRING(data)` with LIKE
4. Expand `occurred_at` range

### Incomplete API Call Sequence
- Offer creation logs may exceed retention window
- Use trace IDs for related APM spans
