# Standard DG API Flow - Request/Response Reference

## 1. Authentication

### Request
```json
POST /airline/v1.1/auth
Headers:
  Content-Type: application/json
  X-Forwarded-For: 192.168.0.1

{
  "client_id": "<{partner}-id from hts-airlines-staging-oauth-conf>",
  "client_secret": "<{partner}-secret from hts-airlines-staging-oauth-conf>",
  "audience": "https://airlines-api.staging.hopper.com",
  "grant_type": "client_credentials"
}
```

Note: Frontier does not send `audience` or `grant_type`. All other partners include both fields.

### Response (2xx)
```json
{
  "access_token": "eyJ...",
  "token_type": "bearer",
  "expires_in": 54000
}
```

## 2. Create DG Offers

### Standard Partner Request (HK Express, Flyadeal, Jazeera, Gother, Volaris)
```json
POST /airline/v1.1/dg_offers
Headers:
  Content-Type: application/json
  Authorization: Bearer <access_token>

{
  "request_type": "ancillary",
  "itinerary": [
    {
      "ancillaries": [
        {
          "covered": true,
          "passenger_reference": "PASSENGER1",
          "total_price": "139.70",
          "type": "cabin_bag"
        },
        {
          "covered": true,
          "passenger_reference": "PASSENGER1",
          "total_price": "1190.00",
          "type": "checked_bag"
        },
        {
          "covered": true,
          "passenger_reference": "PASSENGER1",
          "total_price": "930.00",
          "type": "seat"
        }
      ],
      "currency": "<partner_currency>",
      "passenger_pricing": [
        {
          "individual_price": "20000",
          "passenger_count": {
            "count": 1,
            "type": "adult"
          }
        }
      ],
      "passengers": [
        {
          "first_name": "John",
          "gender": "male",
          "last_name": "Doe",
          "passenger_reference": "PASSENGER1",
          "passenger_type": "adult",
          "nationality": "HK"
        }
      ],
      "slices": [
        {
          "segments": [
            {
              "origin_airport": "<IATA>",
              "destination_airport": "<IATA>",
              "departure_date_time": "<ISO8601_no_Z>",
              "arrival_date_time": "<ISO8601_no_Z>",
              "flight_number": "1234",
              "validating_carrier_code": "<carrier_code>",
              "cabin": "economy"
            }
          ]
        },
        {
          "segments": [
            {
              "origin_airport": "<IATA>",
              "destination_airport": "<IATA>",
              "departure_date_time": "<ISO8601_no_Z>",
              "arrival_date_time": "<ISO8601_no_Z>",
              "flight_number": "1235",
              "validating_carrier_code": "<carrier_code>",
              "cabin": "economy"
            }
          ]
        }
      ],
      "total_price": "<calculated_total>"
    }
  ],
  "session": {
    "point_of_sale": "<country_code>",
    "language": "<lang_code>"
  }
}
```

### Key Rules
- Uses `cabin` field (values: economy, business, first) - NOT `fare_class` (that is CFAR)
- Date format: `YYYY-MM-DDTHH:mm:ss` (no `Z` suffix, no timezone offset)
- `total_price` = sum of passenger pricing + ancillary totals
- Ancillaries include `covered: true` and `passenger_reference` for standard partners
- Advance minutes default: 1445 (1 day + 5 min), except Gother: 4325 (3 days + 5 min)
- **Auth returns HTTP 201** (not 200) — always check for 2xx, not just 200
- **Pricing must be realistic for the currency** — the example below uses HKD values (individual_price "20000"). For other currencies (SAR, EUR, MXN, etc.), use the per-currency defaults from [Partner Specifics: Realistic Pricing](partner-specifics.md#realistic-pricing-by-currency-of033-prevention) to avoid OF033 errors

### Response (2xx)
```json
[
  {
    "id": "<offer_id>",
    "premium": "<amount>",
    "coverage": "<amount>",
    "currency": "<currency_code>",
    "merchandising_url": "<url>"
  }
]
```

Note: Response is an array. Extract `[0].id` as the offer ID.

## 3. Create DG Contract

### Standard Partner Request
```json
POST /airline/v1.1/dg_contracts
Headers:
  Content-Type: application/json
  Authorization: Bearer <access_token>

{
  "offer_ids": ["<offer_id_from_step_2>"],
  "itinerary": {
    "ancillaries": [
      {
        "covered": true,
        "passenger_reference": "PASSENGER1",
        "total_price": "139.70",
        "type": "cabin_bag"
      },
      {
        "covered": true,
        "passenger_reference": "PASSENGER1",
        "total_price": "1190.00",
        "type": "checked_bag"
      },
      {
        "covered": true,
        "passenger_reference": "PASSENGER1",
        "total_price": "930.00",
        "type": "seat"
      }
    ],
    "currency": "<partner_currency>",
    "passenger_pricing": [
      {
        "individual_price": "20000",
        "passenger_count": {
          "count": 1,
          "type": "adult"
        }
      }
    ],
    "passengers": [
      {
        "first_name": "John",
        "gender": "male",
        "last_name": "Doe",
        "passenger_reference": "PASSENGER1",
        "passenger_type": "adult",
        "nationality": "HK"
      }
    ],
    "slices": [ ... ],
    "total_price": "<calculated_total>"
  }
}
```

Note: The itinerary structure is the same as step 2, but is a single object (not wrapped in an array). The `offer_ids` array must contain the offer ID from the offers response.

### Response (2xx)
```json
{
  "id": "<contract_id>",
  "reference": "<contract_reference>",
  "status": "created",
  "offer_ids": ["<offer_id>"],
  "premium": "<amount>",
  "coverage": "<amount>"
}
```

## 4. Get DG Contract

### Request
```
GET /airline/v1.1/dg_contracts/<contract_id>
Headers:
  Authorization: Bearer <access_token>
```

### Response (2xx)
Returns full contract object matching the creation response with additional details.

## 5. Update DG Contract Status

### Request
```json
PUT /airline/v1.1/dg_contracts/<contract_id>/update_status
Headers:
  Content-Type: application/json
  Authorization: Bearer <access_token>

{
  "status": "confirmed",
  "pnr_reference": "123ABC",
  "email_address": "test@example.com"
}
```

Note: Wait ~1 second after contract creation before calling update_status.

### Response (2xx)
```json
{
  "contract_id": "<contract_id>",
  "status": "confirmed",
  "pnr_reference": "123ABC"
}
```

## Date/Time Calculation

Itinerary dates must be dynamically calculated:

1. Get the current time at the **origin airport's timezone** (using UTC offset)
2. Add `advanceMinutes` to get the outbound departure time
3. For return flights: add `advanceMinutes` + 8 hours
4. Calculate arrival time by adding the flight duration
5. Format as `YYYY-MM-DDTHH:mm:ss` (no Z suffix)

## Validation Checklist

- [ ] Auth returns valid token
- [ ] DG offers return an array with at least one offer containing `id`, `premium`, and `coverage`
- [ ] Contract creation uses offer_ids from offers response
- [ ] Contract GET returns matching contract_id and status
- [ ] Status update transitions contract to "confirmed"
- [ ] All currency values match the partner's configured currency
- [ ] Language in session matches partner's supported languages
- [ ] Step status codes are HTTP 2xx (not necessarily 200)
