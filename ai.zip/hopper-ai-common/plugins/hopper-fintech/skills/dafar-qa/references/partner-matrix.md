# DAFAR Partner Configuration Matrix

| Partner | Carrier Code | Credential Keys (in `hts-airlines-staging-oauth-conf`) | Languages | Default Currency | All Currencies | Airports | Default Route | Advance Min | Point of Sale |
|---|---|---|---|---|---|---|---|---|---|
| Frontier Airlines | F9 | `frontier-id` / `frontier-secret` | en, es | USD | USD | GRB, DEN, BOS | DEN -> BOS | 1445 | US |
| Flyadeal | F3 | `flyadeal-id` / `flyadeal-secret` | en, ar | SAR | SAR, USD | JED, RUH | JED -> RUH | 1445 | SA |
| Jazeera Airways | J9 | `jazeera-id` / `jazeera-secret` | en, ar, ru | SAR | KWD, SAR, USD, EGP, JOD, INR, AED, EUR, LKR, BHD, QAR, OMR, BDT, LBP, PKR, GEL, KZT, ETB, NPR | KWI, GYD | KWI -> GYD | 1445 | KW |
| Gother | VJ | `gother-id` / `gother-secret` | en, th | THB | THB, USD, EUR | BKK, HND, JFK, LAX | BKK -> HND | 4325 | TH |
| Volaris | Y4 | `volaris-id` / `volaris-secret` | en | MXN | MXN, USD | MEX, GDL, CUN, TIJ | MEX -> GDL | 1445 | MX |
| HK Express | UO | `hkexpress-id` / `hkexpress-secret` | en | HKD | HKD, JPY, KRW, TWD, THB, CNY, PHP, USD, MYR | HKG, PKX, CZX, HND | HKG -> HND | 1445 | HK |
| Wizz Air | W6 | `wizz-air-id` / `wizz-air-secret` | en | EUR | EUR (validated) | BUD, LTN (validated) | BUD -> LTN | 1445 | HU |
| Air Canada | AC | `air-canada-id` / `air-canada-secret` | en | CAD | CAD, USD | YYZ, YVR | TBD | 1445 | CA |
| Air Asia | AK | `air-asia-id` / `air-asia-secret` | en | MYR | MYR, USD | KUL, SIN | TBD | 1445 | MY |
| Spirit | NK | `spirit-id` / `spirit-secret` | en | USD | USD | FLL, LGA | FLL -> LGA | 1445 | US |
| Virgin Australia | VA | `virgin-australia-id` / `virgin-australia-secret` | en | AUD | AUD, USD | SYD, MEL | TBD | 1445 | AU |
| Viva Aerobus | VB | `viva-aerobus-id` / `viva-aerobus-secret` | en, es | MXN | MXN, USD | MEX, CUN | TBD | 1445 | MX |
| Avelo Airlines | XP | `avelo-airlines-id` / `avelo-airlines-secret` | en | USD | USD | HVN, ATL | HVN -> ATL | 1445 | US |
| Porter Airlines | PD | `porter-id` / `porter-secret` | en | CAD | CAD, USD | YTZ, YOW | YTZ -> YOW | 1445 | CA |

All credentials are in a single secret: `hts-airlines-staging-oauth-conf` in `gcp-hopper-app-staging`.

## API Connectivity (from Hopper AI / gcp-hopper-cicd)

The documented base URL `https://hc-airlines.staging.h4r.io` is NOT resolvable from the Hopper AI pod (which runs in `gcp-hopper-cicd`). Use the partner-api ingress gateway instead:

| Property | Value |
|---|---|
| Ingress IP | `34.111.178.58` |
| Host header | `airlines-api.staging.hopper.com` |
| Auth audience | `https://airlines-api.staging.hopper.com` |

**curl example:**
```bash
curl -sk -H "Host: airlines-api.staging.hopper.com" \
  https://34.111.178.58/airline/v1.1/auth
```

**In Python (urllib):**
```python
BASE_URL = "https://34.111.178.58"
HOST     = "airlines-api.staging.hopper.com"
# Include -H "Host: {HOST}" in all curl calls, or set Host header in urllib requests
```

Note: The `requests` library is NOT available in the Hopper AI runtime. Use `curl` via `subprocess` or `urllib` from the standard library.

## Auth Body Patterns

All credentials come from the single secret `hts-airlines-staging-oauth-conf` in `gcp-hopper-app-staging`.

**Frontier** (no audience/grant_type):
```json
{ "client_id": "<{partner}-id>", "client_secret": "<{partner}-secret>" }
```

**All other partners** (with audience/grant_type):
```json
{ "client_id": "<{partner}-id>", "client_secret": "<{partner}-secret>", "audience": "https://airlines-api.staging.hopper.com", "grant_type": "client_credentials" }
```

## Point of Sale Mapping (by currency)

| Currency | Point of Sale |
|---|---|
| USD | US |
| HKD | HK |
| THB | TH |
| SAR | SA |
| KWD | KW |
| MXN | MX |
| EUR | DE |
| GBP | UK |
| JPY | JP |

For widget testing, append `-x-invis` suffix (e.g., `US-x-invis`).

Wizz Air validation note: EUR requests were validated with `point_of_sale=HU`.

For Russian language, use currency-based point of sale instead of language-based.

## Flight Duration Reference (minutes)

| Route | Duration |
|---|---|
| GRB <-> DEN | 120 |
| DEN -> BOS | 210 |
| BOS -> DEN | 270 |
| JED <-> RUH | 90 |
| KWI <-> GYD | 150 |
| BKK -> HND | 420 |
| HND -> BKK | 390 |
| HKG <-> PKX | 195 |
| HKG <-> CZX | 120 |
| HKG <-> HND | 210 |
| MEX <-> GDL | 75 |
| MEX <-> CUN | 130 |
| MEX <-> TIJ | 210 |
| BUD <-> LTN | 150 |
| HVN -> ATL | 150 |
| ATL -> HVN | 150 |
| FLL -> LGA | 180 |
| LGA -> FLL | 180 |
| YTZ -> YOW | 60 |
| YOW -> YTZ | 60 |

## Airport Timezones (UTC offset)

| Airport | UTC Offset |
|---|---|
| GRB | -6 |
| DEN | -6 |
| BOS | -4 |
| JED | +3 |
| RUH | +3 |
| KWI | +3 |
| GYD | +4 |
| BKK | +7 |
| HND | +9 |
| JFK | -5 |
| LAX | -8 |
| HKG | +8 |
| PKX | +8 |
| CZX | +8 |
| MEX | -6 |
| GDL | -6 |
| CUN | -5 |
| TIJ | -8 |
| BUD | +2 |
| LTN | +1 |
| HVN | -4 |
| ATL | -4 |
| FLL | -4 |
| LGA | -4 |
| YTZ | -4 |
| YOW | -4 |

## Itinerary Types

All partners support:
- One-way (single slice, single segment)
- Round-trip (two slices, one segment each)

## Passenger Types

- 1 adult (individual_price varies by currency — see [Partner Specifics: Realistic Pricing](partner-specifics.md#realistic-pricing-by-currency-of033-prevention))
- 2 adults (same individual_price, count=2)
- Frontier uses specific passengers: 2 adults (price: "430.18") + 1 lap_infant (price: "10.00")

**Important**: Do NOT use "20000" as a universal default — it is only valid for HKD. Using HKD-scale values for SAR, EUR, or other currencies causes OF033 failures in staging.

## Default Test Data

- Standard passenger name: "John Doe"
- Standard passenger reference: "PASSENGER1"
- Frontier passenger references: "4ed2e42a", "dbf81ef8", "44e2c64f"
- PNR reference: "123ABC"
- Email: configurable at runtime
