# Frontier Airlines - Spreedly Payment Flow

Frontier is the only DAFAR partner that requires payment tokenization. After the standard DG flow (auth -> offers -> contract -> confirm), two additional steps are required.

## Frontier-Specific Details

- Carrier code: `F9`
- Currency: USD only
- Airports: GRB (Green Bay), DEN (Denver), BOS (Boston)
- Default origin: DEN, default destination: BOS
- Uses hardcoded flight numbers: 787 (outbound), 786 (return)
- Advance minutes: 1445 (1 day + 5 minutes)
- Auth body does NOT include `audience` or `grant_type` fields
- In staging, offers can fail with `OF033` if departure is too soon; use first departure at least ~48 hours in the future

## Frontier Auth Request

```json
POST /airline/v1.1/auth
Headers:
  Content-Type: application/json
  X-Forwarded-For: 192.168.0.1

{
  "client_id": "<frontier-id from hts-airlines-staging-oauth-conf>",
  "client_secret": "<frontier-secret from hts-airlines-staging-oauth-conf>"
}
```

## Frontier DG Offers Request

```json
POST /airline/v1.1/dg_offers
Headers:
  Content-Type: application/json
  Authorization: Bearer <access_token>

{
  "request_type": "ancillary",
  "itinerary": [
    {
      "passengers": [
        {
          "passenger_reference": "4ed2e42a",
          "passenger_type": "adult"
        },
        {
          "passenger_reference": "dbf81ef8",
          "passenger_type": "adult"
        },
        {
          "passenger_reference": "44e2c64f",
          "passenger_type": "lap_infant"
        }
      ],
      "passenger_pricing": [
        {
          "passenger_count": {
            "count": 2,
            "type": "adult"
          },
          "individual_price": "430.18"
        },
        {
          "passenger_count": {
            "count": 1,
            "type": "lap_infant"
          },
          "individual_price": "10.00"
        }
      ],
      "slices": [
        {
          "segments": [
            {
              "origin_airport": "GRB",
              "destination_airport": "DEN",
              "departure_date_time": "<calculated>",
              "arrival_date_time": "<calculated>",
              "flight_number": "787",
              "validating_carrier_code": "F9",
              "cabin": "economy"
            }
          ]
        },
        {
          "segments": [
            {
              "origin_airport": "DEN",
              "destination_airport": "GRB",
              "departure_date_time": "<calculated>",
              "arrival_date_time": "<calculated>",
              "flight_number": "786",
              "validating_carrier_code": "F9",
              "cabin": "economy"
            }
          ]
        }
      ],
      "ancillaries": [
        {
          "passenger_reference": "4ed2e42a",
          "total_price": "15.00",
          "type": "checked_bag"
        },
        {
          "total_price": "5.00",
          "type": "seat"
        },
        {
          "total_price": "5.00",
          "type": "seat"
        },
        {
          "total_price": "5.00",
          "type": "seat"
        }
      ],
      "currency": "USD"
    }
  ],
  "session": {
    "point_of_sale": "US",
    "language": "EN",
    "user_info": {
      "airline_user_id": "frequent-flyer-123456789"
    }
  }
}
```

### Key Differences from Standard Partners
- Includes `passengers` array with specific references (including `lap_infant`)
- Includes `user_info.airline_user_id` in session
- Ancillaries do NOT have `covered` or `passenger_reference` on all items
- Multiple `passenger_pricing` entries (adults + lap_infant)

## Frontier DG Contract Request

```json
POST /airline/v1.1/dg_contracts
Headers:
  Content-Type: application/json
  Authorization: Bearer <access_token>

{
  "offer_ids": ["<offer_id>"],
  "itinerary": {
    "passengers": [
      {
        "passenger_reference": "4ed2e42a",
        "passenger_type": "adult"
      },
      {
        "passenger_reference": "dbf81ef8",
        "passenger_type": "adult"
      },
      {
        "passenger_reference": "44e2c64f",
        "passenger_type": "lap_infant"
      }
    ],
    "passenger_pricing": [
      {
        "passenger_count": {
          "count": 2,
          "type": "adult"
        },
        "individual_price": "430.18"
      },
      {
        "passenger_count": {
          "count": 1,
          "type": "lap_infant"
        },
        "individual_price": "10.00"
      }
    ],
    "slices": [
      {
        "segments": [
          {
            "origin_airport": "GRB",
            "destination_airport": "DEN",
            "departure_date_time": "<calculated>",
            "arrival_date_time": "<calculated>",
            "flight_number": "787",
            "validating_carrier_code": "F9",
            "cabin": "economy"
          }
        ]
      },
      {
        "segments": [
          {
            "origin_airport": "DEN",
            "destination_airport": "GRB",
            "departure_date_time": "<calculated>",
            "arrival_date_time": "<calculated>",
            "flight_number": "786",
            "validating_carrier_code": "F9",
            "cabin": "economy"
          }
        ]
      }
    ],
    "ancillaries": [
      {
        "passenger_reference": "4ed2e42a",
        "total_price": "15.00",
        "type": "checked_bag"
      },
      {
        "total_price": "5.00",
        "type": "seat"
      },
      {
        "total_price": "5.00",
        "type": "seat"
      },
      {
        "total_price": "5.00",
        "type": "seat"
      }
    ],
    "currency": "USD"
  }
}
```

Note: Itinerary is a single object (not an array) in the contract request.

## Step 6: Tokenize Payment via Spreedly

### Request
```json
POST https://core.spreedly.com/v1/payment_methods.json
Headers:
  Content-Type: application/json
  Authorization: Basic <base64(spreedly_username:spreedly_password)>

{
  "payment_method": {
    "email": "test@example.com",
    "credit_card": {
      "number": "4111111111111111",
      "month": "09",
      "year": "2029",
      "first_name": "John",
      "last_name": "Smith",
      "address1": "123 12th St",
      "address2": "Building B",
      "city": "Quebec City",
      "state": "QC",
      "zip": "G1R 4S9",
      "country": "CA",
      "verification_value": "123"
    }
  }
}
```

### Response (2xx)
```json
{
  "transaction": {
    "payment_method": {
      "token": "<payment_method_token>"
    }
  }
}
```

## Step 7: Process DG Payment

### Request
```json
POST /airline/v1.1/dg_contracts/<contract_id>/payment
Headers:
  Content-Type: application/json
  Authorization: Bearer <access_token>

{
  "payment_token": "<payment_method_token_from_spreedly>",
  "first_name": "John",
  "last_name": "Smith",
  "address_line1": "123 12th St",
  "address_line2": "Building B",
  "city": "Quebec City",
  "state_or_province": "QC",
  "postal_code": "G1R 4S9",
  "country": "CA",
  "pnr_reference": "ABC123",
  "phone_number": "123566464448",
  "email_address": "test@example.com"
}
```

Note: Payment body uses flat fields (not nested `billing_address`/`contact` objects).

### Response (2xx)
```json
{
  "contract_id": "<contract_id>",
  "payment_status": "completed"
}
```

## Frontier Workflow Order

Frontier's workflow skips the Update step and goes directly to payment:

```
1. Auth
2. DG Offers
3. DG Contract
4. (Optional validation) Get DG Contract
5. Tokenize Payment Card (Spreedly)
6. Process DG Payment
```

### Important Staging Behavior (Observed)

- Calling `PUT /dg_contracts/{id}/update_status` with `confirmed` before Frontier payment can cause payment failure `CO112` ("The contract status is incorrect.")
- For Frontier, treat payment as the status progression trigger and do not run update_status before payment

## Validation Checklist

- [ ] Spreedly tokenization returns a valid `transaction.payment_method.token`
- [ ] Payment token is correctly passed to the DG payment endpoint
- [ ] Payment endpoint returns success status
- [ ] Contract status reflects payment completion
- [ ] Test with invalid card numbers to verify error handling
- [ ] Step status codes are HTTP 2xx (not necessarily 200)
