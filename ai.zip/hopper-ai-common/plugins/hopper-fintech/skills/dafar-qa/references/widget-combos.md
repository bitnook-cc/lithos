# DAFAR Widget Partner/Language Combinations

Total combinations: 12

| # | Partner | Language | Point of Sale | Default Currency |
|---|---|---|---|---|
| 1 | Frontier Airlines | en | US | USD |
| 2 | Frontier Airlines | es | US | USD |
| 3 | Flyadeal | en | SA | SAR |
| 4 | Flyadeal | ar | SA | SAR |
| 5 | Jazeera Airways | en | KW | KWD |
| 6 | Jazeera Airways | ar | KW | KWD |
| 7 | Jazeera Airways | ru | KW | KWD |
| 8 | Gother | en | TH | THB |
| 9 | Gother | th | TH | THB |
| 10 | Volaris | en | MX | MXN |
| 11 | HK Express | en | HK | HKD |
| 12 | Wizz Air | en | HU | EUR |

## With -x-invis Suffix

Each combination above can also be tested with the `-x-invis` suffix on point_of_sale for invisible widget tracking, doubling the total test surface to 24 combinations.
