# DG Offers - Schema Reference

## Request Schema

```
POST /airline/v1.1/dg_offers

{
  "request_type": "ancillary",              # required (standard partners include this)
  "itinerary": [                            # required, array of 1
    {
      "ancillaries": [                      # optional (standard partners include this)
        {
          "covered": true,                  # standard partners only
          "passenger_reference": "<string>",# standard partners only
          "total_price": "<string>",        # monetary value as string
          "type": "<string>"                # "cabin_bag", "checked_bag", "seat"
        }
      ],
      "currency": "<string>",              # required, 3-letter currency code
      "passenger_pricing": [               # required, array
        {
          "passenger_count": {             # required
            "count": <integer>,            # required, >= 1
            "type": "<string>"             # required, "adult" or "lap_infant"
          },
          "individual_price": "<string>"   # required, monetary value as string
        }
      ],
      "passengers": [                      # required when ancillaries include passenger_reference
        {
          "first_name": "<string>",        # standard partners only
          "gender": "<string>",            # standard partners only
          "last_name": "<string>",         # standard partners only
          "passenger_reference": "<string>",# required
          "passenger_type": "<string>",    # required, "adult" or "lap_infant"
          "nationality": "<string>"        # standard partners only
        }
      ],
      "slices": [                          # required, array
        {
          "segments": [                    # required, array
            {
              "origin_airport": "<IATA>",           # required, 3-letter code
              "destination_airport": "<IATA>",      # required, 3-letter code
              "departure_date_time": "<ISO8601>",   # required, YYYY-MM-DDTHH:mm:ss (no Z)
              "arrival_date_time": "<ISO8601>",     # required, YYYY-MM-DDTHH:mm:ss (no Z)
              "flight_number": "<string>",          # required
              "validating_carrier_code": "<string>", # required, 2-letter code
              "cabin": "<string>"                   # required for DG (NOT fare_class)
            }
          ]
        }
      ],
      "total_price": "<string>"            # standard partners only
    }
  ],
  "session": {                             # required
    "point_of_sale": "<string>",           # required, country code
    "language": "<string>",                # required, language code (uppercase)
    "user_info": {                         # Frontier only
      "airline_user_id": "<string>"
    }
  }
}
```

**Important**: The example below uses HKD pricing. For other currencies, substitute the `individual_price`, ancillary prices, and `total_price` with realistic values from [Partner Specifics: Realistic Pricing](partner-specifics.md#realistic-pricing-by-currency-of033-prevention). Using HKD-scale values (e.g. "20000") for SAR, EUR, or other currencies will cause OF033 errors.

## Example: Standard Partner (HK Express, HKD)

```json
{
  "request_type": "ancillary",
  "itinerary": [
    {
      "ancillaries": [
        { "covered": true, "passenger_reference": "PASSENGER1", "total_price": "139.70", "type": "cabin_bag" },
        { "covered": true, "passenger_reference": "PASSENGER1", "total_price": "1190.00", "type": "checked_bag" },
        { "covered": true, "passenger_reference": "PASSENGER1", "total_price": "930.00", "type": "seat" }
      ],
      "currency": "HKD",
      "passenger_pricing": [
        { "individual_price": "20000", "passenger_count": { "count": 1, "type": "adult" } }
      ],
      "passengers": [
        { "first_name": "John", "gender": "male", "last_name": "Doe", "passenger_reference": "PASSENGER1", "passenger_type": "adult", "nationality": "HK" }
      ],
      "slices": [
        {
          "segments": [
            { "origin_airport": "HKG", "destination_airport": "HND", "departure_date_time": "2026-03-10T14:30:00", "arrival_date_time": "2026-03-10T18:00:00", "flight_number": "1234", "validating_carrier_code": "UO", "cabin": "economy" }
          ]
        },
        {
          "segments": [
            { "origin_airport": "HND", "destination_airport": "HKG", "departure_date_time": "2026-03-10T22:30:00", "arrival_date_time": "2026-03-11T02:00:00", "flight_number": "1235", "validating_carrier_code": "UO", "cabin": "economy" }
          ]
        }
      ],
      "total_price": "22259.70"
    }
  ],
  "session": {
    "point_of_sale": "HK",
    "language": "EN"
  }
}
```

## Example: Frontier (USD)

```json
{
  "request_type": "ancillary",
  "itinerary": [
    {
      "passengers": [
        { "passenger_reference": "4ed2e42a", "passenger_type": "adult" },
        { "passenger_reference": "dbf81ef8", "passenger_type": "adult" },
        { "passenger_reference": "44e2c64f", "passenger_type": "lap_infant" }
      ],
      "passenger_pricing": [
        { "passenger_count": { "count": 2, "type": "adult" }, "individual_price": "430.18" },
        { "passenger_count": { "count": 1, "type": "lap_infant" }, "individual_price": "10.00" }
      ],
      "slices": [
        {
          "segments": [
            { "origin_airport": "GRB", "destination_airport": "DEN", "departure_date_time": "2026-03-10T00:00:00", "arrival_date_time": "2026-03-10T02:00:00", "flight_number": "787", "validating_carrier_code": "F9", "cabin": "economy" }
          ]
        },
        {
          "segments": [
            { "origin_airport": "DEN", "destination_airport": "GRB", "departure_date_time": "2026-03-10T04:00:00", "arrival_date_time": "2026-03-10T06:00:00", "flight_number": "786", "validating_carrier_code": "F9", "cabin": "economy" }
          ]
        }
      ],
      "ancillaries": [
        { "passenger_reference": "4ed2e42a", "total_price": "15.00", "type": "checked_bag" },
        { "total_price": "5.00", "type": "seat" },
        { "total_price": "5.00", "type": "seat" },
        { "total_price": "5.00", "type": "seat" }
      ],
      "currency": "USD"
    }
  ],
  "session": {
    "point_of_sale": "US",
    "language": "EN",
    "user_info": { "airline_user_id": "frequent-flyer-123456789" }
  }
}
```

## Response Schema

```
[                                           # response is an ARRAY (not object with "offers" key)
  {
    "id": "<string>",                       # offer ID, used in contract creation
    "premium": "<string>",                  # price of the DG product
    "coverage": "<string>",                 # coverage amount
    "currency": "<string>",                 # 3-letter currency code
    "merchandising_url": "<string>"         # optional, URL for widget
  }
]
```

Note: Extract `response[0].id` as the offer ID for the contract step.
Also capture `hts-session-id` response header for booking confirmed events.

## Common Errors

- 400: Missing required fields, invalid cabin value, malformed dates
- 401: Expired or invalid token
- 422 (OF033): Unrealistic pricing for the currency — use per-currency defaults from partner-specifics.md
- 422: Unsupported partner/language/currency combination
