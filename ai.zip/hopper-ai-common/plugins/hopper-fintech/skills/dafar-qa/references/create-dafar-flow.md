# Create DAFAR - Consolidated Flow

> ⛔ *NEVER CALL PRODUCTION APIs. All DAFAR QA MUST target staging only. Production calls create real contracts with real airlines and real money. There are NO exceptions.*

Single reference for creating a DG contract. Use this for the common "create a DAFAR" request.

## Partner Quick Reference

| Partner | Code | Lang | Currency | Airports | Route | Advance Min | Notes |
|---------|------|------|----------|----------|-------|-------------|-------|
| Frontier | F9 | en, es | USD | GRB, DEN, BOS | DEN→BOS | 1445 | Spreedly payment; no update_status before payment |
| Flyadeal | F3 | en, ar | SAR | JED, RUH | JED→RUH | 1445 | Standard |
| Jazeera | J9 | en, ar, ru | SAR | KWI, GYD | KWI→GYD | 1445 | Standard |
| Gother | VJ | en, th | THB | BKK, HND, JFK, LAX | BKK→HND | 4325 | Standard |
| Volaris | Y4 | en | MXN | MEX, GDL, CUN, TIJ | MEX→GDL | 1445 | Standard |
| HK Express | UO | en | HKD | HKG, PKX, CZX, HND | HKG→HND | 1445 | Standard |
| Wizz Air | W6 | en | EUR | BUD, LTN | BUD→LTN | 1445 | Credentials: `wizz-air-id`/`wizz-air-secret` from `hts-airlines-staging-oauth-conf` |
| Avelo Airlines | XP | en | USD | HVN, ATL | HVN→ATL | 1445 | Standard |
| Spirit | NK | en | USD | FLL, LGA | FLL→LGA | 1445 | Carrier-direct rebooking (`modifyJourney`) |
| Porter | PD | en | CAD | YTZ, YOW | YTZ→YOW | 1445 | Standard |

**Auth:** Frontier omits `audience` and `grant_type`; all others include both.

## API Sequence (Standard Partners)

1. **Auth** `POST /airline/v1.1/auth` → `access_token`
2. **Offers** `POST /airline/v1.1/dg_offers` → `[0].id` (offer_id)
3. **Contract** `POST /airline/v1.1/dg_contracts` → `id` (contract_id)
4. **Get** `GET /airline/v1.1/dg_contracts/{id}` → verify
5. **Update** `PUT /airline/v1.1/dg_contracts/{id}/update_status` → `confirmed`

**Frontier:** Steps 1–3, then:
- Step 6: `POST https://core.spreedly.com/v1/payment_methods.json` (Basic auth: SPREEDLY_*) with `payment_method.credit_card` → `transaction.payment_method.token`
- Step 7: `POST /airline/v1.1/dg_contracts/{id}/payment` with `payment_token`, `first_name`, `last_name`, `address_line1`, `city`, `state_or_province`, `postal_code`, `country`, `pnr_reference`, `email_address`, `phone_number`
Do NOT call update_status before payment (causes CO112).

## Request Schemas (Minimal)

### 1. Auth
```json
{ "client_id": "<{partner}-id from secret>", "client_secret": "<{partner}-secret from secret>" }
```
Frontier only. Others add: `"audience": "https://airlines-api.staging.hopper.com", "grant_type": "client_credentials"`

All credentials come from the single secret `hts-airlines-staging-oauth-conf` in `gcp-hopper-app-staging`.

Headers: `Content-Type: application/json`, `X-Forwarded-For: 192.168.0.1`

### 2. DG Offers
- `itinerary`: array of 1 object with `slices`, `passenger_pricing`, `passengers`, `currency`, `ancillaries`
- `passengers` array is required when ancillaries include `passenger_reference` (i.e. all standard partners)
- Segments: `cabin` (economy/business/first) — NOT `fare_class`
- `session`: `point_of_sale`, `language`
- Frontier: add `session.user_info.airline_user_id`

### 3. DG Contracts
- `offer_ids`: from offers response `[0].id`
- `itinerary`: same as offers but **single object** (not array)

### 4. Update Status
```json
{ "status": "confirmed", "pnr_reference": "123ABC", "email_address": "<email>" }
```
Wait ~1s after contract creation before calling.

## Date/Time Calculation

1. Current time at **origin airport timezone** (UTC offset)
2. Add `advanceMinutes` → outbound departure
3. Return: add advanceMinutes + 8h
4. Format: `YYYY-MM-DDTHH:mm:ss` (no Z)

## Execution Tips

- Use a single `python3` script: auth → offers → contract → get → update (or payment for Frontier)
- Cache tokens per partner (15h validity)
- Email: trigger user → Slack → fallback `dg.<timestamp>@example.com`
- Portal URL: `https://cloud.portal.staging.hopper.com/airline/dg/{contractId}?&advanced=true`
- Frontier staging: departure ≥48h from now to avoid OF033

## Validation

- Treat HTTP 2xx as success; validate required fields
- Monetary values: strings
- Extract `merchandising_url` from offers for reporting
- **Always present the merchandising URL in a code block** (`` ``` ``), never as a Slack `<url|text>` link — Slack corrupts the long base64 `offerData` query parameter, causing JSON parse errors in the widget
