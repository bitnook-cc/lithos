# Exercise Fulfillment Error Codes

When automated rebooking fails, the error code from `AirlinesFulfillService` appears in the Datadog error log stack trace as:
```
java.lang.RuntimeException: Could not process automated rebooking: {CODE} : {message}
```

## Fulfillment Errors (from `AirlinesFulfillService.scala`)

| Code | Error | Meaning | Likely Cause |
|------|-------|---------|--------------|
| FU007 | Fulfillment failure | `pollFulfill` returned `FulfillResponse.Failure` | Downstream booking provider rejected the booking (fare unavailable, validation error) |
| FU008 | Fulfillment aborted | `pollFulfill` returned `FulfillResponse.Aborted` | Booking was started but aborted by the provider (inventory gone, payment issue post-auth) |
| FU009 | Empty poll results | `pollFulfill` returned `FulfillResponse.empty` | Provider returned no results after polling completed |
| FU010 | Unexpected poll state | Poll exhausted max retries while still `Pending` | Fulfillment timed out — provider didn't respond within `oklahomaMaxTries` polls |
| FU012 | Empty initiate response | `InitiateFulfillmentResponse` had no result | Fulfillment couldn't even start — upstream quote/discount issue |

## Impact

All fulfillment errors trigger the same fallback in `DgExerciseService.processAutomatedRebooking`:
1. Exception caught by `recoverWith` (line ~2274)
2. Exercise status set to `DgStatus.Queued`
3. `sendRebookingRequestEmail(contract)` called
4. Exercise awaits manual CS rebooking

## Common Scenarios

### Cross-carrier rebook in staging (e.g., W6→KL)
- Most common: `FU008` (aborted)
- The staging booking pipeline may not fully support third-party airline fulfillment
- The fare selected during quote may become unavailable by fulfillment time

### Same-carrier rebook failing
- Check if the fare/inventory is still available
- Check if payment authorization succeeded (search for `PaymentService/Authorize` in logs)
- Check `oklahomaMaxTries` config — fulfillment may be timing out

## Searching for Errors

```
service:hc-airlines env:staging "Could not process automated rebooking"
```

Or search by specific error code:
```
service:hc-airlines env:staging "FU008"
```
