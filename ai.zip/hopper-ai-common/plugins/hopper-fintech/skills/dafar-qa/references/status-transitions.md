# DG Status Transitions

## Contract Statuses

| Status | Description | Triggered By |
|---|---|---|
| `created` | Contract exists but not yet confirmed | `POST /dg_contracts` |
| `confirmed` | Contract confirmed with PNR and email | `PUT /dg_contracts/{id}/update_status` |
| `exercised` | Disruption occurred, claim processed | Portal / disruption detection system |

### Contract Transitions

```
created    -> confirmed     (API: update_status with pnr + email)
confirmed  -> exercised     (System: disruption event detected)
```

### Invalid Contract Transitions (Should Return Error)

```
created    -> exercised     (cannot skip confirmation)
confirmed  -> created       (cannot go backwards)
exercised  -> confirmed     (cannot go backwards)
exercised  -> created       (cannot go backwards)
```

### Frontier Special Case

For Frontier Airlines, even after `confirmed` status, the contract requires payment processing:
```
created -> confirmed -> payment_processed -> exercised
```
The payment step is an additional requirement, not a status change.

## Exercise Statuses

| Status | Description | Triggered By |
|---|---|---|
| `created` | Exercise initiated, disruption verified, customer browsing alternatives | Customer starts exercise flow via `/customer/dg/check_verification_code` |
| `queued` | Awaiting manual CS rebooking | Auto-rebook failed or not eligible (see below) |
| `confirmed` | Rebooking completed, new flight booked | Auto: Pub/Sub `Ticketed` event. Manual: CS via support API |

### Exercise Transitions

```
created    -> confirmed     (Automated rebooking succeeds: Lexington Ticketed event or Spirit sync confirm)
created    -> queued        (Auto-rebook not eligible, OR auto-rebook attempted but failed)
queued     -> confirmed     (CS agent manually rebooks and confirms via support API or Cloud Portal)
```

### How an exercise ends up `queued`

There are two code paths (both in `DgExerciseService.rebook()`):

1. **`isAutomatedRebookingEligible()` returns `false`** (line ~2139):
   - Status set to `Queued` immediately
   - Rebooking request email sent
   - Reasons: checked bags, unsupported document type, excluded airline (FR), health SSR, feature flag off

2. **Automated rebooking attempted but fails** (line ~2274):
   - `processAutomatedRebooking()` throws exception (e.g., fulfillment error FU007/FU008)
   - `recoverWith` catches it, sets status to `Queued`
   - Rebooking request email sent
   - Reasons: fulfillment aborted/failed/timed out (see `references/exercise-error-codes.md`)

### How an exercise gets `confirmed` from `queued`

- CS agent rebooks the customer manually on a new flight
- CS calls `updateExerciseStatusToConfirmedAfterRebooking` via the support API
- Or confirms through the Cloud Portal: `https://cloud.portal.staging.hopper.com/airline/dg/{contractId}?&advanced=true`
