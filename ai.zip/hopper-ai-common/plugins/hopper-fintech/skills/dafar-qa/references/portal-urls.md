# Cloud Portal URL Patterns

## DAFAR (DG) Contracts

```
https://cloud.portal.staging.hopper.com/airline/dg/{contractId}?&advanced=true
```

## CFAR Contracts (for reference)

```
https://cloud.portal.staging.hopper.com/airline/cfar/{contractId}
```

## Key Differences

- DAFAR portal URLs include `?&advanced=true` query parameter
- DAFAR uses `/dg/` path segment, CFAR uses `/cfar/`
- Both use the contract_id (not contract_reference) in the URL

## Portal Access

- Portal is IAP-protected (requires Hopper authentication)
- Staging portal: `cloud.portal.staging.hopper.com`
