# Partner-Specific Behavior

## Frontier Airlines

Frontier is the only DAFAR partner that requires payment processing:
- Carrier code: `F9`
- Hardcoded flight numbers: 787 (outbound), 786 (return)
- Hardcoded passenger references: "4ed2e42a" (adult), "dbf81ef8" (adult), "44e2c64f" (lap_infant)
- Requires Spreedly payment tokenization after contract creation
- Auth body does NOT include `audience` or `grant_type`
- Different payload structure for DG offers/contracts (multiple passenger types, no `covered` flag on ancillaries)
- Workflow: Auth -> Offers -> Contract -> Tokenize Payment -> Process Payment (no Get/Update steps)
- Includes `user_info.airline_user_id` in session
- In staging, DG offers may fail with `OF033` if departure is too close; set departure to at least ~48 hours from now
- In staging, calling `update_status=confirmed` before payment can cause payment failure `CO112`; payment should be run directly after contract creation

## HK Express

- Carrier code: `UO`
- Standard 5-step flow (Auth -> Offers -> Contract -> Get -> Update)
- Includes `passengers` with `first_name`, `last_name`, `gender`, `nationality` fields
- Ancillaries include `covered: true` and `passenger_reference`
- Includes `total_price` at itinerary level
- Supports 9 currencies: HKD, JPY, KRW, TWD, THB, CNY, PHP, USD, MYR

## Flyadeal

- Carrier code: `F3`
- Standard 5-step flow
- Supports SAR and USD currencies
- Airports: JED (Jeddah), RUH (Riyadh)
- Languages: EN, AR

## Jazeera Airways

- Carrier code: `J9`
- Standard 5-step flow
- Default currency: SAR (not KWD despite being Kuwait-based)
- Supports 19 currencies (most of any partner)
- Languages: EN, AR, RU
- Airports: KWI (Kuwait), GYD (Baku)

## Gother

- Carrier code: `VJ`
- Standard 5-step flow
- Default language: TH (not EN)
- Supports THB, USD, EUR
- Airports: BKK, HND, JFK, LAX

## Volaris

- Carrier code: `Y4`
- Standard 5-step flow
- Supports MXN and USD
- Airports: MEX, GDL, CUN, TIJ

## Wizz Air

- Carrier code: `W6`
- Standard 5-step flow (Auth -> Offers -> Contract -> Get -> Update)
- Auth succeeded with audience + grant_type body pattern
- Credentials: `wizz-air-id` and `wizz-air-secret` from `hts-airlines-staging-oauth-conf` secret
- Validated configuration in staging: point_of_sale `HU`, language `EN`, currency `EUR`
- Validated route in staging: BUD -> LTN (round-trip payload accepted)
- DG offers include `merchandising_url` and `merchandising_url_web_component`
- In staging, `dg_offers` may return `OF033` if itinerary pricing is unrealistic for the currency (for example using HKD-scale values like "20000" for EUR or SAR); always use plausible amounts per currency (see Realistic Pricing by Currency below)

## Spirit Airlines

- Carrier code: `NK`
- Standard 5-step flow (Auth -> Offers -> Contract -> Get -> Update)
- Credentials: `spirit-id` and `spirit-secret` from `hts-airlines-staging-oauth-conf` secret
- Default currency: USD
- Language: EN
- Airports: FLL (Fort Lauderdale), LGA (New York LaGuardia)
- Default route: FLL -> LGA
- Point of sale: US
- Rebooking: carrier-direct API (`modifyJourney`), synchronous — confirmed immediately (does NOT use Lexington)

## Porter Airlines

- Carrier code: `PD`
- Standard 5-step flow (Auth -> Offers -> Contract -> Get -> Update)
- Credentials: `porter-id` and `porter-secret` from `hts-airlines-staging-oauth-conf` secret
- Default currency: CAD
- Language: EN
- Airports: YTZ (Toronto Billy Bishop), YOW (Ottawa)
- Default route: YTZ -> YOW
- Point of sale: CA

## Avelo Airlines

- Carrier code: `XP`
- Standard 5-step flow (Auth -> Offers -> Contract -> Get -> Update)
- Credentials: `avelo-airlines-id` and `avelo-airlines-secret` from `hts-airlines-staging-oauth-conf` secret
- Default currency: USD
- Language: EN
- Airports: HVN (New Haven), ATL (Atlanta)
- Default route: HVN -> ATL
- Point of sale: US

## Realistic Pricing by Currency (OF033 Prevention)

Staging `dg_offers` returns `OF033` ("An offer could not be saved") when `individual_price` or ancillary values are unrealistically high for the given currency. Use these tested defaults:

| Currency | `individual_price` | `cabin_bag` | `checked_bag` | `seat` | `total_price` | Notes |
|----------|-------------------|-------------|---------------|--------|---------------|-------|
| HKD | `20000` | `139.70` | `1190.00` | `930.00` | `22259.70` | Original default — only valid for HKD |
| USD | `430.18` | `15.00` | `25.00` | `15.00` | `485.18` | Frontier uses multi-pax; see Frontier flow |
| SAR | `500.00` | `50.00` | `75.00` | `60.00` | `685.00` | Validated for Flyadeal JED→RUH |
| EUR | `150.00` | `25.00` | `35.00` | `20.00` | `230.00` | Validated for Wizz Air BUD→LTN |
| THB | `5000.00` | `300.00` | `500.00` | `400.00` | `6200.00` | Gother BKK→HND |
| MXN | `3000.00` | `200.00` | `350.00` | `250.00` | `3800.00` | Volaris MEX→GDL |
| KWD | `50.00` | `5.00` | `8.00` | `6.00` | `69.00` | Jazeera KWI→GYD |
| CAD | `350.00` | `20.00` | `35.00` | `20.00` | `425.00` | Porter YTZ→YOW |

**Important**: Always select pricing from this table based on the partner's currency. Do NOT use the HKD default of "20000" for other currencies — it will cause OF033 failures.

## Widget Testing (-x-invis suffix)

All partners support an `-x-invis` suffix on the point_of_sale for invisible/widget testing:
- Format: `{pointOfSale}-x-invis` (e.g., "US-x-invis")
- Used for analytics tracking of invisible widget placements
- For Russian language, use currency-based point of sale (not language-based) before appending suffix

## Flight Status Change APIs

These APIs are used to simulate flight disruptions for testing DG exercise flows:

### Standard Flight Status Change (Delay)
```json
POST /flights/v1/status_changes
Authorization: Bearer <access_token>

[
  {
    "flight_id": {
      "marketing_airline_code": "<carrier_code>",
      "flight_number": "<number>",
      "origin_airport": "<IATA>",
      "destination_airport": "<IATA>",
      "scheduled_departure_date_time": "<ISO8601>",
      "scheduled_arrival_date_time": "<ISO8601>"
    },
    "status_change": {
      "type": "delayed",
      "estimated_departure_date_time": "<ISO8601>",
      "estimated_arrival_date_time": "<ISO8601>"
    }
  }
]
```

### Standard Flight Status Change (Cancellation)
```json
POST /flights/v1/status_changes
Authorization: Bearer <access_token>

[
  {
    "flight_id": {
      "marketing_airline_code": "<carrier_code>",
      "flight_number": "<number>",
      "origin_airport": "<IATA>",
      "destination_airport": "<IATA>",
      "scheduled_departure_date_time": "<ISO8601>",
      "scheduled_arrival_date_time": "<ISO8601>"
    },
    "status_change": {
      "type": "canceled"
    }
  }
]
```

### Custom Flight Status Change (Frontier-specific delay)
```json
POST /flights/v1/status_changes_custom
Authorization: Bearer <access_token>

{
  "sequenceNo": 20250508162002,
  "departureNumber": 1,
  "carrierCode": "F9",
  "flightNumber": "787",
  "opsSuffix": "",
  "origin": "GRB",
  "destination": "DEN",
  "flightDateUTC": "2025-08-04",
  "tailNo": "710",
  "equipmentType": "321",
  "arrivalGate": "A77",
  "stdUTC": "<scheduled_departure>",
  "etdUTC": "<estimated_departure>",
  "staUTC": "<scheduled_arrival>",
  "etaUTC": "<estimated_arrival>",
  "operationStatus": "OPERATED",
  "flightDelays": [
    {
      "delayCode": "199",
      "delayMinutes": "120",
      "description": "RETURNTOON-TIME",
      "type": "Delay",
      "direction": "departure"
    },
    {
      "delayCode": "199",
      "delayMinutes": "120",
      "description": "RETURNTOON-TIME",
      "type": "Delay",
      "direction": "arrival"
    }
  ]
}
```

### Custom Flight Status Change (Frontier-specific cancellation)
```json
POST /flights/v1/status_changes_custom
Authorization: Bearer <access_token>

{
  "sequenceNo": 20250508162951,
  "departureNumber": 1,
  "carrierCode": "F9",
  "flightNumber": "787",
  "opsSuffix": "",
  "origin": "GRB",
  "destination": "DEN",
  "flightDateUTC": "<date>",
  "tailNo": "-D1204",
  "equipmentType": "320",
  "stdUTC": "<scheduled_departure>",
  "etdUTC": "<scheduled_departure>",
  "staUTC": "<scheduled_arrival>",
  "etaUTC": "<scheduled_arrival>",
  "operationStatus": "CANCELLED",
  "flightDelays": []
}
```

### Booking Confirmed Event
```json
POST /airline/v1.1/events
Headers:
  Content-Type: application/json
  Authorization: Bearer <access_token>
  HC-Session-ID: <session_id>

{
  "type": "booking_confirmed"
}
```

Note: The `HC-Session-ID` header comes from the `hts-session-id` response header of the DG offers call.
