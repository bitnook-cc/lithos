# DG Contracts - Schema Reference

## Create Contract Request

```
POST /airline/v1.1/dg_contracts

{
  "offer_ids": ["<string>"],                # required, from dg_offers response[0].id
  "itinerary": {                            # required, single object (NOT array)
    "ancillaries": [...],                   # same structure as offers request
    "currency": "<string>",
    "passenger_pricing": [...],
    "passengers": [...],                    # if included in offers, include here too
    "slices": [...],
    "total_price": "<string>"               # standard partners only
  }
}
```

Key difference from offers: `itinerary` is a **single object**, not wrapped in an array.

## Example: Standard Partner (HK Express)

```json
{
  "offer_ids": ["<offer_id>"],
  "itinerary": {
    "ancillaries": [
      { "covered": true, "passenger_reference": "PASSENGER1", "total_price": "139.70", "type": "cabin_bag" },
      { "covered": true, "passenger_reference": "PASSENGER1", "total_price": "1190.00", "type": "checked_bag" },
      { "covered": true, "passenger_reference": "PASSENGER1", "total_price": "930.00", "type": "seat" }
    ],
    "currency": "HKD",
    "passenger_pricing": [
      { "individual_price": "20000", "passenger_count": { "count": 1, "type": "adult" } }
    ],
    "passengers": [
      { "first_name": "John", "gender": "male", "last_name": "Doe", "passenger_reference": "PASSENGER1", "passenger_type": "adult", "nationality": "HK" }
    ],
    "slices": [
      {
        "segments": [
          { "origin_airport": "HKG", "destination_airport": "HND", "departure_date_time": "2026-03-10T14:30:00", "arrival_date_time": "2026-03-10T18:00:00", "flight_number": "1234", "validating_carrier_code": "UO", "cabin": "economy" }
        ]
      },
      {
        "segments": [
          { "origin_airport": "HND", "destination_airport": "HKG", "departure_date_time": "2026-03-10T22:30:00", "arrival_date_time": "2026-03-11T02:00:00", "flight_number": "1235", "validating_carrier_code": "UO", "cabin": "economy" }
        ]
      }
    ],
    "total_price": "22259.70"
  }
}
```

## Example: Frontier

```json
{
  "offer_ids": ["<offer_id>"],
  "itinerary": {
    "passengers": [
      { "passenger_reference": "4ed2e42a", "passenger_type": "adult" },
      { "passenger_reference": "dbf81ef8", "passenger_type": "adult" },
      { "passenger_reference": "44e2c64f", "passenger_type": "lap_infant" }
    ],
    "passenger_pricing": [
      { "passenger_count": { "count": 2, "type": "adult" }, "individual_price": "430.18" },
      { "passenger_count": { "count": 1, "type": "lap_infant" }, "individual_price": "10.00" }
    ],
    "slices": [
      {
        "segments": [
          { "origin_airport": "GRB", "destination_airport": "DEN", "departure_date_time": "2026-03-10T00:00:00", "arrival_date_time": "2026-03-10T02:00:00", "flight_number": "787", "validating_carrier_code": "F9", "cabin": "economy" }
        ]
      },
      {
        "segments": [
          { "origin_airport": "DEN", "destination_airport": "GRB", "departure_date_time": "2026-03-10T04:00:00", "arrival_date_time": "2026-03-10T06:00:00", "flight_number": "786", "validating_carrier_code": "F9", "cabin": "economy" }
        ]
      }
    ],
    "ancillaries": [
      { "passenger_reference": "4ed2e42a", "total_price": "15.00", "type": "checked_bag" },
      { "total_price": "5.00", "type": "seat" },
      { "total_price": "5.00", "type": "seat" },
      { "total_price": "5.00", "type": "seat" }
    ],
    "currency": "USD"
  }
}
```

## Create Contract Response

```json
{
  "id": "<contract_id>",
  "reference": "<contract_reference>",
  "status": "created",
  "offer_ids": ["<offer_id>"],
  "premium": "<amount>",
  "coverage": "<amount>"
}
```

## Get Contract

```
GET /airline/v1.1/dg_contracts/<contract_id>
Headers:
  Authorization: Bearer <access_token>

Response: Full contract object with all fields from creation plus:
- timestamps
- passenger details
- itinerary details
```

## Common Errors

- 400: Invalid offer_ids, missing ancillaries
- 404: Contract not found (invalid contract_id)
- 409: Offer already used in another contract
