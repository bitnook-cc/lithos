# DG Contract Status Update - Schema Reference

## Request

```json
PUT /airline/v1.1/dg_contracts/<contract_id>/update_status
Headers:
  Content-Type: application/json
  Authorization: Bearer <access_token>

{
  "status": "confirmed",
  "pnr_reference": "123ABC",
  "email_address": "test@example.com"
}
```

Note: Wait ~1 second after contract creation before calling update_status to ensure the contract is ready.

## Response

```json
{
  "contract_id": "<contract_id>",
  "status": "confirmed",
  "pnr_reference": "123ABC"
}
```

## Status Transitions

```
created -> confirmed      (via update_status)
confirmed -> exercised    (via disruption event / portal)
```

- Only `created -> confirmed` is triggered via the API
- `confirmed -> exercised` happens through the cloud portal or disruption detection
- Frontier skips this step entirely (goes directly to payment after contract creation)

## Common Errors

- 400: Invalid status transition (e.g. already confirmed)
- 404: Contract not found
- 422: Missing pnr_reference or email_address
