# DAFAR QA Skill

Full QA suite for DAFAR (Disruption Guarantee for Airlines) contracts, ported from `hopper-org/cedar`.

## Capabilities

### Contract Investigation (360 View)
```
@Hopper AI show me a 360 view of DAFAR contract 1f129120-b123-6618-9eaf-210438752fcd
```

### Contract Creation
```
@Hopper AI create a DAFAR for Wizz Air
@Hopper AI create a DG contract for Frontier
```

### Widget Validation
```
@Hopper AI validate merchandising widgets for all partners
```

### Helper Script
```bash
uv run dafar-contract.py datadog {contract_id}
uv run dafar-contract.py bq-events {session_id}
uv run dafar-contract.py bq-contract {contract_id}
uv run dafar-contract.py trace-links {trace_id}
```

## File Structure

```
dafar-qa/
  SKILL.md                          # Main skill (investigation + creation + widgets)
  README.md                         # This file
  dafar-contract.py                 # CLI helper for queries and links
  references/
    create-dafar-flow.md            # Consolidated contract creation flow
    standard-flow.md                # Standard 5-step API sequence
    frontier-payment.md             # Frontier Spreedly payment flow
    dg-offers-schema.md             # DG offers request/response schema
    dg-contracts-schema.md          # DG contracts request/response schema
    dg-update-schema.md             # DG update_status schema
    partner-matrix.md               # Partner config matrix (all partners)
    partner-specifics.md            # Per-partner behavioral differences
    widget-combos.md                # Widget partner/language test matrix
    status-transitions.md           # Contract status transition rules
    portal-urls.md                  # Cloud portal URL patterns
```

## Secrets

Partner credentials are in GCP Secret Manager (`gcp-hopper-app-staging`).
The `platform-ai-hopper` service account has read access to staging secrets only.

See SKILL.md for the secret name mapping per partner.

## Data Sources

- **Datadog**: `service:hc-airlines` logs and APM traces
- **BigQuery**: `gcp-hopper-etldata-staging.hc_analytics.events_v2`
