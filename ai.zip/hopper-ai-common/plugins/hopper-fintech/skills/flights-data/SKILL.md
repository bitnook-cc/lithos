---
name: flights-data
description: >
  Use when analyzing flight bookings, internal shopping data, provider shop volume,
  or external shadow/echo traffic in BigQuery. Covers booking ledger data (flight_product),
  internal shop results (shop_trip_fare), provider-level shop aggregations, external GDS
  market data (Daventry), and conversion analysis across routes and carriers.
---

# Flights Data Analysis

Use this skill when users ask about:
- **Flight bookings**: reservation counts, booking volume, revenue, carrier mix, PNR data, ticket data
- **Internal shopping**: Hopper's own search results, fare pricing, trip details, shelf ratings
- **Provider shop volume**: how many shops hit each GDS provider (Sabre, Amadeus, Travelfusion, etc.)
- **External market data / shadow traffic**: anonymized GDS search data showing global pricing and demand
- **Conversion analysis**: combining booking and shopping data to understand funnel metrics
- **Route-level analytics**: origin/destination demand, pricing trends, carrier availability

---

## Table Quick Reference

| Domain | Table | Project.Dataset | Type | Best For |
|--------|-------|-----------------|------|----------|
| Bookings | `fact_flight_product_unique_by_session` | `h4r-common-bi-prd.brooklyn__slv` | View | Booking volume, revenue, reservation status |
| Shopping | `fact_shop_trip_fare` | `h4r-common-bi-prd.daventry__slv` | View | Internal shop results, fare-level detail |
| Shopping (WholeCo) | `wholeco_fact_shop_trip_fare` | `h4r-common-bi-prd.flights_shop__gld` | View | Combined Hopper + Capital One shopping |
| Provider Volume | `wholeco_provider_shop_volume` | `h4r-common-bi-prd.flights_shop__gld` | Incremental | Provider-level shop counts by hour |
| Shadow Traffic | `route_report_*_v3` | `gcp-hopper-etldata-production.warehouse` | External Parquet | Market pricing, demand trends |
| Shadow Traffic | `shops_v3` / `internal_shops_v3` | `gcp-hopper-etldata-production.warehouse` | External Parquet | Raw search-level detail |

---

## 1. Flight Bookings: `fact_flight_product_unique_by_session`

### Overview

The flight product tables are the **source of truth for flight bookings**. They replace the older
`booking_facts_v2`. The data comes from Brooklyn's Post Ticketing Machine (PTM) session models and
is streamed to BigQuery.

**Full table**: `h4r-common-bi-prd.brooklyn__slv.fact_flight_product_unique_by_session`

This is a deduplicated view over `fact_flight_product` (partitioned by `session_timestamp`, ~18M rows).
It keeps only the latest load per `session.id` using `ROW_NUMBER() OVER (PARTITION BY session.id ORDER BY session.load_timestamp DESC)`.

### Data Model

The table contains **four nested record types** in each row, representing a hierarchy:

| Record | Description | Key ID |
|--------|-------------|--------|
| `reservation_fact` | Top-level booking: pricing, status, tenant, carrier codes | `reservation_id` |
| `pnr_facts` | PNR-level: buying/selling prices, provider, margin, commission | `supplemental_pnr_id` |
| `ticket_facts` | Ticket-level: passenger info, ticket numbers, route | `supplemental_ticket_id` |
| `segment_facts` | Segment-level: flight details, carriers, times, fare brands | `supplemental_segment_id` |

**Linking to other tables**: Use `reservation_id` (called `itinerary_id` in `booking_facts_v2`, `product_id` in cart tables).

### Key Columns

**Reservation level** (`reservation_fact.*`):

| Column | Type | Description |
|--------|------|-------------|
| `reservation_id` | STRING | Primary booking identifier |
| `tenant_id` | STRING | `hopper-app`, `smcc`, etc. |
| `booking_date` | TIMESTAMP | When the booking was made |
| `reservation_status` | STRING | Current booking status |
| `selling_adult_pricing.usd_base` | NUMERIC | Selling base price in USD |
| `selling_adult_pricing.usd_taxes` | NUMERIC | Selling taxes in USD |
| `selling_adult_pricing.currency` | STRING | Original selling currency |
| `outgoing_validating_carrier_code` | STRING | IATA carrier code (outbound) |
| `returning_validating_carrier_code` | STRING | IATA carrier code (return) |
| `point_of_sale` | STRING | Point of sale country |
| `is_multi_provider` | BOOLEAN | Multi-provider booking |
| `is_multi_city` | BOOLEAN | Multi-city itinerary |
| `user_id` | STRING | Hopper user ID |
| `cart_action` | STRING | Cart action type |

**PNR level** (`pnr_facts.*`):

| Column | Type | Description |
|--------|------|-------------|
| `provider` | STRING | GDS provider (e.g. Sabre, Amadeus) |
| `sub_provider` | STRING | Sub-provider detail |
| `trip_type` | STRING | `one_way`, `round_trip` |
| `buying.usd_base` | NUMERIC | Buying base price USD |
| `selling.usd_base` | NUMERIC | Selling base price USD |
| `mor_margin.percent` | NUMERIC | Margin percentage |
| `total_commission_usd` | NUMERIC | Commission in USD |
| `settlement_type` | STRING | Settlement method |
| `brand_type` | STRING | Fare brand type |

**Segment level** (`segment_facts.*`):

| Column | Type | Description |
|--------|------|-------------|
| `origin_code` | STRING | IATA airport code |
| `destination_code` | STRING | IATA airport code |
| `marketing_carrier` | STRING | Marketing carrier IATA code |
| `operating_carrier` | STRING | Operating carrier IATA code |
| `departure_time_utc` | TIMESTAMP | Departure time UTC |
| `arrival_time_utc` | TIMESTAMP | Arrival time UTC |
| `flight_duration_second` | INTEGER | Flight duration in seconds |
| `fare_basis_code` | STRING | Fare basis code |
| `booking_class_code` | STRING | Booking class |
| `equipment_type` | STRING | Aircraft type |

### Query Rules

- **Partition filter**: Always filter on `session_timestamp` (the underlying table's partition key).
  Use `WHERE session_timestamp >= TIMESTAMP('2025-06-01')` to limit scan.
- **Dedup is built-in**: The view already deduplicates by session — no need to add ROW_NUMBER().
- **Nested records**: Use dot notation to access nested fields (e.g. `reservation_fact.booking_date`).
- **Top-level fields**: `reservation_id`, `session_timestamp`, `reservation_step`, `ptm_outcome`
  exist at the top level alongside the nested records.

### Example: Daily Booking Volume

```sql
SELECT
  DATE(reservation_fact.booking_date) AS booking_date,
  reservation_fact.tenant_id,
  COUNT(DISTINCT reservation_id) AS bookings,
  SUM(reservation_fact.selling_adult_pricing.usd_base + reservation_fact.selling_adult_pricing.usd_taxes) AS total_revenue_usd
FROM `h4r-common-bi-prd.brooklyn__slv.fact_flight_product_unique_by_session`
WHERE
  session_timestamp >= TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 30 DAY)
  AND reservation_fact.reservation_status IS NOT NULL
GROUP BY 1, 2
ORDER BY 1 DESC
```

### Example: Bookings by Carrier and Provider

```sql
SELECT
  reservation_fact.outgoing_validating_carrier_code AS carrier,
  pnr_facts.provider,
  COUNT(DISTINCT reservation_id) AS bookings,
  AVG(pnr_facts.selling.usd_base + pnr_facts.selling.usd_taxes) AS avg_selling_price_usd
FROM `h4r-common-bi-prd.brooklyn__slv.fact_flight_product_unique_by_session`
WHERE
  session_timestamp >= TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 7 DAY)
  AND reservation_fact.reservation_status IS NOT NULL
GROUP BY 1, 2
ORDER BY bookings DESC
LIMIT 20
```

---

## 2. Flight Shopping: `fact_shop_trip_fare`

### Overview

Hopper's **internal shopping data** — every flight search result with full trip and fare detail.

**Full table**: `h4r-common-bi-prd.daventry__slv.fact_shop_trip_fare`

**Size**: ~575 billion rows. **Always filter by partition date and use LIMIT when exploring.**

### Key Columns

**Shop-level** (shared across all trips in a shop):

| Column | Type | Description |
|--------|------|-------------|
| `stf_trip_shop_id` | STRING | Unique shop identifier |
| `stf_trip_shop_received_date_utc` | DATE | **Partition key** — day the shop was made |
| `stf_trip_shop_trigger_name` | STRING | What triggered the shop: `InAppShop`, `Houston`, etc. |
| `stf_trip_shop_trigger_user_id` | STRING | User ID (only set for `InAppShop`) |
| `stf_trip_shop_query_tenant_id` | STRING | Tenant: `hopper-app`, `smcc`, etc. |
| `stf_trip_shop_query_origin` | STRING | Origin IATA code |
| `stf_trip_shop_query_destination` | STRING | Destination IATA code |
| `stf_trip_shop_query_departure_date` | STRING | Requested departure date |
| `stf_trip_shop_query_return_date` | STRING | Requested return date |
| `stf_trip_shop_query_pax_adult` | INTEGER | Number of adult passengers |
| `stf_trip_shop_trip_count` | INTEGER | Total trips returned in this shop |

**Trip-level**:

| Column | Type | Description |
|--------|------|-------------|
| `stf_trip_id` | STRING | Unique trip within a shop |
| `stf_trip_type` | STRING | `one_way`, `round_trip`, `open_jaw` |
| `stf_trip_index` | INTEGER | Position in search results |
| `stf_trip_outgoing_origin` | STRING | Actual outgoing origin airport |
| `stf_trip_outgoing_destination` | STRING | Actual outgoing destination airport |
| `stf_trip_outgoing_stops` | INTEGER | Number of stops (outgoing) |
| `stf_trip_outgoing_marketing_carrier_codes` | STRING | Marketing carriers (outgoing) |
| `stf_trip_advance_days` | INTEGER | Days between shop and departure |
| `stf_trip_length_of_stay` | INTEGER | Length of stay in days |
| `stf_trip_lowest_cabin_class` | STRING | Lowest cabin class in trip |

**Fare-level** (one trip can have multiple fares):

| Column | Type | Description |
|--------|------|-------------|
| `stf_fare_id` | STRING | Unique fare within a trip |
| `stf_fare_source` | STRING | Provider the fare came from |
| `stf_fare_pricing_base_rounded` | FLOAT | Base fare (local currency, rounded) |
| `stf_fare_pricing_taxes_rounded` | FLOAT | Taxes (local currency, rounded) |
| `stf_fare_pricing_hopper_fee_rounded` | FLOAT | Hopper booking fee |
| `stf_fare_usd_exchange_rate` | FLOAT | USD exchange rate |
| `stf_fare_pricing_currency` | STRING | Pricing currency |
| `stf_fare_outgoing_shelf_rating` | INTEGER | Shelf rating: 0 (Basic) to 4 (Luxury) |
| `stf_fare_outgoing_shelf_brand_name` | STRING | Brand name (e.g. "Delta Main Classic") |
| `stf_trip_validating_carrier_code` | STRING | IATA validating carrier code |

### Query Rules

1. **Always filter by partition**: `WHERE stf_trip_shop_received_date_utc = '2026-03-01'` (or a date range).
   Without this, BQ will scan the entire 575B-row table.
2. **Use clustering columns** in WHERE clauses for best performance:
   `stf_trip_shop_id`, `stf_trip_shop_query_tenant_id`, `stf_trip_shop_trigger_name`, `stf_trip_type`
3. **Start with LIMIT** when exploring. Even a single day can have billions of rows.

### Example: Daily Search Volume by Route

```sql
SELECT
  stf_trip_shop_received_date_utc AS shop_date,
  stf_trip_shop_query_origin AS origin,
  stf_trip_shop_query_destination AS destination,
  COUNT(DISTINCT stf_trip_shop_id) AS shop_count,
  COUNT(DISTINCT stf_trip_id) AS trip_count
FROM `h4r-common-bi-prd.daventry__slv.fact_shop_trip_fare`
WHERE
  stf_trip_shop_received_date_utc = DATE_SUB(CURRENT_DATE(), INTERVAL 1 DAY)
  AND stf_trip_shop_trigger_name = 'InAppShop'
  AND stf_trip_type = 'round_trip'
GROUP BY 1, 2, 3
ORDER BY shop_count DESC
LIMIT 50
```

---

## 2b. WholeCo Shopping: `wholeco_fact_shop_trip_fare`

**Full table**: `h4r-common-bi-prd.flights_shop__gld.wholeco_fact_shop_trip_fare`

A **UNION ALL** of Hopper (`fact_shop_trip_fare`) and Capital One (`cot_stage_shop_trip_fare_facts`)
shopping data. Same schema but with cleaner column aliases (no `stf_` prefix)
and calculated price fields:

| Calculated Column | Formula |
|-------------------|---------|
| `fare_pricing_subtotal` | `base + taxes + COALESCE(dynamic_adjustment, 0)` |
| `fare_pricing_grand_total` | `subtotal + hopper_fee` |
| `fare_usd_pricing_subtotal` | `subtotal / exchange_rate` |
| `fare_usd_pricing_grand_total` | `grand_total / exchange_rate` |

Use this table when you need **cross-tenant** shopping analysis (Hopper + Capital One combined).

Filter by `query_tenant_id` to separate tenants. Filter by `received_date_utc` (partition key).

---

## 3. Provider Shop Volume: `wholeco_provider_shop_volume`

### Overview

Aggregated **hourly counts of shops sent to each GDS provider**. Useful for monitoring provider
health, comparing shop volume across providers, and detecting drops/spikes.

**Full table**: `h4r-common-bi-prd.flights_shop__gld.wholeco_provider_shop_volume`

### Schema

| Column | Type | Description |
|--------|------|-------------|
| `hour_ts` | TIMESTAMP | Hour bucket (partition key via DAY truncation) |
| `tenant` | STRING | Tenant identifier (`hopper-app`, `smcc`, etc.) |
| `trigger` | STRING | Shop trigger type |
| `provider` | STRING | Raw provider name (`Sabre GDS`, `Amadeus GDS`, `Travelfusion`) |
| `sub_provider` | STRING | Sub-provider (for Travelfusion/Facade) or `'Not Applicable'` |
| `normalized_provider` | STRING | Normalized provider name for cross-source comparison |
| `pcc` | STRING | Pseudo City Code (for Facade) or `'Not Applicable'` |
| `offers` | INTEGER | Number of offers/trips returned |
| `shop_count` | INTEGER | Number of shops made |
| `empty_shop_count` | INTEGER | Shops that returned 0 results |
| `weighted_shop_count` | NUMERIC | Weighted shop count (Southlake uses `total_weighting`) |

### Example: Hourly Shop Volume by Provider

```sql
SELECT
  hour_ts,
  normalized_provider,
  SUM(shop_count) AS total_shops,
  SUM(empty_shop_count) AS empty_shops,
  SAFE_DIVIDE(SUM(empty_shop_count), SUM(shop_count)) AS empty_rate
FROM `h4r-common-bi-prd.flights_shop__gld.wholeco_provider_shop_volume`
WHERE
  hour_ts >= TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 24 HOUR)
  AND tenant = 'hopper-app'
GROUP BY 1, 2
ORDER BY 1, 2
```

---

## 4. Shadow Traffic (Daventry): External GDS Data

### Overview

Anonymized flight shopping data collected from Global Distribution System (GDS) partners.

All tables are in `gcp-hopper-etldata-production.warehouse`.

### Critical: Performance & Query Rules

These tables are **massive external Parquet sources** with long startup times.

1. **Always increase timeout** for queries against these tables.
2. **Always filter by required partitions** — queries without partition filters are rejected.
3. **Start small**: Use `LIMIT` and narrow date ranges when exploring.
4. **Prefer summary tables** (`route_report_*`) over raw data (`shops_v3`).

### 4a. Summary Tables: `route_report_*_v3`

**Best for**: High-level metrics, trends, aggregate stats. **Always check these first.**

#### Mandatory Partition Filters

Every query against `route_report_*` tables **MUST** include:

| Column | Required | Values |
|--------|----------|--------|
| `date` | Yes | Shopping date |
| `filter` | Yes | `'NoFilter'`, `'NoLCC'`, `'ShortLayover'`, `'NonStop'`, `'And(ShortLayover,NoLCC)'`, `'And(NonStop,NoLCC)'` |
| `trip_type` | Yes | `'one_way'`, `'round_trip'`, `'open_jaw'` |

#### Avoiding Double-Counting

- `filter='NoFilter'` includes all shops. `NoLCC`, `NonStop`, etc. are subsets.
  **Never sum across filter values.**
- `origin.region_type` can be `'airport'` or `'city'`. JFK results are included in NYC.
  **Filter to `'airport'`** for accurate totals.

#### Example: Weekly Route Stats

```sql
SELECT
  date,
  origin.code AS origin,
  destination.code AS destination,
  stats.shops AS total_searches,
  stats.trips AS total_itineraries,
  stats.best_price AS min_price_usd,
  stats.price10 AS great_price_usd
FROM `gcp-hopper-etldata-production.warehouse.route_report_stats_1week_v3`
WHERE
  date = '2026-02-17'
  AND filter = 'NoFilter'
  AND trip_type = 'round_trip'
  AND origin.region_type = 'airport'
  AND destination.region_type = 'airport'
ORDER BY stats.shops DESC
LIMIT 100
```

### 4b. Raw Data Tables

**Best for**: Deep dives, specific itinerary details, carrier/fare analysis.
**Use with extreme caution** — these are enormous.

| Table | Description | Partition Keys |
|-------|-------------|----------------|
| `shops_v3` | Full firehose — all external search results | `received_date`, `trip_type` |
| `internal_shops_v3` | Hopper-originated searches only | `received_date`, `trip_type` |
| `trips_1pct_v3` | 1% sample of interesting itineraries | `received_date` |
| `segments_1pct_v3` | 1% sample of flight segments | `received_date` |

---

## 5. Common Analysis Patterns

### Top Routes by Internal Search Volume

```sql
SELECT
  stf_trip_shop_query_origin AS origin,
  stf_trip_shop_query_destination AS destination,
  COUNT(DISTINCT stf_trip_shop_id) AS shops
FROM `h4r-common-bi-prd.daventry__slv.fact_shop_trip_fare`
WHERE
  stf_trip_shop_received_date_utc = DATE_SUB(CURRENT_DATE(), INTERVAL 1 DAY)
  AND stf_trip_shop_trigger_name = 'InAppShop'
GROUP BY 1, 2
ORDER BY shops DESC
LIMIT 20
```

### Provider Health Check

```sql
SELECT
  normalized_provider,
  SUM(shop_count) AS total_shops,
  SUM(empty_shop_count) AS empty_shops,
  ROUND(SAFE_DIVIDE(SUM(empty_shop_count), SUM(shop_count)) * 100, 2) AS empty_pct
FROM `h4r-common-bi-prd.flights_shop__gld.wholeco_provider_shop_volume`
WHERE
  hour_ts >= TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 7 DAY)
  AND tenant = 'hopper-app'
GROUP BY 1
ORDER BY total_shops DESC
```

### Market Price Trends (Shadow Traffic)

```sql
SELECT
  date,
  stats.price10 AS great_price_usd,
  stops.no.price10 AS nonstop_great_price
FROM `gcp-hopper-etldata-production.warehouse.route_report_stats_1week_v3`
WHERE
  date >= DATE_SUB(CURRENT_DATE(), INTERVAL 90 DAY)
  AND filter = 'NoFilter'
  AND trip_type = 'round_trip'
  AND origin.code = 'JFK'
  AND destination.code = 'LHR'
  AND origin.region_type = 'airport'
ORDER BY date
```

---

## 6. Common Pitfalls

### Booking Data
1. **Session ID mismatch**: Session IDs in flight product tables do NOT match `booking_facts_v2`.
   Always join via `reservation_id`.
2. **Nested records**: The table embeds four record types. Use dot notation and be aware that
   not all records are populated for every row.

### Shopping Data
3. **Massive table**: `fact_shop_trip_fare` has 575B+ rows. Always filter by
   `stf_trip_shop_received_date_utc` and use LIMIT.
4. **Trigger filtering**: `stf_trip_shop_trigger_name = 'InAppShop'` gives user-initiated shops.
   Other triggers (Houston, background monitors) inflate volume counts.
5. **Multiple fares per trip**: Each trip can have multiple fare entries. Count distinct
   `stf_trip_id` or `stf_trip_shop_id` for trip/shop counts — not raw rows.

### Provider Volume
6. **Weighted vs raw counts**: Southlake uses `total_weighting` for `weighted_shop_count`.
   Other providers set `weighted_shop_count = shop_count`. Use `shop_count` for apples-to-apples
   comparison; use `weighted_shop_count` only for Sabre-specific analysis.
7. **Data availability dates**: Southlake/Facade from 2025-03-01. Madrid/London from 2025-05-02.

### Shadow Traffic
8. **Partition elimination error**: `route_report_*` requires `date`, `filter`, `trip_type`.
   `shops_v3` requires `received_date` and `trip_type`.
9. **Table not found**: `route_report_stats_1day_v3` does NOT exist. Use `_1week_v3`.
10. **Double-counting filters**: `filter='NoFilter'` includes all. Never sum across filter values.
11. **Double-counting geography**: `origin.code='NYC'` includes JFK+LGA+EWR.
    Filter to `origin.region_type='airport'`.
12. **best_price outliers**: Use `stats.price10` instead of `stats.best_price` for reliable pricing.
