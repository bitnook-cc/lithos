# CFAR Offers - Schema Reference

## Request Schema

```
POST /airline/v1.1/cfar_offers

{
  "request_type": "ancillary",              # required
  "ext_attributes": {},                     # required, Map[String, String] — partner metadata
  "itinerary": [                            # required, array of 1
    {
      "ancillaries": [                      # optional
        {
          "covered": true,                  # optional
          "passenger_reference": "<string>",# optional
          "total_price": "<string>",        # monetary value as string
          "type": "<string>"                # "cabin_bag", "checked_bag", "seat"
        }
      ],
      "currency": "<string>",              # required, 3-letter currency code
      "fare_rules": [                      # optional: itinerary-level fare rules
        {
          "modification_type": "<string>",  # "cancellation" or "change"
          "modification_time": "<string>",  # "before_departure", "after_departure", "anytime"
          "allowed": <boolean>,
          "fee": "<string>",               # optional, penalty fee amount
          "percentage": "<string>",        # optional, percentage-based penalty
          "refund_method": "<string>",     # optional: "ftc", "cash", "manual_cash"
          "currency": "<string>"           # optional, penalty currency
        }
      ],
      "other_fares": [                     # optional: alternative fares in same cabin
        {
          "fare_rules": [...],             # same structure as above
          "fare_basis": "<string>"
        }
      ],
      "passenger_pricing": [               # required, array (minItems: 1)
        {
          "passenger_count": {             # required
            "count": <integer>,            # required, >= 1
            "type": "<string>"             # required: adult, child, seated_infant, lap_infant
          },
          "individual_price": "<string>",  # required, monetary value as string
          "taxes": [                       # optional: ARRAY of cfar_passenger_tax objects
            { "code": "<string>", "amount": "<string>", "currency": "<string>" }
          ]
        }
      ],
      "passengers": [                      # optional (minimal in CFAR vs DG)
        {
          "passenger_reference": "<string>",# required
          "passenger_type": "<string>",    # required: adult, child, seated_infant, lap_infant
          "first_name": "<string>",        # optional
          "last_name": "<string>"          # optional
        }
      ],
      "slices": [                          # required, array (minItems: 1, max 10)
        {
          "fare_brand": "<string>",        # optional: e.g. "flex", "Lite"
          "fare_basis": "<string>",        # optional: slice-level fare basis e.g. "YBA123US"
          "fare_rules": [...],             # optional: slice-level fare rules
          "passenger_pricing": [...],      # optional: slice-level pricing override
          "total_price": "<string>",       # optional
          "segments": [                    # required, array
            {
              "origin_airport": "<IATA>",           # required, 3-letter code
              "destination_airport": "<IATA>",      # required, 3-letter code
              "departure_date_time": "<ISO8601>",   # required, YYYY-MM-DDTHH:mm:ss (no Z)
              "arrival_date_time": "<ISO8601>",     # required, YYYY-MM-DDTHH:mm:ss (no Z)
              "flight_number": "<string>",          # required
              "validating_carrier_code": "<string>", # required, 2-letter code
              "fare_class": "<string>"              # required: basic_economy, economy, premium_economy, business, first
            }
          ]
        }
      ],
      "total_price": "<string>"            # optional
    }
  ],
  "session": {                             # required
    "point_of_sale": "<string>",           # required, country code
    "language": "<string>"                 # required, language code (uppercase)
  }
}
```

Note: `coverage_extension` lives on the **offer response** (`cfar_offer.coverage_extension`), not on the request itinerary.

### Key Differences from DG Offers

| Field | CFAR | DG |
|-------|------|-----|
| Segment fare field | `fare_class` (basic_economy/economy/premium_economy/business/first) | `cabin` (economy/premium_economy/business/first — no basic_economy) |
| `fare_rules` | Yes — at itinerary, slice, and other_fares levels | No |
| `fare_basis` | Yes — at slice level | No |
| `other_fares` | Yes — alternative fares with their own fare_rules | No |
| `coverage_extension` | Yes — on the offer response (max ancillaries coverage amount) | No |
| `taxes` in passenger_pricing | Yes — array of cfar_passenger_tax `{code, amount, currency}` | Yes — array of dg_passenger_tax |
| Passenger data richness | Minimal (ref + type + optional name) | Extensive (ref, type, name, DOB, gender, passport, nationality) |

### FareRule Model (Critical for Refundable Fare Handling)

```
FareRule {
  modification_type: "cancellation" | "change"
  modification_time: "after_departure" | "anytime" | "before_departure"
  allowed: Boolean
  fee: Option[BigDecimal]          // penalty fee
  percentage: Option[BigDecimal]   // percentage-based penalty
  refund_method: Option["ftc" | "cash" | "manual_cash"]
  currency: Option[Currency]
}
```

Fare rules appear at three levels:
1. **Itinerary level** — applies to the entire booking
2. **Slice level** — applies to individual flight segments
3. **Within `other_fares`** — alternative fare rules for comparison

They directly affect exercise payout calculations:
- Penalties are deducted from refund amounts
- `refund_method` determines cash vs FTC split
- `other_fares` helps determine if the customer could have gotten a refundable fare

## Example: Standard Partner (Spirit Airlines, USD)

```json
{
  "request_type": "ancillary",
  "ext_attributes": {},
  "itinerary": [
    {
      "ancillaries": [
        { "covered": true, "passenger_reference": "PASSENGER1", "total_price": "25.00", "type": "checked_bag" },
        { "covered": true, "passenger_reference": "PASSENGER1", "total_price": "15.00", "type": "seat" }
      ],
      "currency": "USD",
      "fare_rules": [
        {
          "modification_type": "cancellation",
          "modification_time": "before_departure",
          "allowed": true,
          "fee": "75.00",
          "refund_method": "ftc",
          "currency": "USD"
        }
      ],
      "passenger_pricing": [
        {
          "individual_price": "350.00",
          "passenger_count": { "count": 1, "type": "adult" },
          "taxes": [{ "code": "US", "amount": "42.50", "currency": "USD" }]
        }
      ],
      "passengers": [
        { "passenger_reference": "PASSENGER1", "passenger_type": "adult", "first_name": "John", "last_name": "Doe" }
      ],
      "slices": [
        {
          "segments": [
            { "origin_airport": "LGA", "destination_airport": "BOS", "departure_date_time": "2026-04-15T14:30:00", "arrival_date_time": "2026-04-15T16:00:00", "flight_number": "1234", "validating_carrier_code": "NK", "fare_class": "economy" }
          ]
        },
        {
          "segments": [
            { "origin_airport": "BOS", "destination_airport": "LGA", "departure_date_time": "2026-04-15T20:30:00", "arrival_date_time": "2026-04-15T22:00:00", "flight_number": "1235", "validating_carrier_code": "NK", "fare_class": "economy" }
          ]
        }
      ],
      "total_price": "432.50"
    }
  ],
  "session": {
    "point_of_sale": "US",
    "language": "EN"
  }
}
```

## Response Schema

```
[                                           # response is an ARRAY (not object)
  {
    "id": "<string>",                       # offer ID, used in contract creation
    "premium": "<string>",                  # price of the CFAR product
    "coverage": "<string>",                 # coverage amount
    "coverage_extension": "<string>",       # optional, max ancillaries coverage
    "currency": "<string>",                 # 3-letter currency code
    "merchandising_url": "<string>"         # optional, URL for widget
  }
]
```

Note: Extract `response[0].id` as the offer ID for the contract step.
Also capture `hts-session-id` response header for booking confirmed events.

## Common Errors

- 400: Missing required fields, invalid fare_class value, malformed dates
- 401: Expired or invalid token
- 422: Unrealistic pricing for the currency — use per-currency defaults from partner-specifics.md
- 422: Unsupported partner/language/currency combination
