# CFAR Contract Status Transitions

## Contract Statuses

The `cfar_status` enum has exactly 5 values:

| Status | Description | Triggered By |
|---|---|---|
| `created` | Contract exists but not yet confirmed | `POST /cfar_contracts` |
| `confirmed` | Contract confirmed with PNR and email | `PUT /cfar_contracts/{id}/update_status` (or `/payment` for HTS MOR) |
| `voided` | Contract voided (typically by support) | Support API |
| `charged_back` | Chargeback filed against the contract | Chargeback processing |
| `canceled` | Contract canceled before expiry | `PUT /cfar_contracts/{id}/update_status` or Support API |

## Valid Transitions

```
created    -> confirmed     (API: update_status with pnr + email, or /payment for HTS MOR)
confirmed  -> voided        (Support API: void contract)
confirmed  -> charged_back  (System: chargeback processing)
confirmed  -> canceled      (API/Support: must be before expiry)
```

## Invalid Transitions

```
created    -> voided        (cannot void before confirmation)
created    -> canceled      (cannot cancel before confirmation)
confirmed  -> created       (cannot go backwards)
voided     -> confirmed     (terminal state)
charged_back -> confirmed   (terminal state)
canceled   -> confirmed     (terminal state)
```

## Exercise Statuses

| Status | Description | Triggered By |
|---|---|---|
| `created` | Exercise initiated | `POST /cfar_contract_exercises` |
| `confirmed` | Exercise completed, payouts initialized | `PUT /cfar_contract_exercises/{id}/mark_completed` |

## Exercise Transitions

```
created    -> confirmed     (API: mark_completed with refund details)
```

Failed exercise attempts surface as 4xx errors on the create or mark_completed call (validation, fraud check, contract not in confirmed status) rather than as a distinct exercise status.
