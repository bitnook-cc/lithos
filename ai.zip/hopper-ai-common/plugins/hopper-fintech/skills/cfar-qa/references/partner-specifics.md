# CFAR Partner-Specific Behavior

## Virgin Australia

- Carrier code: `VA`
- Auth: Sabre OAuth (clientId/clientSecret/authUri)
- PSS: Sabre
- Currency: AUD (single currency)
- Default route: SYD→MEL
- Payout method: Hyperwallet
- MOR: Partner
- Booking client: Real (live Sabre integration)
- Standard 5-step flow (Auth → Offers → Contract → Get → Update)

## Spirit Airlines

- Carrier code: `NK`
- Auth: Callback-based (no traditional OAuth)
- Currency: USD (single currency)
- Default route: LGA→BOS
- Payout method: Partner Credits
- MOR: Partner
- Booking client: Mock
- Used in most generic CFAR integration test fixtures

## Capital One

- No carrier code (OTA partner, not airline)
- Auth: API Key
- Currencies: CAD, USD, EUR (3 currencies)
- Default route: LGA→BOS
- Payout method: Partner Credits
- MOR: Partner
- Booking client: Real
- Staging callback URL: `https://hts-callback.staging.hoppercot.com`
- Also has a Corporate variant (Capital One Corporate)

## AirAsia

- Carrier code: `AK`
- Auth: Callback-based
- Currencies: 21 supported currencies (most of any CFAR partner)
- Default route: LGA→BOS (also JFK→LAX for multi-segment tests)
- Payout method: PushToCard + Hyperwallet
- MOR: Partner
- Booking client: Real
- Exercise cancellation uses AirAsia easycancel webhook endpoint
- For cancellation triage, see hopper-fintech:cfar-exercise-cancellation-triage

## Air Canada

- Carrier code: `AC`
- Auth: OAuth 2.0
- Currency: CAD (single currency)
- Default route: LGA→BOS
- Payout method: OverRefund
- MOR: **HTS MOR** — partner captures booking, HTS captures CFAR fee via `/payment` endpoint
- Booking client: Mock
- Do NOT call update_status before payment

## Jazeera Airways

- Carrier code: `J9`
- Auth: Dual callback (two authentication paths)
- PSS: Dual Navitaire (two Navitaire clients)
- Currencies: 18 supported currencies
- Default route: KWI→DXB
- Payout method: Spreedly + BankAccount
- MOR: Partner
- Booking client: Dual real clients
- Most complex partner configuration

## HK Express

- Carrier code: `UO`
- Auth: Navitaire (API Key + Username/Password)
- Currencies: HKD (primary)
- Default CFAR route: HKG→BKK
- **Uses separate CFAR credentials**: `HKEXPRESS_CLIENT_USERNAME_CFAR` / `HKEXPRESS_CLIENT_PASSWORD_CFAR`
- Also supports DG (uses `_DAFAR` suffix credentials)
- Navitaire staging URL: `https://dotrezapir4x-akm.test.uo.navitaire.com/`

## Flair Airlines

- Carrier code: `F8`
- Auth: API Key
- Currency: CAD
- Default route: NTE→YYC
- Standard flow

## Frontier Airlines

- Carrier code: `F9`
- Auth body does NOT include `audience` or `grant_type`
- Also supports DG (see dafar-qa skill for Frontier-specific Spreedly payment flow)

## Flyadeal

- Carrier code: `F3`
- Auth: Navitaire (API Key + Username/Password)
- Currencies: SAR, USD
- Also supports DG

## Two MOR Models

### Partner as MOR (most partners)
Partner captures everything (booking + CFAR fee). Standard flow uses update_status to confirm.

### HTS as MOR (e.g. Air Canada)
Partner captures booking only. HTS captures CFAR fee via `POST /cfar_contracts/{id}/payment`.
- Do NOT call update_status before payment
- Payment endpoint requires payment token and billing details
- See hts-mor-payment.md for full flow

## Flight Duration Reference (minutes)

| Route | Duration |
|---|---|
| LGA <-> BOS | 90 |
| SYD <-> MEL | 90 |
| KWI <-> DXB | 120 |
| HKG <-> BKK | 180 |
| NTE <-> YYC | 480 |
| JFK <-> LAX | 330 |

## Airport Timezones (UTC offset)

| Airport | UTC Offset |
|---|---|
| LGA | -4 |
| BOS | -4 |
| SYD | +11 |
| MEL | +11 |
| KWI | +3 |
| DXB | +4 |
| HKG | +8 |
| BKK | +7 |
| NTE | +2 |
| YYC | -6 |
| JFK | -4 |
| LAX | -7 |

## Supported Currencies per Partner

Sourced from `cfar-product-configuration.conf` (`offer.eligibility.allowedCurrencies`). The first currency listed is the canonical/primary currency for mock data; pick an alternate when explicitly testing FX behavior. An empty list (e.g. Oman Air) means "all currencies, gated only by the payment gateway".

| Partner | Config Key | Allowed Currencies |
|---|---|---|
| Hopper (default test) | `hopperCfarConfiguration` | CAD, USD, EUR |
| Amadeus | `amadeusCfarConfiguration` | CAD, USD, EUR, PHP, MYR, KWD |
| Virgin Australia | `virginAustraliaCfarConfiguration` | AUD |
| Air Canada | `airCanadaCfarConfiguration` | CAD |
| Spirit Airlines | `spiritAirlinesCfarConfiguration` | USD |
| Frontier Airlines | `frontierAirlinesCfarConfiguration` | USD |
| AirAsia | `airAsiaCfarConfiguration` | AUD, BDT, GBP, BND, EUR, HKD, INR, IDR, JPY, MOP, MYR, NZD, PHP, SGD, KRW, LKR, THB, USD, VND, CNY, TWD, SAR |
| Jazeera Airways | `jazeeraAirwaysCfarConfiguration` | KWD, SAR, USD, EGP, JOD, INR, AED, EUR, LKR, BHD, QAR, OMR, BDT, LBP, PKR, GEL, KZT, ETB, NPR |
| Flair Airlines | `flairAirlinesCfarConfiguration` | CAD, USD |
| HTS Airline | `htsAirlineCfarConfiguration` | CAD, USD |
| Travix Budget Air | `travixBudgetAirCfarConfiguration` | USD, CAD, EUR, GBP |
| Volaris | `volarisCfarConfiguration` | MXN, USD, ARS, AUD, GBP, CAD, COP, EUR, ILS, PEN |
| Hopper Security Limited | `hopperSecurityLimitedCfarconfiguration` | CAD, USD, EUR |
| Hopper Security All Access | `hopperSecurityAllAccesCfarConfiguration` | CAD, USD, EUR |
| HK Express | `hkExpressCfarConfiguration` | HKD, JPY, KRW, TWD, THB, CNY, PHP, USD, MYR |
| Sample OTA | `sampleOtaCfarConfiguration` | CAD, USD, EUR |
| Flyadeal | `flyadealCfarConfiguration` | AED, JOD, SAR, USD |
| Capital One | `capitalOneCfarConfiguration` | CAD, USD, EUR |
| Capital One Corporate | `capitalOneCorporateCfarConfiguration` | (inherits default) |
| Gother | `gotherCfarConfiguration` | HKD, JPY, KRW, TWD, THB, CNY, PHP, USD, MYR |
| RBC | `rbcCfarConfiguration` | CAD, USD, EUR |
| Bootstrap | `bootstrapCfarConfiguration` | USD |
| Serko | `serkoCfarConfiguration` | CAD, USD, EUR |
| Temp1dc77ba6 | `Temp1dc77ba6CfarConfiguration` | CAD, USD, EUR |
| Oman Air | `omanAirCfarConfiguration` | _all_ (`allowedCurrencies: []`) |
| WestJet | `westjetCfarConfiguration` | CAD, USD |
| Yahoo | `yahooCfarConfiguration` | USD |

Hopper-internal `bootstrap`, `htsAirline`, `Temp1dc77ba6`, `sampleOta`, `gother` configs are demo/test tenants — only use for QA fixtures, not real partner verification.

## Mock Pricing Defaults per Currency

These are reasonable per-passenger base fares for a 1-leg ~90 min domestic route. Adjust upward for longer hauls (HKG→BKK ~1.5×, multi-segment ~2×).

| Currency | Individual Price | Tax | Ancillary (bag) | Ancillary (seat) | Notes |
|---|---|---|---|---|---|
| USD | 350.00 | 42.50 | 25.00 | 15.00 | NK / F9 / yahoo / bootstrap |
| CAD | 425.00 | 55.00 | 30.00 | 18.00 | AC / F8 / WJ |
| EUR | 320.00 | 38.00 | 22.00 | 14.00 | EU/MEA partners |
| GBP | 280.00 | 34.00 | 20.00 | 12.00 | UK pricing |
| AUD | 480.00 | 60.00 | 35.00 | 20.00 | VA — keep ≥ AUD 100 to satisfy refund threshold (`amount: 999.99` cap) |
| HKD | 2700.00 | 320.00 | 195.00 | 115.00 | UO / gother |
| SGD | 460.00 | 55.00 | 33.00 | 19.00 | AirAsia |
| MYR | 1480.00 | 180.00 | 105.00 | 65.00 | AirAsia / Amadeus |
| PHP | 19500.00 | 2300.00 | 1400.00 | 850.00 | AirAsia / Amadeus |
| THB | 12500.00 | 1500.00 | 900.00 | 540.00 | AirAsia / UO |
| JPY | 38500 | 4600 | 2750 | 1650 | UO / AirAsia (zero-decimal — pass as integer string) |
| KRW | 460000 | 55000 | 33000 | 20000 | UO / AirAsia (zero-decimal) |
| TWD | 11000 | 1300 | 800 | 470 | UO / AirAsia |
| CNY | 2500.00 | 300.00 | 180.00 | 110.00 | UO / AirAsia |
| INR | 28500.00 | 3400.00 | 2100.00 | 1300.00 | J9 / Amadeus |
| AED | 1280.00 | 155.00 | 92.00 | 55.00 | F3 / J9 |
| SAR | 1300.00 | 160.00 | 95.00 | 58.00 | F3 / J9 |
| KWD | 105.00 | 13.00 | 7.50 | 4.50 | J9 / Amadeus (high-value currency — keep amounts low) |
| MXN | 6800.00 | 820.00 | 490.00 | 295.00 | Volaris |
| BRL / COP / ARS / PEN | scale from USD ~× exchange rate | — | — | — | Volaris LATAM tail |

For currencies not listed, pick the closest analogue and round to a sane retail price. The validator on `cfar_offers` rejects "obviously fake" prices (e.g. USD 1.00) with a 422.

## Mock Pricing Examples

```jsonc
// USD (Spirit, Yahoo, Bootstrap, Frontier)
"passenger_pricing": [{
  "individual_price": "350.00",
  "passenger_count": { "count": 1, "type": "adult" },
  "taxes": [{ "code": "US", "amount": "42.50", "currency": "USD" }]
}]

// AUD (Virgin Australia)
"passenger_pricing": [{
  "individual_price": "480.00",
  "passenger_count": { "count": 1, "type": "adult" },
  "taxes": [{ "code": "AU", "amount": "60.00", "currency": "AUD" }]
}]

// JPY (HK Express) — zero-decimal currency
"passenger_pricing": [{
  "individual_price": "38500",
  "passenger_count": { "count": 1, "type": "adult" },
  "taxes": [{ "code": "JP", "amount": "4600", "currency": "JPY" }]
}]
```
