# Cloud Portal URL Patterns

## CFAR Contracts

```
https://cloud.portal.staging.hopper.com/airline/cfar/{contractId}
```

The URL uses the `contract_id` (UUID), not the `contract_reference`.

## Portal Access

- Portal is IAP-protected (requires Hopper authentication)
- Staging portal: `cloud.portal.staging.hopper.com`
