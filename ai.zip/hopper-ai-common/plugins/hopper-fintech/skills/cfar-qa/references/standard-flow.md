# Standard CFAR API Flow - Request/Response Reference

## 1. Authentication

### Request
```json
POST /airline/v1.1/auth
Headers:
  Content-Type: application/json
  X-Forwarded-For: 192.168.0.1

{
  "client_id": "<{partner}-id from hts-airlines-staging-oauth-conf>",
  "client_secret": "<{partner}-secret from hts-airlines-staging-oauth-conf>",
  "audience": "https://airlines-api.staging.hopper.com",
  "grant_type": "client_credentials"
}
```

Note: Frontier does not send `audience` or `grant_type`. All other partners include both fields.

### Response (2xx)
```json
{
  "access_token": "eyJ...",
  "token_type": "bearer",
  "expires_in": 54000
}
```

## 2. Create CFAR Offers

### Standard Partner Request (Spirit Airlines, USD)
```json
POST /airline/v1.1/cfar_offers
Headers:
  Content-Type: application/json
  Authorization: Bearer <access_token>

{
  "request_type": "ancillary",
  "ext_attributes": {},
  "itinerary": [
    {
      "ancillaries": [
        { "covered": true, "passenger_reference": "PASSENGER1", "total_price": "25.00", "type": "checked_bag" },
        { "covered": true, "passenger_reference": "PASSENGER1", "total_price": "15.00", "type": "seat" }
      ],
      "currency": "USD",
      "fare_rules": [
        {
          "modification_type": "cancellation",
          "modification_time": "before_departure",
          "allowed": true,
          "fee": "75.00",
          "refund_method": "ftc",
          "currency": "USD"
        }
      ],
      "passenger_pricing": [
        {
          "individual_price": "350.00",
          "passenger_count": { "count": 1, "type": "adult" },
          "taxes": [{ "code": "US", "amount": "42.50", "currency": "USD" }]
        }
      ],
      "passengers": [
        { "passenger_reference": "PASSENGER1", "passenger_type": "adult", "first_name": "John", "last_name": "Doe" }
      ],
      "slices": [
        {
          "segments": [
            { "origin_airport": "LGA", "destination_airport": "BOS", "departure_date_time": "2026-04-15T14:30:00", "arrival_date_time": "2026-04-15T16:00:00", "flight_number": "1234", "validating_carrier_code": "NK", "fare_class": "economy" }
          ]
        },
        {
          "segments": [
            { "origin_airport": "BOS", "destination_airport": "LGA", "departure_date_time": "2026-04-15T20:30:00", "arrival_date_time": "2026-04-15T22:00:00", "flight_number": "1235", "validating_carrier_code": "NK", "fare_class": "economy" }
          ]
        }
      ],
      "total_price": "432.50"
    }
  ],
  "session": {
    "point_of_sale": "US",
    "language": "EN"
  }
}
```

### Key Rules
- Uses `fare_class` field (values: basic_economy, economy, premium_economy, business, first) — NOT `cabin` (that is DG)
- CFAR supports `fare_rules`, `fare_basis`, `other_fares`, `coverage_extension` fields — DG does not
- Passenger data is minimal (ref + type + optional name) compared to DG (which requires DOB, gender, passport, nationality)
- Date format: `YYYY-MM-DDTHH:mm:ss` (no `Z` suffix, no timezone offset)
- **Auth returns HTTP 201** (not 200) — always check for 2xx, not just 200

### Response (2xx)
```json
[
  {
    "id": "<offer_id>",
    "premium": "<amount>",
    "coverage": "<amount>",
    "currency": "<currency_code>",
    "merchandising_url": "<url>"
  }
]
```

Note: Response is an array. Extract `[0].id` as the offer ID.

## 3. Create CFAR Contract

### Standard Partner Request
```json
POST /airline/v1.1/cfar_contracts
Headers:
  Content-Type: application/json
  Authorization: Bearer <access_token>

{
  "offer_ids": ["<offer_id_from_step_2>"],
  "ext_attributes": {},
  "itinerary": {
    "ancillaries": [
      { "covered": true, "passenger_reference": "PASSENGER1", "total_price": "25.00", "type": "checked_bag" },
      { "covered": true, "passenger_reference": "PASSENGER1", "total_price": "15.00", "type": "seat" }
    ],
    "currency": "USD",
    "fare_rules": [
      {
        "modification_type": "cancellation",
        "modification_time": "before_departure",
        "allowed": true,
        "fee": "75.00",
        "refund_method": "ftc",
        "currency": "USD"
      }
    ],
    "passenger_pricing": [
      {
        "individual_price": "350.00",
        "passenger_count": { "count": 1, "type": "adult" },
        "taxes": [{ "code": "US", "amount": "42.50", "currency": "USD" }]
      }
    ],
    "passengers": [
      { "passenger_reference": "PASSENGER1", "passenger_type": "adult", "first_name": "John", "last_name": "Doe" }
    ],
    "slices": [
      {
        "segments": [
          { "origin_airport": "LGA", "destination_airport": "BOS", "departure_date_time": "2026-04-15T14:30:00", "arrival_date_time": "2026-04-15T16:00:00", "flight_number": "1234", "validating_carrier_code": "NK", "fare_class": "economy" }
        ]
      },
      {
        "segments": [
          { "origin_airport": "BOS", "destination_airport": "LGA", "departure_date_time": "2026-04-15T20:30:00", "arrival_date_time": "2026-04-15T22:00:00", "flight_number": "1235", "validating_carrier_code": "NK", "fare_class": "economy" }
        ]
      }
    ],
    "total_price": "432.50"
  }
}
```

Note: The itinerary structure is the same as step 2, but is a single object (not wrapped in an array). The `offer_ids` array must contain the offer ID from the offers response.

### Response (2xx)
```json
{
  "id": "<contract_id>",
  "reference": "<contract_reference>",
  "status": "created",
  "offer_ids": ["<offer_id>"],
  "premium": "<amount>",
  "coverage": "<amount>"
}
```

## 4. Get CFAR Contract

### Request
```
GET /airline/v1.1/cfar_contracts/<contract_id>
Headers:
  Authorization: Bearer <access_token>
```

### Response (2xx)
Returns full contract object matching the creation response with additional details.

## 5. Update CFAR Contract Status

### Request
```json
PUT /airline/v1.1/cfar_contracts/<contract_id>/update_status
Headers:
  Content-Type: application/json
  Authorization: Bearer <access_token>

{
  "status": "confirmed",
  "pnr_reference": "123ABC",
  "email_address": "test@example.com"
}
```

Note: Wait ~1 second after contract creation before calling update_status.

### Response (2xx)
```json
{
  "contract_id": "<contract_id>",
  "status": "confirmed",
  "pnr_reference": "123ABC"
}
```

## Date/Time Calculation

Itinerary dates must be dynamically calculated:

1. Get the current time at the **origin airport's timezone** (using UTC offset)
2. Add `advanceMinutes` (default: 1445) to get the outbound departure time
3. For return flights: add `advanceMinutes` + 8 hours
4. Calculate arrival time by adding the flight duration
5. Format as `YYYY-MM-DDTHH:mm:ss` (no Z suffix)

## Validation Checklist

- [ ] Auth returns valid token
- [ ] CFAR offers return an array with at least one offer containing `id`, `premium`, and `coverage`
- [ ] Contract creation uses offer_ids from offers response
- [ ] Contract GET returns matching contract_id and status
- [ ] Status update transitions contract to "confirmed"
- [ ] All currency values match the partner's configured currency
- [ ] Language in session matches partner's supported languages
- [ ] Step status codes are HTTP 2xx (not necessarily 200)
- [ ] `fare_class` used (not `cabin`)
