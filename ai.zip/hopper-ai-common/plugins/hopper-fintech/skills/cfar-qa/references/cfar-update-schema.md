# CFAR Contract Status Update - Schema Reference

## Request

```json
PUT /airline/v1.1/cfar_contracts/<contract_id>/update_status
Headers:
  Content-Type: application/json
  Authorization: Bearer <access_token>

{
  "status": "confirmed",                    # required: cfar_status enum
  "pnr_reference": "ABC123",                # required when transitioning to "confirmed"
  "email_address": "john@doe.com",          # optional
  "phone_number": "12345678900",            # optional
  "first_name": "John",                     # optional, cardholder
  "last_name": "Smith",                     # optional, cardholder
  "address_line1": "123 12th St",           # optional
  "address_line2": "Building B",            # optional
  "city": "Quebec City",                    # optional
  "state_or_province": "QC",                # optional
  "postal_code": "G1R 4S9",                 # optional
  "country": "CA",                          # optional
  "taxes_total": "20.00",                   # optional
  "taxes": [                                # optional, array of cfar_tax
    { "code": "<string>", "amount": "<string>", "currency": "<string>" }
  ],
  "currency": "USD",                        # optional, updated currency at payment time
  "exchange_rate": "0.75"                   # optional, partner-provided exchange rate
}
```

Note: Wait ~1 second after contract creation before calling update_status to ensure the contract is ready.

Valid `status` values (from `cfar_status` enum): `created`, `confirmed`, `charged_back`, `voided`, `canceled`.

## Response

```json
{
  "contract_id": "<contract_id>",
  "status": "confirmed",
  "pnr_reference": "123ABC"
}
```

## On Confirmation

When a contract transitions to `confirmed`:
- USD exchange rate is captured
- Contract is registered for disruption monitoring
- Fraud event is published
- Confirmation email is sent to the provided email address

## Status Transitions via API

```
created -> confirmed      (via update_status with pnr + email)
confirmed -> canceled     (via update_status, must be before expiry)
```

- `confirmed -> voided` is triggered via Support API, not the Partner API
- `confirmed -> charged_back` happens through chargeback processing
- HTS MOR partners should NOT call update_status before payment

## Common Errors

- 400: Invalid status transition (e.g. already confirmed)
- 404: Contract not found
- 422: Missing pnr_reference or email_address
