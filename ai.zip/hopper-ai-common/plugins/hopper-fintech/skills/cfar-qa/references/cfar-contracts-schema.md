# CFAR Contracts - Schema Reference

## Create Contract Request

```
POST /airline/v1.1/cfar_contracts

{
  "offer_ids": ["<string>"],                # required, from cfar_offers response[0].id
  "ext_attributes": {},                     # required, Map[String, String] — partner metadata
  "pnr_reference": "<string>",              # optional, can be set at creation
  "itinerary": {                            # required, single object (NOT array)
    "ancillaries": [...],                   # same structure as offers request
    "currency": "<string>",
    "fare_rules": [...],                    # optional, same structure as offers
    "other_fares": [...],                   # optional, same structure as offers
    "passenger_pricing": [...],             # taxes is ARRAY of cfar_passenger_tax
    "passengers": [...],
    "slices": [...],
    "total_price": "<string>"
  }
}
```

Key difference from offers: `itinerary` is a **single object**, not wrapped in an array.

## Example: Standard Partner (Spirit Airlines)

```json
{
  "offer_ids": ["<offer_id>"],
  "ext_attributes": {},
  "itinerary": {
    "ancillaries": [
      { "covered": true, "passenger_reference": "PASSENGER1", "total_price": "25.00", "type": "checked_bag" },
      { "covered": true, "passenger_reference": "PASSENGER1", "total_price": "15.00", "type": "seat" }
    ],
    "currency": "USD",
    "fare_rules": [
      {
        "modification_type": "cancellation",
        "modification_time": "before_departure",
        "allowed": true,
        "fee": "75.00",
        "refund_method": "ftc",
        "currency": "USD"
      }
    ],
    "passenger_pricing": [
      {
        "individual_price": "350.00",
        "passenger_count": { "count": 1, "type": "adult" },
        "taxes": [{ "code": "US", "amount": "42.50", "currency": "USD" }]
      }
    ],
    "passengers": [
      { "passenger_reference": "PASSENGER1", "passenger_type": "adult", "first_name": "John", "last_name": "Doe" }
    ],
    "slices": [
      {
        "segments": [
          { "origin_airport": "LGA", "destination_airport": "BOS", "departure_date_time": "2026-04-15T14:30:00", "arrival_date_time": "2026-04-15T16:00:00", "flight_number": "1234", "validating_carrier_code": "NK", "fare_class": "economy" }
        ]
      },
      {
        "segments": [
          { "origin_airport": "BOS", "destination_airport": "LGA", "departure_date_time": "2026-04-15T20:30:00", "arrival_date_time": "2026-04-15T22:00:00", "flight_number": "1235", "validating_carrier_code": "NK", "fare_class": "economy" }
        ]
      }
    ],
    "total_price": "432.50"
  }
}
```

## Create Contract Response

```json
{
  "id": "<contract_id>",
  "reference": "<contract_reference>",
  "status": "created",
  "offer_ids": ["<offer_id>"],
  "premium": "<amount>",
  "coverage": "<amount>"
}
```

## Get Contract

```
GET /airline/v1.1/cfar_contracts/<contract_id>
Headers:
  Authorization: Bearer <access_token>

Response: Full contract object with all fields from creation plus:
- timestamps
- passenger details
- itinerary details
- fare_rules
- exercise history (if any)
```

## Common Errors

- 400: Invalid offer_ids, missing required fields
- 404: Contract not found (invalid contract_id)
- 409: Offer already used in another contract
