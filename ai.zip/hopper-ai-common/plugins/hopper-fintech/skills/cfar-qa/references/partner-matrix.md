# CFAR Partner Configuration Matrix

## Primary QA Partners

| # | Partner | Code | Auth | PSS | Currencies | Payout Method | MOR | Booking Client | Default Route | events_v2 tenant |
|---|---------|------|------|-----|------------|---------------|-----|----------------|---------------|------------------------|
| 1 | Virgin Australia | VA | Sabre OAuth | Sabre | AUD | Hyperwallet | Partner | Real | SYD→MEL | `fa-virgin-aus` |
| 2 | Spirit Airlines | NK | Callback | Partner-managed | USD | Partner Credits | Partner | Mock | LGA→BOS | `fa-spirit` |
| 3 | Capital One | — | API Key | Custom | CAD, USD, EUR | Partner Credits | Partner | Real | LGA→BOS | `capone` |
| 4 | AirAsia | AK | Callback | Custom | 21 currencies | PushToCard + Hyperwallet | Partner | Real | LGA→BOS | `fa-air-asia` |
| 5 | Air Canada | AC | OAuth | Custom | CAD | OverRefund | HTS MOR | Mock | LGA→BOS | `fa-air-canada` |
| 6 | Jazeera Airways | J9 | Dual callback | Dual Navitaire | 18 currencies | Spreedly + BankAccount | Partner | Dual real clients | KWI→DXB | `fa-jazeera` |

## CFAR-Only Partners (CfarPartner)

| Partner | Notes |
|---------|-------|
| Capital One | Primary QA partner (see above) |
| Capital One Corporate | Similar to Capital One |
| Amadeus | Sabre OAuth auth |
| Virgin Australia | Primary QA partner (see above) |
| Air Canada | HTS MOR model (see above) |
| AirAsia | Primary QA partner (see above) |
| Hopper Security Limited | Internal |
| Travix (Budget Air) | Mock client (dev) |
| Westjet | Mock client (dev) |
| RBC | — |
| Serko | Mock client (dev) |
| Yahoo | Mock client (dev) |
| Bootstrap | — |
| Temp test partner | Testing only |

## Multi-Product Partners (CFAR + DG)

| Partner | Code | events_v2 tenant | Notes |
|---------|------|------------------------|-------|
| Hopper | — | `Hopper` | Internal |
| Spirit Airlines | NK | `fa-spirit` | Primary QA partner |
| HK Express | UO | `fa-hk-express` | Separate CFAR credentials (_CFAR suffix) |
| Flair Airlines | F8 | `fa-flair` | API Key auth |
| Flyadeal | F3 | `fa-flyadeal` | Navitaire auth |
| Frontier Airlines | F9 | `fa-frontier` | Omits audience/grant_type in auth |
| HTS Airline | — | — | Internal |
| Volaris | Y4 | `fa-volaris` | Standard flow |
| Sample Airline | — | — | Testing only |
| Jazeera Airways | J9 | `fa-jazeera` | Primary QA partner |
| Hopper Security All Access A | — | — | Internal |
| Hopper Security All Access B | — | — | Internal |
| Sample OTA | — | — | Testing only |
| Gother | VJ | `fa-gother` | Standard flow |
| Oman Air | WY | `fa-omanair` | Sabre OAuth auth |

## Credential Keys (in `hts-airlines-staging-oauth-conf`)

| Partner | Client ID Key | Client Secret Key |
|---------|---------------|-------------------|
| Air Canada | `air-canada-id` | `air-canada-secret` |
| AirAsia | `air-asia-id` | `air-asia-secret` |
| Flyadeal | `flyadeal-id` | `flyadeal-secret` |
| Frontier | `frontier-id` | `frontier-secret` |
| Gother | `gother-id` | `gother-secret` |
| HK Express (CFAR) | `HKEXPRESS_CLIENT_USERNAME_CFAR` | `HKEXPRESS_CLIENT_PASSWORD_CFAR` |
| Jazeera | `jazeera-id` | `jazeera-secret` |
| Spirit | `spirit-id` | `spirit-secret` |
| Virgin Australia | `virgin-australia-id` | `virgin-australia-secret` |
| Volaris | `volaris-id` | `volaris-secret` |
| Wizz Air | `wizz-air-id` | `wizz-air-secret` |

All credentials are in a single secret: `hts-airlines-staging-oauth-conf` in `gcp-hopper-app-staging`.

## API Connectivity (from Hopper AI / gcp-hopper-cicd)

The documented base URL `https://hc-airlines.staging.h4r.io` is NOT resolvable from the Hopper AI pod (which runs in `gcp-hopper-cicd`). Use the partner-api ingress gateway instead:

| Property | Value |
|---|---|
| Ingress IP | `34.111.178.58` |
| Host header | `airlines-api.staging.hopper.com` |
| Auth audience | `https://airlines-api.staging.hopper.com` |

**curl example:**
```bash
curl -sk -H "Host: airlines-api.staging.hopper.com" \
  https://34.111.178.58/airline/v1.1/auth
```

**In Python (urllib):**
```python
BASE_URL = "https://34.111.178.58"
HOST     = "airlines-api.staging.hopper.com"
# Include -H "Host: {HOST}" in all curl calls, or set Host header in urllib requests
```

Note: The `requests` library is NOT available in the Hopper AI runtime. Use `curl` via `subprocess` or `urllib` from the standard library.

## Auth Body Patterns

All credentials come from the single secret `hts-airlines-staging-oauth-conf` in `gcp-hopper-app-staging`.

**Frontier** (no audience/grant_type):
```json
{ "client_id": "<{partner}-id>", "client_secret": "<{partner}-secret>" }
```

**All other partners** (with audience/grant_type):
```json
{ "client_id": "<{partner}-id>", "client_secret": "<{partner}-secret>", "audience": "https://airlines-api.staging.hopper.com", "grant_type": "client_credentials" }
```

## Configuration Sources

- Partner types: `hc-airlines/src/main/resources/partners.conf`
- Per-partner CFAR settings: `cfar-product-configuration.conf` (1743 lines — currencies, payout methods, exercise eligibility, etc.)
- Runtime flags: LaunchDarkly (`cfar-purchase-enabled`, `cfar-exercise-enabled`, `cfar-exercise-session-check-revalidation-enabled`)

## Default Test Data

- Standard passenger name: "John Doe"
- Standard passenger reference: "PASSENGER1"
- PNR reference: "123ABC"
- Email: configurable at runtime
