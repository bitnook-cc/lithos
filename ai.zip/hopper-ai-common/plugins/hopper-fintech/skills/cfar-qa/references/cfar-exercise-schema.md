# CFAR Exercise - Schema Reference

## Create Exercise Request

```
POST /airline/v1.1/cfar_contract_exercises
Headers:
  Content-Type: application/json
  Authorization: Bearer <access_token>

{
  "contract_id": "<string>",                # optional (UUID), identifies the contract
  "itinerary": {                            # required
    "slices": [                             # required, NonEmptyList
      {
        "segments": [                       # required
          {
            "origin_airport": "<IATA>",
            "destination_airport": "<IATA>",
            "departure_date_time": "<ISO8601_no_Z>",
            "arrival_date_time": "<ISO8601_no_Z>",
            "flight_number": "<string>",
            "validating_carrier_code": "<string>",
            "fare_class": "<string>"
          }
        ],
        "fare_rules": [...],               # optional, slice-level fare rules
        "fare_basis": "<string>"            # optional
      }
    ],
    "passenger_pricing": [...],             # optional
    "ancillaries": [...],                   # optional
    "passengers": [...],                    # optional
    "other_fares": [...]                    # optional
  },
  "pnr_reference": "<string>",             # required
  "email_address": "<string>",             # optional
  "airline_refund_penalty": "<string>",     # optional, penalty fee from airline
  "airline_refund_method": "<string>",      # optional: "ftc", "cash", "manual_cash"
  "currency": "<string>",                  # optional
  "first_name": "<string>",                # optional
  "last_name": "<string>",                 # optional
  "callback_url": "<URL>",                 # optional
  "redirectback_url": "<URL>",             # optional
  "ext_attributes": {},                    # required, Map[String, String]
  "session": {                             # optional
    "point_of_sale": "<string>",
    "language": "<string>"
  }
}
```

Note: `passenger_pricing[].taxes` is an array of `cfar_passenger_tax` objects (`{code, amount, currency}`).

### Key Fields

- `contract_id`: UUID of the confirmed CFAR contract to exercise
- `pnr_reference`: PNR in the airline system (required)
- `airline_refund_penalty`: Penalty fee from the airline's fare rules — deducted from refund
- `airline_refund_method`: Determines how the refund splits between cash and FTC
  - `cash`: full refund in cash
  - `ftc`: refund as flight travel credit
  - `manual_cash`: manual cash refund processing

### Prerequisites

- Contract must be in `confirmed` status
- `contract.fraud` must NOT be `true` (blocks exercise initiation)
- `cfar-exercise-enabled` LaunchDarkly flag must be enabled

## Create Exercise Response (201)

```json
{
  "id": "<exercise_id>",
  "contract_id": "<contract_id>",
  "exercise_initiated_date_time": "<ISO8601>",
  "cash_refund_allowance": "<amount>",
  "ftc_refund_allowance": "<amount>",
  "currency": "<currency_code>",
  "redirection_token": "<token>",
  "redirection_url": "<url>"
}
```

### Response Fields

- `cash_refund_allowance`: Maximum cash refund amount after penalties
- `ftc_refund_allowance`: Maximum FTC refund amount after penalties
- `redirection_token` / `redirection_url`: For customer-facing exercise portal redirect

## Mark Exercise Completed

```
PUT /airline/v1.1/cfar_contract_exercises/<exercise_id>/mark_completed
Headers:
  Content-Type: application/json
  Authorization: Bearer <access_token>

{
  "refund_amount": "<string>",              # optional, actual refund amount
  "refund_method": "<string>"               # optional: "ftc", "cash", "manual_cash"
}
```

Both fields are optional but typically at least one is provided.

### On Completion

When mark_completed is called:
- Payouts are initialized
- Payout processing is triggered
- Fraud gateway check runs (`FraudGateway.cfarFraudPayoutDecision()`)
  - `Issue` → proceed with payout
  - `Hold` → manual review required

## Mark Completed Response (200)

Returns updated `CfarContractExercise` with the same structure as the create response, plus updated status and payout details.

## Exercise Lifecycle

```
POST /cfar_contract_exercises           → exercise status = "created"
PUT  /cfar_contract_exercises/{id}/mark_completed → exercise status = "confirmed"
                                         → payout processing begins
                                         → fraud check runs
```

## Payout States (Post-Exercise)

After exercise completion, payouts can be in these states:
- `Initiated` — payout processing started
- `Completed` — payout successfully delivered
- `Held` — fraud check returned Hold, manual review needed
- `HeldWithToken` — held with a payment token
- `FraudCheckExpired` — fraud check timed out
- `FraudCheckRejected` — fraud check rejected the payout

## Common Errors

- 400: Contract not in confirmed status
- 400: Contract already exercised
- 403: Contract flagged for fraud (contract.fraud = true)
- 404: Contract or exercise not found
- 422: Invalid refund method or amount
