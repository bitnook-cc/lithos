# HTS MOR Payment Flow

HTS MOR (Merchant of Record) is an alternative payment model where the partner captures the booking and HTS captures the CFAR fee separately.

## Partners Using HTS MOR

Currently: **Air Canada** (AC)

## How It Differs from Partner MOR

| Aspect | Partner MOR | HTS MOR |
|--------|-------------|---------|
| Who captures CFAR fee | Partner (bundled with booking) | HTS (separate charge) |
| Confirmation method | `PUT /update_status` | `POST /payment` |
| Status after purchase | `confirmed` via update_status | `confirmed` via payment |

## API Sequence (HTS MOR)

1. **Auth** `POST /airline/v1.1/auth` → `access_token`
2. **Offers** `POST /airline/v1.1/cfar_offers` → offer_id
3. **Contract** `POST /airline/v1.1/cfar_contracts` → contract_id
4. **Payment** `POST /airline/v1.1/cfar_contracts/{id}/payment` → confirmed

**Important**: Do NOT call `update_status` before payment. The payment endpoint handles status transition.

## Payment Request

```json
POST /airline/v1.1/cfar_contracts/<contract_id>/payment
Headers:
  Content-Type: application/json
  Authorization: Bearer <access_token>

{
  "payment_token": "<payment_method_token>",
  "first_name": "John",
  "last_name": "Smith",
  "address_line1": "123 12th St",
  "address_line2": "Building B",
  "city": "Quebec City",
  "state_or_province": "QC",
  "postal_code": "G1R 4S9",
  "country": "CA",
  "pnr_reference": "ABC123",
  "phone_number": "123566464448",
  "email_address": "test@example.com"
}
```

Note: Payment body uses flat fields (not nested `billing_address`/`contact` objects).

## Payment Response (2xx)

```json
{
  "succeeded": true
}
```

The response is the `cfar_payment` schema — a single boolean `succeeded` field. To verify the contract status transitioned to `confirmed`, follow up with `GET /cfar_contracts/{id}`.

## Common Errors

- 400: Invalid payment token
- 409: Contract already confirmed
- 422: Missing required billing fields
- CO112: "The contract status is incorrect" — caused by calling update_status before payment
