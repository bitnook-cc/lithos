# CFAR Widget Partner/Language Combinations

## Partners Without the Merchandising Widget

**Spirit Airlines, Air Canada, AirAsia, and Flair Airlines do not render the Hopper merchandising widget.** Their `cfar_offers` responses do not include a `merchandising_url`; instead they carry inline modal copy (`contents.{lang}.bullet_points`, `tile_title`, `modal_title`, etc.) that the partner UI renders directly. Skip widget validation for these partners.

## Primary QA Combos

| # | Partner | Language | Point of Sale | Default Currency |
|---|---------|----------|---------------|------------------|
| 1 | Virgin Australia | en | AU | AUD |
| 2 | Spirit Airlines | en | US | USD |
| 3 | Capital One | en | CA | CAD |
| 4 | AirAsia | en | MY | MYR |
| 5 | Air Canada | en | CA | CAD |
| 6 | Jazeera Airways | en | KW | USD |
| 7 | Jazeera Airways | ar | KW | USD |
| 8 | HK Express | en | HK | HKD |
| 9 | Flair Airlines | en | CA | CAD |
| 10 | Flyadeal | en | SA | SAR |
| 11 | Flyadeal | ar | SA | SAR |
| 12 | Frontier Airlines | en | US | USD |

## Multi-Product Partners (also in DAFAR)

Partners like HK Express, Flyadeal, Frontier, Jazeera, Volaris, and Gother support both CFAR and DG widgets. When validating these partners, test both `/cfar_offers` and `/dg_offers` merchandising URLs.

## With -x-invis Suffix

Each combination above can also be tested with the `-x-invis` suffix on point_of_sale for invisible widget tracking (e.g., `AU-x-invis`), doubling the total test surface.
