# Create CFAR - Consolidated Flow

> ⛔ *NEVER CALL PRODUCTION APIs. All CFAR QA MUST target staging only. Production calls create real contracts with real airlines and real money. There are NO exceptions.*

Single reference for creating a CFAR contract. Use this for the common "create a CFAR" request.

## Partner Quick Reference

| Partner | Code | Auth | Currency | Route | Advance Min | Notes |
|---------|------|------|----------|-------|-------------|-------|
| Virgin Australia | VA | Sabre OAuth | AUD | SYD→MEL | 1445 | Hyperwallet payouts |
| Spirit Airlines | NK | Callback | USD | LGA→BOS | 1445 | Partner credits; mock booking client |
| Capital One | — | API Key | CAD | LGA→BOS | 1445 | Partner credits |
| AirAsia | AK | Callback | MYR | LGA→BOS | 1445 | PushToCard + Hyperwallet |
| Air Canada | AC | OAuth | CAD | LGA→BOS | 1445 | HTS MOR; OverRefund payouts |
| Jazeera Airways | J9 | Dual callback | USD | KWI→DXB | 1445 | Spreedly + BankAccount |
| HK Express | UO | Navitaire | HKD | HKG→BKK | 1445 | Separate CFAR credentials |
| Flair Airlines | F8 | API Key | CAD | NTE→YYC | 1445 | Standard flow |

**Auth:** Frontier omits `audience` and `grant_type`; all others include both.

## API Sequence (Standard Partners — Partner as MOR)

1. **Auth** `POST /airline/v1.1/auth` → `access_token`
2. **Offers** `POST /airline/v1.1/cfar_offers` → `[0].id` (offer_id)
3. **Contract** `POST /airline/v1.1/cfar_contracts` → `id` (contract_id)
4. **Get** `GET /airline/v1.1/cfar_contracts/{id}` → verify
5. **Update** `PUT /airline/v1.1/cfar_contracts/{id}/update_status` → `confirmed`

**HTS MOR partners** (e.g. Air Canada): Steps 1–3, then:
- Step 6: `POST /airline/v1.1/cfar_contracts/{id}/payment` with payment token and billing details
Partner captures booking; HTS captures CFAR fee via `/payment`.
Do NOT call update_status before payment for HTS MOR partners.

## Request Schemas (Minimal)

### 1. Auth
```json
{ "client_id": "<{partner}-id from secret>", "client_secret": "<{partner}-secret from secret>" }
```
Standard partners add: `"audience": "https://airlines-api.staging.hopper.com", "grant_type": "client_credentials"`

All credentials come from the single secret `hts-airlines-staging-oauth-conf` in `gcp-hopper-app-staging`.

Headers: `Content-Type: application/json`, `X-Forwarded-For: 192.168.0.1`

### 2. CFAR Offers
- `itinerary`: array of 1 object with `slices`, `passenger_pricing`, `passengers`, `currency`, `ancillaries`
- Segments: `fare_class` (basic_economy/economy/premium_economy/business/first) — NOT `cabin`
- CFAR-specific fields: `fare_rules` (at itinerary/slice level), `fare_basis`, `other_fares`, `coverage_extension`
- `session`: `point_of_sale`, `language`

### 3. CFAR Contracts
- `offer_ids`: from offers response `[0].id`
- `itinerary`: same as offers but **single object** (not array)

### 4. Update Status
```json
{ "status": "confirmed", "pnr_reference": "123ABC", "email_address": "<email>" }
```
Wait ~1s after contract creation before calling.

## Date/Time Calculation

1. Current time at **origin airport timezone** (UTC offset)
2. Add `advanceMinutes` → outbound departure
3. Return: add advanceMinutes + 8h
4. Format: `YYYY-MM-DDTHH:mm:ss` (no Z)

## Execution Tips

- Use a single `python3` script: auth → offers → contract → get → update (or payment for HTS MOR)
- Cache tokens per partner (15h validity)
- Email: trigger user → Slack → fallback `cfar.<timestamp>@example.com`
- Portal URL: `https://cloud.portal.staging.hopper.com/airline/cfar/{contractId}`

## Validation

- Treat HTTP 2xx as success; validate required fields
- Monetary values: strings
- Extract `merchandising_url` from offers for reporting
- **Always present the merchandising URL in a code block** (`` ``` ``), never as a Slack `<url|text>` link — Slack corrupts the long base64 `offerData` query parameter, causing JSON parse errors in the widget
