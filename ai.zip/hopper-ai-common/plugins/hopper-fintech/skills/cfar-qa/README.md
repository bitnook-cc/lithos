# CFAR QA Skill

Full QA suite for CFAR (Cancel For Any Reason) contracts, covering contract creation, exercise, investigation, and widget validation.

## Capabilities

### Contract Investigation (360 View)
```
@Hopper AI show me a 360 view of CFAR contract 1f129120-b123-6618-9eaf-210438752fcd
```

### Contract Creation
```
@Hopper AI create a CFAR for Spirit Airlines
@Hopper AI create a CFAR contract for Virgin Australia
```

### Widget Validation
```
@Hopper AI validate merchandising widgets for all CFAR partners
```

## File Structure

```
cfar-qa/
  SKILL.md                          # Main skill (investigation + creation + exercise + widgets)
  README.md                         # This file
  references/
    create-cfar-flow.md             # Consolidated contract creation flow
    standard-flow.md                # Standard 5-step API sequence
    hts-mor-payment.md              # HTS MOR payment flow (Air Canada etc.)
    cfar-offers-schema.md           # CFAR offers request/response schema
    cfar-contracts-schema.md        # CFAR contracts request/response schema
    cfar-update-schema.md           # CFAR update_status schema
    cfar-exercise-schema.md         # Exercise create + mark_completed schema
    partner-matrix.md               # Partner config matrix (all 29 partners)
    partner-specifics.md            # Per-partner behavioral differences
    widget-combos.md                # Widget partner/language test matrix
    status-transitions.md           # Contract + exercise status transition rules
    portal-urls.md                  # Cloud portal URL patterns
```

## Secrets

Partner credentials are in GCP Secret Manager (`gcp-hopper-app-staging`).
The `platform-ai-hopper` service account has read access to staging secrets only.

See SKILL.md for the secret name mapping per partner.

## Data Sources

- **Datadog**: `service:hc-airlines` logs and APM traces (authoritative for contract state)
- **BigQuery**: `gcp-hopper-etldata-staging.hc_analytics.events_v2` (analytics events — filter by `session.tenant` with the `fa-` prefix, e.g. `fa-spirit`, `fa-jazeera`, `fa-air-canada`)
- **Pub/Sub**: `cfar_fintech_flights_events` topic (event pipeline)

## Related Skills

- [cfar-exercise-cancellation-triage](../cfar-exercise-cancellation-triage/) — Booking cancellation triage
- [cfar-fraud-review](../cfar-fraud-review/) — Fraud signals and investigation
- [dafar-qa](../dafar-qa/) — DAFAR (Disruption Guarantee) QA — similar structure, different product
