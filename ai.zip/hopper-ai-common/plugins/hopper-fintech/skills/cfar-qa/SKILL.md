---
name: cfar-qa
description: >
  Use when creating or testing flights CFAR contracts for airline partners, looking up
  a specific contract (360 view), or validating merchandising widgets. Covers contract
  creation via the Airlines API, exercise flow, partner credentials, and BigQuery
  analytics. This skill is currently for flights CFAR QA only — for production triage
  or lodging CFAR investigation, see cfar-triage.
  Triggers: "create a CFAR", "create CFAR contract", "test CFAR",
  "contract 360 view", "widget validation", "cfar offers", "airline CFAR".
---

# Flights CFAR QA

> **Scope:** `cfar-qa` currently covers flights CFAR QA/testing only. Lodging CFAR
> does not have a dedicated QA skill yet; use [cfar-triage](hopper-fintech:cfar-triage)
> for lodging debugging or production investigation.

## Overview

This skill covers **flights CFAR** (Cancel For Any Reason) for airline partners. It
provides QA procedures for:
- Investigating flights CFAR contracts (360 view, tracing, debugging)
- Creating new flights CFAR contracts end-to-end via the Airlines API
- Exercising flights CFAR contracts (partner-initiated and customer self-service)
- Validating merchandising widgets across partners and languages
- Analyzing contract lifecycle events in BigQuery and Datadog

**Service**: `hc-airlines` direct Airline API (`/airline/v1.1`)
**Environment**: staging (default for QA)

> ⛔ *VERY IMPORTANT — NEVER CALL PRODUCTION APIs*
>
> Under NO circumstances should you ever call production CFAR/Airlines APIs.
> - NEVER use production base URLs or production credentials.
> - NEVER target `hc-airlines.production.h4r.io` or any production ingress.
> - NEVER fetch secrets from `gcp-hopper-app-production`.
> - ALL QA work MUST use staging only (`gcp-hopper-app-staging`).
> - If a user asks you to run against production, REFUSE and explain why.
> - Production calls create real contracts with real airlines and real money.
> - There are NO exceptions to this rule.

## HTS Partner Context

This skill documents QA against the **hc-airlines direct API** (`/airline/v1.1/`).
Some HTS partners reach hc-airlines through gateway/BFF paths in production, but that
is not the primary workflow for this skill.

```
HTS gateway partners:  Partner BFF → hts-cfar → hts-gateway → hts-fintech-flights → hc-airlines
HTS direct API partners: Partner → Kong → hts-fintech-flights → hc-airlines
```

Do not mix the HTS `/flights-cfar/*` API model with the direct `/airline/v1.1/*`
QA procedures below. For HTS endpoint behavior, production triage, or cross-service
architecture, use [cfar-triage](hopper-fintech:cfar-triage) and
[cfar-reference](hopper-fintech:cfar-reference).

## When to Use This Skill

Invoke this skill when:
- Investigating a CFAR contract by ID
- Creating a new CFAR contract for testing
- Exercising a CFAR contract (partner API or customer self-service)
- Debugging quote, booking, or exercise flows
- Performing QA validation on airline integrations
- Tracing API call sequences for a contract
- Validating merchandising widget URLs
- Analyzing contract state transitions
- Investigating payout or refund issues

## Supported Partners

29 partners support CFAR, split into two categories:

### Primary QA Partners

| Partner | Code | Auth | Currency | Route | MOR | Notes |
|---------|------|------|----------|-------|-----|-------|
| Virgin Australia | VA | Sabre OAuth | AUD | SYD→MEL | Partner | Hyperwallet payouts; real booking client |
| Spirit Airlines | NK | Callback | USD | LGA→BOS | Partner | Partner credits; mock booking client |
| Capital One | — | API Key | CAD, USD, EUR | LGA→BOS | Partner | Partner credits; real booking client |
| AirAsia | AK | Callback | 21 currencies | LGA→BOS | Partner | PushToCard + Hyperwallet; real booking client |
| Air Canada | AC | OAuth | CAD | LGA→BOS | HTS MOR | OverRefund payouts; mock booking client |
| Jazeera Airways | J9 | Dual callback | 18 currencies | KWI→DXB | Partner | Spreedly + BankAccount; dual Navitaire clients |

### Additional CFAR-Only Partners

Capital One Corporate, Amadeus, Hopper Security Limited, Travix (Budget Air), Westjet, RBC, Serko, Yahoo, Bootstrap, temp test partner.

### Additional Multi-Product Partners (CFAR + DG)

Hopper, HK Express, Flair Airlines, Flyadeal, Frontier Airlines, HTS Airline, Volaris, Sample Airline, Hopper Security All Access A & B, Sample OTA, Gother, Oman Air.

See [Partner Matrix](references/partner-matrix.md) for full details (auth, PSS, currencies, payout methods, MOR model, booking clients).
See [Partner Specifics](references/partner-specifics.md) for per-partner behavioral differences.

## Partner Credentials (Staging Only)

CFAR and DAFAR share the same OAuth 2.0 Client Credentials infrastructure. Most partners reuse the same credentials for both products.

All partner OAuth credentials are in a *single* GCP Secret Manager secret:

- **Secret name**: `hts-airlines-staging-oauth-conf`
- **Project**: `gcp-hopper-app-staging`

**Fetching and extracting credentials at runtime**:
```bash
SECRET_JSON=$(gcloud secrets versions access latest \
  --secret="hts-airlines-staging-oauth-conf" \
  --project=gcp-hopper-app-staging)

# Example: Virgin Australia
CLIENT_ID=$(echo "$SECRET_JSON" | python3 -c "import sys,json; print(json.load(sys.stdin)['virgin-australia-id'])")
CLIENT_SECRET=$(echo "$SECRET_JSON" | python3 -c "import sys,json; print(json.load(sys.stdin)['virgin-australia-secret'])")
```

> ⛔ *NEVER fetch secrets from production projects. Only `gcp-hopper-app-staging` is permitted.*

### HK Express Exception

HK Express uses **separate CFAR credentials** (different from DAFAR):
- `HKEXPRESS_CLIENT_USERNAME_CFAR` / `HKEXPRESS_CLIENT_PASSWORD_CFAR` (vs `_DAFAR` suffix)

### Auth Patterns by PSS

| Pattern | Partners |
|---------|----------|
| OAuth 2.0 (Sabre) — clientId/clientSecret/authUri | Amadeus, Virgin Australia, Oman Air |
| API Key + Username/Password (Navitaire) | HK Express, Jazeera, Flyadeal |
| API Key Only | AirAsia, Flair, Gother |
| Mock Clients (dev) | Travix, Westjet, Serko, Yahoo |

### LaunchDarkly Feature Flags

Runtime behavior is controlled by these flags:
- `cfar-purchase-enabled` — enables/disables CFAR purchase flow
- `cfar-exercise-enabled` — enables/disables CFAR exercise flow
- `cfar-exercise-session-check-revalidation-enabled` — controls exercise session revalidation

## Creating a CFAR Contract

For "create a CFAR" requests, follow the [Create CFAR Flow](references/create-cfar-flow.md).

### API Sequence (Standard Partners)

1. **Auth** `POST /airline/v1.1/auth` → `access_token`
2. **Offers** `POST /airline/v1.1/cfar_offers` → offer_id
3. **Contract** `POST /airline/v1.1/cfar_contracts` → contract_id
4. **Get** `GET /airline/v1.1/cfar_contracts/{id}` → verify
5. **Update** `PUT /airline/v1.1/cfar_contracts/{id}/update_status` → `confirmed`

**HTS MOR partners** (e.g. Air Canada): Steps 1-3, then `POST /airline/v1.1/cfar_contracts/{id}/payment` to capture the CFAR fee. See [HTS MOR Payment](references/hts-mor-payment.md).

### API Base URL

Use staging: `https://hc-airlines.staging.h4r.io` (or read from environment if set).

### Key Rules

- CFAR uses `fare_class` field in segments (NOT `cabin` — that's DG)
  - Values: `basic_economy`, `economy`, `premium_economy`, `business`, `first`
- CFAR supports `fare_rules` at itinerary, slice, and otherFares levels — see [CFAR Offers Schema](references/cfar-offers-schema.md)
- All three create endpoints (`/cfar_offers`, `/cfar_contracts`, `/cfar_contract_exercises`) require `ext_attributes` (Map[String, String]) — pass `{}` when there is no metadata
- `passenger_pricing[].taxes` is an **array of `cfar_passenger_tax`** objects (`{code, amount, currency}`), not a string
- `passenger_type` enum: `adult`, `child`, `seated_infant`, `lap_infant`
- `cfar_status` enum: `created`, `confirmed`, `charged_back`, `voided`, `canceled` (no `failed`, `exercised`, or persisted `expired`)
- Date format: `YYYY-MM-DDTHH:mm:ss` (no Z suffix)
- Auth requires `X-Forwarded-For: 192.168.0.1` header
- Auth returns HTTP 201 (not 200) — always check for 2xx, not just 200
- Frontier auth body omits `audience` and `grant_type`; all others include both
- Always confirm the contract (update_status → confirmed) unless user says otherwise
- After CFAR offers, always extract and display the `merchandising_url` from the offer response
- After completion, display both the merchandising URL and the cloud portal URL:
  `https://cloud.portal.staging.hopper.com/airline/cfar/{contractId}`
- **Merchandising URL display**: Always present the merchandising URL inside a code block (`` ``` ``), NEVER as a Slack `<url|text>` link. The `offerData` query parameter contains a long base64-encoded payload that Slack link formatting corrupts, causing `SyntaxError: Expected ',' or '}'` in the widget. The cloud portal URL (short) can safely use Slack link format.

### Execution

Use a single `python3` script for the full API sequence. See reference files for request/response schemas:
- [Standard Flow](references/standard-flow.md)
- [HTS MOR Payment](references/hts-mor-payment.md)
- [CFAR Offers Schema](references/cfar-offers-schema.md)
- [CFAR Contracts Schema](references/cfar-contracts-schema.md)
- [CFAR Update Schema](references/cfar-update-schema.md)

### Email for Confirmation

Resolve confirmation email using this priority:
1. Use trigger user email from Slack context (`Email` field)
2. Use a generated test email (`cfar.<timestamp>@example.com`) if unavailable

## Exercise Flow

CFAR exercises are initiated after a contract is confirmed. Two models exist:

### Partner-Initiated Exercise (Partner API)

Two-step flow:

1. **Create Exercise** `POST /airline/v1.1/cfar_contract_exercises`
2. **Complete Exercise** `PUT /airline/v1.1/cfar_contract_exercises/{exerciseId}/mark_completed`

See [CFAR Exercise Schema](references/cfar-exercise-schema.md) for full request/response details.

#### Create Exercise Request (key fields)

```json
POST /airline/v1.1/cfar_contract_exercises
Headers:
  Content-Type: application/json
  Authorization: Bearer <access_token>

{
  "contract_id": "<contract_id>",
  "ext_attributes": {},
  "itinerary": {
    "slices": [
      {
        "segments": [
          {
            "origin_airport": "<IATA>",
            "destination_airport": "<IATA>",
            "departure_date_time": "<ISO8601_no_Z>",
            "arrival_date_time": "<ISO8601_no_Z>",
            "flight_number": "<string>",
            "validating_carrier_code": "<carrier_code>",
            "fare_class": "economy"
          }
        ]
      }
    ]
  },
  "pnr_reference": "123ABC",
  "email_address": "test@example.com",
  "airline_refund_penalty": "50.00",
  "airline_refund_method": "cash",
  "currency": "USD"
}
```

`ext_attributes` is required (Map[String, String]). Pass `{}` when there is no airline-specific metadata to attach.

**Response (201)**: Returns `CfarContractExercise` with `id`, `contract_id`, `exercise_initiated_date_time`, `cash_refund_allowance`, `ftc_refund_allowance`, `currency`, `redirection_token`, `redirection_url`.

#### Mark Completed Request

```json
PUT /airline/v1.1/cfar_contract_exercises/{exerciseId}/mark_completed
Headers:
  Content-Type: application/json
  Authorization: Bearer <access_token>

{
  "refund_amount": "350.00",
  "refund_method": "cash"
}
```

**Response (200)**: Updated `CfarContractExercise`.

### Customer Self-Service Exercise (Customer API)

**Only Oman Air currently implements the customer self-service exercise flow.** All other partners use the partner-initiated exercise endpoints described above.

Session-based flow for the claims portal:

1. `POST /customer/cfar_exercises` — creates exercise + generates `HC-Session-ID`
2. Verification codes (email/SMS)
3. Payout method selection
4. `POST /customer/initiate_payout` — triggers payout processing
5. Receipt download

Auth: `HC-Session-ID` header (generated in step 1, not OAuth).

### Fare Rules Impact on Exercise

Fare rules directly affect exercise payout calculations:
- Cancellation penalties from `fare_rules` are deducted from the refund amount
- `airline_refund_method` on the exercise request determines cash vs FTC split
- Only `refundable == true` payment methods are included in refund calculations
- FTC penalties are calculated separately from cash penalties
- Currency mismatches between refundable payments and coverage currency are validated

### Fraud Workflow Integration

Before payout processing, `FraudGateway.cfarFraudPayoutDecision()` runs:
- **Issue** → proceed with payout
- **Hold** → manual review required (payout states: `Held`, `HeldWithToken`, `FraudCheckExpired`, `FraudCheckRejected`)

If `contract.fraud = true` (set via Support API), exercise initiation is blocked entirely.

For fraud investigation details, see [hopper-fintech:cfar-fraud-review](hopper-fintech:cfar-fraud-review).

## Merchandising Widget Validation

When testing widgets, run CFAR offers for each partner/language combo and validate that `merchandising_url` is returned and accessible.

See [Widget Combos](references/widget-combos.md) for the test matrix.

Test with `-x-invis` suffix on point_of_sale for invisible widget tracking (e.g., `US-x-invis`).

## Contract Investigation (360 View)

When given a contract ID, provide a comprehensive view.

### Data Sources

#### 1. Datadog Logs
**Service**: `hc-airlines`
**Environment**: `staging` (default)

Prefer the Datadog MCP server tools (`mcp__datadog__*`) when available. The `hopper-fintech` plugin declares a Datadog MCP server in `.mcp.json`.

If Datadog MCP tools are not loaded, fall back to the Datadog REST API via curl:
- API base URL: `https://api.${DD_SITE}` — always use `$DD_SITE`, never hardcode
- Auth headers: `DD-API-KEY: $DD_API_KEY` and `DD-APPLICATION-KEY: $DD_APP_KEY`

```bash
curl -s -X POST "https://api.${DD_SITE}/api/v2/logs/events/search" \
  -H "Content-Type: application/json" \
  -H "DD-API-KEY: $DD_API_KEY" \
  -H "DD-APPLICATION-KEY: $DD_APP_KEY" \
  -d '{
    "filter": {
      "query": "service:hc-airlines env:staging {contract_id}",
      "from": "now-30d",
      "to": "now"
    },
    "sort": "timestamp",
    "page": { "limit": 50 }
  }'
```

#### 2. BigQuery

**Analytics events** (authoritative for the lifecycle): `gcp-hopper-etldata-staging.hc_analytics.events_v2`

Filter airline traffic with `session.tenant = 'fa-<airline>'` (e.g. `fa-spirit`, `fa-jazeera`, `fa-air-canada`). The `partner_name` column carries the same value but `tenant` is the canonical key.

Contract-level facts (status, premium, coverage) are not materialized to a dedicated airline contracts table — derive them by joining the relevant `cfar_*` event types below, or fall back to Datadog logs / the cloud portal.

**Chargeback analysis**:
- Production: `gcp-hopper-finance-production.chargebacks.chargeback_facts`
- Development: `gcp-hopper-finance-development.chargebacks.chargeback_facts_hc_airlines`

**Important**: CFAR contract IDs are embedded in the `data` JSON payload of analytics events. Use `TO_JSON_STRING(data) LIKE '%{contract_id}%'` or extract via `JSON_EXTRACT_SCALAR(data, '$.eventProperties.cfarPurchaseProperties.contractId')`.

**Known CFAR event types** (in lifecycle order):
1. `cfar_offers_eligible_partner` — session init / partner eligibility
2. `cfar_offers_request` — offer/quote requested
3. `cfar_contract_request` — contract creation requested
4. `cfar_complete_buy` — contract purchased
5. `booking_confirmed` — booking confirmed with PNR
6. `cfar_purchase_email_sent` — confirmation email sent
7. `cfar_exercise_request` — exercise initiated
8. `cfar_exercise_complete` — exercise completed
9. `fa_payout_initiated` — payout processing started
10. `fa_payout_completed` — payout finished

**Sample query — find events by contract ID**:
```sql
SELECT
  occurred_at,
  type,
  session.id as session_id,
  session.tenant,
  JSON_EXTRACT_SCALAR(data, '$.eventProperties.cfarPurchaseProperties.contractId') as contract_id,
  data
FROM `gcp-hopper-etldata-staging.hc_analytics.events_v2`
WHERE occurred_at > TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 7 DAY)
  AND session.tenant = '{tenant}'
  AND TO_JSON_STRING(data) LIKE '%{contract_id}%'
ORDER BY occurred_at
```

**Sample query — find all events in a session**:
```sql
SELECT
  occurred_at,
  type,
  session.id as session_id,
  session.tenant,
  data
FROM `gcp-hopper-etldata-staging.hc_analytics.events_v2`
WHERE occurred_at > TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 7 DAY)
  AND session.id = '{session_id}'
ORDER BY occurred_at
```

### 360 View Procedure

When given a contract ID:

1. **Overview**: Contract ID, reference, PNR, partner, environment, status, session ID
2. **API Call Sequence Timeline**: Trace full lifecycle (offer → contract → confirmation → exercise → payout)
3. **Flight Itinerary**: Routes, flight numbers, times, fare class
4. **Coverage & Pricing**: Base fare, ancillaries, premium, coverage %, cap
5. **Passengers**: Count, type, references
6. **Ancillaries**: Price per type
7. **Fare Rules**: Modification types, penalties, refund methods
8. **Exercise Details** (if exercised): Exercise ID, refund amount, refund method, payout status, fraud check result
9. **Infrastructure & Traces**: Service version, Datadog trace IDs with APM links

### Output Format

Use **Slack mrkdwn** (NOT GitHub markdown):
```
*360 View: CFAR Contract `{contract_id}`*

*Overview*
- *Contract ID*: `{contract_id}`
- *Reference*: `{reference}`
- *PNR*: `{pnr}`
- *Partner*: {partner_name} (`{tenant}`)
- *Status*: {status}

*API Call Sequence*
*0. Offer Creation* (HH:MM:SS UTC)
...

*Exercise Details*
- *Exercise ID*: `{exercise_id}`
- *Refund Amount*: {amount} {currency}
- *Refund Method*: {method}
- *Payout Status*: {status}

*Datadog Traces*
- <https://${DD_SITE}/apm/traces?query=trace_id:{trace_id}|Contract Creation>
```

## Contract Lifecycle

See [Status Transitions](references/status-transitions.md) and [Portal URLs](references/portal-urls.md).

### Contract Statuses

```
Created ──→ Confirmed ──→ Voided
    │              │──→ ChargedBack
    │              │──→ Canceled
    └──→ Failed
```

`canceled` must be applied before contract expiry. `charged_back` is persisted on
`cfar_contracts.status` and paired with `charged_back_date_time`; chargeback batch
processing may also restore the contract to `confirmed` if the finance chargeback
event is won. Expired is not persisted as a hc-airlines contract status in this QA flow.

### Exercise Statuses

```
Created ──→ Confirmed
    └──→ Failed
```

Exercise completion is tracked on `cfar_contract_exercises`, not by changing the
contract status to `exercised`. Historical `exercised` contract statuses were
backfilled to `confirmed` when exercise state moved to the exercise table.

### vs DAFAR

- DG has additional contract statuses `Queued` and `Failed` — not used in CFAR v1.1
- DG exercise is triggered by disruption detection; CFAR exercise is customer/partner-initiated
- Both CFAR and DG can use `Voided`, `ChargedBack`, and `Canceled` contract statuses

## Cross-References

- For CFAR service architecture, integration paths, and data tables, see [cfar-reference](hopper-fintech:cfar-reference).
- For booking cancellation triage (timeout handling, partner integration failures, cancellation status stuck in Processing), see [cfar-exercise-cancellation-triage](hopper-fintech:cfar-exercise-cancellation-triage).
- For payout fraud holds, manual fraud flagging, or fraud check expiration, see [cfar-fraud-review](hopper-fintech:cfar-fraud-review).
- For analytics event exploration and session lookups, see [analytics-events](hopper-fintech:analytics-events).

## Self-Healing

When testing reveals discrepancies between documented behavior and actual API responses:
1. Create a branch from `master` named `fix/cfar-qa-{short-description}`
2. Update the relevant files under `plugins/hopper-fintech/skills/cfar-qa/` (SKILL.md or references)
3. Open a draft PR to `hopper-ai-common` with evidence of what changed
4. Do NOT merge — a human must review

Only self-heal for confirmed, reproducible discrepancies. Do not speculate.

## Debugging Tips

### Missing Logs
1. Verify the contract ID is correct
2. Check the environment (staging vs production)
3. Expand time window
4. Try searching by reference number or session ID

### Missing BigQuery Events
1. Events publish to Pub/Sub topic `cfar_fintech_flights_events` and may lag by several minutes
2. Query by `session.id` instead of contract ID for pre-purchase events
3. Search `TO_JSON_STRING(data)` with LIKE
4. Expand `occurred_at` range

### Incomplete API Call Sequence
- Offer creation logs may exceed retention window
- Use trace IDs for related APM spans

### Exercise/Payout Issues
- Check fraud hold status — payout may be in `Held` or `FraudCheckExpired` state
- Verify fare rules penalties were correctly applied to refund calculation
- Check cancellation workflow state: `Pending → Processing → Completed/Failed/ProcessingTimedOut`
- For AirAsia, check partner webhook response (easycancel endpoint)
- 30-minute timeout applies for partner cancellation response
