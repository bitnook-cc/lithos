---
name: disruption
description: >
  Use when analyzing flight disruptions, cancellations, delays, flight notifications,
  disruption protection contracts, rebooking quality, quotes, refunds, or subscription
  coverage. Covers both Chicago (flight status) and Disruption Platform (product analytics)
  data in BigQuery.
---

# Disruption Analytics

Use this skill when users ask about flight disruptions, cancellations, delays, flight
notifications, disruption protection contracts, rebooking quality, quotes, refunds, or
subscription coverage.

## Overview

Two SQLMesh projects power disruption analytics:

- **Chicago** — Flight status and disruption detection. Raw flight notifications from
  data providers (OAG, CIRIUM) normalized into cancellations, delays, and a unified
  disruptions view. Segment-level summaries combine schedule, notification counts,
  disruption counts, and subscription data. Gold layer aggregates daily summaries by
  airline and airport, plus data provider quality indicators.

- **Disruption Platform** — Disruption protection product analytics. Contracts (premium,
  coverage, redemption, state ledger), rebooking search and option quality metrics,
  quotes, refunds, and cart transactions. Gold layer provides daily rebooking KPIs and
  cap simulation for product tuning.

All data lives in BigQuery project **`h4r-common-bi-prd`** across four datasets.

## Data Sources

### Chicago Silver — `h4r-common-bi-prd.chicago__slv`

Event-level flight disruption data. These are large tables — always filter by date when
querying directly.

| Table | Description |
|-------|-------------|
| `cancellations` | Deduplicated flight cancellations. One row per first cancellation notification per segment per data provider. Filter on `ts_added`. |
| `departure_delays` | Deduplicated departure delays. One row per first occurrence of a unique delay amount per segment per data provider. Filter on `ts_added`. |
| `disruptions` | Union of cancellations and delays. One row per unique disruption event (CANCELLED or DELAYED) per segment per provider. Filter on `ts_added`. |
| `flight_notifications` | Pass-through view of all flight status updates from data providers. Filter on `ts_added`. |
| `flight_subscriptions` | Client subscriptions to flight segments, enriched with schedule and tenant details. Filter on `client_subscription_added_ts`. |
| `segment_data_provider_metrics` | Per-airline per-data-provider aggregate metrics: notification, cancellation, and delay counts with derived rates. Small table, no date filter needed. |
| `segment_disruption_summary` | Per-segment summary combining schedule, notification counts, disruption counts, delay/cancellation details, and subscription data. Filter on `schedule_departure_utc`. |

### Chicago Gold — `h4r-common-bi-prd.chicago__gld`

Aggregated daily and periodic summaries.

| Table | Description |
|-------|-------------|
| `airline_daily_disruption_summary` | Daily disruption summary per airline: segment counts, delay buckets (30m/1h/2h/3h+), cancellations, percentages. Filter on `departure_date`. |
| `airport_daily_disruption_summary` | Daily disruption summary per departure airport, same structure as airline summary. Filter on `departure_date`. |
| `airline_notification_summary` | Airline-level notification and disruption summary for the last 3 months. Includes delay/cancellation metrics, subscription coverage, provider breakdowns. Small table. |
| `airport_notification_summary` | Airport-level notification and disruption summary for the last 3 months, same structure as airline summary. Small table. |
| `segment_data_provider_quality_indicators` | Data quality flags per airline per provider. Surfaces anomalies in notification rates, delay detection, cancellation detection, and processing lag. Small table. |
| `tenant_airline_subscription_summary` | Top 10 airlines per tenant by subscription volume. Small table. |
| `tenant_airport_subscription_summary` | Top 10 departure airports per tenant by subscription volume. Small table. |

### Disruption Platform Silver — `h4r-common-bi-prd.disruption_platform__slv`

Contract and rebooking event data. Large tables — filter by date when querying.

| Table | Description |
|-------|-------------|
| `contract_with_state_ledger` | Disruption protection contract combined with state ledger entries. One row per contract; state history in an array. Contains premium, redemption, coverage policies, itinerary slices, and purchaser details. Filter on `purchased_time`. |
| `fact_rebooking_search` | Per-search rebooking quality metrics: options shown vs excluded, exclusion reasons (price cap, fare class, MCT), same-day vs next-day. Filter on `shop_date`. |
| `fact_rebooking_option` | Per-trip-option detail: price, fare rating, nonstop, exclusion reasons, arrival delay vs original. Filter on `shop_date`. |
| `quote_table` | Disruption protection quotes: pricing, SKU, coverage/redemption policies, session context. Filter on `offered_time`. |
| `flight_refund` | Flight refunds associated with disruption contracts. Filter on `created_time`. |
| `disruption_cart_sell_transactions` | Sell transactions for disruption financial reports. Filtered to successful charges. Small table, no date filter needed. |

### Disruption Platform Gold — `h4r-common-bi-prd.disruption_platform__gld`

Aggregated rebooking metrics.

| Table | Description |
|-------|-------------|
| `rebooking_daily_metrics` | Daily pre-computed rebooking quality KPIs by tenant: search count, avg options shown, filter rate, exclusion breakdowns, nonstop vs connecting, airline switch rate. Filter on `metric_date`. |
| `rebooking_search_summary` | Per-search rebooking summary with exclusion proportions and shown-option characteristics. Filter on `shop_date`. |
| `rebooking_cap_simulation` | Simulates impact of raising rebooking cost caps and allowing fare class upgrades. Each row is one simulation scenario per tenant. Small table. |

## Key Concepts

### Disruption Types
- **CANCELLED** — Flight cancelled entirely
- **DELAYED** — Flight departure delayed (tracked in minutes)

### Data Providers
- **OAG** and **CIRIUM** — Two independent flight data providers. Both are tracked and
  compared via quality indicator tables.

### Contract States
Disruption protection contracts follow a lifecycle: `Initial` -> `Eligible` -> `Redeem` ->
`Conclude` (or `Void`). The `state_ledger_entries` array on each contract tracks all
state transitions with timestamps, amounts, and event details.

### Rebooking Quality Metrics
Rebooking searches return trip options that are filtered by:
- **Price cap** — Per-passenger or total cost limit
- **Fare class** — Maximum fare class rating (0=BasicEconomy through 4=First)
- **MCT** — Minimum connection time
- **Matching** — Excluded if identical to original itinerary

### Tenant IDs
Common tenant identifiers: `hopper-app`, `capone`, `rbc`, `fa-flair`. These appear
across subscriptions, contracts, and rebooking tables.

## Fraud Analysis Rules & Gotchas

**Always check the LAST payout event**: When reviewing the payout method for a CFAR/DAFAR contract, users may attempt multiple methods (e.g., a failed `push_to_card` followed by a successful `BankAccount`). Always look for the **last** payout event (order by `publish_time DESC` in `cfar_manual_review_detail_extract`) to determine the actual, final payout method used.

## Common Queries

### Disruption rates by airline (last 30 days)

```sql
SELECT
  airline_code,
  SUM(total_segments) AS total_flights,
  SUM(total_cancellations) AS cancellations,
  SUM(flights_delayed_1hr_plus) AS delayed_1hr_plus,
  ROUND(SAFE_DIVIDE(SUM(total_cancellations), SUM(total_segments)), 4) AS cancel_rate,
  ROUND(SAFE_DIVIDE(SUM(flights_delayed_1hr_plus), SUM(total_segments)), 4) AS delay_1hr_rate
FROM `h4r-common-bi-prd.chicago__gld.airline_daily_disruption_summary`
WHERE departure_date > CURRENT_DATE() - INTERVAL 30 DAY
GROUP BY airline_code
ORDER BY total_flights DESC
```

### Rebooking quality trends by tenant

```sql
SELECT
  tenant_id,
  metric_date,
  search_count,
  avg_options_shown,
  avg_filter_rate,
  pct_excluded_by_price,
  pct_nonstop_shown
FROM `h4r-common-bi-prd.disruption_platform__gld.rebooking_daily_metrics`
WHERE metric_date > CURRENT_DATE() - INTERVAL 30 DAY
ORDER BY tenant_id, metric_date
```

### Contract volume and redemption by tenant

```sql
SELECT
  tenant_id,
  contract_state,
  COUNT(*) AS contracts,
  SUM(premium_amount_usd) AS total_premium_usd,
  SUM(redeem_amount_usd) AS total_redeemed_usd
FROM `h4r-common-bi-prd.disruption_platform__slv.contract_with_state_ledger`
WHERE DATE(purchased_time) > CURRENT_DATE() - INTERVAL 30 DAY
GROUP BY tenant_id, contract_state
ORDER BY tenant_id, contracts DESC
```
