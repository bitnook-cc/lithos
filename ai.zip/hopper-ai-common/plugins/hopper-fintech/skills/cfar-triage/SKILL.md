---
name: cfar-triage
description: >
  Use when triaging CFAR issues, debugging failed exercises or payouts, investigating
  contract state problems, or responding to CFAR-related Datadog alerts for flights
  or lodging. Covers both verticals and all integration paths.
---

# CFAR Triage

## Overview

This skill covers debugging CFAR issues across both flights and lodging verticals.
Before diving into logs, understand the service chain — see
[cfar-reference](hopper-fintech:cfar-reference) for integration paths,
service chains, DD telemetry name mappings, and data table locations.

## First Steps for Any CFAR Alert

1. **Identify the vertical** — flights (hc-airlines) or lodging (cfar-lodging)?
   - DD service `hc-airlines` or `hts-fintech-flights` → flights
   - DD service `cfar-lodging` or `hts-fintech-lodging` → lodging
2. **Identify the environment** — always add `env:staging` or `env:production` to DD queries
3. **Get the contract or order ID** — from the alert, log message, or reporter
4. **Check which integration path** — see [cfar-reference](hopper-fintech:cfar-reference) for how to identify the path from DD traces
5. **Protect PII** — do not access, query, or output PII unless required. PII includes names, email addresses, phone numbers, physical addresses, IP addresses, travel document numbers, frequent flyer / loyalty identifiers, KTN/redress numbers, DOB, device IDs, or other user-identifying fields. This applies to all output surfaces (Slack, terminal, logs, documents). Booking/reservation references are acceptable debugging identifiers; Hopper ID / Amplitude ID may be shared when needed. Extracting specific non-PII fields from JSON payloads (error codes, status values, amounts, timestamps) is fine for triage — avoid dumping entire raw rows or full opaque payloads because they can contain PII mixed with operational fields.

## Flights CFAR Triage

### Key DD Service Names

| DD Service | Role |
|------------|------|
| `hts-fintech-flights` | Stateless REST gateway — if errors appear here, check hc-airlines next |
| `hc-airlines` | Source of truth — contract persistence (PostgreSQL), exercise, payouts |
| `hts-cfar` | Oklahoma cart integration in hts-gateway — offer/contract fulfillment |
| `hts-gateway` | Request proxy — if 5xx here, check if hts-fintech-flights is reachable |
| `hts-fintech-orders` | Order/payment store — check for payment authorization failures |

### Flights API Versions

| Base Path | Auth | Notes |
|-----------|------|-------|
| `/flights-cfar/v1/` | Auth0 OAuth | Same handlers as v2 |
| `/flights-cfar/v2/` | Kong API key | **Current**, default for new integrations |

The version number is the auth scheme, not a different API contract.

Staging: `https://hts-fintech-flights.staging.h4r.io`

### Events Table

Flights CFAR events go to:
```
gcp-hopper-etldata-{env}.hc_analytics.events_v2
```

Partition: `DATE(occurred_at)` — always include in WHERE clause.

Key event types (lifecycle order):
`cfar_offers_eligible_partner` → `cfar_offers_request` → `cfar_contract_request` →
`cfar_complete_buy` → `booking_confirmed` → `cfar_purchase_email_sent` →
`cfar_exercise_request` → `cfar_exercise_complete`

Filter by tenant: `session.tenant` (e.g., `session.tenant = 'fa-spirit'`)

### Contract States (Flights)

```
DRAFTED → CONFIRMED → EXERCISED | VOIDED | CANCELED
```

The partner-facing `flights-cfar` API model includes an `expired` status, but do not
assume every read path derives it the same way. For a reported issue, verify the actual
contract response and trace path. Gateway consumers may derive expiry in `hts-cfar`;
direct API behavior depends on the current `hts-fintech-flights` / `hc-airlines` read
path. Expiry is still enforced at exercise time regardless of which status is returned.

### Common Flights Failure Patterns

| Symptom | Where to look | Likely cause |
|---------|---------------|-------------|
| Offer creation fails | `service:hc-airlines` `"CreateOffers"` | fintech-models pricing error, invalid itinerary |
| Contract stuck in DRAFTED | `service:hts-fintech-orders` | Payment authorization failed (check Spreedly) |
| Exercise not completing | `service:hc-airlines` `"FulfillQuote"` | Partner booking cancellation timeout, payout failure |
| `mark_completed` not called | `service:hc-airlines` `"mark_completed"` | Upstream timeout after partner webhook |
| Payout held | `service:hc-airlines` `"FraudGateway"` | Fraud hold — check fraud decision in logs |

### DD Log Queries (Flights)

Search for a contract:
```
service:hc-airlines env:{env} {contract_id}
```

Search for exercise failures:
```
service:hc-airlines env:{env} ("ExerciseService" OR "FulfillQuote") status:error
```

Search for payout issues:
```
service:hc-airlines env:{env} ("PayoutService" OR "payout") {contract_id}
```

## Lodging CFAR Triage

### Key DD Service Names

| DD Service | Role |
|------------|------|
| `hts-fintech-lodging` | Stateless REST gateway — if errors here, check cfar-lodging next |
| `cfar-lodging` | Source of truth — contract persistence (Spanner), exercise, payouts |
| `cfar-lodging-subscriber` | PubSub consumer — processes payout status updates from customer-payouts |
| `cfar-lodging-dashboard` | Internal dashboard (BigQuery-backed) — not in the request path |
| `hts-fintech-orders` | Order/payment store — shared with flights |

### Lodging API Versions

Three API families exist with confusing naming:

| Base Path | Auth | Status |
|-----------|------|--------|
| `/cfar-hotels/v1` | Auth0 OAuth | Legacy — different endpoint surface, no contract get/search |
| `/lodging-cfar/v1` | Auth0 OAuth | Active — full endpoints with contract status |
| `/lodging-cfar/v2` | Kong API key | **Current** — same endpoints as v1, different auth |

Do NOT treat `/cfar-hotels/v1` and `/lodging-cfar/v1` as the same thing. The version
number is the auth scheme, not the API contract.

### Partner API Status Mapping

| cfar-lodging state | Partner API status |
|--------------------|--------------------|
| `PENDING` | `drafted` |
| `PURCHASE` | `confirmed` |
| `EXERCISE` | `exercised` |
| `VOID` | `voided` |
| `CANCEL` | `canceled` |

### Events Table

Lodging CFAR events go to a **different table** than flights:
```
gcp-hopper-etldata-{env}.fintech_analytics.events
```

Partition: `DATE(occurred_at)` — always include in WHERE clause.
Filter by namespace: `namespace = 'hotel_cfar'`

### Contract States (Lodging)

```
PENDING → PURCHASE → EXERCISE | VOID | CANCEL
```

There is no persisted EXPIRED state in cfar-lodging. A purchased contract past its
`expires_at` is still stored as `PURCHASE`. Whether the partner sees `confirmed` or
`expired` depends on the read path — verify the actual contract response and trace.
Expiry is enforced at exercise time regardless of which status is returned. EXPIRED
derivation in the downstream services is a WIP.

### Common Lodging Failure Patterns

| Symptom | Where to look | Likely cause |
|---------|---------------|-------------|
| Offer pricing fails | `service:cfar-lodging` `"GenerateRequest"` | fintech-models error (Remote pricing), or cfar-business library error (Local pricing) |
| Reservation verification fails | `service:cfar-lodging` `"ReservationService"` | Per-tenant reservation API unavailable or returning unexpected status |
| Exercise payout not arriving | `service:cfar-lodging-subscriber` | Subscriber not processing payout events from customer-payouts PubSub |
| Contract not found | `service:hts-fintech-lodging` | Check API version — `/cfar-hotels/v1` is legacy and has different contract lookup behavior than `/lodging-cfar/v1` or `/v2` |
| Config mismatch | `service:cfar-lodging` `"ConfigService"` | cfar-lodging uses fintech-config in `ServiceWins` mode — local HOCON may not reflect production config |

### DD Log Queries (Lodging)

Search for a contract:
```
service:cfar-lodging env:{env} {contract_id}
```

Search for exercise failures:
```
service:cfar-lodging env:{env} ("ExerciseService" OR "exercise") status:error
```

Search for payout subscriber issues:
```
service:cfar-lodging-subscriber env:{env} ("PayoutState" OR "payout" OR "exercise")
```

Search for reservation verification:
```
service:cfar-lodging env:{env} "ReservationService" {tenant}
```

### Dashboard and Contract Detail

Cloud portal: `cfar-lodging-dashboard.portal.hopper.com` (production).

Avoid querying or dumping raw Spanner extract mirror rows in Slack because raw
operational datasets can contain PII. Prefer dashboard views, sanitized analytics
events, aggregate counts, and redacted status summaries. If raw operational data is
required, have a human use approved internal tooling and share only minimal redacted
findings.

### API Schemas

This skill does not inline request/response schemas. To find them:
- Postman collections: `fintech-platform/tooling/documentation-generator/postman/collections/`
- Tapir endpoint definitions: `fintech-platform/api/http/lodging-cfar/src/`

Use `gh api` or a local `fintech-platform` checkout (branch `main`) to access.

## Lodging Pricing: Local vs Remote

Lodging CFAR has two pricing modes per partner:

- **Remote** — cfar-lodging calls fintech-models ML API over HTTP for pricing
- **Local** — hts-fintech-lodging runs pricing in-process via cfar-business library (no network call to cfar-lodging for pricing)

If a pricing issue affects only some partners, check which pricing mode they use.
The mode is configured per partner in hts-fintech-lodging's `base.conf` (`pricingConfig`).

## Exercise Portal Flow

When debugging exercise portal issues (customer self-service):

```
Exercise Widget → Kong → hts-fintech-exercise-bff → hc-airlines (flights) or cfar-lodging (lodging)
```

DD services in order: `hts-fintech-exercise-bff` → `hc-airlines` or `cfar-lodging`

The exercise widget is a JS app in `hts-fintech-ancillaries-web`. It handles its own
UI translations — the backend returns only structured data, no localized text.

## Triage Checklist

1. **Check contract state** — is it in the expected lifecycle stage?
2. **Check payment status** — did authorization/capture succeed? (hts-fintech-orders)
3. **Check payout status** — for exercise issues, is payout pending/held/failed?
4. **Check fraud hold** — was the exercise flagged by FraudGateway?
5. **Check partner booking status** — can the booking actually be cancelled?
6. **Check the other vertical** — flights and lodging flows are structurally parallel; an issue in one may exist in the other
7. **Check recent deployments** — if something was working recently, look at recent PRs in the relevant service

## Common Investigation Issues

**No logs found:**
1. Verify the contract/order ID is correct
2. Confirm the environment (staging vs production)
3. Expand the time window — DD log retention is ~15 days
4. Try searching by reference number or session ID instead of contract ID

**No BigQuery events:**
1. Events publish via PubSub and may lag by several minutes
2. For pre-purchase events, query by `session.id` instead of contract ID
3. Use `TO_JSON_STRING(data) LIKE '%{id}%'` for embedded IDs
4. Always include `DATE(occurred_at)` partition filter

**Exercise/cancellation stuck:**
- Cancellation workflow states: `Pending → Processing → Completed | Failed | ProcessingTimedOut`
- Partner cancellation response has a 30-minute timeout
- Check fraud hold — payout may be in `Held` or `FraudCheckExpired` state
- For AirAsia, see [cfar-exercise-cancellation-triage](hopper-fintech:cfar-exercise-cancellation-triage)

## Legacy Path Triage

This skill covers HTS CFAR triage. If the issue involves the **legacy path** (services
like `cfar-air-orchestrator`, `cfar-lodging-orchestrator`, `cfar-core`, `b2b-coordinators`),
the data infrastructure is different from HTS. Legacy data does not flow through
`hc_analytics.events_v2` or `fintech_analytics.events`. Instead, use the legacy BQ
datasets (production only):
- `gcp-hopper-etldata-production.cfar_core` — legacy contract/event/quote data
- `gcp-hopper-etldata-production.cfar_air` — legacy flights CFAR data; may include sensitive fields, so use only when necessary and redact output

See [cfar-reference](hopper-fintech:cfar-reference) data-tables.md for details.

## Cross-References

- [cfar-reference](hopper-fintech:cfar-reference) — service architecture, integration paths, DD telemetry mappings, database tables, BigQuery data sources
- [cfar-exercise-cancellation-triage](hopper-fintech:cfar-exercise-cancellation-triage) — AirAsia-specific cancellation webhook triage
- [cfar-qa](hopper-fintech:cfar-qa) — creating and testing flights CFAR contracts
- [cfar-fraud-review](hopper-fintech:cfar-fraud-review) — fraud investigation workflow
- [state-machine-debugging](hopper-developer:state-machine-debugging) — Oklahoma session debugging
- [secure-log-debugging](hopper-developer:secure-log-debugging) — external API call tracing
- [datadog-ops](hopper-developer:datadog-ops) — general Datadog investigation
