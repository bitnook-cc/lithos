---
name: analytics-events
description: >
  Use when looking up fintech analytics events, session activity, or event data from
  hc_analytics.events_v2 (flights) or fintech_analytics.events (lodging) in BigQuery.
  Use for fintech session event lookups, event type exploration, partner event filtering,
  or event volume trends.
---

# Fintech Analytics Events

Use this skill when users ask about *fintech* analytics events, session lookups, or event data exploration.

## Data Sources

**Flights and lodging use different event tables.**

**PII rule:** Do not access, query, or output PII unless required. PII includes names,
email addresses, phone numbers, physical addresses, IP addresses, travel document
numbers, frequent flyer / loyalty identifiers, KTN/redress numbers, DOB, device IDs,
and other user-identifying fields. This applies to all output surfaces (Slack,
terminal, logs, documents). Booking or reservation references are acceptable debugging
identifiers (they identify a booking, not a person). Hopper ID / Amplitude ID may be
shared when needed. Extracting specific non-PII fields from `data` JSON (error codes,
status values, amounts, timestamps) is fine for debugging. Avoid dumping full `data`
JSON, entire raw rows, or unredacted partner payloads because opaque payloads can
contain PII mixed with operational fields.

### Flights Events

| Environment | Table |
|-------------|-------|
| Production  | `gcp-hopper-etldata-production.hc_analytics.events_v2` |
| Staging     | `gcp-hopper-etldata-staging.hc_analytics.events_v2` |

Filter by tenant: `session.tenant = 'fa-<airline>'` (e.g., `fa-spirit`, `fa-air-canada`).

### Lodging Events

| Environment | Table |
|-------------|-------|
| Production  | `gcp-hopper-etldata-production.fintech_analytics.events` |
| Staging     | `gcp-hopper-etldata-staging.fintech_analytics.events` |

Filter by namespace: `namespace = 'hotel_cfar'` for lodging CFAR events.

### Defaults

Default to **production** unless the user specifies staging. Determine the vertical
from context — if the question mentions hotels, lodging, or cfar-lodging, use
`fintech_analytics.events`. Otherwise default to `hc_analytics.events_v2`.

**Important:** Both tables are partitioned on `occurred_at`. Every query MUST include a
`DATE(occurred_at)` filter or BigQuery will reject it. Default to the last 7 days if
the user doesn't specify a time range.

## Table Schema

Before writing queries, fetch the current schema from BigQuery:

```sql
SELECT field_path, data_type
FROM `{project}.hc_analytics.INFORMATION_SCHEMA.COLUMN_FIELD_PATHS`
WHERE table_name = 'events_v2'
```

This returns all columns including nested struct field paths (e.g. `session.partner_name`,
`session.device.platform_type`) so you don't need to guess at column names.

## Session Event Lookup

The primary use case. Given a session ID, retrieve all events in chronological order.

```sql
SELECT
  occurred_at,
  type,
  namespace,
  session.partner_name,
  entity_id,
  JSON_EXTRACT_SCALAR(data, '$.result.type') AS result
FROM `{project}.hc_analytics.events_v2`
WHERE session.id = '{session_id}'
  AND DATE(occurred_at) >= DATE_SUB(CURRENT_DATE(), INTERVAL 7 DAY)
ORDER BY occurred_at
```

If the user provides a date or date range, use that instead of the 7-day default.

To inspect event details for debugging, select only the specific JSON paths needed.
Avoid `TO_JSON_STRING(data) AS data_json` unless a human explicitly needs a local
inspection query, and never paste the raw payload into Slack.

### Example

User asks: "Show me the events for session 9debdd8e-d953-3976-bfa5-f5319a3df027"

Query:
```sql
SELECT
  occurred_at,
  type,
  namespace,
  session.partner_name,
  entity_id,
  JSON_EXTRACT_SCALAR(data, '$.result.type') AS result
FROM `gcp-hopper-etldata-production.hc_analytics.events_v2`
WHERE session.id = '9debdd8e-d953-3976-bfa5-f5319a3df027'
  AND DATE(occurred_at) >= DATE_SUB(CURRENT_DATE(), INTERVAL 7 DAY)
ORDER BY occurred_at
```

Result:
| occurred_at | type | partner_name | result |
|---|---|---|---|
| 2026-02-12 06:50:26 | cfar_offers_eligible_partner | capone | |
| 2026-02-12 06:50:26 | cfar_offers_request | capone | eligible |
| 2026-02-12 06:52:52 | cfar_offers_eligible_partner | capone | |
| 2026-02-12 06:52:52 | cfar_offers_request | capone | not_eligible |
| 2026-02-12 06:54:42 | cfar_offers_eligible_partner | capone | |
| 2026-02-12 06:54:42 | cfar_offers_request | capone | not_eligible |

This shows a user on Capone browsing flights — the first search was eligible for CFAR,
but subsequent searches were not eligible. Display results as a table and summarize the
session activity for the user.

## Useful Queries

**List event types by volume (last 3 days):**
```sql
SELECT type, COUNT(*) AS cnt
FROM `{project}.hc_analytics.events_v2`
WHERE DATE(occurred_at) >= DATE_SUB(CURRENT_DATE(), INTERVAL 3 DAY)
GROUP BY type
ORDER BY cnt DESC
```

**Events for a partner:**
```sql
SELECT occurred_at, type, session.id AS session_id, entity_id
FROM `{project}.hc_analytics.events_v2`
WHERE session.partner_name = '{partner_name}'
  AND DATE(occurred_at) >= DATE_SUB(CURRENT_DATE(), INTERVAL 1 DAY)
ORDER BY occurred_at DESC
LIMIT 100
```

**Daily volume by event type (for trend charts):**
```sql
SELECT DATE(occurred_at) AS event_date, type, COUNT(*) AS event_count
FROM `{project}.hc_analytics.events_v2`
WHERE DATE(occurred_at) >= DATE_SUB(CURRENT_DATE(), INTERVAL 14 DAY)
GROUP BY event_date, type
ORDER BY event_date, event_count DESC
```

## Cross-References

- See [cfar-reference](hopper-fintech:cfar-reference) for CFAR service architecture and data table overview
- See [cfar-triage](hopper-fintech:cfar-triage) for debugging CFAR issues using event data
- See [fintech-pricing](hopper-fintech:fintech-pricing) for product-level metrics from `universal_report`
