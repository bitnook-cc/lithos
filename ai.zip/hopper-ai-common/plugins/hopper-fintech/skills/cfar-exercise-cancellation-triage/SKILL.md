---
name: cfar-exercise-cancellation-triage
description: >
  Use when triaging CFAR exercise cancellation issues for airline partners (especially AirAsia),
  investigating failed or stuck cancellations, verifying the AirAsia easycancel webhook was called,
  confirming mark_completed status, identifying who triggered cancellations from Cloud Portal,
  or debugging the end-to-end CFAR exercise cancellation flow in hc-airlines.
  Triggers: "cfar cancellation", "exercise cancellation", "easycancel", "update_booking_cancellation_status",
  "cancel_booking", "mark_completed", "stuck exercise", "failed cancellation", "AirAsia cancellation",
  "cancellation triage", "who cancelled", "who triggered cancellation", "Cloud Portal cancellation".
---

# CFAR Exercise Cancellation Triage

Triage skill for investigating CFAR exercise cancellation issues in `hc-airlines` production.
Covers the full cancellation lifecycle: trigger, partner webhook, and completion.

## When to Use

- A CFAR exercise is stuck or didn't complete cancellation
- Need to verify the AirAsia easycancel webhook was called and returned 200
- Need to confirm `mark_completed` was called for exercises
- Investigating who triggered cancellations from Cloud Portal
- Debugging cancellation failures (timeouts, errors)
- Batch-verifying a list of exercise IDs

## Cancellation Flow (End-to-End)

The CFAR exercise cancellation follows this sequence:

```
1. Agent triggers via Cloud Portal
   PUT cloud.portal.hopper.com/support/v1.0/cfar/{exerciseId}/update_booking_cancellation_status
   └─ IAP header: x-goog-authenticated-user-email identifies the caller

2. System calls cancel_booking
   POST cloud.portal.hopper.com/support/v1.0/{exerciseId}/cancel_booking
   └─ Log: "Executing Cancel Booking callback for exercise {exerciseId}"

3. Partner webhook (AirAsia example)
   POST https://asia-southeast1-airasia-flights-prd.cloudfunctions.net/easycancel-webhook-listener-prd
   └─ Body: {"pnrReference","sessionId","exerciseId","refundAmount","refundCurrency","refundInitiatedByHopper":true}
   └─ Expected response: 200 OK, body: "received"

4. State update
   Log: "start updateCancellationState for exercise: {exerciseId}"
   Log: "done updateCancellationState for exercise: {exerciseId}"

5. Mark completed (called by airlines-api, NOT Cloud Portal)
   PUT airlines-api.hopper.com/airline/v1.1/cfar_contract_exercises/{exerciseId}/mark_completed

6. Analytics event emitted
   Event: fa_booking_cancellation_completed
   └─ Contains: partner, payout details, success/failure, error_detail
```

## Triage Steps

### Step 1: Find `update_booking_cancellation_status` Calls

Search for the triggering call in Datadog logs:

```
Query: service:hc-airlines env:production "Received request: PUT" update_booking_cancellation_status {exerciseId}
Index: use the appropriate weekly index (e.g., mar-24-apr-01-service-hc-airlines-env-production) or default indexes
```

Use `mcp__datadog__search_datadog_logs` with:
- `query`: `service:hc-airlines env:production "Received request: PUT" update_booking_cancellation_status {exerciseId}`
- `from`/`to`: appropriate time range
- For historical data, specify the correct `indexes` (weekly indexes follow pattern: `{month}-{day}-{month}-{day}-service-hc-airlines-env-production`)

### Step 2: Identify Who Triggered the Cancellation

The caller is identified via IAP headers in the companion "Request headers" log line:

```
Query: service:hc-airlines env:production update_booking_cancellation_status "x-goog-authenticated-user-email" {exerciseId}
```

Key header fields:
- `x-goog-authenticated-user-email`: the caller's email (e.g., `accounts.google.com:lcannuli@hopper.com`)
- `x-client-city` / `x-client-region`: caller's location
- `x-envoy-original-path`: confirms the exercise ID in the URL

Caller email domains map to organizations:
- `@hopper.com` — Hopper internal
- `@igt.hopper.com` — IGT support agents
- `@teleperformance.hopper.com` — Teleperformance support agents

### Step 3: Verify Partner Webhook (AirAsia easycancel)

Check that `cancel_booking` was called and the AirAsia webhook returned 200:

```
Query: service:hc-airlines env:production (easycancel OR "cancel_booking") {exerciseId}
```

Look for these log lines in sequence:
1. `Received request: POST .../support/v1.0/{exerciseId}/cancel_booking`
2. `Executing Cancel Booking callback for exercise {exerciseId}`
3. `Sending request: POST https://asia-southeast1-airasia-flights-prd.cloudfunctions.net/easycancel-webhook-listener-prd`
4. `Request: POST ...easycancel-webhook-listener-prd, ... response: 200 OK, ... body: received`

The webhook request body contains:
```json
{
  "pnrReference": "ABC123",
  "sessionId": "uuid",
  "exerciseId": "uuid",
  "refundAmount": "123.45",
  "refundCurrency": "MYR",
  "refundInitiatedByHopper": true
}
```

**If the easycancel call is missing**: the exercise may have been in a state where `cancel_booking` was not triggered (e.g., already cancelled, or the update_booking_cancellation_status only updated state without triggering the partner callback).

### Step 4: Verify `mark_completed`

Check that the exercise was marked as completed:

```
Query: service:hc-airlines env:production "mark_completed" {exerciseId}
```

Expected log: `Received request: PUT http://airlines-api.hopper.com/airline/v1.1/cfar_contract_exercises/{exerciseId}/mark_completed`

**Note**: `mark_completed` is called by `airlines-api.hopper.com`, not by Cloud Portal. It is triggered automatically after a successful cancellation flow. Multiple log entries per exercise are normal (retries/replicas).

### Step 5: Cross-Reference with Analytics Events (Optional)

For deeper investigation, search for the `fa_booking_cancellation_completed` event:

```
Query: "fa_booking_cancellation_completed" {exerciseId}
From: broader time range (event may be emitted asynchronously)
Storage: flex_and_indexes (for historical data)
```

This event contains:
- `partner`: e.g., `fa-air-asia`
- `payoutProperties.success`: `true` or `false`
- `payoutProperties.error_code` / `error_detail`: failure reason (e.g., `"Marked as failed from CS dashboard"`, `"Partner booking cancellation timed out"`)
- `payoutProperties.payout_amount` / `payout_currency`
- `cfarExerciseProperties.pnr`
- `userProperties.partnerId`

## Partner Webhook Endpoints

| Partner | Webhook URL |
|---------|------------|
| AirAsia | `https://asia-southeast1-airasia-flights-prd.cloudfunctions.net/easycancel-webhook-listener-prd` |

> Add other partner endpoints here as they are discovered.

## Batch Verification

When verifying multiple exercise IDs at once:

1. Use OR queries to search for multiple IDs simultaneously:
   ```
   (id1 OR id2 OR id3 ...) service:hc-airlines env:production "Received request: PUT" update_booking_cancellation_status
   ```

2. For the partner webhook check, split into batches of ~10 IDs per query to avoid DD query limits:
   ```
   (easycancel OR "cancel_booking") (id1 OR id2 OR id3 ...) service:hc-airlines env:production
   ```

3. For `mark_completed` verification:
   ```
   "mark_completed" (id1 OR id2 OR id3 ...) service:hc-airlines env:production
   ```

4. Summarize results in a table format:

| Exercise ID | Triggered By | AirAsia Webhook | Response | mark_completed |
|---|---|---|---|---|
| `abc123...` | user@hopper.com | Called | 200 OK | Yes |
| `def456...` | user@igt.hopper.com | NOT called | N/A | No |

## Common Failure Modes

| Symptom | Likely Cause | Investigation |
|---------|-------------|---------------|
| `update_booking_cancellation_status` called but no `cancel_booking` | Exercise in wrong state or already processed | Check exercise state in DB or prior cancellation attempts |
| `easycancel` returns non-200 | AirAsia endpoint issue | Check response body for error details; retry may be needed |
| `cancel_booking` called but no `mark_completed` | Partner webhook timed out or failed | Look for timeout logs: `"Partner booking cancellation timed out"` |
| `mark_completed` called but analytics event shows `success: false` | Downstream failure after partner ack | Check `error_detail` in the analytics event |
| Same exercise ID called multiple times | Agent retry or re-trigger from CS dashboard | Normal if previous attempt failed; verify final state |

## Datadog Index Naming Convention

Weekly log indexes for hc-airlines production follow the pattern:
```
{mon}-{dd}-{mon}-{dd}-service-hc-airlines-env-production
```

Examples:
- `mar-24-apr-01-service-hc-airlines-env-production` (Mar 24 – Apr 1)
- `apr-01-apr-08-service-hc-airlines-env-production` (Apr 1 – Apr 8)

Use these when searching historical logs. For recent logs (last few days), the default index works.

## Related Skills

- See [cfar-reference](hopper-fintech:cfar-reference) for CFAR service architecture and data tables
- See [cfar-triage](hopper-fintech:cfar-triage) for general CFAR triage across flights and lodging
- See [cfar-fraud-review](hopper-fintech:cfar-fraud-review) for fraud investigation on CFAR exercises
- See [exercise-monitoring](hopper-fintech:exercise-monitoring) for daily exercise anomaly detection
- See [analytics-events](hopper-fintech:analytics-events) for querying analytics events in BigQuery
