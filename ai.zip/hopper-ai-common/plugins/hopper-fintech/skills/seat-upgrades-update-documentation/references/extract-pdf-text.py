#!/usr/bin/env python3
"""Extract PDF text content to per-page .txt files and a TOC summary.

Usage:
    python3 extract-pdf-text.py <pdf_path> <output_dir>

Outputs:
    <output_dir>/page-NN.txt     — one per page, raw text
    <output_dir>/toc.txt         — TOC with page numbers
    <output_dir>/sections.json   — section-to-page mapping (level-1 sections with page ranges)
"""
import fitz
import json
import os
import re
import sys

if len(sys.argv) < 3:
    print("Usage: python3 extract-pdf-text.py <pdf_path> <output_dir>")
    sys.exit(1)

ALLOWED_BASE = "/tmp"

pdf_path = sys.argv[1]
out_dir = sys.argv[2]

if not os.path.realpath(pdf_path).startswith(os.path.realpath(ALLOWED_BASE) + os.sep):
    print(f"ERROR: pdf_path must be under {ALLOWED_BASE}, got: {pdf_path}")
    sys.exit(1)
if not os.path.realpath(out_dir).startswith(os.path.realpath(ALLOWED_BASE) + os.sep):
    print(f"ERROR: out_dir must be under {ALLOWED_BASE}, got: {out_dir}")
    sys.exit(1)

os.makedirs(out_dir, exist_ok=True)

MAX_PDF_SIZE = 200 * 1024 * 1024  # 200 MB
MAX_PAGE_TEXT = 1 * 1024 * 1024   # 1 MB per page

pdf_size = os.path.getsize(pdf_path)
if pdf_size > MAX_PDF_SIZE:
    print(f"ERROR: PDF too large ({pdf_size} bytes, max {MAX_PDF_SIZE})")
    sys.exit(1)

doc = fitz.open(pdf_path)
total_pages = len(doc)

# --- Extract TOC ---
toc = doc.get_toc()
toc_lines = []
level1_sections = []

for level, title, page_1indexed in toc:
    title = title.strip()
    if not title:
        continue
    page_0indexed = page_1indexed - 1
    indent = "  " * (level - 1)
    toc_lines.append(f"{indent}{title} (page {page_0indexed})")

    if level == 1:
        match = re.match(r'^(\d+(?:\.\d+)*)\s', title)
        if match:
            section_number = match.group(1)
        elif title.lower().startswith("introduction"):
            section_number = "intro"
        elif title.lower().startswith("change log"):
            section_number = "changelog"
        elif title.lower().startswith("table of content"):
            section_number = "toc"
        else:
            section_number = re.sub(r'[^a-z0-9\-]', '', title.lower().replace(" ", "-"))[:64]

        section_id = section_number.replace(".", "-") if re.match(r'^\d', section_number) else section_number
        section_id = re.sub(r'[^a-z0-9\-]', '', section_id)[:64]
        level1_sections.append({
            "sectionNumber": section_number,
            "sectionId": section_id,
            "title": title,
            "startPage": page_0indexed,
        })

# --- Compute page ranges for level-1 sections ---
for i, section in enumerate(level1_sections):
    if i + 1 < len(level1_sections):
        section["endPage"] = level1_sections[i + 1]["startPage"] - 1
    else:
        section["endPage"] = total_pages - 1
    section["pdfPages"] = list(range(section["startPage"], section["endPage"] + 1))

# --- Write per-page text ---
for page_num in range(total_pages):
    page = doc[page_num]
    text = page.get_text()
    text_bytes = text.encode("utf-8")
    if len(text_bytes) > MAX_PAGE_TEXT:
        print(f"WARNING: truncating page {page_num} text ({len(text_bytes)} bytes, max {MAX_PAGE_TEXT})")
        text = text_bytes[:MAX_PAGE_TEXT].decode("utf-8", errors="ignore")
    page_file = os.path.join(out_dir, f"page-{page_num:02d}.txt")
    with open(page_file, "w") as f:
        f.write(text)

# --- Write TOC ---
with open(os.path.join(out_dir, "toc.txt"), "w") as f:
    f.write("\n".join(toc_lines))

# --- Write sections map ---
with open(os.path.join(out_dir, "sections.json"), "w") as f:
    json.dump(level1_sections, f, indent=2)

doc.close()
print(f"Extracted {total_pages} pages to {out_dir}")
print(f"Found {len(level1_sections)} level-1 sections")
for s in level1_sections:
    print(f"  {s['sectionNumber']}: {s['title']} (pages {s['startPage']}-{s['endPage']})")
