# PDF to TypeScript Conversion Rules

## File structure

```typescript
import type { DocumentationData } from './documentationTypes';

// Image imports
import rulesOverview from '../../assets/documentation/2-2-1-rules-overview.jpg';
// ... other imports

export const documentationContent: DocumentationData = {
  title: '...',
  version: '...',
  lastUpdated: '...',
  sections: [
    // ... structured sections with markers
  ],
};
```

## Types to follow (from `documentationTypes.ts`)

```typescript
type DocBlock = {
  type: 'paragraph' | 'heading' | 'image' | 'table' | 'list' | 'note';
  content?: string;
  level?: 1 | 2 | 3;
  src?: string;          // Imported variable (not a string literal)
  alt?: string;
  caption?: string;
  rows?: string[][];     // First row = header
  items?: string[];
  ordered?: boolean;
  variant?: 'info' | 'warning' | 'tip';
};
```

## Section markers

Every top-level section (depth-0 in the `sections` array) MUST be wrapped with marker comments:

```typescript
// --- SECTION START: {section-id} ---
{
  id: '{section-id}',
  title: '...',
  content: [...],
  children: [...],
},
// --- SECTION END: {section-id} ---
```

These markers enable incremental updates without reading the full file.

## Conversion rules

1. **PDF headings** -> `DocSection` with kebab-case id and children for sub-levels
   - Level 1 heading -> section at depth 0
   - Level 2 heading -> section in `children` at depth 0
   - Level 3 heading -> section in `children` at depth 1

2. **Paragraphs** -> `{ type: 'paragraph', content: '...' }`
   - Use `<strong>` for bold, `<em>` for italic
   - Keep links with `<a href="...">...</a>`

3. **Bullet lists** -> `{ type: 'list', items: [...] }`
   - `ordered: true` for numbered lists
   - Inline HTML allowed in items

4. **Tables** -> `{ type: 'table', rows: [[...], [...]] }`
   - First row = headers
   - Inline HTML allowed in cells

5. **Images** -> `{ type: 'image', src: importedVariable, alt: '...', caption: '...' }`
   - `src` must reference the imported variable (not a string)
   - `alt` describes the image content

6. **Notes/Callouts** -> `{ type: 'note', content: '...', variant: 'info' | 'warning' | 'tip' }`
