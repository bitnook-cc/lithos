#!/usr/bin/env python3
"""Extract images from PDF and build/update image registry.

Usage:
    python3 extract-images.py <pdf_path> <assets_dir>

Outputs:
    <assets_dir>/_image-registry.json  — updated image registry
    <assets_dir>/_change-report.json   — change report (new/changed/unchanged/deleted)
    <assets_dir>/*.jpg                 — extracted images
"""
import fitz
from PIL import Image
import io
import os
import json
import hashlib
import re
import sys
from datetime import datetime, timezone

if len(sys.argv) < 3:
    print("Usage: python3 extract-images.py <pdf_path> <assets_dir>")
    sys.exit(1)

ALLOWED_BASE = "/tmp"

pdf_path = sys.argv[1]
out_dir = sys.argv[2]

if not os.path.realpath(pdf_path).startswith(os.path.realpath(ALLOWED_BASE) + os.sep):
    print(f"ERROR: pdf_path must be under {ALLOWED_BASE}, got: {pdf_path}")
    sys.exit(1)
if not os.path.realpath(out_dir).startswith(os.path.realpath(ALLOWED_BASE) + os.sep):
    print(f"ERROR: out_dir must be under {ALLOWED_BASE}, got: {out_dir}")
    sys.exit(1)

registry_path = os.path.join(out_dir, "_image-registry.json")


def safe_path(base, filename):
    target = os.path.realpath(os.path.join(base, filename))
    base_real = os.path.realpath(base)
    if not target.startswith(base_real + os.sep):
        raise ValueError(f"Path traversal detected: {filename}")
    return target

def validate_registry_entry(img):
    if not isinstance(img.get("pdfPage"), int):
        return False
    if not isinstance(img.get("extractionIndex"), int):
        return False
    if not isinstance(img.get("filename"), str) or not img["filename"]:
        return False
    if img.get("importName") is not None and not isinstance(img["importName"], str):
        return False
    if isinstance(img.get("importName"), str) and not re.match(r'^[a-zA-Z_][a-zA-Z0-9_]*$', img["importName"]):
        return False
    return True


# --- Load existing registry (if present) ---
old_registry = None
if os.path.exists(registry_path):
    with open(registry_path) as f:
        old_registry = json.load(f)
old_images_by_key = {}
if old_registry:
    for img in old_registry.get("images", []):
        if not validate_registry_entry(img):
            print(f"WARNING: skipping invalid registry entry: {img}")
            continue
        key = (img["pdfPage"], img["extractionIndex"])
        old_images_by_key[key] = img

MAX_PDF_SIZE = 200 * 1024 * 1024  # 200 MB
MAX_IMAGE_SIZE = 50 * 1024 * 1024  # 50 MB
MAX_IMAGE_COUNT = 1000

# --- PDF size guard ---
pdf_size = os.path.getsize(pdf_path)
if pdf_size > MAX_PDF_SIZE:
    print(f"ERROR: PDF too large ({pdf_size} bytes, max {MAX_PDF_SIZE})")
    sys.exit(1)

# --- PDF hash (streaming) ---
sha = hashlib.sha256()
with open(pdf_path, "rb") as f:
    for chunk in iter(lambda: f.read(65536), b""):
        sha.update(chunk)
pdf_hash = sha.hexdigest()

# --- Open the PDF ---
doc = fitz.open(pdf_path)

# --- Build page -> section-number mapping from TOC ---
toc = doc.get_toc()
page_section_map = {}

for level, title, page_1indexed in toc:
    title = title.strip()
    if not title:
        continue
    page_0indexed = page_1indexed - 1
    match = re.match(r'^(\d+(?:\.\d+)*)\s', title)
    if match:
        section_num = match.group(1)
        page_section_map[page_0indexed] = section_num
    elif title.lower().startswith("introduction"):
        page_section_map[page_0indexed] = "intro"
    elif title.lower().startswith("change log"):
        page_section_map[page_0indexed] = "changelog"
    elif title.lower().startswith("table of content"):
        page_section_map[page_0indexed] = "toc"


def get_section_for_page(page_num):
    for p in range(page_num, -1, -1):
        if p in page_section_map:
            return page_section_map[p]
    return "misc"


def section_num_to_prefix(section_num):
    if section_num in ("intro", "changelog", "toc", "misc"):
        return section_num
    return section_num.replace(".", "-")


# --- Extract images ---
pdf_images = []
for page_num in range(len(doc)):
    page = doc[page_num]
    images = page.get_images(full=True)
    for img_idx, img in enumerate(images):
        xref = img[0]
        smask = img[1]
        pdf_images.append((xref, smask, page_num, img_idx))

if len(pdf_images) > MAX_IMAGE_COUNT:
    print(f"ERROR: too many images ({len(pdf_images)}, max {MAX_IMAGE_COUNT})")
    doc.close()
    sys.exit(1)

# --- Count images per section for -a, -b, -c suffix ---
section_image_counts = {}

results = []
change_report = {"new": [], "changed": [], "unchanged": [], "deleted": []}

for idx, (xref, smask, page_num, img_idx) in enumerate(pdf_images):
    base_image = doc.extract_image(xref)
    image_bytes = base_image["image"]

    if len(image_bytes) > MAX_IMAGE_SIZE:
        print(f"WARNING: skipping oversized image xref={xref} ({len(image_bytes)} bytes)")
        continue

    content_hash = hashlib.sha256(image_bytes).hexdigest()

    pil_img = Image.open(io.BytesIO(image_bytes))
    has_alpha = smask != 0 or pil_img.mode == 'RGBA' or pil_img.mode == 'PA'

    if has_alpha or pil_img.mode != 'RGB':
        if smask != 0 and 0 < smask < doc.xref_length():
            smask_image = doc.extract_image(smask)
            mask_bytes = smask_image["image"]
            mask_pil = Image.open(io.BytesIO(mask_bytes)).convert('L')
            if pil_img.mode != 'RGBA':
                pil_img = pil_img.convert('RGBA')
            if mask_pil.size != pil_img.size:
                mask_pil = mask_pil.resize(pil_img.size, Image.LANCZOS)
            pil_img.putalpha(mask_pil)
        white_bg = Image.new('RGB', pil_img.size, (255, 255, 255))
        if pil_img.mode == 'RGBA':
            white_bg.paste(pil_img, mask=pil_img.split()[3])
        else:
            pil_img = pil_img.convert('RGB')
            white_bg = pil_img
        pil_img = white_bg

    section_num = get_section_for_page(page_num)
    prefix = section_num_to_prefix(section_num)

    key = (page_num, img_idx)
    old_entry = old_images_by_key.get(key)

    if old_entry and old_entry["contentHash"] == content_hash:
        filename = old_entry["filename"]
        import_name = old_entry["importName"]
        change_report["unchanged"].append(filename)
    else:
        temp_name = f"img-{idx:02d}-page-{page_num:02d}"
        temp_path = os.path.join(out_dir, f"{temp_name}.jpg")
        pil_img.save(temp_path, 'JPEG', quality=92)

        if old_entry:
            filename = old_entry["filename"]
            import_name = old_entry["importName"]
            final_path = safe_path(out_dir, filename)
            os.rename(temp_path, final_path)
            change_report["changed"].append(filename)
        else:
            filename = f"{temp_name}.jpg"
            import_name = None
            change_report["new"].append(filename)

    if section_num not in section_image_counts:
        section_image_counts[section_num] = 0
    section_image_counts[section_num] += 1

    results.append({
        "index": idx,
        "page": page_num,
        "filename": filename,
        "importName": import_name,
        "width": pil_img.size[0],
        "height": pil_img.size[1],
        "contentHash": content_hash,
        "sectionNumber": section_num,
        "isNew": old_entry is None,
        "extractionIndex": img_idx
    })

# --- Detect deleted images ---
current_keys = {(page_num, img_idx) for _, _, page_num, img_idx in pdf_images}
if old_registry:
    for img in old_registry.get("images", []):
        key = (img["pdfPage"], img["extractionIndex"])
        if key not in current_keys:
            deleted_path = safe_path(out_dir, img["filename"])
            if os.path.exists(deleted_path):
                os.remove(deleted_path)
            change_report["deleted"].append(img["filename"])

doc.close()

# --- Write updated registry ---
new_registry = {
    "pdfHash": pdf_hash,
    "extractedAt": datetime.now(timezone.utc).isoformat(),
    "images": [
        {
            "filename": r["filename"],
            "importName": r["importName"],
            "pdfPage": r["page"],
            "extractionIndex": r["extractionIndex"],
            "width": r["width"],
            "height": r["height"],
            "contentHash": r["contentHash"],
            "sectionNumber": r["sectionNumber"]
        }
        for r in results
    ]
}

with open(registry_path, "w") as f:
    json.dump(new_registry, f, indent=2)

# --- Report ---
print(f"PDF hash: {pdf_hash}")
print(f"Total images: {len(results)}")
print(f"  Unchanged: {len(change_report['unchanged'])}")
print(f"  Changed:   {len(change_report['changed'])}")
print(f"  New:       {len(change_report['new'])}")
print(f"  Deleted:   {len(change_report['deleted'])}")

if change_report["new"]:
    print(f"\nNew images (need naming at step 7):")
    for f_name in change_report["new"]:
        r = next(r for r in results if r["filename"] == f_name)
        print(f"  [{r['index']:2d}] page {r['page']:2d} section {r['sectionNumber']} -> {f_name}")

with open(os.path.join(out_dir, "_change-report.json"), "w") as f:
    json.dump(change_report, f, indent=2)
