---
name: finance
description: >
  Use when analyzing finance ledger data, revenue planning, HTS actuals or forecasts,
  profitability analysis, PNR lookups, or package booking financials. Use when querying
  the finance ledger, consolidated revenue tables, or cross-domain financial analysis in BigQuery.
---

# Finance Analytics

Use this skill when users ask about finance ledger data, revenue planning, HTS actuals/forecasts,
profitability analysis, PNR lookups, or package booking financials.

## Data Sources

### Finance Ledger

`gcp-hopper-finance-production.ledger.public_management_ledger_v3`

The source of truth for all financial transactions.

- **Date column**: `entry_creation_time` (always filter for performance)
- **Key fields**: `purchase_id`, `tenant_id`, `operation`, `account`, `amount_usd`

### HTS Revenue Plan & Consolidated Tables

When users ask about the **"rev plan"**, **"revenue plan"**, or **actuals**, they typically want data from the consolidated tables filtered to `version = 'RunRate'`. The version field has three values:

- **`RunRate`** — Actuals (realized financial data). This is the default for most reporting.
- **`Base`** — Base forecast (80% confidence). Used for forward-looking projections.
- **`Upside`** — Upside forecast. Only use when the user explicitly asks for upside.

| Table | Description |
|-------|-------------|
| `h4r-common-bi-prd.hts_finance_data__gld.fact_consolidated_wholeco_public` | **Primary table for actuals.** Public subset of the whole-company consolidated view. Pre-filtered to `version = 'RunRate'` (actuals only), excludes OPEX and Headcount. Use this as the default when users ask about the "rev plan" or historical actuals. |
| `h4r-common-bi-prd.hts_finance_data__gld.fact_consolidated_wholeco` | Full whole-company consolidated metrics. Contains all versions (RunRate, Base, Upside). Filter `WHERE version = 'RunRate'` for actuals. |
| `h4r-common-bi-prd.hts_finance_data__gld.fact_var` | Value at Risk calculations and fintech exposure|

### Intercompany Filtering on Consolidated Tables

**Always filter `WHERE intercompany = 'F'` by default** when querying `fact_consolidated_wholeco` or `fact_consolidated_wholeco_public`.

These tables include intercompany rows (Profit Share between HT and HTS, and Payments/PSP fees) under `account_category = 'Gross Revenue'`. These intercompany entries are flagged with `intercompany = 'T'` and will inflate revenue figures if not excluded.

- **`intercompany = 'F'`** — External revenue only. Matches `fact_rev_plan_hts` and is the correct default for most reporting.
- **`intercompany = 'T'`** — Intercompany transfers (Profit Share, Payments). Only include when explicitly analyzing whole-company P&L consolidation or intercompany flows.

This primarily affects **Hopper-App** (Consumer distribution channel), which has intercompany Profit Share entries. Portal tenants like Capital One are unaffected because they have no intercompany rows under Gross Revenue.

**Example — Gross Revenue by tenant and product:**

```sql
select
  tenant,
  product,
  format_date('%Y-%m', month) as month,
  sum(amount) as gross_revenue
from `h4r-common-bi-prd.hts_finance_data__gld.fact_consolidated_wholeco_public`
where
  account_category = 'Gross Revenue'
  and intercompany = 'F'
  and month >= '2025-01-01'
group by 1, 2, 3
order by 1, 2, 3
```

Only omit the `intercompany = 'F'` filter if the user explicitly asks for intercompany transactions, whole-company consolidated views, or profit share analysis.

### HT Finance (Hopper Travel)

| Table | Description |
|-------|-------------|
| `h4r-common-bi-prd.ht_finance_data__gld.fact_consolidated` | HT consolidated financial reporting |

### Universal Report (for product context)

`h4r-common-fintech-bi-prd.reports.universal_report`

For fintech-specific product metrics, see the `hopper-fintech:fintech-pricing` skill.

**Join key to ledger**: `finance_ledger.purchase_id = ur.ledger_purchase_id`

## Table Shortcuts

When users reference these terms, use the corresponding table:

| Term | Table |
|------|-------|
| "the ledger" / "finance ledger" | `gcp-hopper-finance-production.ledger.public_management_ledger_v3` |
| "universal report" / "UR" | `h4r-common-fintech-bi-prd.reports.universal_report` |
| "rev plan" / "revenue plan" / "actuals" | `h4r-common-bi-prd.hts_finance_data__gld.fact_consolidated_wholeco_public` (already filtered to RunRate/actuals) |

## FA (Fintech Ancillary) Tenants

FA refers to airline partner tenants in the HTSFA business unit.

**In Universal Report**: `WHERE business_unit = 'htsfa'`

**In Finance tables**: `WHERE distribution_channel = 'Fintech Ancillary'`

**Current FA air tenants**:
- air_asia, air_canada, azal, flair_airlines, flyadeal
- frontier_airlines, jazeera_airways, spirit_airlines
- virgin_australia, viva_aerobus, volaris

## PNR Lookups

### In Universal Report (Preferred)

`pnr_reference` column is available for FA airline tenants.

```sql
SELECT * FROM `h4r-common-fintech-bi-prd.reports.universal_report`
WHERE pnr_reference IN ('Y9MJKF', 'CBOSNZ')
```

### In Finance Ledger (Legacy)

For **some** FA tenants, PNRs are in the `note` field (primarily on exercise operations):

**Tenants WITH PNRs in ledger**: air_asia, air_canada, virgin_australia, volaris, flyadeal, jazeera_airways, flair_airlines

**Tenants WITHOUT PNRs in ledger**: spirit_airlines, frontier_airlines, viva_aerobus, azal

## Ledger <> UR Joins

**Primary join key**: `finance_ledger.purchase_id = ur.ledger_purchase_id`

**Do NOT** join through booking tables (Brooklyn, air_booking_supplemental_ids_lookup) when analyzing ledger/UR data.

## Operation-Based Ledger Analysis

When analyzing ledger data with multiple operations, structure your query with separate CTEs:

```sql
-- 1. Define reusable lists with UNNEST
WITH pnr_list AS (
  SELECT DISTINCT pnr FROM UNNEST(['PNR1', 'PNR2', 'PNR3']) AS pnr
)

-- 2. Separate CTEs by operation type
, ledger_purchase AS (
  SELECT
    purchase_id,
    DATE(entry_creation_time) AS attach_date,
    amount_usd AS revenue
  FROM `gcp-hopper-finance-production.ledger.public_management_ledger_v3`
  WHERE tenant_id = 'air_asia'
    AND operation = 'purchase'
    AND account = 'revenue'
    AND DATE(entry_creation_time) > '2025-11-30'
    AND note IN (SELECT pnr FROM pnr_list)
)

, ledger_exercise AS (
  SELECT
    purchase_id,
    DATE(entry_creation_time) AS exercise_date,
    amount_usd AS payout
  FROM `gcp-hopper-finance-production.ledger.public_management_ledger_v3`
  WHERE tenant_id = 'air_asia'
    AND operation = 'exercise'
    AND account = 'cogs'
    AND DATE(entry_creation_time) > '2025-11-30'
    AND note IN (SELECT pnr FROM pnr_list)
)

-- 3. Join operations together
, ledger AS (
  SELECT e.*, p.attach_date, p.revenue
  FROM ledger_exercise e
  LEFT JOIN ledger_purchase p USING (purchase_id)
)

-- 4. Join UR using ledger_purchase_id
SELECT l.*, ur.*
FROM ledger l
LEFT JOIN `h4r-common-fintech-bi-prd.reports.universal_report` ur
  ON l.purchase_id = ur.ledger_purchase_id
```

**Key principles:**
- Define lists once with UNNEST at the top
- Separate by operation type for clarity
- Apply filters early (tenant, product, date, account)
- Join on purchase_id between ledger and UR

## CFAR Profitability Analysis

### Critical Concept: Profit Per Offer vs Profit Per Attach

**Always use Profit Per Offer (GPPO)** as the primary metric:
- GPPO = `Total GP / Total Offers` = `(GP per Attach) x (Attach Rate)`
- Measures true business value per customer shown the product
- Profit Per Attach alone is misleading when attach rates change

### Expiration Maturity

CFAR policies don't finalize profit until travel departs.

| Field | Description |
|-------|-------------|
| `expired = true` | Policy has expired (travel departed) |
| `estimated_gross_profit_usd` | Estimate for all policies |
| `gross_profit_usd` | Actual for expired policies only |

**Maturity reliability:**
- 95-100% expired: Highly reliable
- 85-95%: Fairly reliable
- 65-85%: Use with caution
- <65%: Too early for profit conclusions

### Estimated vs Actual Comparison

Only compare for mature cohorts (85%+ expired):

```sql
WITH monthly_metrics AS (
  SELECT
    DATE_TRUNC(DATE(offer_time), MONTH) AS month,
    SUM(offered_ind) AS total_offers,
    SUM(attached_ind) AS total_attaches,
    COUNT(CASE WHEN attached_ind = 1 AND expired = true THEN 1 END) AS expired_attaches,
    SUM(CASE WHEN attached_ind = 1 THEN estimated_gross_profit_usd END) AS total_estimated_gp,
    SUM(CASE WHEN attached_ind = 1 AND expired = true THEN gross_profit_usd END) AS total_expired_gp
  FROM `h4r-common-fintech-bi-prd.reports.universal_report`
  WHERE business_unit = 'htsfa'
    AND product = 'cfar'
    AND tenant_id = 'air_canada'
  GROUP BY month
)
SELECT
  month,
  ROUND(expired_attaches / NULLIF(total_attaches, 0) * 100, 1) AS pct_expired,
  ROUND(total_estimated_gp / NULLIF(total_offers, 0), 4) AS est_gp_per_offer,
  ROUND((total_expired_gp / NULLIF(expired_attaches, 0)) * (total_attaches / NULLIF(total_offers, 0)), 4) AS actual_gp_per_offer_prorated
FROM monthly_metrics
WHERE expired_attaches / NULLIF(total_attaches, 0) >= 0.85
ORDER BY month DESC
```

## Package Bookings (Air + Hotel)

### Architecture

Package bookings create **one** `purchase_id`/`order_id` containing both air and hotel components.

```
purchase_id: 3312daa3-b28e-445b-8dec-a9de4420355b
|- line_of_business = 'air',   account_type = 'fare',    amount_usd = 1872.19
|- line_of_business = 'hotel', account_type = 'fare',    amount_usd = 621.76
|- line_of_business = 'hotel', account_type = 'revenue', amount_usd = 99.74
```

### Package Registry Table

`h4r-common-bi-prd.package_shopping_cart__slv.package_reservations`

**Key fields:**
- `lodging_customer_confirmation_id` - Links to hotel booking
- `flight_reservation_id` - Links to air booking
- `customer_confirmation_id` - Overall package confirmation

### Identifying Package Order IDs

```sql
WITH package_order_ids AS (
  SELECT DISTINCT lbwr.ledger_transaction_id AS order_id
  FROM `h4r-common-bi-prd.package_shopping_cart__slv.package_reservations` pr
  JOIN `gcp-hopper-etldata-production.warehouse.lodging_bookings_with_revenue` lbwr
    ON pr.lodging_customer_confirmation_id = lbwr.reservation_id
  WHERE pr.tenant_id = 'virgin-au'
)
SELECT * FROM package_order_ids
```

### Separating Air vs Hotel for Commission Analysis

```sql
-- Air components from packages
SELECT
  order_id,
  SUM(CASE WHEN account_type = 'fare' THEN amount_usd END) AS air_gbv,
  SUM(CASE WHEN account_type = 'revenue' THEN amount_usd END) AS air_commission
FROM `gcp-hopper-finance-research.hts_finops.hts_rev_share_all_portals`
WHERE order_id IN (SELECT order_id FROM package_order_ids)
  AND line_of_business = 'air'
GROUP BY order_id
```

### Current Package Availability

- **Virgin AU (virgin-au)**: Live since Sep 2025
- **SMCC (smcc)**: Launching April 2026

## Query Best Practices

### Date Filtering

Always filter large tables by date for performance:

```sql
WHERE DATE(entry_creation_time) >= DATE_SUB(CURRENT_DATE(), INTERVAL 30 DAY)
```

### NULL Handling

Use `NULLIF()` in denominators:

```sql
SUM(a) / NULLIF(SUM(b), 0)
```

### Time-Based Patterns

```sql
-- Month-over-month comparison
SELECT
  month,
  total_metric,
  LAG(total_metric) OVER (ORDER BY month) AS prior_month,
  SAFE_DIVIDE(total_metric - LAG(total_metric) OVER (ORDER BY month),
              LAG(total_metric) OVER (ORDER BY month)) * 100 AS pct_change
FROM monthly_metrics
```
