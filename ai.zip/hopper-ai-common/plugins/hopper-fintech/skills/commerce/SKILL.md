---
name: commerce
description: >
  Use when analyzing travel commerce bookings, conversion rates, revenue metrics, or user
  behavior across hotels, flights, cars, and packages for commerce partners like Virgin AU,
  CommBank, SMCC, NuBank, TripAdvisor, or other tenants. Covers frontend events, booking
  tables, and cross-vertical analysis in BigQuery.
---

# Commerce Analytics

Use this skill when users ask about travel bookings (hotels, flights, cars, packages), conversion rates,
booking trends, or user behavior for commerce partners.

## Data Sources

### 1. Frontend Events

`gcp-hopper-etldata-production.casablanca.frontend_events`

Captures all user interaction events from web and mobile platforms.

**Key Fields:**
- `name` - Event name (e.g., 'hotel_entry', 'hotel_tapped_entry', 'hotel_complete_buy', 'air_entry', 'complete_buy_air', 'cars_entry', 'complete_buy_car')
- `user_id`, `session_id` - User/session identifiers
- `ts` - Timestamp
- `extra_properties` - JSON field with metadata
  - `$.tenant` - Tenant identifier (extract with JSON_VALUE)
  - `state.locale`, `state.currency`, `state.signed_in`

**Common Events:**
- `launched_application` - App/website opened
- `hotel_entry` or `hotel_tapped_entry` - User initiated hotel search
- `hotel_complete_buy` - User completed hotel booking
- `air_entry` - User initiated flight search
- `complete_buy_air` - User completed flight booking
- `cars_entry` - User initiated car search
- `complete_buy_car` - User completed car rental

**Extract Tenant:**
```sql
JSON_VALUE(extra_properties, '$.tenant') AS tenant
```

### 2. Hotel Bookings

`h4r-common-lodging-bi-prd.wholeco__fulfillment__gld.fact_lodging_bookings_with_revenue`

Fact table containing all hotel bookings with revenue metrics.

**Key Fields:**
- **Identifiers**: `reservation_id`, `booking_session_id`, `user_id`, `lodging_id`, `tenant_id` (partner identifier)
- **Dates**: `booked_at_datetime`, `check_in_date`, `check_out_date`
- **Financial**: `sell_gbv` (what customer pays), `total_provider_revenue` (what Hopper earns)
- **Categorization**: `channel` (web/ios/android), `lodging_provider` (direct and 3p providers)
- **Status**: `reservation_status`, `cancelled_at_date`, `is_refundable`, `nth_bookings`

**Important Notes:**
- Use `tenant_id` to filter by partner (NOT `extra_properties.tenant` like frontend_events)
- Filter by `reservation_status = 'completed'` for travelled bookings
- Exclude cancelled if needed: `cancelled_at_date IS NULL`
- For monthly trends: `FORMAT_DATETIME('%Y-%m', booked_at_datetime)`

### 3. Hotel Dimensions (Gold)

`h4r-common-lodging-bi-prd.supply__gld.dim_lodgings`

Core hotel attributes.

**Key Fields:**
- `lodging_id` - Join key
- `lodging_name` - Hotel name
- `country_name`, `country_code`
- `city_name`, `chain_name`, `address`
- `is_active_version` - Active record indicator

**Usage:**
- ALWAYS filter by `is_active_version = TRUE` to ensure you are only using currently active hotel records.

### 4. Hotel Dimensions (SCD)

`h4r-common-lodging-bi-prd.supply__slv.dim_lodgings_junk_scd`

Detailed hotel attributes with history (Slowly Changing Dimension).

**Key Fields:**
- `lodging_id`
- `market_name` - Market/metro area
- `star_rating`
- `sf_is_key_account` - Salesforce key account flag
- `contracted_status`
- `is_current` - Current record indicator

**Usage:**
- Use `is_current = TRUE` for current attributes
- Join on `lodging_id AND is_current = TRUE`

### 5. Flight Bookings

`gcp-hopper-etldata-production.warehouse.tickets_with_revenue`

Fact table containing all flight bookings with revenue metrics.

**Key Fields:**
- **Identifiers**: `user_id`, `tenant_id` (partner identifier), `session_id`
- **Dates**: `booking_date`, `departure_date`, `return_date`
- **Financial**: `selling_usd_gbv` (what customer pays)
- **Flight details**: `trip_type`, `ticket_provider`, `validating_carrier`, `origin_code` (airport code), `destination_code` (airport code)
- **Status**: `cancel_status`, `nth_bookings`

**Usage:**
- Similar query patterns to hotel bookings
- Use for cross-vertical analysis (hotel + flight packages)
- Filter by tenant for partner-specific analysis

### 6. Car Rentals

`gcp-hopper-etldata-production.warehouse.car_bookings_facts`

Fact table containing all car rentals.

**Key Fields:**
- **Identifiers**: `hopper_user_id`, `tenant_id` (partner identifier), `hopper_session_id`
- **Dates**: `transaction_date`, `pick_up_date`, `drop_off_date`
- **Financial**: `total_price_usd` (what customer pays)
- **Car rental details**: `pick_up_country`, `pick_up_city`, `pay_type`, `provider`, `brand`

### 7. Package Bookings

`h4r-common-bi-prd.package_shopping_cart__slv.package_reservations`

**Key Fields:**
- **Identifiers**: `user_id`, `tenant_id` (partner identifier), `lodging_customer_confirmation_id`, `flight_reservation_id`
- **Dates**: `created_at`, `start_date`, `end_date`
- **Status**: `status`

**Usage:**
- Need to combine with hotel/flight/car booking tables for package analysis

## Key Metrics

### Conversion Rate (Hotels)

**Definition:** Bookings over unique searchers (not strictly aligned numerator/denominator).

```sql
WITH users AS (
  SELECT
    COUNT(DISTINCT CASE WHEN name in ('hotel_entry','hotel_tapped_entry') THEN user_id END) AS unique_searchers,
    COUNTIF(name = 'hotel_complete_buy') AS bookings
  FROM `gcp-hopper-etldata-production.casablanca.frontend_events`
  WHERE ts >= TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 30 DAY)
    AND JSON_VALUE(extra_properties, '$.tenant') = 'virgin-au'
)
SELECT
  unique_searchers,
  bookings,
  ROUND(SAFE_DIVIDE(bookings, unique_searchers) * 100, 2) AS conversion_rate_pct
FROM users
```

### Gross Booking Value (GBV)

**Definition:** Total value of bookings (what customers pay).

```sql
SELECT
  tenant_id,
  'hotels' as vertical,
  COUNT(DISTINCT booking_session_id) AS total_bookings,
  SUM(sell_gbv) AS total_gbv,
  SUM(sell_gbv)/COUNT(DISTINCT booking_session_id) AS aov
FROM `h4r-common-lodging-bi-prd.wholeco__fulfillment__gld.fact_lodging_bookings_with_revenue`
WHERE DATE(booked_at_datetime) >= DATE_SUB(CURRENT_DATE(), INTERVAL 30 DAY)
  AND tenant_id = 'commbank-au'
GROUP BY tenant_id
UNION ALL
SELECT
  tenant_id,
  'air' as vertical,
  COUNT(DISTINCT session_id) AS total_bookings,
  SUM(selling_usd_gbv) AS total_gbv,
  SUM(selling_usd_gbv)/COUNT(DISTINCT session_id) AS aov
FROM `gcp-hopper-etldata-production.warehouse.tickets_with_revenue`
WHERE DATE(booking_date) >= DATE_SUB(CURRENT_DATE(), INTERVAL 30 DAY)
  AND tenant_id = 'commbank-au'
GROUP BY tenant_id
UNION ALL
SELECT
  tenant_id,
  'cars' as vertical,
  COUNT(DISTINCT hopper_session_id) AS total_bookings,
  SUM(total_price_usd) AS total_gbv,
  SUM(total_price_usd)/COUNT(DISTINCT hopper_session_id) AS aov
FROM `gcp-hopper-etldata-production.warehouse.car_bookings_facts`
WHERE DATE(transaction_date) >= DATE_SUB(CURRENT_DATE(), INTERVAL 30 DAY)
  AND tenant_id = 'commbank-au'
GROUP BY tenant_id
```

### Revenue Per Transaction (Hotels)

```sql
SELECT
  tenant_id,
  COUNT(DISTINCT booking_session_id) AS total_bookings,
  SUM(total_provider_revenue) AS total_revenue,
  ROUND(SUM(total_provider_revenue) / COUNT(DISTINCT booking_session_id), 2) AS revenue_per_booking
FROM `h4r-common-lodging-bi-prd.wholeco__fulfillment__gld.fact_lodging_bookings_with_revenue`
WHERE DATE(booked_at_datetime) >= DATE_SUB(CURRENT_DATE(), INTERVAL 30 DAY)
  AND tenant_id = 'virgin-au'
GROUP BY tenant_id
```

### Cancellation Rate

```sql
SELECT
  tenant_id,
  COUNTIF(reservation_status = 'cancelled') AS cancelled_bookings,
  COUNT(*) AS total_bookings,
  ROUND(SAFE_DIVIDE(COUNTIF(reservation_status = 'cancelled'), COUNT(*)) * 100, 2) AS cancellation_rate_pct
FROM `h4r-common-lodging-bi-prd.wholeco__fulfillment__gld.fact_lodging_bookings_with_revenue`
WHERE DATE(booked_at_datetime) >= DATE_SUB(CURRENT_DATE(), INTERVAL 30 DAY)
  AND tenant_id = 'virgin-au'
GROUP BY tenant_id
```

## Common Query Patterns

### Monthly Booking Trend (Hotels)

```sql
SELECT
  FORMAT_DATETIME('%Y-%m', booked_at_datetime) AS booking_month,
  COUNT(DISTINCT booking_session_id) AS total_bookings,
  COUNT(DISTINCT user_id) AS unique_bookers,
  SUM(sell_gbv) AS total_gbv,
  SUM(sell_gbv)/COUNT(DISTINCT booking_session_id) AS aov,
  AVG(sell_adr) AS adr,
  AVG(length_of_stay) AS avg_los,
  AVG(booking_advance) AS avg_booking_advance,
  SUM(total_provider_revenue) AS total_revenue
FROM `h4r-common-lodging-bi-prd.wholeco__fulfillment__gld.fact_lodging_bookings_with_revenue`
WHERE tenant_id = 'virgin-au'
  AND DATE(booked_at_datetime) >= DATE_SUB(CURRENT_DATE(), INTERVAL 12 MONTH)
GROUP BY booking_month
ORDER BY booking_month DESC
```

### Geographic Performance (Hotels)

```sql
SELECT
  d.country_name,
  j.market_name,
  COUNT(DISTINCT f.booking_session_id) AS bookings,
  SUM(f.sell_gbv) AS total_gbv,
  AVG(f.sell_adr) AS avg_adr,
  SUM(f.total_provider_revenue) AS total_revenue
FROM `h4r-common-lodging-bi-prd.wholeco__fulfillment__gld.fact_lodging_bookings_with_revenue` f
JOIN `h4r-common-lodging-bi-prd.supply__gld.dim_lodgings` d
  ON f.lodging_id = d.lodging_id
JOIN `h4r-common-lodging-bi-prd.supply__slv.dim_lodgings_junk_scd` j
  ON f.lodging_id = j.lodging_id AND j.is_current = TRUE
WHERE f.tenant_id = 'virgin-au'
  AND DATE(f.booked_at_datetime) >= DATE_SUB(CURRENT_DATE(), INTERVAL 30 DAY)
GROUP BY d.country_name, j.market_name
ORDER BY bookings DESC
LIMIT 100
```

### Package Bookings

```sql
WITH packages AS
  (SELECT id,
          tenant_id,
          created_at,
          date_trunc(date(created_at), MONTH) AS MONTH ,
          lodging_customer_confirmation_id,
          flight_reservation_id
   FROM `h4r-common-bi-prd.package_shopping_cart__slv.package_reservations`
   WHERE tenant_id='virgin-au'),
     hotels AS
  (SELECT packages.*,
          "Hotel" AS Line_of_Business,
          sell_gbv AS GBV
   FROM packages
   LEFT JOIN
     (SELECT *
      FROM `h4r-common-lodging-bi-prd.wholeco__fulfillment__gld.fact_lodging_bookings_with_revenue`
      WHERE booked_at_datetime>='2025-07-01') b ON packages.lodging_customer_confirmation_id=b.reservation_id),
     flights AS
  (SELECT packages.*,
          "Air" AS Line_of_Business,
          selling_usd_gbv AS GBV
   FROM packages
   LEFT JOIN
     (SELECT *
      FROM `gcp-hopper-etldata-production.warehouse.tickets_with_revenue`
      WHERE booking_date>='2025-07-01') b ON packages.flight_reservation_id=b.itinerary_id)
SELECT tenant_id,
       Line_of_Business,
       MONTH,
       count(DISTINCT id) AS Bookings,
       sum(GBV) AS GBV
FROM
  (SELECT *
   FROM hotels
   UNION ALL SELECT *
   FROM flights)
GROUP BY ALL
```

## Important Field Differences

**Tenant Identifier:**
- `frontend_events`: `JSON_VALUE(extra_properties, '$.tenant')`
- Booking tables: `tenant_id` (direct column)

**Revenue Fields (Hotel bookings):**
- `sell_gbv` = What customer pays (GBV)
- `total_provider_revenue` = What Hopper earns (commission + markup)
- Don't confuse the two!

## Best Practices

1. **Always filter by date** to avoid full table scans:
   ```sql
   WHERE ts >= TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 30 DAY)
   ```

2. **Use SAFE_DIVIDE** to avoid division by zero:
   ```sql
   SAFE_DIVIDE(numerator, denominator)
   ```

3. **Monthly aggregation**:
   ```sql
   FORMAT_DATETIME('%Y-%m', booked_at_datetime) AS booking_month
   ```

4. **Exclude cancelled bookings** if needed:
   ```sql
   WHERE cancelled_at_date IS NULL
   ```
