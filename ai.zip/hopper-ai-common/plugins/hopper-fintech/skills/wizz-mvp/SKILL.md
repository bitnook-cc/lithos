---
name: wizz-mvp
description: >
  Use when creating Jira bugs, tasks, or stories for the Wizz DAFAR MVP epic (HTSFA-3375),
  triaging Wizz Air DAFAR issues reported in Slack, or answering questions about the epic's
  status (open tasks, unassigned issues, blockers, progress, workload).
  Triggers: "Wizz DAFAR bug", "Wizz MVP task", "create bug in HTSFA-3375",
  "Wizz DAFAR issue", "Wizz Air ticket", "DAFAR MVP ticket",
  "Wizz DAFAR status", "open tasks in HTSFA-3375", "unassigned Wizz tickets",
  "Wizz MVP progress", "what's left on Wizz DAFAR", "Wizz DAFAR overview".
---

# Wizz DAFAR MVP -- Epic Management & Issue Creation

## Overview

This skill covers the **Wizz DAFAR MVP** epic ([HTSFA-3375](https://hopper-jira.atlassian.net/browse/HTSFA-3375)): querying its status, creating new issues, and triaging bugs from Slack. It ensures consistent field values, well-structured descriptions, and correct priority classification.

**Project**: HTSFA (HTS - Fintech Ancillaries)
**Epic**: HTSFA-3375 (Wizz DAFAR MVP)
**Jira Cloud ID**: `c5551a32-a87d-4739-93d7-fbf1a838a70e`

## When to Use This Skill

- Asking about epic status: open issues, progress, blockers, workload
- Finding unassigned, high-priority, or stale issues in the epic
- Creating a bug or task under the Wizz DAFAR MVP epic
- Triaging a Wizz DAFAR issue reported in a Slack thread
- Generating Jira ticket title/description from conversational context
- Reviewing whether a Wizz DAFAR ticket has correct field values

## Epic Overview & Queries

Use `mcp__atlassian__searchJiraIssuesUsingJql` with `cloudId: c5551a32-a87d-4739-93d7-fbf1a838a70e` for all queries below.

### Common JQL Queries

| Question | JQL |
|----------|-----|
| All open issues | `parentEpic = HTSFA-3375 AND statusCategory != Done AND status != Cancelled ORDER BY priority ASC, created DESC` |
| Unassigned issues | `parentEpic = HTSFA-3375 AND statusCategory != Done AND status != Cancelled AND assignee is EMPTY ORDER BY priority ASC, created DESC` |
| High/Critical priority open | `parentEpic = HTSFA-3375 AND statusCategory != Done AND status != Cancelled AND priority in (Critical, High) ORDER BY priority ASC, created DESC` |
| Open bugs only | `parentEpic = HTSFA-3375 AND statusCategory != Done AND status != Cancelled AND issuetype = Bug ORDER BY priority ASC, created DESC` |
| Done / completed | `parentEpic = HTSFA-3375 AND statusCategory = Done ORDER BY resolutiondate DESC` |
| Assigned to a specific person | `parentEpic = HTSFA-3375 AND statusCategory != Done AND status != Cancelled AND assignee = <account_id> ORDER BY priority ASC` |
| Created in last 7 days | `parentEpic = HTSFA-3375 AND created >= -7d ORDER BY created DESC` |
| Stale (no update in 14 days) | `parentEpic = HTSFA-3375 AND statusCategory != Done AND status != Cancelled AND updated <= -14d ORDER BY updated ASC` |

### Presenting Results

When the user asks for an overview or status report, present results in a structured format:

- *Total / Open / Done / Cancelled* counts
- Group open issues by type (Bug vs Task) or priority
- Highlight unassigned and high-priority items
- Link each issue as `<https://hopper-jira.atlassian.net/browse/{key}|{key}>` for Slack clickability
- If the user asks "what's left" or "progress", show both open and done counts to convey completion %

### Looking Up Assignees

To query issues for a specific person, first resolve their Jira account ID:

```
mcp__atlassian__lookupJiraAccountId:
  cloudId: c5551a32-a87d-4739-93d7-fbf1a838a70e
  emailAddress: <user's email>
```

Then use the returned `accountId` in the `assignee = <account_id>` JQL clause.

---

## Required Fields & Defaults

Every issue in this epic MUST set these fields. Use the defaults below unless the context clearly indicates otherwise.

| Field | Default Value | Jira Field Key | ID |
|-------|---------------|----------------|-----|
| Partner | Wizz | `customfield_10805` | `12595` |
| Product | Air DG | `customfield_10806` | `12043` |
| Team | Flights Product | `customfield_11018` | `12721` |
| Priority | Medium | `priority` | `3` |

### Responsibility Field (`customfield_10807`)

Choose based on the nature of the issue:

| Value | ID | Use When |
|-------|----|----------|
| Backend | `12048` | API logic, data processing, contract lifecycle, email, pricing, exercise flow |
| Frontend | `12050` | Widget rendering, CSS, UI display, merchandising widget, portal UX |
| Both | `12049` | Changes span backend + frontend (e.g., new field displayed from API) |
| Neither | `12051` | Config-only, documentation, process changes |

**Default**: `Backend` (most common in this epic)

## Epic Link

Set the parent to `HTSFA-3375` using the `parent` parameter when creating issues:

```
parent: "HTSFA-3375"
```

## Issue Type Guidelines

| Type | When to Use |
|------|-------------|
| **Bug** | Something is broken, rendering incorrectly, or behaving unexpectedly |
| **Task** | New work, improvements, config changes, translations, integrations |
| **Spike** | Investigation needed before implementation can be scoped |

## Title Guidelines

Titles should be concise and descriptive. Follow these patterns:

**Bugs:**
- `{What's broken} in {where}` -- e.g., "Georgian language text renders incorrectly in Wizz DAFAR merchandising widget"
- `{Action} fails when {condition}` -- e.g., "DAFAR bookings with infants can't exercise"
- `Mismatch between {A} and {B} leading to {consequence}`

**Tasks:**
- `{Action verb} {what}` -- e.g., "Translate Wizz widget contents in all supported languages"
- `{Action verb} {what} in {where}` -- e.g., "Set the Wizz FAQ links in partner product config"
- `Add/Enable/Configure {feature} for Wizz`

**General rules:**
- Do NOT prefix with "Wizz:" or "DAFAR:" -- the epic provides that context
- Keep under 100 characters
- Use present tense for bugs (describes the problem state)
- Use imperative mood for tasks (describes what to do)

## Description Template

When generating a description from a Slack thread, use this structure:

### Bug Description

```markdown
## Summary
One-sentence description of the problem and its user impact.

## Steps to Reproduce
1. Step one
2. Step two
3. Observe the issue

## Expected Behavior
What should happen.

## Actual Behavior
What actually happens. Reference screenshots if available.

## Additional Context
- Reported by: {reporter name}
- Slack thread: {link to thread}
- Affected languages/locales: {if applicable}
- Environment: {staging/production}
```

### Task Description

```markdown
## Summary
What needs to be done and why.

## Acceptance Criteria
- [ ] Criterion 1
- [ ] Criterion 2

## Additional Context
- Slack thread: {link to thread}
- Related tickets: {if any}
```

## Priority Classification

| Priority | Criteria |
|----------|----------|
| **Critical** | Production down, all users affected, revenue-impacting |
| **High** | Major feature broken, workaround exists but painful, partner-reported blocker |
| **Medium** | Functional issue with workaround, cosmetic issues on key flows, most new work |
| **Low** | Minor cosmetic issues, nice-to-have improvements, non-urgent tech debt |

**Default**: Medium (established pattern in this epic)

## Generating Tickets from Slack Threads

When a user asks to create a ticket from a Slack thread:

1. **Read the full thread** to understand the issue context
2. **Identify the issue type** (Bug vs Task) from the conversation
3. **Extract key details**: what's broken, who reported it, screenshots, affected areas
4. **Determine responsibility**: is this a frontend (widget/CSS/UI), backend (API/data/logic), or both issue?
5. **Draft title and description** using the templates above
6. **Look up the assignee's Jira account ID** using their email from `<slack-context>`
7. **Create the issue** with all required fields using defaults from this skill

### Jira API Call Pattern

```
mcp__atlassian__createJiraIssue:
  cloudId: c5551a32-a87d-4739-93d7-fbf1a838a70e
  projectKey: HTSFA
  issueTypeName: Bug | Task
  summary: <generated title>
  description: <generated description>
  contentFormat: markdown
  assignee_account_id: <looked up from email>
  parent: HTSFA-3375
  additional_fields:
    priority: { name: <classified priority> }  # Use Priority Classification criteria above; default Medium
    customfield_10805: { id: "12595" }   # Partner: Wizz
    customfield_10806: { id: "12043" }   # Product: Air DG
    customfield_10807: { id: "<chosen>" } # Responsibility
    customfield_11018: { id: "12721" }   # Team: Flights Product
```

## Common Mistakes

| Mistake | Fix |
|---------|-----|
| Using Product "Disruption Recovery Platform" | Use "Air DG" (id: `12043`) -- all Wizz DAFAR issues use this |
| Missing Team field | Always set Team to "Flights Product" -- API rejects without it |
| Title prefixed with "Wizz DAFAR:" | Drop the prefix; the epic provides context |
| Missing Slack thread link in description | Always include the thread URL in Additional Context |
| Wrong Responsibility | Frontend = widget/UI, Backend = API/data, Both = spans layers |
