---
name: cfar-fraud-review
description: >
  Use when conducting CFAR fraud reviews, investigating fraud signals, risk classification,
  or analyzing payout anomalies. Covers proper table usage, identity matching, cluster analysis,
  behavioral anomaly detection, and investigation workflow for CFAR fraud cases.
---

# CFAR Fraud Review

## 1. Core Tables & Data Filtering

- When querying `cfar_fraud_report_raw`, **always** filter by `current_state IN ('exercised', 'lapsed', 'attached')`. Ignore dropped contracts.
- When querying `cfar_daily_fraud_cluster_review_extract`, **always** filter by `first_connected_contract_id_flag = 1` to avoid duplicates.
- Note: In the cluster review extract, fields outside `connected_ids` represent the cluster entity, while values inside the `connected_ids` record represent the individual contracts.

## 2. Entity Prioritization & Payouts

- **Always prioritize clusters** (`first_connected_id`) over user IDs (even for AirAsia) to detect multi-account abuse. Treat a cluster as a single entity.
- **Always check the LAST payout event** (order by `publish_time DESC`) to determine the final payout method. Do not classify risk based on the first attempt.

## 3. The CFAR Fraud and Abuse Signals (MUST CHECK)

When handling CFAR fraud reviews, you must always check the following signals:

- **Cluster Accumulations (Volume & Frequency)**: Analyze Cohort Concentration and Lifetime History (the cluster's historical behavior).
- **Payout Method & Risk Level**: Check the Method Type. Is it a `BankAccount` or `WireAccount` (higher risk), or is it `push_to_card` (low risk)?
- **Identity Matching**: Compare purchaser vs. payee details. Mismatches here are a major red flag.
- **Behavioral & Routing Anomalies**: Check Route/Date Accumulations. Are the exercises concentrated on specific routes (e.g., PEN-KUL), origins, destinations, or departure dates?
- **Baseline Comparison**: Does the distribution of these exercised routes/dates look abnormal compared to the baseline distribution of ALL contracts purchased in that exact same week?
- **Prior Fraud History & Mitigation**: Check Previous Reviews. Does the cluster already have a `cluster_review_result` of "fraud" in `gcp-hopper-ds-research.yliu.cfar_daily_fraud_cluster_review_extract`?

## 4. Investigation Summary Structure

When summarizing fraud investigations, structure findings as follows:

- **Alert Context**: Gap vs. threshold.
- **Cluster Analysis**: Classify based on lifetime behavior (lapsed vs. exercised, time from purchase to exercise, overlapping flights, bulk purchases, etc.), not just the analyzed week.
- **Suspicious Clusters**: Explicitly list the `first_connected_id` for clusters with massive payouts or zero history.
- **Recommendation**: Provide a brief, actionable recommendation based on the signals.

## Cross-References

- See [cfar-reference](hopper-fintech:cfar-reference) for CFAR service architecture and data tables
- See [cfar-triage](hopper-fintech:cfar-triage) for debugging CFAR production issues
- See [exercise-monitoring](hopper-fintech:exercise-monitoring) for daily exercise anomaly detection
