---
name: fintech-ai-data-analytics
description: >
  Use when analyzing A/B test or feature flag experiment data for fintech-ai,
  including exposure volume analysis, variant distribution, day-over-day
  comparison, booking conversion join, DAFAR/CFAR attach rates, or
  treatment-vs-control ratio from casablanca BigQuery tables.
---

# Fintech AI Data Analytics

A toolkit of query patterns for analyzing feature flag experiments and A/B tests
on fintech-ai products. Each pattern is independent — pick the ones relevant to
the question being asked. They are not sequential steps.

## Data Sources

All queries use the Casablanca analytics tables in BigQuery.

**PII rule:** Do not access, query, or output PII unless required. PII includes
names, email addresses, phone numbers, physical addresses, IP addresses, travel
document numbers, frequent flyer / loyalty identifiers, DOB, and device IDs.
Hopper ID and booking references are acceptable debugging identifiers.

### Tables

| Data | Production | Staging |
|------|-----------|---------|
| Backend events (exposures, server-side) | `gcp-hopper-etldata-production.casablanca.backend_events` | `gcp-hopper-etldata-staging.casablanca.backend_events` |
| Frontend events (bookings, client-side) | `gcp-hopper-etldata-production.casablanca.frontend_events` | `gcp-hopper-etldata-staging.casablanca.frontend_events` |

Default to **production** unless the user specifies staging.

### Schema Notes

- Partition column: `ts` (TIMESTAMP). There is **no `dt` column**. Always
  filter with `DATE(ts)`.
- Event type column: `name` (STRING). There is **no `event_type` column**.
- Properties column: `extra_properties` (JSON type). Use `JSON_EXTRACT_SCALAR`
  to extract fields — do **not** use `CAST(extra_properties AS STRING)`.
- Other columns: `id` (INTEGER), `user_id` (STRING), `session_id` (STRING),
  `campaign` (STRING), `referrer` (STRING), `raw_event` (STRING).

### Billing Project

Always use `gcp-hopper-ds-research` as the billing project for BigQuery queries.

---

## Query Patterns

### Exposure Volume by Variant

*What it's for:* Understanding how many times each variant of a flag was served
over a date range. This is the starting point for any experiment analysis —
confirms the flag is live, variants are being served, and traffic is flowing.

*When to use:* At the beginning of an analysis, to verify the experiment is
running and get a high-level picture of volume per variant per day.

```sql
SELECT
  DATE(ts) AS day,
  JSON_EXTRACT_SCALAR(extra_properties, '$.flag_variant') AS variant,
  COUNT(*) AS exposures
FROM `{project}.casablanca.backend_events`
WHERE name = 'feature_flag_exposure'
  AND JSON_EXTRACT_SCALAR(extra_properties, '$.flag_name') = '{flag_name}'
  AND DATE(ts) BETWEEN '{start_date}' AND '{end_date}'
GROUP BY day, variant
ORDER BY day, exposures DESC
```

### Day-Over-Day Comparison

*What it's for:* Comparing traffic between two specific days to detect shifts
caused by a flag change (e.g., a ramp-up or rollout). Shows whether traffic
moved between variants or changed overall.

*When to use:* After a flag configuration change (targeting update, percentage
rollout change) to confirm it took effect. When comparing days where the flag
changed mid-day, restrict both days to the same hour window for an
apples-to-apples comparison.

```sql
SELECT
  DATE(ts) AS day,
  JSON_EXTRACT_SCALAR(extra_properties, '$.flag_variant') AS variant,
  COUNT(*) AS exposures,
  COUNT(DISTINCT user_id) AS unique_users
FROM `{project}.casablanca.backend_events`
WHERE name = 'feature_flag_exposure'
  AND JSON_EXTRACT_SCALAR(extra_properties, '$.flag_name') = '{flag_name}'
  AND DATE(ts) IN ('{day1}', '{day2}')
  AND EXTRACT(HOUR FROM ts) BETWEEN {start_hour} AND {end_hour}
GROUP BY day, variant
ORDER BY day, variant
```

*Interpretation:* A declining Control alongside growing treatment variants
indicates traffic reallocation. Calculate the treatment-to-control ratio for
each day to quantify the shift.

### Hourly Exposure Rate (Pre/Post Change)

*What it's for:* Measuring the immediate impact of a flag change that happened
at a known time within a single day. Computes the per-hour exposure rate before
and after the change for each variant.

*When to use:* When a flag was toggled or reconfigured at a specific time and
you want to confirm the change took effect and measure the magnitude of the
shift — without waiting for a full day of data.

```sql
SELECT
  JSON_EXTRACT_SCALAR(extra_properties, '$.flag_variant') AS variant,
  CASE
    WHEN ts < TIMESTAMP('{change_time}') THEN 'before'
    ELSE 'after'
  END AS period,
  COUNT(*) AS exposures,
  TIMESTAMP_DIFF(
    MAX(ts), MIN(ts), HOUR
  ) AS hours_span,
  ROUND(COUNT(*) / NULLIF(TIMESTAMP_DIFF(MAX(ts), MIN(ts), HOUR), 0)) AS avg_per_hour
FROM `{project}.casablanca.backend_events`
WHERE name = 'feature_flag_exposure'
  AND JSON_EXTRACT_SCALAR(extra_properties, '$.flag_name') = '{flag_name}'
  AND DATE(ts) = '{change_date}'
GROUP BY variant, period
ORDER BY variant, period
```

Replace `{change_time}` with the UTC timestamp of the flag change
(e.g., `2026-05-28 14:25:00 UTC`).

### Variant Distribution (Percentage Split)

*What it's for:* Showing each variant's share of total traffic as a percentage.
Validates that the configured rollout percentages match what's actually being
served.

*When to use:* To verify traffic allocation matches expectations (e.g., a
50/25/25 split). Useful for catching misconfigured targeting rules or unexpected
variant drift.

```sql
WITH counts AS (
  SELECT
    DATE(ts) AS day,
    JSON_EXTRACT_SCALAR(extra_properties, '$.flag_variant') AS variant,
    COUNT(*) AS exposures
  FROM `{project}.casablanca.backend_events`
  WHERE name = 'feature_flag_exposure'
    AND JSON_EXTRACT_SCALAR(extra_properties, '$.flag_name') = '{flag_name}'
    AND DATE(ts) BETWEEN '{start_date}' AND '{end_date}'
  GROUP BY day, variant
),
daily_totals AS (
  SELECT day, SUM(exposures) AS total FROM counts GROUP BY day
)
SELECT
  c.day,
  c.variant,
  c.exposures,
  ROUND(100.0 * c.exposures / d.total, 1) AS pct_of_total
FROM counts c
JOIN daily_totals d ON c.day = d.day
ORDER BY c.day, c.exposures DESC
```

### Booking Conversion by Variant

*What it's for:* Measuring whether exposed users completed a booking, broken
down by variant. This is the primary outcome metric for most experiments — did
the treatment variant lead to more purchases?

*When to use:* To answer "does this variant convert better?" Joins backend
exposures to frontend `complete_buy` events on `user_id`, ensuring the exposure
preceded the booking.

```sql
WITH exposures AS (
  SELECT
    user_id,
    JSON_EXTRACT_SCALAR(extra_properties, '$.flag_variant') AS variant,
    MIN(ts) AS first_exposure_ts
  FROM `{project}.casablanca.backend_events`
  WHERE name = 'feature_flag_exposure'
    AND JSON_EXTRACT_SCALAR(extra_properties, '$.flag_name') = '{flag_name}'
    AND DATE(ts) BETWEEN '{start_date}' AND '{end_date}'
  GROUP BY user_id, variant
),
bookings AS (
  SELECT
    user_id,
    ts AS booking_ts,
    extra_properties
  FROM `{project}.casablanca.frontend_events`
  WHERE name = 'complete_buy'
    AND DATE(ts) BETWEEN '{start_date}' AND '{end_date}'
)
SELECT
  e.variant,
  COUNT(DISTINCT e.user_id) AS exposed_users,
  COUNT(DISTINCT b.user_id) AS converting_users,
  ROUND(100.0 * COUNT(DISTINCT b.user_id) / NULLIF(COUNT(DISTINCT e.user_id), 0), 2) AS conversion_rate_pct
FROM exposures e
LEFT JOIN bookings b
  ON e.user_id = b.user_id
  AND b.booking_ts >= e.first_exposure_ts
GROUP BY e.variant
ORDER BY conversion_rate_pct DESC
```

### Fintech Product Attach Rates (DAFAR / CFAR)

*What it's for:* Measuring whether bookings included fintech add-on products,
broken down by experiment variant. This is critical for fintech-ai experiments
where the goal is to increase product attach rates.

*When to use:* When the experiment hypothesis is about fintech product adoption
(e.g., "does the new offer flow increase DAFAR attach?"). Builds on the booking
conversion join above.

- **DAFAR attached**: `JSON_EXTRACT_SCALAR(extra_properties, '$.delay_choice') = '1'`
- **CFAR attached**: `JSON_EXTRACT_SCALAR(extra_properties, '$.cfar_choice') = 'true'`

```sql
WITH exposures AS (
  SELECT
    user_id,
    JSON_EXTRACT_SCALAR(extra_properties, '$.flag_variant') AS variant,
    MIN(ts) AS first_exposure_ts
  FROM `{project}.casablanca.backend_events`
  WHERE name = 'feature_flag_exposure'
    AND JSON_EXTRACT_SCALAR(extra_properties, '$.flag_name') = '{flag_name}'
    AND DATE(ts) BETWEEN '{start_date}' AND '{end_date}'
  GROUP BY user_id, variant
),
bookings AS (
  SELECT
    user_id,
    ts AS booking_ts,
    JSON_EXTRACT_SCALAR(extra_properties, '$.delay_choice') AS delay_choice,
    JSON_EXTRACT_SCALAR(extra_properties, '$.cfar_choice') AS cfar_choice
  FROM `{project}.casablanca.frontend_events`
  WHERE name = 'complete_buy'
    AND DATE(ts) BETWEEN '{start_date}' AND '{end_date}'
)
SELECT
  e.variant,
  COUNT(DISTINCT b.user_id) AS total_bookings,
  COUNTIF(b.delay_choice = '1') AS dafar_attached,
  ROUND(100.0 * COUNTIF(b.delay_choice = '1') / NULLIF(COUNT(DISTINCT b.user_id), 0), 1) AS dafar_rate_pct,
  COUNTIF(b.cfar_choice = 'true') AS cfar_attached,
  ROUND(100.0 * COUNTIF(b.cfar_choice = 'true') / NULLIF(COUNT(DISTINCT b.user_id), 0), 1) AS cfar_rate_pct
FROM exposures e
JOIN bookings b
  ON e.user_id = b.user_id
  AND b.booking_ts >= e.first_exposure_ts
GROUP BY e.variant
ORDER BY e.variant
```

---

## Common Mistakes

| Mistake | Fix |
|---------|-----|
| Using `dt` as partition column | Use `DATE(ts)` — there is no `dt` column |
| Using `event_type` to filter events | Use `name` — there is no `event_type` column |
| `CAST(extra_properties AS STRING)` | Use `JSON_EXTRACT_SCALAR(extra_properties, '$.key')` |
| Comparing full days when flag changed mid-day | Restrict both days to the same hour window |
| Forgetting `DATE(ts)` filter | Required — table is partitioned on `ts` |
| Using wrong billing project | Always use `gcp-hopper-ds-research` |

## Cross-References

- See [analytics-events](hopper-fintech:analytics-events) for general analytics event exploration and session lookups
- See [fintech-ai-monitoring](hopper-fintech:fintech-ai-monitoring) for Datadog APM/RUM monitoring of fintech-ai
- See [fintech-pricing](hopper-fintech:fintech-pricing) for product-level metrics from `universal_report`
- See [cfar-reference](hopper-fintech:cfar-reference) for CFAR service architecture
