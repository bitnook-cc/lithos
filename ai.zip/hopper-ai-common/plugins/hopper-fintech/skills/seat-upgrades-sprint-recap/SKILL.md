---
name: seat-upgrades-sprint-recap
description: >
  Generate bi-weekly sprint recap for the seat-upgrades team (Monday & Thursday mornings).
  Covers: in-progress/blocked tickets per person, top planned tickets by priority,
  recently completed tickets, To Discuss tickets with comment summaries,
  and unanswered Slack mentions for managers.
  Triggers: "sprint recap", "team recap", "ticket recap", "standup recap",
  "seat upgrades recap", "generate recap", "weekly update", "team status".
---

# Seat Upgrades Sprint Recap

Async replacement for daily standups. Runs every Monday and Thursday morning to give the team structured visibility into ticket progress, upcoming work, and pending decisions.

## Configuration

### Jira

- **Project**: HTSFA
- **Cloud ID**: `hopper-jira.atlassian.net`
- **Product filter**: `cf[10806] = "Air Dynamic Upgrades"` (custom field `customfield_10806`)
- **Ticket URL pattern**: `https://hopper-jira.atlassian.net/browse/{key}`

All JQL queries MUST include the product filter to scope results to seat-upgrades tickets only.

### Slack

The recap is posted in the **channel where the skill is invoked** — there is no hardcoded default channel.

The following channels are used for **Step 5 (Unanswered Mentions)** — Slack mention searches:

| Channel | ID | Type |
|---------|-----|------|
| #hts-fa-seat-upgrade | C092ZV0H2TV | public |
| #hts-fa-seat-upgrade-product | C09CWHNK9JP | public |
| #hts-fa-seat-upgrades-deployments | C09HF28JU4X | public |
| #hts-fa-seat-upgrade-private | C0AMRGXARMK | private |
| #hts-fa-seat-upgrade-dev | C09KFBX90DR | private |
| #hts-fa-seat-upgrades-qa | C0ANMMQ9XE0 | private |

### Team Members (dynamic)

Team members are **not hardcoded**. They are derived automatically from the 4 batch JQL queries run in Steps 1–4. After running all 4 queries, extract unique assignees (accountId + displayName) from the combined results. Then resolve each person's Slack ID using `mcp__slack__slack_search_users` with their display name.

Anyone who has at least one ticket assigned (in progress, planned, recently completed, or to discuss) is considered a team member for that recap.

### Recap Recipients (managers needing visibility)

| Name | Slack ID | Role |
|------|----------|------|
| Thibaut Soudan | U03130ST2KC | Product |
| Timothy Alliez | U030W6BCKRU | Product |

### Jira Workflow Statuses

| Status (JQL name) | Emoji | Category |
|-------------------|-------|----------|
| Backlog | - | A faire |
| Prévu | :small_blue_diamond: | A faire (Planned) |
| To Discuss | :speech_balloon: | A faire |
| En cours | :large_blue_circle: | En cours (In Progress) |
| Examiner | :eyes: | En cours (Review) |
| Ready to Ship | :rocket: | En cours |
| Progress Blocked | :red_circle: | En cours (Blocked) |
| Terminé(e) | :white_check_mark: | Terminé (Done) |
| Annulé | :no_entry_sign: | Terminé (Canceled) |
| Iceboxed | :snowflake: | Terminé |

### Priority Emojis

Replace priority text labels with emojis for visual scanning:

| Priority | Emoji | Slack code |
|----------|-------|------------|
| Blocker | :no_entry: | `:no_entry:` |
| Critical | :bangbang: | `:bangbang:` |
| Highest | ⏫ | `:arrow_double_up:` |
| High | 🔼 | `:arrow_up_small:` |
| Medium | ➖ | `:heavy_minus_sign:` |
| Low | 🔽 | `:arrow_down_small:` |
| Lowest | ⏬ | `:arrow_double_down:` |

## Procedure

### Step 0 — Determine Recap Window & Discover Team

Calculate the lookback period since the previous recap:
- **Monday** recap: last recap was Thursday → lookback = `4d`
- **Thursday** recap: last recap was Monday → lookback = `3d`
- **Manual invocation**: ask the user, or default to `3d`

Compute `{lookback_date}` as `YYYY-MM-DD` for use in Slack search date filters.

**Discover team members**: Run the 5 batch JQL queries from Steps 1–5 first (including backlog count), then extract unique assignees (accountId + displayName) from the combined results of Steps 1–4. Resolve each person's Slack ID using `mcp__slack__slack_search_users` with their display name. Cache the mapping `{accountId → displayName, slackId}` for use in output formatting.

### Step 0b — Backlog Count

Run a backlog count query (fetch all, count results):
```
project = HTSFA AND cf[10806] = "Air Dynamic Upgrades" AND status = "Backlog"
```
Fields: `summary` only, `maxResults: 100`. Count the total number of issues returned. This count is displayed in the overview stats header.

### Step 1 — In Progress & Blocked (per person)

For **each team member**, run:

```
project = HTSFA AND cf[10806] = "Air Dynamic Upgrades" AND status in ("En cours", "Examiner", "Ready to Ship", "Progress Blocked") AND assignee = "{accountId}" ORDER BY status ASC, priority ASC
```

Tool: `mcp__atlassian-mcp-server__searchJiraIssuesUsingJql`
Fields: `summary, status, priority, labels`

Group results by person. Use status emojis from the table above. Highlight `Progress Blocked` tickets prominently. If a person has zero active tickets, write "No active tickets".

### Step 2 — Top 5 Planned (per person)

For **each team member**, run:

```
project = HTSFA AND cf[10806] = "Air Dynamic Upgrades" AND status = "planned" AND assignee = "{accountId}" ORDER BY priority ASC, created ASC
```

Fetch `maxResults: 5`. These are the next tasks in the pipeline. Show priority for each.

### Step 3 — Completed Since Last Recap (per person)

For **each team member**, run:

```
project = HTSFA AND cf[10806] = "Air Dynamic Upgrades" AND resolved >= "-{days}d" AND assignee = "{accountId}" ORDER BY resolved DESC
```

Replace `{days}` with the lookback period (3 or 4). If a person completed nothing, omit them from this section entirely.

### Step 4 — To Discuss (global)

```
project = HTSFA AND cf[10806] = "Air Dynamic Upgrades" AND status = "To Discuss" ORDER BY priority ASC, created ASC
```

For each ticket returned, fetch the issue details with `mcp__atlassian-mcp-server__getJiraIssue` (include `description, comment`) using `responseContentFormat: "markdown"`. Summarize in 1-2 lines: what the ticket is about and what decision/clarification is needed. Note who is assigned and who was tagged in comments.

### Step 5 — Unanswered Mentions (for managers)

For **each recap recipient** (Thibaut, Timothy):

#### 5a — Slack mentions

1. Search for messages mentioning them since the last recap:
   ```
   query: "<@{SLACK_ID}> after:{lookback_date}"
   ```
   Use `mcp__slack__slack_search_public_and_private` to cover all 6 team channels (public + private). Search each channel separately:
   `in:#hts-fa-seat-upgrade`, `in:#hts-fa-seat-upgrade-product`, `in:#hts-fa-seat-upgrades-deployments`, `in:#hts-fa-seat-upgrade-private`, `in:#hts-fa-seat-upgrade-dev`, `in:#hts-fa-seat-upgrades-qa`.

2. For each result, read the thread with `mcp__slack__slack_read_thread` and check if the mentioned person has replied (look for their Slack ID in the thread authors).

3. List only messages where the person has **not** replied. Include: message link, short preview, author, channel.

#### 5b — Jira ticket mentions

1. From the tickets already fetched in Steps 1, 2, and 4 (in progress, blocked, planned, to discuss), identify tickets that have comments (total > 0).

2. For each ticket with comments, fetch full comments using `mcp__atlassian-mcp-server__getJiraIssue` with `responseContentFormat: "markdown"` if not already fetched.

3. Check each comment body for mentions of the recipient (look for their Jira accountId in `[~accountId:{ID}]` patterns, or their display name).

   | Recipient | Jira Account ID |
   |-----------|-----------------|
   | Thibaut Soudan | 61f427f5cb7c5f006b12fa1e |
   | Timothy Alliez | 61f427e65a0988006b5b102a |

4. If a recipient was mentioned in a comment, check if they authored any **subsequent** comment on that ticket. If not, the mention is unanswered.

5. List unanswered Jira mentions with: ticket link, comment author, short preview.

If no unanswered mentions (Slack or Jira), write "No pending mentions".

## Output Format

Reply directly in the conversation thread — do NOT use `slack_send_message`. Use Slack mrkdwn formatting (not GitHub markdown).

The message is organized by **section first, then people within each section** — NOT by person first.

If the output exceeds Slack's 4000-char soft limit, split it across multiple reply messages. Keep each section together — never split a section across messages.

### Message Template

The recap is split across multiple reply messages when needed (4000-char soft limit per message).

**Main message** (Sections 0–3):
```
:bar_chart: *Seat Upgrades — Recap {Monday/Thursday} {YYYY-MM-DD}*

> :red_circle: *{N}* blocked  ·  :small_blue_diamond: *{N}* planned  ·  :speech_balloon: *{N}* to discuss  ·  :inbox_tray: *{N}* backlog  ·  :white_check_mark: *{N}* completed

━━━━━━━━━━━━━━━━━━━━━
:pushpin: *1. In Progress / Blocked ({count})*

*<@SLACK_ID> {Person Name}*
{status_emoji} {priority_emoji} <https://hopper-jira.atlassian.net/browse/HTSFA-XXXX|HTSFA-XXXX> — Summary

*<@SLACK_ID> {Person Name}*
{status_emoji} {priority_emoji} <https://hopper-jira.atlassian.net/browse/HTSFA-XXXX|HTSFA-XXXX> — Summary

_No active tickets:_ <@SLACK_ID>, <@SLACK_ID>, <@SLACK_ID>

━━━━━━━━━━━━━━━━━━━━━
:small_blue_diamond: *2. Planned — top 5 per person ({count})*

*<@SLACK_ID> {Person Name}*
• {priority_emoji} <https://hopper-jira.atlassian.net/browse/HTSFA-XXXX|HTSFA-XXXX> — Summary
• {priority_emoji} <https://hopper-jira.atlassian.net/browse/HTSFA-XXXX|HTSFA-XXXX> — Summary

━━━━━━━━━━━━━━━━━━━━━
:white_check_mark: *3. Completed since last recap ({count})*

*<@SLACK_ID> {Person Name}*
• :white_check_mark: <https://hopper-jira.atlassian.net/browse/HTSFA-XXXX|HTSFA-XXXX> — Summary

_No tickets completed in this period._
```

**Thread reply 1** (Section 4):
```
:speech_balloon: *4. To Discuss ({count})*

{priority_emoji} *{Priority Group Label}*
• <https://hopper-jira.atlassian.net/browse/HTSFA-XXXX|HTSFA-XXXX> — Summary · <@SLACK_ID>
• <https://hopper-jira.atlassian.net/browse/HTSFA-XXXX|HTSFA-XXXX> — Summary · _Unassigned_

{priority_emoji} *{Priority Group Label}*
• <https://hopper-jira.atlassian.net/browse/HTSFA-XXXX|HTSFA-XXXX> — Summary · <@SLACK_ID>

_No To Discuss tickets._
```

**Thread reply 2** (Section 5):
```
:bell: *5. Unanswered mentions*

*<@U03130ST2KC> Thibaut:*
_Slack:_
• <{message_url}|Message> — "preview..." (from <@AUTHOR_ID>, in #channel)
_Jira:_
• <https://hopper-jira.atlassian.net/browse/HTSFA-XXXX|HTSFA-XXXX> — mentioned by {author} in comment: "preview..."

*<@U030W6BCKRU> Timothy:*
_No pending mentions_
```

### Formatting Rules

- Ticket links: `<https://hopper-jira.atlassian.net/browse/HTSFA-XXXX|HTSFA-XXXX>`
- User mentions: `<@SLACK_ID>`
- Bold: `*text*`, Italic: `_text_`
- **Overview stats**: blockquote line after title with counts for blocked, planned, to discuss, backlog, and completed
- **Section headers**: emoji + bold number + title + ticket count in parentheses, e.g. `*1. In Progress / Blocked (2)*`
- **Priority emojis**: use the Priority Emojis table above — never use text labels like `(Medium)`
- **Section 1 (In Progress/Blocked)**: list people with active tickets first (with status + priority emojis), then consolidate all inactive people on one line: `_No active tickets:_ <@ID1>, <@ID2>, <@ID3>`
- **Sections 2-3**: only show people who have tickets in that section — omit people with none
- **Section 4 (To Discuss)**: group tickets by priority level with sub-headers (`{priority_emoji} *{Label}*`). Each ticket on one line: `• <link|KEY> — Summary · <@SLACK_ID>` (or `· _Unassigned_`)
- **Section 5 (Mentions)**: global — not grouped by person
- Keep summaries to one line per ticket — no descriptions
- If an entire section is empty, show the section header + italic "No..." message — don't skip the section
- All output text must be in **English**
- **Message splitting**: main message = sections 0-3, thread reply 1 = section 4, thread reply 2 = section 5. Keep each section together — never split a section across messages

## Optimization

To minimize API calls, batch the JQL queries where possible:

**Single query for all active tickets** (instead of per-person):
```
project = HTSFA AND cf[10806] = "Air Dynamic Upgrades" AND status in ("En cours", "Examiner", "Ready to Ship", "Progress Blocked") ORDER BY assignee ASC, status ASC, priority ASC
```
Then group results by assignee in the output formatting step.

**Single query for all planned tickets** (use `"planned"` — `"Prévu"` fails due to accent encoding in MCP tool):
```
project = HTSFA AND cf[10806] = "Air Dynamic Upgrades" AND status = "planned" ORDER BY assignee ASC, priority ASC, created ASC
```
Then take top 5 per assignee.

**Single query for all recently completed**:
```
project = HTSFA AND cf[10806] = "Air Dynamic Upgrades" AND resolved >= "-{days}d" ORDER BY assignee ASC, resolved DESC
```

**Single query for To Discuss**:
```
project = HTSFA AND cf[10806] = "Air Dynamic Upgrades" AND status = "To Discuss" ORDER BY priority ASC, created ASC
```

**Backlog count**:
```
project = HTSFA AND cf[10806] = "Air Dynamic Upgrades" AND status = "Backlog"
```
Fields: `summary` only. Count the returned issues for the overview stats.

This reduces per-person JQL calls down to 5 batch JQL calls + N `getJiraIssue` calls for To Discuss comments.

## Scheduling

This skill is designed to be invoked by a scheduled Slack message to hopper-ai:
- **Monday** at 8:00 AM ET
- **Thursday** at 8:00 AM ET

Scheduled message prompt:
```
Generate the seat-upgrades sprint recap
```

The recap will be posted in whichever channel the message is sent from.
