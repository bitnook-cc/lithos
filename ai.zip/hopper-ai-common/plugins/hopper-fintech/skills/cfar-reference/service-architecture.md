# CFAR Operational Routing Reference

## Scope and Source of Truth

Use this file as an **operational overlay** for Hopper AI triage. It captures the
Datadog names, trace signals, and path-identification hints that are useful when
someone asks the Slack bot to investigate a CFAR issue.

For canonical common-realm HTS Fintech Ancillaries architecture, service
responsibilities, API auth/versioning, and product flow semantics, defer to
`hopper-org/fintech-platform`. That repo is the actively maintained source of truth
for common-realm HTS FA backend systems. CapOne's main difference is the gateway
entrypoint: it uses its own `hts-gateway` deployment on the capone realm before
reaching common-realm `hts-fintech-*` backend services.

Useful fintech-platform areas to look for, as of this writing:
- Architecture docs for the common-realm HTS FA service map, product concepts, and API routing
- Lodging CFAR product specs and business rules
- Generated partner docs for offer, purchase, and exercise flows
- Lodging CFAR HTTP API contract definitions

If this file conflicts with fintech-platform or service code, fintech-platform/code
wins for common-realm backend behavior. Update this file only for bot-specific
routing, telemetry, triage context, and entrypoint/realm operational caveats.

## Datadog Path Classification

Do not classify a tenant from memory or partner lists. Classify the request path from
the observed Datadog trace and then use fintech-platform or service code for behavior
details.

| Signal in DD traces | Path |
|---------------------|------|
| `hts-cfar` and `hts-gateway` appear before `hts-fintech-*` | Gateway path |
| `commerce-portals` or `commerce-api` appears before `hts-gateway` | Commerce stack entrypoint |
| First Hopper backend span is `hts-fintech-flights` or `hts-fintech-lodging` | Direct API / Kong entrypoint |
| `b2b-coordinators`, `cfar-air-orchestrator`, `cfar-lodging-orchestrator`, or `cfar-core` appears | Legacy path; do not apply HTS analytics/table assumptions |
| `hts-gateway` realm/environment tags show `capone` | CapOne gateway entrypoint; downstream fintech backend services are common-realm |

Search spans by tenant:
```
service:hts-fintech-flights @tenant:{tenant-name}
service:hts-fintech-lodging @tenant:{tenant-name}
service:commerce-api @tenant:{tenant-name}
service:b2b-coordinators @tenant:{tenant-name}
```

## Exercise Debugging Entry Points

For canonical exercise flow behavior, defer to fintech-platform's generated exercise
docs. For triage, search `hts-fintech-exercise-bff` for customer self-service
exercise issues, then search the product service for the vertical:
- Flights: `hc-airlines`
- Lodging: `cfar-lodging`

If the issue was reported against a partner API exercise endpoint instead of the
customer portal, start with the relevant partner-facing gateway service
(`hts-fintech-flights` or `hts-fintech-lodging`) and follow the trace downstream.

## DD Telemetry Name Mapping

### hts-gateway workloads
| DD Service | Purpose |
|------------|---------|
| `hts-gateway` | Main gateway — authenticates and proxies |
| `hts-cfar` | CFAR gateway module — offers, contracts, and gateway integration |
| `hts-bookings` | Booking retrieval and modifications |
| `hts-disruption` | Disruption protection workflows |
| `hts-media` | Media/ads |
| `hts-lodging-shop-results` | Lodging shop results forwarding |

### Commerce stack
| DD Service | Purpose |
|------------|---------|
| `commerce-portals` | Partner portal frontend |
| `commerce-api` | Commerce backend that calls into hts-gateway |

### Fintech BFFs
| DD Service | Purpose |
|------------|---------|
| `hts-fintech-flights` | Flights REST gateway (stateless) |
| `hts-fintech-lodging` | Lodging REST gateway (stateless) |
| `hts-fintech-orders` | Order store + payment orchestrator (Spanner) |
| `hts-fintech-exercise-bff` | Exercise portal BFF |

### Product services
| DD Service | Purpose |
|------------|---------|
| `hc-airlines` | Flights CFAR/DG business logic (PostgreSQL) |
| `cfar-lodging` | Lodging CFAR business logic (Spanner) |
| `cfar-lodging-subscriber` | Payout event consumer for cfar-lodging |

### Legacy
| DD Service | Purpose |
|------------|---------|
| `cfar-air-orchestrator` | Legacy flights exercise orchestrator |
| `cfar-lodging-orchestrator` | Legacy lodging exercise orchestrator |
| `cfar-core` | Legacy contract store |
| `b2b-coordinators` | Legacy gRPC proxy |

## Triage Caveats

- Treat fintech-platform as the source of truth for common-realm HTS FA service
  architecture, API routing, and product flow behavior.
- Gateway or commerce entrypoints may involve **Oklahoma** fulfillment orchestration,
  but confirm from the trace or stored identifiers such as `shopping_cart_order_id`
  before assuming Oklahoma is in the purchase path.
- CapOne's special case is the entrypoint: its gateway/BFF infrastructure runs on the
  capone realm, then reaches common-realm fintech backend services.
- Legacy-path issues use different services and data pipelines. If the trace includes
  legacy services, switch to the legacy data references in `data-tables.md`.
- For analytics table routing, use `data-tables.md`: flights and lodging do not use
  the same BigQuery event table.
