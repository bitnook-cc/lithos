# CFAR Data Tables

## Scope and Source of Truth

Use this file as a privacy-safe data lookup guide for Hopper AI triage. It is not a
schema reference. For API contracts and product flows, defer to fintech-platform. For
live operational schemas, verify against the owning service code, owning team, or live
database schema before relying on table/column details.

## Operational Databases

These are the source-of-truth contract stores. They may contain PII or sensitive
commercial data. Use them for understanding service ownership and data lineage, not
as default Slack-bot query targets.

For schema-sensitive implementation work, verify the current schema with the owning
flights or lodging team, the live database schema, or the service code before relying
on this section. Treat the table names here as operational orientation for triage.

**PII rule:** Do not access, query, or output PII unless required for the task. PII
includes names, email addresses, phone numbers, physical addresses, IP addresses,
travel document numbers, frequent flyer / loyalty identifiers, KTN/redress numbers,
DOB, device IDs, and other user-identifying fields. This applies to all output
surfaces — Slack, terminal, logs, documents, screenshots. Booking or reservation
references are acceptable debugging identifiers (they identify a booking, not a
person). Hopper ID / Amplitude ID may be shared when needed. Prefer sanitized
analytics tables, dashboards, aggregate counts, operational IDs, status names, and
short redacted snippets. Extracting specific non-PII fields from JSON payloads
(error codes, status values, amounts, timestamps) is fine for debugging. Avoid
dumping entire raw rows or full opaque payloads because they can contain PII mixed
with operational fields.

### hc-airlines — PostgreSQL (flights CFAR)

Key tables: `cfar_offers`, `cfar_contracts`, `cfar_contract_exercises`, `cfar_fares`,
`cfar_form_of_payment`, `cfar_exercise_payout`, `cfar_booking_cancellation`, `cfar_activity_log`.
All keyed by `id` (UUID), with `contract_id` as the main lookup for exercise/payout/cancellation tables.

DAFAR tables follow the same pattern with `dg_` prefix.

### cfar-lodging — Spanner (lodging CFAR)

**V3 tables (current):** `offer_v3`, `contract_v3`, `exercise_v3`, `event_v3`.
Key lookups: `contract_id`, `order_id`, `session_id`, `tenant`.

V2 tables (`orders`, `contract`, `exercise`, `event`) are legacy and being superseded by V3.

### hts-fintech-orders — Spanner (shared order/payment store)

Tables: `Order`, `contract`, `order_payment`, `payment_transaction`.
Key lookups: `id`, `order_id`, `contract_id`, `tenant`.

## BigQuery — Analytics Events

**Flights and lodging use different event tables.** These are preferred for Slack-bot
investigation because they are analytics-oriented. Still, inspect selected fields and
return only minimal, redacted output.

| Vertical | Table | Partition | Key Filter |
|----------|-------|-----------|------------|
| Flights | `gcp-hopper-etldata-{env}.hc_analytics.events_v2` | `DATE(occurred_at)` | `session.tenant = 'fa-<airline>'` |
| Lodging | `gcp-hopper-etldata-{env}.fintech_analytics.events` | `DATE(occurred_at)` | `namespace = 'hotel_cfar'` |

## Legacy Path Data (cfar-core / orchestrators)

Legacy CFAR data does NOT flow through `hc_analytics.events_v2` or `fintech_analytics.events`.
It uses a separate ETL pipeline and its own BQ datasets. These exist in **production only**
(not staging).

The current `cfar-triage` skill is HTS-focused. Use this legacy section as reference
context when a report points at cfar-core/orchestrator data; if legacy triage becomes
common, add a dedicated legacy CFAR triage skill instead of growing the HTS playbook.

### Operational database

`cfar-core` uses Spanner. Tables: `quote`, `contract`, `event`.
Keyed by `contract_id`, `tenant`, `domain`. `owner` is deprecated.

### BigQuery datasets (production only)

| Dataset | Use |
|---------|-----|
| `gcp-hopper-etldata-production.cfar_core` | Legacy contract/event/quote data (public views) |
| `gcp-hopper-etldata-production.cfar_air` | Legacy flights CFAR data; may include sensitive fields, so use only when necessary and redact output |
| `gcp-hopper-etldata-production.cfar_lodging` | Legacy lodging CFAR event data; may include sensitive fields, so use only when necessary and redact output |

## BigQuery — Reporting, Finance, Fraud

| Table | Contains |
|-------|----------|
| `h4r-common-fintech-bi-prd.reports.universal_report` | Cross-product metrics: attach rates, exercise rates, premium, margin |
| `gcp-hopper-finance-production.ledger.public_management_ledger_v3` | Finance ledger |
| `gcp-hopper-ds-research.yliu.cfar_fraud_report_raw` | Per-contract fraud signals — may contain PII; use only aggregate counts and redacted output |
