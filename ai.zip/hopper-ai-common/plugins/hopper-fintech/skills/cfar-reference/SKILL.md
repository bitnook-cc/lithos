---
name: cfar-reference
description: >
  Use when needing CFAR operational context for triage: Datadog telemetry name
  mappings, integration-path discovery hints, privacy-safe database table locations,
  or BigQuery data sources. Defer to fintech-platform for canonical common-realm
  HTS Fintech Ancillaries architecture, API contracts, and product flow documentation.
---

# CFAR Reference

Operational reference for CFAR triage and data lookup. This is intentionally **not**
the canonical system architecture document. For higher-level common-realm HTS
Fintech Ancillaries architecture, API contracts, lodging CFAR business rules, and
partner-facing offer/purchase/exercise flows, defer to `hopper-org/fintech-platform`.
CapOne uses a separate gateway entrypoint on the capone realm, but still reaches
common-realm `hts-fintech-*` backend services.

Useful fintech-platform areas to look for, as of this writing:
- Architecture docs for the common-realm HTS FA service map and system concepts
- Repo architecture docs for fintech-platform layer rules
- Lodging CFAR product specs and business rules
- Generated partner flow docs for offer, purchase, and exercise behavior
- Lodging CFAR HTTP API contract definitions

This skill keeps the context Hopper AI needs during Slack triage: which Datadog
services to search, how to infer the active integration path from traces, where
analytics events live, and how to avoid exposing PII.

## Operational Routing

See [service-architecture.md](service-architecture.md) for:
- Operational integration-path hints (gateway, commerce, direct API, CapOne, legacy)
- How to discover which path a tenant uses from DD traces
- Exercise debugging entry points
- DD telemetry name → service purpose mapping
- Operational caveats that are useful during triage

## Data Tables

See [data-tables.md](data-tables.md) for:
- Operational data ownership hints
- Privacy-safe query guidance and PII handling rules
- Sanitized analytics event tables (flights vs lodging — different tables)
- Reporting, finance, and fraud table names

## Quick Reference

### Which vertical am I looking at?

| DD Service | Vertical |
|------------|----------|
| `hc-airlines`, `hts-fintech-flights` | Flights |
| `cfar-lodging`, `cfar-lodging-subscriber`, `hts-fintech-lodging` | Lodging |
| `hts-fintech-orders`, `hts-fintech-exercise-bff` | Shared (both verticals) |
| `hts-cfar`, `hts-gateway` | Gateway layer (both verticals) |
| `cfar-air-orchestrator`, `cfar-lodging-orchestrator`, `cfar-core` | Legacy |

### Where is the data?

| Data | Flights | Lodging |
|------|---------|---------|
| Contract source of truth | hc-airlines PostgreSQL | cfar-lodging Spanner (v3 tables) |
| Analytics events | `hc_analytics.events_v2` | `fintech_analytics.events` |
| Orders/payments | hts-fintech-orders Spanner (shared) | hts-fintech-orders Spanner (shared) |
| Contract detail access | Use approved internal tools; do not dump raw rows | Use approved internal tools; do not dump raw rows |
| Cross-product metrics | `universal_report` (shared) | `universal_report` (shared) |

## Cross-References

- [cfar-triage](hopper-fintech:cfar-triage) — debugging CFAR production issues
- [cfar-qa](hopper-fintech:cfar-qa) — creating and testing flights CFAR contracts
- [cfar-exercise-cancellation-triage](hopper-fintech:cfar-exercise-cancellation-triage) — AirAsia cancellation webhook triage
- [cfar-fraud-review](hopper-fintech:cfar-fraud-review) — fraud investigation workflow
- [analytics-events](hopper-fintech:analytics-events) — flights event queries
- [fintech-pricing](hopper-fintech:fintech-pricing) — universal_report metrics
- [finance](hopper-fintech:finance) — finance ledger queries
- [state-machine-debugging](hopper-developer:state-machine-debugging) — Oklahoma session debugging
- [datadog-ops](hopper-developer:datadog-ops) — general Datadog investigation
