# hopper-fintech

Skills for Hopper fintech and analytics teams. Covers fintech product pricing, exercise monitoring, CFAR fraud review, DAFAR contract QA, finance/ledger analysis, disruption protection, media ad campaigns, commerce analytics, flights data, and analytics events.

## Skills

| Skill | Description |
|-------|-------------|
| `fintech-pricing` | Fintech product metrics — attach rates, exercise rates, pricing, revenue, margin |
| `finance` | Finance ledger, revenue planning, profitability, PNR lookups |
| `exercise-monitoring` | Daily exercise anomaly detection using z-score analysis |
| `cfar-exercise-cancellation-triage` | CFAR exercise cancellation triage — end-to-end flow, AirAsia webhook verification, failure modes |
| `cfar-fraud-review` | CFAR fraud signals, risk classification, investigation workflow |
| `cfar-qa` | Flights CFAR contract creation, exercise, investigation, 360° view, widget validation for airline partners |
| `cfar-triage` | CFAR triage across flights and lodging — DD queries, failure patterns, exercise debugging |
| `cfar-reference` | Shared CFAR reference — service architecture, integration paths, DD telemetry mappings, data tables |
| `dafar-qa` | DAFAR contract investigation, 360° view, API tracing for airline partners |
| `disruption` | Flight disruption protection, rebooking quality, contract analytics |
| `media` | HTS Media ad campaign performance, spend pacing, ROAS |
| `commerce` | Travel commerce bookings, conversion, revenue across verticals |
| `flights-data` | Flight bookings, shopping, provider volume, shadow traffic |
| `analytics-events` | Analytics event exploration and session lookups |
| `fintech-ai-data-analytics` | A/B test analysis — exposure volume, variant comparison, booking conversion, DAFAR/CFAR attach rates |
| `offer-recovery` | Orphaned CFAR/DG offer triage — investigate why partner offers were never converted into contracts |
| `seat-upgrades-booking-investigation` | Seat upgrades booking investigation — end-to-end lifecycle lookup by bookingId or PNR |
| `seat-upgrades-sprint-recap` | Bi-weekly sprint recap for the seat-upgrades team — in-progress, blocked, planned, completed tickets and unanswered mentions |
| `seat-upgrades-update-documentation` | Update Air Seat Upgrades back-office in-app documentation from a User Guide PDF via Slack — incremental image extraction, TypeScript generation, and PR creation |
| `wizz-mvp` | Wizz DAFAR MVP issue creation — field defaults, title/description generation, priority classification |
