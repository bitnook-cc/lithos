# hopper-javascript

JavaScript and TypeScript skills for Hopper services.

## Skills

| Skill | Purpose |
|---|---|
| `js-dependabot` | Analyze and fix Dependabot dependency alerts in JavaScript projects |

## Install

```
/plugin marketplace add hopper-org/hopper-ai-common
/plugin install hopper-javascript@hopper-ai-common
```
