---
name: js-dependabot
description: >-
  Analyze Dependabot dependency alerts and upgrade packages to address them.
  Use when fixing Dependabot security alerts, upgrading vulnerable npm
  dependencies, or remediating dependency vulnerabilities in JavaScript projects.
metadata:
  author: flights-travel-agency
  version: "1.0.0"
---

Help me address the dependabot security alerts for this repository.

The repository that is expected to use a package management system expected in front-end development
(e.g., npm, pnpm, yarn). The commands below assume npm but adjust them accordingly
if the repository is using a different package manager. Warn user if you are not familiar
with the package manager.

## Phase 1: Discovery & Scoping
  1. Fetch alerts using GitHub CLI:
     gh api repos/{owner}/{repo}/dependabot/alerts --jq '.[] | select(.state == "open") | {package: .security_vulnerability.package.name, severity: .security_vulnerability.severity, summary: .security_advisory.summary}'
  2. Group alerts by severity (critical, high, medium, low) and identify unique packages.
  3. Trace dependency trees to find top-level packages:
     npm ls <vulnerable-package> --all
  4. Identify which are direct vs transitive dependencies:
     - Direct: Listed in package.json dependencies/devDependencies
     - Transitive: Pulled in by other packages
## Phase 2: Remediation Strategy
  1. For direct dependencies: Check for latest versions and upgrade:
     npm view <package> version
     - Major version upgrades are acceptable if tests pass
  2. For transitive dependencies:
     - Prefer upgrading the parent package (including major versions if tests pass)
     - Only use npm overrides as a last resort when:
       - Parent package has no update available
       - Major upgrade breaks functionality
  3. After changes: Run npm install and verify:
     - Packages updated correctly: npm ls <package>
     - No breaking changes: Run tests/build commands
  4. Re-evaluate existing overrides in package.json:
     - Check if each override is still necessary after upgrades
     - Remove overrides where the dependency tree now naturally includes fixed versions
     - Run npm ls <overridden-package> to verify versions without the override
  5. Document unfixable issues: Some vulnerabilities can't be fixed if:
     - Package is already at latest version with no fix available
     - Override would break parent package compatibility
     - Requires upstream maintainer fix

## Priority Order

1. Critical severity - fix immediately
2. High severity - fix promptly
3. Medium/Low in production dependencies - address soon
4. Medium/Low in devDependencies only - lower priority (not shipped to users)

## Key Commands Reference

- NPM authentication: npm-auth
- Fetch open alerts: gh api repos/{owner}/{repo}/dependabot/alerts --jq '.[] | select(.state == "open") | {package: .security_vulnerability.package.name, severity: .security_vulnerability.severity}'
- Trace dependency tree:  npm ls <package>
- Check latest version: npm view <package> version
- Check all versions: npm view <package> versions --json
- Install: npm install
- Verify:  npm ls <package>
