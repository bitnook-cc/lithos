# hopper-scala

Scala-specific skills for Hopper service codebases.

## Scope

Skills in this plugin assume a Scala service using Hopper's common libraries (Finatra, helpers-play-json, `Deriving`, sbt).

| Skill | Purpose |
|---|---|
| `bump-latest-deps` | Bump SBT dependencies to latest versions via Google Artifact Registry |
| `helpers-http-server` | Finatra HTTP controllers — routes, parameter extraction, request/response patterns |
| `helpers-play-json` | JSON serialization — `Deriving`, sealed traits, enums, `JsFormat.by`, codec patterns |
| `vulnerability-remediation` | Triage and remediate dependency vulnerabilities (Dependabot, CVE floors, base image) in SBT projects |
| `state-machines` | Distributed state machine framework (helpers-machine) — definitions, steps, Chain DSL |
| `type-discovery` | Resolve Scala types (case classes, sealed traits, type aliases) across Hopper repos |

## Install

```
/plugin marketplace add hopper-org/hopper-ai-common
/plugin install hopper-scala@hopper-ai-common
```
