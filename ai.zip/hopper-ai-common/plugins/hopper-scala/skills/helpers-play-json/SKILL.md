---
name: helpers-play-json
description: >-
  Use when reading or writing Scala code that serializes/deserializes JSON at
  Hopper. Triggers: JsFormat, Deriving, play-json, JSON codec, sealed trait
  serialization, JsFormat.by, JsFormat.byInjection, JsFormat.enum, UnionFormat.
---

# helpers-play-json

Hopper's JSON serialization library, API-compatible with Play JSON. Uses `Deriving` for automatic codec generation.

## Detecting Usage

Look for `helper("play-json")` or `helperStable("play-json")` in `build.sbt`.

## Codec Patterns

| Pattern | Meaning |
|---|---|
| `Deriving[JsFormat[T]]` | Auto-derived from case class fields |
| `JsFormat.enum(source)` | Enum serialized as string |
| `JsFormat.by[A, B](to)(from)` | Newtype wrapper — serializes `A` as `B` |
| `JsFormat.byInjection(injection)` | Delegated serialization via `Injection[A, B]` — wire format is `B`'s |
| `JsFormat.byInjection[A, String]` | Enum-like via implicit `StringFormat[A]` — check casing variant |
| `UnionFormat[T]("discriminator").branch[Sub]("tag") { ... }.format` | Manual union type with discriminator |

## Case Classes

`Deriving[JsFormat[T]]` maps each field to a JSON key with the same name. Non-`Option` fields are required. `Option[T]` fields are omitted when `None`.

```scala
implicit lazy val fmt: JsFormat[AuthorizeRequest] = Deriving[JsFormat[AuthorizeRequest]]
```

`@flatten` annotation promotes nested object fields to the parent level.

## Sealed Traits (ADTs)

`Deriving[JsFormat[T]]` for sealed traits adds a discriminator tag:

```scala
sealed trait PaymentMethod
case class CreditCard(number: String) extends PaymentMethod
case object Cash extends PaymentMethod
// CreditCard JSON: {"PaymentMethod": "CreditCard", "number": "..."}
// Cash JSON:       {"PaymentMethod": "Cash"}
```

- Default discriminator field = the sealed trait's simple name
- Default tag value = the subtype's simple name
- Customizable with `@TagLabel("type")` and `@TagValue("cc")`

## `JsFormat.by[A, B]` — Delegated Serialization

`JsFormat.by[A, B](fromB)(toB)` serializes type `A` by converting to `B` first. **The wire format is `B`'s, not `A`'s.**

```scala
// Token is serialized as a plain String
implicit lazy val fmt: JsFormat[Token] = JsFormat.by[Token, String](Token(_))(_.value)
```

When used on sealed trait subtypes, the parent `Deriving` merges the discriminator into `B`'s serialized form:

```scala
sealed trait AlertCommandKey
object AlertCommandKey {
  case class FlightKey(value: AlertKey) extends AlertCommandKey
  object FlightKey {
    // FlightKey wire format = AlertKey's fields, not FlightKey's
    implicit lazy val jsFmt: JsFormat[FlightKey] = JsFormat.by[FlightKey, AlertKey](FlightKey(_))(_.value)
  }
}
```

Wire format for `FlightKey`:
```json
{"AlertCommandKey": "FlightKey", "origin": {"regionType": "Airport", "code": "YUL"}, ...}
```

## `JsFormat.byInjection` — Delegated Serialization via Injection

`JsFormat.byInjection(injection)` works like `JsFormat.by` but uses an `Injection[A, B]` to convert between types. **The wire format is `B`'s, not `A`'s.** This can apply at any level — newtypes, subtypes, or entire sealed traits.

### Trait-level delegation to another sealed trait

When a sealed trait's `JsFormat` uses `byInjection` to delegate to a different sealed trait, the wire format is the target trait's — including its discriminator and subtypes. This is especially deceptive when the source type looks like a simple enum (`AEnum` with case objects) but actually serializes as a tagged union.

```scala
sealed trait SimpleFilter
object SimpleFilter extends AEnum[SimpleFilter] {
  case object None extends SimpleFilter
  case object Fast extends SimpleFilter
  case object Cheap extends SimpleFilter

  val toDetailedFilter: Injection[SimpleFilter, DetailedFilter] = ...
  implicit val jsonFmt: JsFormat[SimpleFilter] = JsFormat.byInjection(toDetailedFilter)
}
```

Despite looking like a simple enum, `SimpleFilter` serializes as `DetailedFilter` — if `DetailedFilter` uses `Deriving[JsFormat]`, the wire format is a tagged union like `{"DetailedFilter": "FastFilter"}`, not `"Fast"`.

### Enum-like delegation to String

When an `AEnum` uses `JsFormat.byInjection[T, String]`, the wire values come from the implicit `StringFormat[T]`, not the case object names.

```scala
sealed trait LocationType
object LocationType extends AEnum[LocationType] {
  case object Airport extends LocationType
  case object City extends LocationType

  implicit val stringFmt: StringFormat[LocationType] = snakeCase.stringInjection
  implicit val jsonFmt: JsFormat[LocationType] = JsFormat.byInjection[LocationType, String]
}
// JSON: "airport" or "city" (snakeCase), NOT "Airport" or "City"
```

The `StringFormat` determines the wire values. Check which casing variant it uses — the same `EnumNames` variant table from the Enums section applies (`snakeCase`, `camelCase`, `lowerCase`, etc.).

## `JsFormat.compatible` — Optional Discriminator

`JsFormat.compatible(derived) { "field" -> JsString("Default") }` makes the discriminator optional with a default value:

```scala
implicit lazy val jsFmt: JsFormat[AlertCommandKey] =
  JsFormat.compatible(Deriving[JsFormat[AlertCommandKey]]) { "AlertCommandKey" -> JsString("FlightKey") }
```

Both valid:
```json
{"AlertCommandKey": "FlightKey", "origin": {...}, ...}
{"origin": {...}, ...}
```

## Enums

```scala
sealed trait Status extends EnumEntry
object Status extends Enum[Status] {
  case object Active extends Status
  case object Inactive extends Status
  val values = findValues
}
implicit val fmt: JsFormat[Status] = JsFormat.enum(Status)
// JSON: "Active" or "Inactive"
```

`JsFormat.enum` uses the case object name by default (PascalCase). Variants change the wire format:

| `EnumNames` variant | Wire value for `NonStop` |
|---|---|
| `source` (default) | `NonStop` |
| `camelCase` | `nonStop` |
| `snakeCase` | `non_stop` |
| `kebabCase` | `non-stop` |
| `capitalSnakeCase` | `NON_STOP` |
| `lowerCase` | `nonstop` |
| `upperCase` | `NONSTOP` |

## Generic / Parameterized Codecs

When a codec has a type parameter, each concrete instantiation produces a different wire format:

```scala
implicit def wrapperFormat[T](implicit fmt: JsFormat[T]): JsFormat[Wrapper[T]] =
  Deriving[JsFormat[Wrapper[T]]]
```

To understand the wire format, substitute the concrete type parameter into the definition and expand fully.

## Type Mapping (Scala → JSON)

| Scala type | JSON type |
|---|---|
| `String` | string |
| `Int`, `Short` | integer |
| `Long` | integer (64-bit) |
| `Double`, `Float` | number |
| `Boolean` | boolean |
| `BigDecimal` | number |
| `List[T]`, `Seq[T]`, `Vector[T]` | array |
| `NonEmptyList[T]` | array (min 1) |
| `Set[T]` | array (unique) |
| `Option[T]` | field omitted when None |
| `Map[String, V]` | object with string keys |
| `Map[EnumType, V]` | object with enum string keys |
| `DateTime`, `Instant`, `ZonedDateTime` | string (date-time) |
| `LocalDate` | string (date) |
| `UUID` | string (uuid) |
| `Currency`, `Duration` | string |

## Common Pitfalls

- **`JsFormat.by[A, B]` / `byInjection` on subtypes** — the wire format is `B`'s, not `A`'s case class fields
- **`JsFormat.byInjection` at the trait level** — an `AEnum` with case objects is not necessarily a simple string enum. Always check the `implicit val jsonFmt` — if it uses `byInjection`, the wire format is the target type's
- **`JsFormat.byInjection[T, String]`** — wire values come from the implicit `StringFormat`, not the case object names. Check the casing variant (`snakeCase`, `camelCase`, etc.)
- **`JsFormat.compatible`** — the discriminator is optional, not required
- **`AEnum` casing** — check which `EnumNames` variant is passed; don't assume PascalCase
- **`@flatten`** — nested fields are promoted, changing the apparent structure
- **Inventing enum values** — always read the source definition; never guess
