---
name: helpers-aligned
description: >-
  Understand helpers-aligned Scala library repos at Hopper. These repos have
  their versions pinned against a specific Helpers version to prevent binary
  compatibility issues. Use when user mentions "helpers-aligned", "helpers
  version", "helpers dispatch", "bump helpers", "helpers-published",
  "HelpersAlignedVersionPlugin", "helpers.version", "patch.version",
  "helpers.sbt", or asks how a Hopper library's version relates to Helpers.
  Also triggers when investigating version mismatches, binary compatibility
  issues, or the automated Helpers bump pipeline across repos.
---

# helpers-aligned

How Hopper's helpers-aligned library ecosystem works: versioning, dispatch chain, and automation.

## What Are Helpers-Aligned Repos?

Helpers-aligned repos are Scala library repos whose versions are pinned to a specific version of Helpers (`hopper-org/Helpers`). This prevents binary compatibility issues — when a service uses `sbt-hopper` at version X, all helpers-aligned libraries it depends on must also be built against Helpers version X.

When Helpers publishes a new release, it triggers an automated cascade that bumps and republishes every helpers-aligned repo against the new Helpers version.

## The Dispatch Chain

Helpers uses GitHub repository dispatch events to propagate version bumps through a two-tier system.

### Tier 1: Dispatched directly from Helpers

When `Helpers/.github/workflows/release.yml` completes, it sends a `helpers-published` event (with the new Helpers version in the payload) to these repos:

- `hopper-interfaces`
- `lodging-common`
- `flights-common`
- `fintech-analytics-helpers`
- `disruption-common`
- `b2bportal-csauth`
- `payments-common`
- `cars-common`
- `copper`
- `mvwc-common`
- `homes-common`
- `intl-localization-flights`

### Tier 2: Dispatched from Tier 1 repos

Some Tier 1 repos dispatch to downstream repos after they finish their own bump:

- `hopper-interfaces` dispatches to `remoteui` and `b2b-interfaces`
- `payments-common` dispatches to `payments-provider-platform`

### How to identify the current dispatch targets

The source of truth is always the workflow files:

```bash
# Tier 1 targets — listed in Helpers release.yml
gh api repos/hopper-org/Helpers/contents/.github/workflows/release.yml \
  --jq '.content' | base64 -d | grep -A1 'repository_dispatch'

# Tier 2 targets — check each Tier 1 repo's bump-helpers workflow
gh api repos/hopper-org/hopper-interfaces/contents/.github/workflows/bump-helpers.yml \
  --jq '.content' | base64 -d | grep -A1 'repository_dispatch'
```

## Versioning Mechanisms

There are two versioning mechanisms for helpers-aligned repos. Check which one a repo uses before making changes.

### Legacy: `project/helpers.sbt`

Used by older repos (e.g. `hopper-interfaces`). The file contains:

```scala
Helpers.helpersVersion in ThisBuild := "1.0.XXXX"
```

The bump workflow calls the `updateHelpersVersion` sbt task.

### HelpersAlignedVersionPlugin: `project/helpers.version` + `project/patch.version`

Used by most repos. Two plain-text files control the version:

- **`project/helpers.version`** — the full Helpers version (e.g. `1.0.9371`)
- **`project/patch.version`** — a local patch counter (e.g. `28`), auto-incremented by CI on each merge to master

The library version is derived as: `<majorVersion>.<helpers_micro>.<patch>`
- `majorVersion` is set in `build.sbt` via `ThisBuild / majorVersion := "1"`
- `helpers_micro` is extracted from `project/helpers.version` (e.g. `1.0.9371` gives `9371`)
- `patch` comes from `project/patch.version`

Example: Helpers `1.0.9371` + patch `28` + majorVersion `1` = library version `1.9371.28`

The bump workflow calls the `bumpHelpers` sbt task and resets `patch.version` to `0`.

### How to identify which mechanism a repo uses

```bash
# If this file exists, it uses HelpersAlignedVersionPlugin
test -f project/helpers.version && echo "HelpersAlignedVersionPlugin" || echo "Legacy (check project/helpers.sbt)"
```

## Version Format Diversity

Different repos produce different version formats despite sharing the same underlying mechanism:

| Repo | Format | Example |
|------|--------|---------|
| `flights-common` | `1.<helpers_micro>.<patch>` | `1.9442.0` |
| `cars-common` | `1.<helpers_micro>.<patch>` | `1.9442.0` |
| `lodging-common` | `1.<helpers_micro>.<patch>` | `1.9442.0` |
| `payments-common` | `v0.1.<patch>` | `v0.1.75` |
| `homes-common` | `v0.1.<patch>` | `v0.1.58` |
| `disruption-common` | `v1.0.<patch>` | `v1.0.76` |
| `remoteui` | `<helpers_micro>.<patch>` | `8086.1` |
| `mvwc-common` | `mvwc-common-v<major>.<minor>.<patch>/release` | `mvwc-common-v1.7.0/release` |
| `b2bportal-csauth` | `v<version>_v<rendered>-rendered` | `v1.9371.0_v1.9371.0-rendered` |
| `hopper-interfaces` | own semver (legacy) | `v1.0` |
| `b2b-interfaces` | monorepo scoped | `@b2bportal-corporate-capone/purchase-api@0.14.2` |

The version format is determined by the repo's `majorVersion` setting and whether it uses git tag prefixes.

## Key SBT Tasks

| Task | Used by | Purpose |
|------|---------|---------|
| `bumpHelpers` | HelpersAlignedVersionPlugin repos | Updates `project/helpers.version`, resets `project/patch.version` to `0` |
| `updateHelpersVersion` | Legacy repos | Updates `project/helpers.sbt` |
| `isSnapshotBuild` | HelpersAlignedVersionPlugin repos | Controls snapshot publishing (not the standard `snapshot` key) |

## Reusable Workflows

Both workflows live in `hopper-org/.github`:

- **`bump-helpers.yml`** — receives `helpers-published` dispatch, runs `bumpHelpers` or `updateHelpersVersion`, commits, and triggers a release
- **`publish-jar.yml`** — standard release workflow. For helpers-aligned repos, pass `helpers-aligned-version: true` to derive the version from `helpers.version` + `patch.version`. Increments `patch.version` on each merge to master.

## How Regular (Non-Helpers-Bump) Releases Work

When a developer merges a PR to master in a helpers-aligned repo:

1. `publish-jar.yml` runs
2. It reads `project/helpers.version` and `project/patch.version`
3. It increments `patch.version` by 1
4. It publishes the artifact with the computed version
5. It commits the updated `patch.version` back to master

This means a helpers-aligned library can have multiple patch releases between Helpers bumps.

## Implications for Dependency Management

- **You cannot manually bump a helpers-aligned library independently of Helpers.** The version is derived from the Helpers version. To get a new version of a helpers-aligned library, either wait for the next Helpers release (which triggers an automatic bump) or make a code change to the library (which triggers a patch release against the current Helpers version).
- **When Helpers bumps, patch resets to 0.** Any patch-level fixes made between Helpers bumps are incorporated into the new Helpers-aligned release.
- **Binary compatibility is enforced by version alignment.** A service using `sbt-hopper 1.0.9371` should use helpers-aligned libraries built against `1.0.9371`. Mixing versions can cause runtime errors.
