---
name: bump-latest-deps
description: >-
  Bump SBT dependencies to latest versions using Google Artifact Registry lookups.
  Supports interactive (default) and headless modes. Use when user says "bump
  dependencies", "upgrade libraries", "update versions", "latest deps", or
  "keep dependencies up to date" in an SBT/Scala project.
---

# bump-latest-deps

Bump SBT dependencies to their latest available versions. Runs in interactive mode by default (presents plan, waits for approval). Use headless mode when explicitly requested.

## Phase 1: Discovery

### 1.1 Identify version-pinned dependencies

Read the project's SBT build definitions to find all explicitly declared dependency versions. Collect each dependency as `(groupId, artifactId, currentVersion, declarationFile)`.

**Always exclude** (high-risk, belong in separate PRs):
- `scalaVersion` / `scala212` / `scala213`
- `semanticdbVersion`
- `sbt-scalafix`

### 1.2 Look up latest versions

Use `gcloud artifacts versions list` to find the latest version for each dependency.

**Repository selection:**
- **Hopper packages** (groupId `com.hopper` or `com.hopper.*`): `--repository=maven-release`
- **External packages**: `--repository=maven-central-remote`

**Artifact naming conventions:**

SBT plugins — `<groupId>:<artifactId>_2.12_1.0`:
```bash
gcloud artifacts versions list \
  --package="<groupId>:<artifactId>_2.12_1.0" \
  --repository=<repo> --location=us --project=gcp-hopper-cicd \
  --limit=1 --sort-by=~updateTime
```

Scala libraries — `<groupId>:<artifactId>_2.13`:
```bash
gcloud artifacts versions list \
  --package="<groupId>:<artifactId>_2.13" \
  --repository=<repo> --location=us --project=gcp-hopper-cicd \
  --limit=1 --sort-by=~updateTime
```

Java libraries (no Scala suffix) — `<groupId>:<artifactId>`:
```bash
gcloud artifacts versions list \
  --package="<groupId>:<artifactId>" \
  --repository=<repo> --location=us --project=gcp-hopper-cicd \
  --limit=1 --sort-by=~updateTime
```

**Proto library naming (helpers >= 1.0.9303):** Proto libraries may exist under multiple artifact names. Check all variants and use the most recent version:
- `com.hopper:<name>` (no suffix — newer convention)
- `com.hopper:<name>_2.12` (old convention)
- `com.hopper:<name>_2.13` (old convention)

If the no-suffix variant has a newer version, update the artifact name in `build.sbt` to drop the suffix.

**Run `gcloud` lookups in parallel** (multiple Bash calls in one message) for efficiency.

### 1.3 Classify updates by risk

| Risk | Criteria | Default action |
|------|----------|----------------|
| **Patch** | x.y.Z bump | Include |
| **Minor** | x.Y.0 bump | Include |
| **Major** | X.0.0 bump | Include but flag — may need code changes |

Skip dependencies already at latest version.

## Phase 2: Update Plan

### Interactive mode (default)

Present a markdown table:

```
| Package | Current | Latest | Risk | Include? |
|---------|---------|--------|------|----------|
```

Ask the user which updates to apply. Wait for confirmation before proceeding.

### Headless mode

Apply all updates automatically. If a major bump causes compilation failure after reasonable fix attempts, revert that bump and note it in the PR description.

## Phase 3: Apply Updates

1. **Edit dependencies** — update each version in place. For proto artifact name changes (dropping `_2.12` suffix), update the artifact name too.
3. **Compile** — reload and compile the project. If compilation fails, fix errors **surgically** — only the minimum change needed (deprecated/changed API replacements, import path updates, new required parameters). Do NOT refactor, clean up, or improve surrounding code.
4. **Test** — compile and run tests. Fix test failures the same way — minimal, surgical changes only. Do NOT disable or skip tests.
5. **Format** — run the project's code formatter
6. **Regenerate build artifacts** — if proto-related dependencies changed, regenerate API docs. Stage any changed generated files. Do not touch `.dependabot_deps` — it is updated automatically by CI.

## Phase 4: Commit & PR

Commit and open a PR. The PR body should include:
- A table: Package | Previous | New | Notes
- Any code changes made for compatibility
- Any skipped dependencies with reasons
- Test results summary

## Dependency Chain Reference

Many versions come transitively through: `sbt-hopper` -> `Helpers` -> `helpers-stable`.

Key files to check for transitive version pins:
- `hopper-org/Helpers` — `project/HopperDeps.scala`
- `hopper-org/helpers-stable` — `project/Versions.scala`

## SBT Dependency Inspection

Use these when debugging dependency issues during compilation:

```bash
sbt '<module>/whatDependsOn <org> <artifact> <version>'  # What pulls in a package
sbt '<module>/dependencyTree' 2>&1 | grep -i "<pkg>"     # Full tree
sbt '<module>/dependencyList' 2>&1 | grep -i "<pkg>"     # Flat resolved list
sbt '<module>/evicted'                                    # Version conflicts
```
