# State Machines — API Reference

## Machine Creation API

| Method | Signature | Description |
|---|---|---|
| `Machine.reliable` | `Machine.reliable[In, Out](graph)` | Persists each step result before proceeding |
| `Machine.backed` | `Machine.backed[In, Out](dataSource)(graph)` | Loads input from DataSource before each step |
| `Machine.mapped` | `Machine.mapped[In, Out](f)(machine)` | Transforms input before delegating to inner machine |

### Machine.reliable

```scala
val machine = Machine.reliable[OrderRequest, Confirmation](
  Chain(validate).andThen(process).andThen(confirm)
)
```

### Machine.backed

```scala
val machine = Machine.backed[OrderState, Confirmation](orderDataSource)(
  Chain(process).andThen(confirm)
)
```

The DataSource is queried before each step to get the latest state. Use when external processes may update the backing data between steps.

### Machine.mapped

```scala
val machine = Machine.mapped[RawRequest, Confirmation](_.toOrderRequest)(orderMachine)
```

Applies a pure transformation to the input before delegating. No persistence of the mapping step.

## Composition API

| Method | Description |
|---|---|
| `machine.asStep(name)` | Embed a machine as a step in another machine's chain |
| `Chain(step).andThen(step)` | Linear sequential composition |
| `Chain(step).branch { ... }` | Conditional branching |
| `Chain(step).provide(value)` | Inject a value into the next step |
| `Chain(step).map(f)` | Transform output without persistence |
| `Step.parallel(steps)(combine)` | Execute steps concurrently |
| `Step.dynamic(name)(f)` | Generate steps at runtime |

## Dynamic Graph API

| Method | Description |
|---|---|
| `Step.dynamic(name)(f)` | Create a dynamic step that generates sub-steps at runtime |
| `Step.dynamic.node(id, step)` | Define a named node within a dynamic step |
| `Step.dynamic.collect(nodes)(combine)` | Collect results from all dynamic nodes |

```scala
Step.dynamic("process-batch") { batch =>
  val nodes = batch.items.map { item =>
    Step.dynamic.node(s"item-${item.id}", processItem)
  }
  Step.dynamic.collect(nodes) { results =>
    BatchResult(results.toList)
  }
}
```

## DataSource API

| Method | Signature | Description |
|---|---|---|
| `get` | `get(id: String): Future[Option[T]]` | Fetch current state |
| `set` | `set(id: String, value: T): Future[Unit]` | Persist updated state |
| `delete` | `delete(id: String): Future[Unit]` | Remove state (optional) |

```scala
class OrderDataSource(db: Database) extends DataSource[OrderState] {
  def get(id: String): Future[Option[OrderState]] =
    db.orders.findById(id)

  def set(id: String, value: OrderState): Future[Unit] =
    db.orders.upsert(id, value)
}
```

## Step Result API

| Result | Factory | Description |
|---|---|---|
| Next | `Step.Result.next(value)` | Proceed to next step |
| Done | `Step.Result.done(value)` | Complete the machine |
| Fail | `Step.Result.fail(error)` | Fail the machine |
| Retry | `Step.Result.retry(delay)` | Retry after delay |
| Pause | `Step.Result.pause` | Pause until external signal |

## Runner API

| Method | Description |
|---|---|
| `runner.run(machine, input)` | Start a new machine execution |
| `runner.resume(machineId)` | Resume a paused/failed machine |
| `runner.signal(machineId, event)` | Send an external event to a paused machine |
| `runner.status(machineId)` | Query current machine status |
| `runner.cancel(machineId)` | Cancel a running machine |

## Migration & Compatibility

### Adding Steps

New steps can be added to the end of a chain without breaking in-progress machines. Machines that have already passed the insertion point will not execute the new step.

### Removing Steps

Removing a step while machines are in-progress can cause failures. Instead:
1. Mark the step as a no-op (return `Step.Result.next(input)`)
2. Wait for all in-progress machines to complete
3. Remove the step in a subsequent deploy

### Renaming Steps

Step names are used as persistence keys. Renaming a step is equivalent to removing the old step and adding a new one. Avoid renaming steps that may have in-progress machines.

### Schema Changes

If step result types change shape:
1. Add JSON migration logic for old persisted results
2. Keep both old and new formats readable for the transition period
3. Clean up after all old machines have completed

## Performance Characteristics

| Operation | Latency | Notes |
|---|---|---|
| Step execution | Varies | Depends on step logic |
| Result persistence | ~5-15ms | Database write per step |
| Resume from storage | ~10-30ms | Database read for full state |
| Parallel step overhead | ~2-5ms | Coordination overhead per parallel branch |
| Dynamic graph setup | ~1-3ms per node | Node creation and registration |

### Optimization Tips

- Batch external calls within a single step rather than using many small steps
- Use `step.sync` for pure computations that don't need persistence
- Keep persisted result payloads small (< 1KB ideal, < 10KB acceptable)
- For large data, store in external storage and pass references through steps

## Remote API

Machines can be triggered and monitored via the service's API if the service exposes machine endpoints:

```
POST /api/v1/machines/{machineName}/start
  Body: { input data }
  Response: { machineId, status }

GET /api/v1/machines/{machineId}/status
  Response: { machineId, status, currentStep, result }

POST /api/v1/machines/{machineId}/signal
  Body: { event data }
  Response: { machineId, status }
```

Exact endpoints depend on the service's controller implementation. Check for `*MachineController.scala` or similar.
