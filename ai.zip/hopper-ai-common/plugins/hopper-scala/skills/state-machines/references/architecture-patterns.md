# State Machines — Architecture Patterns

## Linear Pipeline

The simplest pattern: steps execute sequentially.

```
┌──────────┐    ┌──────────┐    ┌──────────┐    ┌──────────┐
│ Validate │───>│ Process  │───>│  Notify  │───>│ Complete │
└──────────┘    └──────────┘    └──────────┘    └──────────┘
```

```scala
Machine.reliable[Request, Response](
  Chain(validate)
    .andThen(process)
    .andThen(notify)
    .andThen(complete)
)
```

Use for straightforward workflows where each step depends on the previous result.

## Branching Pipeline

Different paths based on intermediate results.

```
                    ┌──────────┐    ┌──────────┐
               ┌───>│ Standard │───>│ Ship     │──┐
┌──────────┐   │    └──────────┘    └──────────┘  │   ┌──────────┐
│ Classify │───┤                                   ├──>│ Confirm  │
└──────────┘   │    ┌──────────┐    ┌──────────┐  │   └──────────┘
               └───>│ Express  │───>│ Rush     │──┘
                    └──────────┘    └──────────┘
```

```scala
Chain(classify)
  .branch {
    case Standard(order) => Chain(processStandard).andThen(ship)
    case Express(order)  => Chain(processExpress).andThen(rush)
  }
  .andThen(confirm)
```

Use when business logic requires different processing paths.

## Fan-Out / Fan-In (Parallel)

Execute independent work concurrently, then combine results.

```
                ┌────────────┐
           ┌───>│ Fetch User │───┐
           │    └────────────┘   │
┌────────┐ │    ┌────────────┐   │    ┌──────────┐
│ Start  │─┼───>│ Fetch Prefs│───┼───>│ Combine  │
└────────┘ │    └────────────┘   │    └──────────┘
           │    ┌────────────┐   │
           └───>│ Fetch Hist │───┘
                └────────────┘
```

```scala
Chain(start)
  .andThen(
    Step.parallel(fetchUser, fetchPrefs, fetchHistory) {
      case (user, prefs, hist) => UserProfile(user, prefs, hist)
    }
  )
```

Use when multiple independent data fetches or operations can run concurrently.

## Saga Pattern

Distributed transaction with compensating actions on failure.

```
┌──────────┐    ┌──────────┐    ┌──────────┐
│ Reserve  │───>│ Charge   │───>│ Confirm  │
│ Inventory│    │ Payment  │    │ Booking  │
└──────────┘    └────┬─────┘    └──────────┘
                     │ fail
                     v
                ┌──────────┐    ┌──────────┐
                │ Refund   │───>│ Release  │
                │ Payment  │    │ Inventory│
                └──────────┘    └──────────┘
```

```scala
Chain(reserveInventory)
  .andThen(chargePayment)
  .branch {
    case Success(charge) => Chain(confirmBooking)
    case Failure(err)    => Chain(refundPayment).andThen(releaseInventory)
  }
```

Use for multi-service transactions where each step has a compensating action.

## Dynamic Batch Processing

Process a runtime-determined number of items.

```
┌──────────┐    ┌──────────────────────────┐    ┌──────────┐
│ Load     │───>│ Dynamic:                 │───>│ Finalize │
│ Batch    │    │  ┌─────┐ ┌─────┐ ┌─────┐│    └──────────┘
└──────────┘    │  │ I-1 │ │ I-2 │ │ I-N ││
                │  └─────┘ └─────┘ └─────┘│
                └──────────────────────────┘
```

```scala
Chain(loadBatch)
  .andThen(
    Step.dynamic("process-items") { items =>
      items.map(i => Step.dynamic.node(i.id, processItem))
    }
  )
  .andThen(finalize)
```

Use when the number of parallel work items is determined at runtime.

## Composed Machines (Orchestrator)

A parent machine delegates to child machines for sub-workflows.

```
┌─────────────────────────────────────────────────────┐
│ Orchestrator Machine                                │
│                                                     │
│  ┌──────────┐   ┌───────────────┐   ┌──────────┐  │
│  │ Prepare  │──>│ Child Machine │──>│ Finalize │  │
│  └──────────┘   │ (as step)     │   └──────────┘  │
│                  └───────────────┘                   │
└─────────────────────────────────────────────────────┘
```

```scala
val childMachine = Machine.reliable[SubRequest, SubResponse](...)

val orchestrator = Machine.reliable[Request, Response](
  Chain(prepare)
    .andThen(childMachine.asStep("child-workflow"))
    .andThen(finalize)
)
```

Use when a sub-workflow is reusable across multiple parent workflows.

## Retry with Backoff

Step retries with exponential backoff on transient failures.

```
┌──────────┐    ┌──────────┐──retry──┐    ┌──────────┐
│ Prepare  │───>│ Call API │<────────┘───>│ Process  │
└──────────┘    └──────────┘              └──────────┘
```

```scala
step.reliable("call-api") { req =>
  apiClient.call(req).map {
    case Success(resp)        => Step.Result.next(resp)
    case TransientError(err)  => Step.Result.retry(exponentialBackoff(retryCount))
    case PermanentError(err)  => Step.Result.fail(err)
  }
}
```

Use for external API calls that may experience transient failures.

## Wait-for-Signal (Human-in-the-Loop)

Machine pauses and waits for an external event.

```
┌──────────┐    ┌──────────┐   signal   ┌──────────┐    ┌──────────┐
│ Submit   │───>│  Pause   │···········>│ Process  │───>│ Complete │
│ Request  │    │ (wait)   │            │ Approval │    └──────────┘
└──────────┘    └──────────┘            └──────────┘
```

```scala
Chain(submitRequest)
  .andThen(
    step.reliable("wait-approval") { _ =>
      Future.successful(Step.Result.pause)
    }
  )
  .andThen(processApproval)
  .andThen(complete)
```

Resume with: `runner.signal(machineId, ApprovalEvent(approved = true))`

Use for workflows requiring human approval, external webhook callbacks, or async event processing.
