# State Machines — Debugging Guide

## Inspecting Machine State

### Finding a Machine's Current State

Query the Runner or database directly:

```scala
val status = runner.status(machineId).futureValue
// Returns: MachineStatus(id, currentStep, state, startedAt, updatedAt)
```

Check the persistence store (typically a database table):

```sql
SELECT * FROM machine_state WHERE machine_id = '<id>';
```

Key columns:
- `machine_id` — unique identifier
- `current_step` — name of the step being executed or last completed
- `state` — serialized machine state (JSON)
- `status` — running, paused, completed, failed
- `updated_at` — last state change timestamp

### Reading Persisted Step Results

Each completed step's result is stored in the machine state JSON. Parse the `state` column to see:

```json
{
  "steps": {
    "validate-order": { "status": "completed", "result": { ... } },
    "process-payment": { "status": "running" }
  }
}
```

## Common Issues

### Idempotency Violations

**Symptom:** Duplicate records, double-charges, or inconsistent state after a machine resumes.

**Cause:** A step performed a non-idempotent side effect (e.g., `INSERT` instead of `UPSERT`, API call without idempotency key).

**Fix:**
- Add idempotency keys to all external API calls
- Use `UPSERT` / `INSERT ... ON CONFLICT` for database writes
- Use CAP tokens for critical operations

```scala
// BAD: not idempotent
step.reliable("create-record") { req =>
  db.insert(Record(req.id, req.data))  // fails on retry
}

// GOOD: idempotent
step.reliable("create-record") { req =>
  db.upsert(Record(req.id, req.data))  // safe on retry
}
```

### "Data source cannot be null"

**Symptom:** `NullPointerException` or "Data source cannot be null" error at machine startup.

**Cause:** A `Machine.backed` machine was created without providing a DataSource, or the DataSource dependency was not injected.

**Fix:** Ensure the DataSource is provided and properly bound in your dependency injection:

```scala
// Check that the DataSource is registered in your module
bind[DataSource[OrderState]].to[OrderDataSource]

// Verify the machine receives it
class OrderWorkflow @Inject()(dataSource: DataSource[OrderState]) {
  val machine = Machine.backed[OrderState, Result](dataSource)(...)
}
```

### "Not in charge"

**Symptom:** Machine execution fails with "Not in charge" or similar leadership error.

**Cause:** The Runner uses leader election to ensure only one instance processes a machine at a time. This error occurs when the current instance loses leadership.

**Fix:**
- This is normally transient — another instance will pick up the machine
- Check that your service's leader election (ZooKeeper, database lock) is healthy
- Verify network connectivity between service instances
- Check logs for leader election churn

### Timeouts

**Symptom:** Machine appears stuck; step has been "running" for longer than expected.

**Cause:** The step's underlying operation timed out or hung without returning a result.

**Diagnosis:**
1. Check the step's `updated_at` timestamp — if stale, the step is stuck
2. Look for the step's operation in downstream service logs
3. Check for network issues or downstream service outages

**Fix:**
- Add explicit timeouts to step operations:
  ```scala
  step.reliable("call-service") { req =>
    serviceClient.call(req)
      .within(30.seconds)
      .map(Step.Result.next)
      .rescue { case _: TimeoutException =>
        Future.value(Step.Result.retry(5.seconds))
      }
  }
  ```
- Configure the Runner's global step timeout
- Implement circuit breakers for external service calls

### Machine Stuck in "Paused" State

**Symptom:** Machine is paused but the expected signal was already sent.

**Cause:** Signal was sent before the machine reached the pause step, or signal was sent to wrong machine ID.

**Fix:**
1. Verify the machine ID used in the signal matches the paused machine
2. Check signal delivery logs
3. Re-send the signal: `runner.signal(machineId, event)`

## Tracing

### Step-Level Tracing

Each step execution emits trace spans. Look for:
- Span name: `machine.step.<step-name>`
- Tags: `machine.id`, `machine.name`, `step.name`, `step.result`

In Datadog APM, search:
```
service:<your-service> resource_name:machine.step.*
```

### Machine-Level Tracing

The full machine execution is traced as a parent span:
- Span name: `machine.run.<machine-name>`
- Tags: `machine.id`, `machine.name`, `machine.status`

### Correlating Logs

Machine executions add MDC context:
- `machineId` — unique execution ID
- `machineName` — machine definition name
- `stepName` — current step name

Search logs with:
```
@machineId:<id>
```

## Resume and Recovery

### Manual Resume

If a machine is stuck, manually trigger a resume:

```scala
runner.resume(machineId)
```

Or via API (if exposed):
```
POST /api/v1/machines/{machineId}/resume
```

### Bulk Recovery

If many machines are stuck (e.g., after an outage), the Runner's recovery process scans for machines in `running` state that haven't been updated recently and resumes them automatically.

Check the Runner's recovery configuration:
- `recovery.interval` — how often the recovery scan runs
- `recovery.stale.threshold` — how long a machine must be idle before recovery
- `recovery.batch.size` — how many machines to resume per scan

### Forcing Completion

In extreme cases, manually update the database to mark a machine as completed or failed:

```sql
UPDATE machine_state
SET status = 'failed', updated_at = NOW()
WHERE machine_id = '<id>' AND status = 'running';
```

**Warning:** Only do this as a last resort. It bypasses compensating actions and may leave downstream systems in an inconsistent state.

## Best Practices for Debugging

1. **Start with the machine state** — query the persistence store to understand where the machine is
2. **Check step results** — each completed step's result is persisted; use it to trace the execution path
3. **Follow the traces** — use Datadog APM to see the full execution timeline
4. **Check downstream systems** — if a step calls an external service, verify that service received and processed the request
5. **Test idempotency** — if you suspect an idempotency issue, run the step twice with the same input in a test and verify identical results
6. **Review resume behavior** — ensure the machine correctly skips completed steps on resume by checking the persisted step results
