---
name: state-machines
description: >-
  Hopper's distributed state machine framework (helpers-machine) for reliable,
  resumable workflows. Covers machine definitions, step types (reliable, backed,
  mapped), Chain DSL, parallel execution, dynamic graphs, persistence, and testing.
  Use when working with state machine code, Machine.reliable, Machine.backed,
  Chain DSL, or debugging state machine behavior in Hopper Scala services.
---

# State Machines (helpers-machine)

Hopper's distributed state machine framework for building reliable, resumable workflows. Machines define a graph of steps that execute asynchronously, persist state between steps, and resume automatically after failures.

## Detecting Usage

Look for `helper("machine")` in `build.sbt`.

```
Glob: **/*Machine.scala, **/*machine*.scala
Grep: "Machine\.(reliable|backed|mapped)"
```

## Core Concepts

A **Machine** is a directed graph of **Steps**. Each step performs work and returns a result that determines the next step. The **Runner** executes machines, persisting state after each step so work can resume if the process restarts.

Key types:
- `Machine[In, Out]` — a state machine from input `In` to output `Out`
- `Step[In, Out]` — a single node in the graph
- `DataSource[T]` — provides external data to a step (database, API, cache)
- `Runner` — executes machines, manages persistence and resume

### Machine Types

| Type | Description | Use Case |
|---|---|---|
| `Machine.reliable[In, Out]` | Each step result is persisted before the next step runs | Default choice for most workflows |
| `Machine.backed[In, Out]` | Like reliable, but backed by a `DataSource` for the input | When you need to load/refresh input data |
| `Machine.mapped[In, Out]` | Transforms machine input before execution | Adapter pattern |

### DataSource

A `DataSource[T]` provides data to steps. It has two methods:
- `get(id): Future[Option[T]]` — fetch current state
- `set(id, value): Future[Unit]` — persist updated state

Common implementations wrap database or cache access.

## Defining Steps

### Step Types

| Step | Description |
|---|---|
| `step.reliable(name)(f)` | Persists result, resumes from result on restart |
| `step.backed(name)(f)` | Reads from DataSource before executing |
| `step.mapped(name)(f)` | Transforms input without side effects |
| `step.sync(name)(f)` | Synchronous computation, no persistence |

A reliable step:

```scala
val authorize: Step[PaymentRequest, AuthResult] =
  step.reliable("authorize") { (req: PaymentRequest) =>
    paymentGateway.authorize(req.amount, req.card)
      .map(result => Step.Result.next(result))
  }
```

### Step Results

| Result | Meaning |
|---|---|
| `Step.Result.next(value)` | Continue to the next step with `value` |
| `Step.Result.done(value)` | Machine completes with `value` |
| `Step.Result.fail(error)` | Machine fails with error |
| `Step.Result.retry(delay)` | Retry this step after `delay` |
| `Step.Result.pause` | Pause; resume on external signal |

## Chain DSL

The `Chain` DSL connects steps into a linear pipeline:

```scala
val machine: Machine[OrderRequest, Confirmation] =
  Machine.reliable[OrderRequest, Confirmation](
    Chain(validateOrder)
      .andThen(reserveInventory)
      .andThen(processPayment)
      .andThen(sendConfirmation)
  )
```

Each step's output type must match the next step's input type. The chain is type-checked at compile time.

### Injecting Values

Use `.provide` to inject a constant or computed value between steps:

```scala
Chain(fetchUser)
  .provide(config.maxRetries)  // injects Int into next step
  .andThen(processWithRetries)
```

### Mapping Between Steps

Use `.map` or `.flatMap` to transform values between steps without creating a new persisted step:

```scala
Chain(fetchOrder)
  .map(order => order.lineItems)
  .andThen(processLineItems)
```

## Conditional Branching

Use `.branch` to choose different paths based on a step's output:

```scala
Chain(validateInput)
  .branch {
    case Valid(data)   => Chain(processData).andThen(complete)
    case Invalid(err)  => Chain(handleError)
  }
```

Branches can have different output types if they converge to a common supertype.

## Parallel Execution

Execute multiple steps concurrently with `Step.parallel`:

```scala
val fetchAll: Step[UserId, UserData] =
  Step.parallel(
    fetchProfile,
    fetchPreferences,
    fetchHistory
  ) { case (profile, prefs, history) =>
    UserData(profile, prefs, history)
  }
```

All parallel steps must have the same input type. Results are combined when all complete.

## Dynamic Graphs

For workflows where the number of steps is determined at runtime:

```scala
val processItems: Step[List[Item], List[Result]] =
  Step.dynamic("process-items") { items =>
    items.map(item => Step.dynamic.node(item.id, processItem))
  }
```

Each dynamic node runs independently and results are collected.

## Composed Machines

Machines can be composed by nesting one machine as a step in another:

```scala
val outerMachine = Machine.reliable[Request, Response](
  Chain(preProcess)
    .andThen(innerMachine.asStep("inner"))
    .andThen(postProcess)
)
```

Use `.asStep(name)` to embed a machine as a step in another machine's chain.

## Persistence

### State Management

The Runner persists the machine's state after each reliable step. State includes:
- Current step name and position in the graph
- Result of each completed step
- Machine input and any DataSource snapshots

### Idempotency

Steps must be idempotent. The Runner may re-execute a step if it completes but the result fails to persist. Design steps so that re-execution produces the same outcome:

- Use idempotency keys for external API calls
- Make database writes upserts rather than inserts
- Avoid side effects that cannot be safely repeated

### CAP Tokens

CAP (Check-And-Persist) tokens ensure exactly-once execution semantics for critical steps. A step acquires a token before executing and releases it after persistence confirms:

```scala
step.reliable("charge-card") { req =>
  withCapToken(req.idempotencyKey) { token =>
    paymentService.charge(req.amount, token)
  }
}
```

### Transient vs Persisted Data

| Data Type | Persisted | Survives Restart |
|---|---|---|
| Step results | Yes | Yes |
| DataSource state | Yes (if backed) | Yes |
| Local variables | No | No |
| Transient context | No | No |

### Resume Process

When a machine resumes after restart:
1. Runner loads persisted state from storage
2. Skips all steps whose results are already persisted
3. Re-executes the last incomplete step
4. Continues the remaining graph

## Sync Points and External Events

A step can pause and wait for an external signal:

```scala
val waitForApproval: Step[Request, Approval] =
  step.reliable("wait-approval") { req =>
    Future.successful(Step.Result.pause)
  }
```

To resume a paused machine, send an event through the Runner:

```scala
runner.signal(machineId, Approval(approved = true))
```

## Testing

### MachineTester

`MachineTester` lets you test individual steps in isolation:

```scala
val tester = MachineTester(myMachine)

val result = tester
  .withInput(OrderRequest("item-1", 2))
  .runStep("validate-order")
  .assertNext[ValidatedOrder]
```

### InMemoryRunner

`InMemoryRunner` executes the full machine in-memory without external persistence:

```scala
val runner = InMemoryRunner()
val result = runner.run(myMachine, input).futureValue

result shouldBe Confirmation("order-123", "confirmed")
```

### Testing Tips

- Test each step independently with `MachineTester` for unit tests
- Use `InMemoryRunner` for integration tests of the full graph
- Mock DataSources to control input data
- Verify idempotency by running the same step twice and asserting identical results
- Test resume behavior by simulating failures between steps

## Best Practices

**Design:**
- Keep steps small and focused on a single operation
- Use meaningful step names that describe the action (e.g., `"authorize-payment"`, not `"step-3"`)
- Prefer `Machine.reliable` unless you specifically need backed or mapped behavior

**Performance:**
- Minimize data stored in step results — large payloads slow persistence
- Use DataSources for large state rather than passing it through steps
- Set appropriate timeouts for steps that call external services

**Reliability:**
- Always design steps to be idempotent
- Use CAP tokens for financial or other critical operations
- Handle partial failures in parallel steps gracefully
- Log step transitions for observability

**Naming:**
- Machine names should describe the workflow: `"order-fulfillment"`, `"user-onboarding"`
- Step names should describe the action: `"validate-input"`, `"send-notification"`

## References

- [API Reference](references/api-reference.md) — Machine creation API, composition, data sources, migration, performance
- [Architecture Patterns](references/architecture-patterns.md) — Common patterns with diagrams
- [Debugging Guide](references/debugging.md) — Troubleshooting, common issues, tracing
