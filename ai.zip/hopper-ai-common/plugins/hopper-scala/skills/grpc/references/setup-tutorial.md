# gRPC Setup Tutorial for Hopper Scala Services

## Introduction

gRPC is a Remote Procedure Call (RPC) library that uses HTTP/2 as its transport protocol. It supports four endpoint types: Unary->Unary, Unary->Streamed, Streamed->Unary, and Streamed->Streamed. The most common pattern, Unary->Unary, is equivalent to a plain HTTP request/response interaction.

Hopper standardized on Protocol Buffers (protobuf) for gRPC because:
- **Schema evolution** is far easier than with JSON over REST
- **Code generation** automatically creates client and server stubs
- **Cross-platform support** with compilers for all major languages
- **Extensibility** enables generation of documentation, validation, proxies, and more
- **Binary protocol** produces smaller message sizes compared to JSON

This guide walks through setting up a new gRPC service in Hopper's Scala ecosystem.

## Project Setup (SBT)

Two options exist for the proto sub-project in `build.sbt`:

- **`hopperProtoc`**: Enables the protobuf compiler but does NOT publish artifacts. Use this when you depend on other services' protos but others don't need to depend on yours.
- **`hopperProtocLibrary`**: Enables the protobuf compiler AND publishes artifacts. Use this when other services need to depend on your protos.

Create a proto sub-project:

```scala
lazy val proto = Project(id = "my-proto", base = file("proto"))
  .settings(hopperProtoc)
```

Add it to the aggregate project:

```scala
Project(id = "...", base = file("."))
  ...
  .aggregate(proto)
```

## Proto File Structure

Create two files in `proto/src/main/protobuf/hopper/myservice/v1/`:

**model.proto** — Shared data models:

```protobuf
syntax = "proto3";

package hopper.myservice.v1;

option java_package = "com.hopper.myservice.v1";

message MyData {
  string message = 1;
  int32 number = 2;
}
```

**first_service.proto** — Service definition:

```protobuf
syntax = "proto3";

package hopper.myservice.v1;

option java_package = "com.hopper.myservice.v1";

import "hopper/myservice/v1/model.proto";

// Request object must follow '<rpc_name>Request' naming convention
message MyEndpointRequest {
  MyData data = 1;
}

// Response object must follow '<rpc_name>Response' naming convention
message MyEndpointResponse {
  MyData data = 1;
}

service FirstService {
  // Some helpful comments on usage
  rpc MyEndpoint(MyEndpointRequest) returns (MyEndpointResponse);
}
```

Run `sbt compile` to generate Scala code for the service, client, and model classes.

## Server Setup

Three components are required:

**Service Implementation:**

```scala
package com.hopper.myservice

import com.hopper.myservice.v1.first_service.FirstServiceFinagleGrpc
import com.hopper.myservice.v1.first_service.MyEndpointRequest
import com.hopper.myservice.v1.first_service.MyEndpointResponse
import com.hopper.myservice.v1.model.MyData
import com.twitter.util.Future

object DefaultFirstService extends FirstServiceFinagleGrpc.FirstService {
  override def myEndpoint(in: MyEndpointRequest): Future[MyEndpointResponse] =
    Future.value {
      MyEndpointResponse(Some(
        in.data
          .map(data => MyData(s"You said, ${data.message}.", data.number + 1))
          .getOrElse(MyData(s"You said nothing."))
      ))
    }
}
```

**Server Configuration and Main Class:**

```scala
package com.hopper.myservice

import com.twitter.util.Managed
import com.hopper.common.app.FlagConfig
import com.hopper.common.configuration.ConfigParser
import com.hopper.common.grpc.server.HopperGrpcServer
import com.hopper.common.lang.Deriving
import com.hopper.myservice.v1.first_service.FirstServiceFinagleGrpc

case class MyServerContext(
  firstService: FirstServiceFinagleGrpc.FirstService
)

case class MyServerConfig() {
  def build: Managed[MyServerContext] =
    Managed.const(MyServerContext(DefaultFirstService))
}
object MyServerConfig {
  implicit lazy val parser: ConfigParser[MyServerConfig] = Deriving[ConfigParser[MyServerConfig]]
}

object Server extends HopperGrpcServer with FlagConfig {
  override val name = "myservice"

  override type ServerConfig = MyServerContext
  private lazy val serverConfig: MyServerConfig = MyServerConfig.parser(config, name)

  override def buildInfo: BuildInfo.type = BuildInfo
  override def setup: Managed[MyServerContext] = serverConfig.build

  addGrpcService(_.firstService)
}
```

The server extends `HopperGrpcServer` for gRPC-only services. For combined HTTP + gRPC, extend `ManagedServer with FinatraHttpServer with BaseGrpcServer`. See the [helpers-http-server skill](hopper-scala:helpers-http-server) for HTTP controller patterns.

**Server build.sbt:**

```scala
lazy val server = Project(id = "my-server", base = file("server"))
  .enablePlugins(BuildInfoPlugin)
  .settings(buildInfoPackage := "com.hopper.myservice")
  .settings(hopperAssembly: _*)
  .settings(
    mainClass in assembly := Some("com.hopper.myservice.Server"),
    libraryDependencies ++= Seq(
      helper("grpc-server"),
      helper("grpc-test") % Test,
    )
  )
  .dependsOn(proto)
```

## Testing with grpcurl

Install grpcurl: `brew install grpcurl`

Start your service with `sbt my-server/run`. It listens on port 7170 (default gRPC port).

**Reflection Commands:**

```bash
# List available services
grpcurl -plaintext localhost:7170 list

# Describe a service
grpcurl -plaintext localhost:7170 describe hopper.myservice.v1.FirstService

# Describe a message
grpcurl -plaintext localhost:7170 describe hopper.myservice.v1.MyEndpointRequest

# Make a request
grpcurl -plaintext \
  -d '{"data": {"message":"Hola", "number":5}}' \
  localhost:7170 \
  hopper.myservice.v1.FirstService/MyEndpoint
```

**Note:** grpcurl uses JSON for convenience, translating to/from protobuf's binary format. It will reject unknown fields, but the binary protocol simply ignores them. Don't rely solely on grpcurl for testing.

## Scala Client Setup

Add the proto dependency and gRPC helper to your proto project:

```scala
lazy val proto = Project(id = "my-proto", base = file("proto"))
  .settings(hopperProtoc)
  .settings(
    protoDependencies += "com.hopper" %% "grpc-example-proto" % "0.1.48",
  )
  .settings(
    libraryDependencies ++= Seq(
      helper("grpc")
    )
  )
```

Update your server config to create and inject the client:

```scala
case class MyServerConfig(
  echoGrpcChannel: GrpcChannel
) {
  def build: Managed[MyServerContext] = {
    for {
      echoChannel <- echoGrpcChannel.build()
      echoClient = EchoServiceFinagleGrpc.EchoServiceClient(echoChannel)
    } yield {
      MyServerContext(DefaultFirstService(echoClient))
    }
  }
}
```

**HOCON Configuration for the gRPC Channel:**

```hocon
my-server {
  echoGrpcChannel {
    target: "unit.grpc-example.svc.cluster.local:7170"
  }
}
```

This configuration uses Kubernetes service discovery to connect to the remote gRPC service. The client will automatically handle connection pooling, retries, and load balancing.
