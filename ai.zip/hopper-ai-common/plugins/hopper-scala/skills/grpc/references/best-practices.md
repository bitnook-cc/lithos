# gRPC and Protobuf Best Practices

## 1. Request Context and Cancellation

gRPC propagates request cancellation through the Finagle stack. If a client disconnects, cancellation propagates to the server and to its downstream requests.

**Key gotcha (common bug when transitioning from HTTP to gRPC):** Outbound requests that derive from an inbound gRPC request will ALL be cancelled when the inbound request completes. If your service fires off a background gRPC call while processing a request, that background call will be cancelled when the main request completes. This is NOT how the Finagle HTTP stack behaves.

To make detached requests, fork the gRPC context:

```scala
def mySideEffect(): Future[Unit] = ???

def myGrpcRequestHandler(req: SomeRequest): Future[SomeResponse] = {
  val forked = io.grpc.Context.current.fork
  forked.run { () => mySideEffect() }
  normalProcess(req).map { r => SomeResponse() }
}
```

## 2. Error Handling

Three goals:

**API clarity:** Use the gRPC rich error model with standard error codes.

**Datadog observability:**
- `StatusRuntimeException` marks requests as failed in Datadog.
- Some statuses (`INVALID_ARGUMENT`, `NOT_FOUND`) are treated as client errors in `OpenTracing.scala` — client span is marked as error, but server span is marked as success. This ensures server error metrics aren't affected by invalid client requests.
- For expected/domain-specific errors, encode error info in the response body. This results in an `OK` gRPC status (success in Datadog), which is desired since the software is working as intended.

**Programmatic handling:**
- Unexpected errors: use `StatusRuntimeException` with standard gRPC status codes (e.g., database error → `INTERNAL`).
- Include the `StatusEx` extractor for client-side handling of both exception types:

```scala
object StatusEx {
  def unapply(t: Throwable): Option[Status.Code] =
    t match {
      case e: StatusRuntimeException => Some(e.getStatus.getCode)
      case e: StatusException => Some(e.getStatus.getCode)
      case _ => None
    }
}

// Usage:
exception match {
  case StatusEx(code) => // handle by code
}
```

- For expected/domain errors, use protobuf's `oneof` construct for union types with success and error variants. Example: a `CardAuthFailure` type lets the API consumer direct the user to provide new card info.

**Warnings:**
- Do NOT use `google.rpc.Status` explicitly in your proto services. `StatusRuntimeException` automatically populates it in trailer metadata.
- Do NOT use the `details` field of `google.rpc.Status` (not fully supported in Java gRPC).
- Prefer standard gRPC error codes over custom error codes.

## 3. Default Values

In proto3, all fields are optional with default values. When a field has its default value, it is NOT sent on the wire. This means you can't tell if a field was explicitly set to the default or was absent entirely.

For scalar types where you need to capture presence, use `google.protobuf` wrapper types (`StringValue`, `Int32Value`, `Int64Value`, `BoolValue`). In Scala, ScalaPB wraps message fields in `Option[T]` and understands primitive wrappers — generating `Option[Int]`, `Option[String]`, etc.

Set `no_default_values_in_constructor: true` at the package level. This requires all fields to be explicitly set when constructing instances, similar to exhaustive pattern matching — it prevents accidentally omitting new fields.

## 4. Validation

`scalapb-validate` is automatically enabled via `hopperProtoc`. Import the constraint definitions and add rules:

```protobuf
import "validate/validate.proto";

message MyMessage {
  string message = 1 [(validate.rules).string = {min_len: 1, max_len: 20}];
  MyOtherMessage other = 2 [(validate.rules).message.required = true];
}
```

Important notes:
- Validation rule changes are almost always a breaking change — consider a new API version.
- Validation runs automatically on **requests only** (not responses — failing on invalid response could leave a request in undefined state).
- Validation runs on both client outbound and server inbound (server can't trust client validated, but client avoids sending doomed requests).
- Access generated validators directly: `MyMessage.validator.validate(msg)` or `implicitly[Validator[MyMessage]].validate(msg)`.
- Disable with `Compile / protoWithScalaPbValidate := false` if needed.

## 5. Linting

Buf Lint is automatically enabled. Default ruleset:

```yaml
lint:
  use:
    - DEFAULT
  enum_zero_value_suffix: _UNSPECIFIED
  rpc_allow_same_request_response: false
  rpc_allow_google_protobuf_empty_requests: false
  rpc_allow_google_protobuf_empty_responses: false
  service_suffix: Service
```

Customize via `buf.yaml` in the project root. Change config file location with `bufConfigFile := file("path/to/buf.yaml")`. Disable as last resort with `Compile / protoWithBufCheckLint := false`.

## 6. Documentation

`protoc-gen-doc` is automatically enabled. It generates markdown at `<project>/docs/<module-name>-api.md`.

- Generated docs change whenever proto files change — commit doc changes with proto changes.
- Disable with `Compile / protoWithGenDoc := false`.
- Customize output with `protoGenDocFilename` and `protoGenDocDirectory` settings.
- Enable cleanup on `sbt clean` with `protoGenDocClean := true` (off by default to avoid surprising git-tracked file deletion).

## 7. Packaging and Versioning

- Proto packages: `hopper.<service>.v<version>` (single major version number, e.g., `hopper.exchangerates.v1`)
- Scala packages: `com.hopper.<service>.v<version>` via `option java_package`
- On breaking changes, increment the version (e.g., `v1` → `v2`)
- The previous version must still be supported while there are usages — duplicate the entire directory structure and proto files with the version updated
- See [Google's documentation](https://cloud.google.com/apis/design/compatibility#backwards-incompatible_breaking_changes) for what constitutes a breaking change
- Validation rule changes almost always break backwards compatibility

## 8. Chimney Transformations

Always use `TransformerF` — **never** use `Transformer`. `Transformer` combined with default constructor values leads to surprising behavior.

Use the `protoTransformerF` builder from hopper-proto, which:
- Disables use of default constructor values
- Enforces a rich error model tracking all transformation errors with field paths (e.g., `foo.bar.baz is required`)

Set `preserve_unknown_fields: false` in ScalaPB options to avoid needing to specify the `unknownFields` field in transformers.

Dependencies:
```scala
libraryDependencies ++= Seq(
  "com.hopper" %% "protobuf-transformers" % "1.0.1",
  "com.hopper" %% "hopper-proto-transformers" % "1.0.1", // if using hopper.core types
  "com.hopper" %% "google-common-protos-transformers" % "1.0.1", // if using google types
)
```

Usage example:
```scala
import com.hopper.chimney.protobuf.Transformers._
import com.hopper.protobuf.Transformers._
import io.scalaland.chimney.dsl._

case class ProtoFoo(id: String, ts: Option[Timestamp])
case class Foo(id: UUID, instant: Instant)

implicit val fooToProto: ProtoTransformerF[Foo, ProtoFoo] =
  protoTransformerF[Foo, ProtoFoo]
    .withFieldRenamed(_.instant, _.ts)
    .buildTransformer

implicit val protoToFoo: ProtoTransformerF[ProtoFoo, Foo] =
  protoTransformerF[ProtoFoo, Foo]
    .withFieldRenamed(_.ts, _.instant)
    .buildTransformer

val foo: Foo = ???
val result: TransformResult[ProtoFoo] = foo.transformIntoF[TransformResult, ProtoFoo]
```

## 9. SBT Dependencies

**`protoDependencies` (recommended):** Makes proto source files available for local code generation. Your service generates its own Scala code from the proto sources. Safe.

**`libraryDependencies` (NOT safe for proto deps):** Adds compiled Scala code to the classpath. Causes runtime binary compatibility errors when transitive proto dependencies are updated.

**Why `libraryDependencies` breaks:** Consider:
- `user-service-proto` v0.1.0 (initial), then v0.2.0 (adds `email` field to `User`)
- `flights-service-proto` v0.1.0 depends on `user-service-proto` v0.1.0 via `protoDependencies` (good)
- `my-service` depends on `user-service-proto` v0.1.0 via `protoDependencies` (good) AND `flights-service-proto` v0.1.0 via `libraryDependencies` (bad!)

Updating `user-service-proto` to v0.2.0 compiles fine but fails at runtime — `flights-service-proto`'s compiled code expects a `User.class` without `email`.

**Exception — `hopper-proto` and `google-common-protos`:** These SHOULD use `libraryDependencies` because they include Scala converters and enforce `versionScheme`. Use the dual-dependency pattern:

```scala
val hopperProtoVersion = "1.0.1"

libraryDependencies ++= Seq(
  "com.hopper" %% "hopper-proto" % hopperProtoVersion,
  "com.hopper" %% "hopper-proto" % hopperProtoVersion % "protobuf",
  "com.hopper" %% "google-common-protos" % hopperProtoVersion,
  "com.hopper" %% "google-common-protos" % hopperProtoVersion % "protobuf",
)
```

The `% "protobuf"` scope allows your proto files to import protos from hopper-proto. The dependency without the scope allows your generated Scala files to import the generated Scala files and converters.

## 10. Rich Scala Clients

When the generated gRPC client isn't sufficient (e.g., need caching, domain logic):

**hopper-interfaces:** Contains protobuf definitions + versioned Scala clients. Updated with each Helpers release. Clients may depend on Helpers.

**Service repo client:** Publish a client library from your service repo. Requirements:
- Only depends on helpers-stable (not Helpers)
- Enable MIMA checks for binary compatibility
- Enable `versionScheme` setting to prevent incompatible versions on the classpath

See [exchange-rates](https://github.com/hopper-org/exchange-rates) for an example of the service repo client pattern.
