---
name: grpc
description: >-
  gRPC and protobuf conventions for Hopper Scala services. Use when working
  with .proto files, gRPC services, protobuf models, ScalaPB code generation,
  protoDependencies, or Chimney transformations.
---

# gRPC and Protobuf

Hopper uses gRPC with Protocol Buffers for service communication. Scala code generation is handled via ScalaPB, built on Finagle via the finagle-grpc library.

## Detecting Usage

Look for `hopperProtoc` or `hopperProtocLibrary` in `build.sbt`, or `.proto` files in the project tree.

```
Glob: **/*.proto, **/proto/src/main/protobuf/**
Grep: "hopperProtoc"
```

## Proto Field Conventions

| Instead of | Use | Why |
|---|---|---|
| `string`, `int32`, `bool` | `google.protobuf.StringValue`, `Int32Value`, `BoolValue` | Captures field presence on the wire |
| Primitive time fields | `com.google.type.DateTime` | Use `com.google.type.Conversions` for Scala conversion |
| Custom decimal types | `hopper.core.v1.DecimalString` | Standard decimal representation |
| Optional fields required in Scala | Add `[(validate.rules).message.required = true]` | ScalaPB defaults to `Option` |

## ScalaPB Package Options

Each proto package should define a `pkg.proto` file with package-level ScalaPB options:

```protobuf
syntax = "proto3";

package hopper.service.v1;

import "scalapb/scalapb.proto";
option java_package = "com.hopper.service.v1";

option (scalapb.options) = {
  scope: PACKAGE
  flat_package: true
  enum_strip_prefix: true
  retain_source_code_info: true
  no_default_values_in_constructor: true
};
```

**Note:** If the proto file will be imported elsewhere, use `scope: FILE` directly in that file instead of relying on `pkg.proto`.

## Key Rules

- **Package format:** `hopper.<service>.v<major_version>`
- **Scala package:** `com.` + proto package via `option java_package`
- **File organization:** Keep models and services in separate `.proto` files
- **One service per file:** Each service definition gets its own file
- **Request/response naming:** Messages must be named `<RpcName>Request` and `<RpcName>Response`
- **Proto dependencies:** Use `protoDependencies` (not `libraryDependencies`) for proto deps — except `hopper-proto` and `google-common-protos`
- **Chimney transformations:** Use `TransformerF` (never `Transformer`)
- **Documentation:** Comment every service, method, message, and field

## References

- [Setup Tutorial](references/setup-tutorial.md) — new gRPC service setup, SBT config, server/client code, grpcurl testing
- [Best Practices](references/best-practices.md) — error handling, validation, linting, Chimney, dependencies, versioning
- [hopper-proto](https://github.com/hopper-org/hopper-proto) — core protobuf types
- [grpc-example](https://github.com/hopper-org/grpc-example) — working reference project
