---
name: helpers-http-server
description: >-
  Use when reading or writing Finatra HTTP controllers in a Hopper Scala
  service. Triggers: RestController, EndpointControllerBuilder, route handler,
  HTTP endpoint, controller, request.jsonAs, render.toJson.
---

# helpers-http-server

Hopper's HTTP server library, built on Finatra. Provides `RestController` and `EndpointControllerBuilder` for defining REST endpoints.

## Detecting Usage

Look for `helper("http-server")` in `build.sbt`.

```
Glob: **/*Controller.scala
Grep: "(get|put|post|delete|patch)\("
```

## Controller Patterns

Controllers extend `RestController` or `EndpointControllerBuilder` and define routes via HTTP method functions:

```scala
class PaymentController(
  override val prefix: String,     // e.g., "/api/v1"
  paymentService: PaymentService,
) extends RestController {

  put("/authorize/:idempotencyKey") { request =>
    val req = request.jsonAs[AuthorizeRequest]
    paymentService.authorize(key(request), req).map(render.toJson(_))
  }

  get("/user-balance") { request =>
    val userId = request.params.getOrBadRequest("user")
    paymentService.userBalance(userId).map(render.toJson(_))
  }
}
```

Key elements:
- **URL prefix**: `override val prefix = "..."` or constructor parameter
- **Routes**: `get(path)`, `post(path)`, `put(path)`, `delete(path)`, `patch(path)`
- **Full path**: `prefix + path`
- **Request body**: `request.jsonAs[T]` — deserializes JSON using `helpers-play-json` (see `hopper-scala:helpers-play-json`)
- **Response**: `render.toJson(result)` — serializes using `helpers-play-json` (see `hopper-scala:helpers-play-json`)

## Parameter Extraction

| Code pattern | Parameter type |
|---|---|
| `request.routeParams("id")` | Path parameter, required |
| `request.params.getOrBadRequest("key")` | Query parameter, required, String |
| `request.params.getIntOrBadRequest("key")` | Query parameter, required, Int |
| `request.params.getLongOrBadRequest("key")` | Query parameter, required, Long |
| `request.params.getBooleanOrBadRequest("key")` | Query parameter, required, Boolean |
| `request.params.get("key")` | Query parameter, optional, String |
| `request.params.getAndTransform("key", default)(f)` | Query parameter, optional (has default) |
| `request.headerMap.get("X-Header")` | Header parameter |

## Finding All Endpoints

1. Find the server main class (from workload BUILD `main_class`)
2. Look for `registry.register(...)` calls to find all registered controllers
3. Check parent classes — controllers may inherit routes

## Other Frameworks (rare)

### Finagle HTTP

```
Glob: **/*Handler.scala, **/*Router.scala
Grep: "Service\[Request,\s*Response\]"
```

## Request Type Extraction

Read each handler's body to find the actual request type:

```scala
post("/priceQuote") { request =>
  val req = request.jsonAs[PriceQuoteRequest]   // <-- THIS is the request type
  service.priceQuote(req).map(render.toJson(_))
}
```

- `request.jsonAs[T]` — `T` is the request type
- If a handler does not call `jsonAs`, it has no JSON request body — it uses query params or path params instead
- **Do not use a generic session or envelope type as a catch-all.** Many endpoints pass session context implicitly (via headers, cookies, or path params) and accept a separate domain-specific request body
- If >5 endpoints appear to share the same request schema, re-read the handler code — you are likely using an envelope type instead of the actual domain type

## Response Type Extraction

The handler's last expression reveals the response type:

| Pattern | Response type |
|---|---|
| `service.method(args).map(render.toJson(_))` | Return type of `service.method()` |
| `render.toJson(result)` | Type of `result` |
| `render.toJson(service.method(args))` | Return type of `service.method()` |
| `render.plain("ok")` | No JSON response body |
| `render.nothing` | No response body |
| `Future.value(response.ok)` | No JSON response body |

To find the concrete response type, trace `service.method()`:

1. Find the service class (constructor parameter of the controller)
2. Find the method definition
3. The return type is `Future[T]` — `T` is your response type
4. If `T` is a wrapper like `ProviderResponse[U]`, expand both the wrapper and the inner type

## External Controller Discovery

Controllers registered via `registry.register(...)` may not be defined in the current repo — they come from library dependencies.

To find them:

1. Search `hopper-org` using `mcp__github__search_code` by class name
2. Read the source with `mcp__github__get_file_contents` to extract routes

Common external controller sources:
- `helpers-http-server` — base controllers and utilities
- `flights-common` — shared flight domain controllers (shopping, seats, eligibility)
- `Helpers` — shared model and API utilities

These are first-class endpoints — do not skip them.
