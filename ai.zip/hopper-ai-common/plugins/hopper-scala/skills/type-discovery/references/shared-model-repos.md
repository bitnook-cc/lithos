# Shared Model Repos

This is a starting point for finding types across Hopper's multi-repo codebase. Always search more broadly if a type isn't found here.

Repos that publish shared libraries have `hopperLibrary`, `librarySettings`, or `hopperProtocLibraryIncludeClasses` in their `build.sbt`.

## Core Framework

| Repo | Module (maven artifact) | Package | Description |
|---|---|---|---|
| `hopper-org/helpers-stable` | `helpers-core` | `com.hopper.common.lang` | Core types: `AEnum`, `Enum`, `Injection`, `TagValue`, `TagLabel`, `OpenEnum` |
| `hopper-org/helpers-stable` | `helpers-play-json` | `com.hopper.common.json` | JSON library: `JsFormat`, `Deriving`, `JsReads`, `JsWrites` |
| `hopper-org/helpers-stable` | `helpers-format` | `com.hopper.common.format` | Binary/protobuf format: `ProtoFormat`, `ByteFormat`, `KeyFormat` |
| `hopper-org/helpers-stable` | `helpers-http-server` | `com.hopper.common.finatra` | HTTP framework: `RestController`, `EndpointControllerBuilder`, `ResponseBuilder` |
| `hopper-org/helpers-stable` | `helpers-http-core` | `com.hopper.common.finatra` | HTTP abstractions: `EndPoint`, `Request`, `BadRequest` |
| `hopper-org/helpers-stable` | `helpers-crypto` | `com.hopper.common.crypto` | Cryptographic utilities |
| `hopper-org/helpers-stable` | `helpers-cache` | `com.hopper.common.cache` | Caching utilities (Caffeine) |
| `hopper-org/finagle-grpc` | `finagle-grpc-runtime` | `com.twitter.finagle.grpc` | Finagle gRPC bridge and runtime |
| `hopper-org/mesh-token` | `mesh-token-core` | `com.hopper.mesh` | JWT authentication model for service mesh |
| `hopper-org/hazel-stack` | `hazel-api`, `hazel-tapir`, etc. | `com.hopper.hazel` | Modern Scala stdlib stack for Pekko/gRPC services (31 modules) |

## Domain Models (Helpers)

| Repo | Module (maven artifact) | Package | Description |
|---|---|---|---|
| `hopper-org/Helpers` | `helpers-model` | `com.hopper.common.model` | Central domain models — the largest shared model library. Contains API objects organized by city name: `Houston` (flights alerts), `Mumbai` (mobile app/inbox), `Moscow` (sharing), `Hartford` (passengers), `Swansea` (airlines), `Lexington` (shopping), `Daventry` (flight events), `Darmstadt` (corporate travel). Also `Tenant`, `TripGrouping`, `Routes`, `PassengerType`, `Shop`, `ShopTrigger`. |
| `hopper-org/Helpers` | `helpers-content-model` | `com.hopper.common.content` | Content/localization models, RemoteUI types |
| `hopper-org/Helpers` | `helpers-machine` | `com.hopper.common.machine` | State machine framework |
| `hopper-org/Helpers` | `helpers-machine-generics` | `com.hopper.common.machine` | Generic state machine with singleton support |
| `hopper-org/Helpers` | `helpers-store` | `com.hopper.common.store` | Key-value store abstractions |
| `hopper-org/Helpers` | `helpers-clients` | `com.hopper.common.clients` | HTTP client utilities for inter-service calls |
| `hopper-org/Helpers` | `helpers-tracking` | `com.hopper.common.tracking` | Event tracking models |
| `hopper-org/Helpers` | `helpers-warehouse` | `com.hopper.common.warehouse` | Data warehouse models |
| `hopper-org/Helpers` | `helpers-b2b-interface` | `com.hopper.common.b2b` | B2B partner interface models |
| `hopper-org/Helpers` | `helpers-apigen` | `com.hopper.common.apigen` | OpenAPI code generation utilities |
| `hopper-org/Helpers` | `helpers-ledger` | `com.hopper.common.ledger` | Ledger/accounting models |
| `hopper-org/Helpers` | `helpers-identifiers` | `com.hopper.common` | Identifier generation utilities |
| `hopper-org/Helpers` | `helpers-spanner` | `com.hopper.common.spanner` | Cloud Spanner utilities |
| `hopper-org/Helpers` | `helpers-pubsub` | `com.hopper.common.pubsub` | Pub/Sub messaging utilities |

## gRPC Interfaces

| Repo | Module (maven artifact) | Package | Description |
|---|---|---|---|
| `hopper-org/hopper-interfaces` | `helpers-model-proto`, `helpers-model-client` | `com.hopper.interfaces` | Protobuf definitions aligned with Helpers model classes + converters |
| `hopper-org/hopper-interfaces` | `bff-proto`, `bff-client` | `com.hopper.interfaces` | Backend-for-Frontend gRPC interface and client |
| `hopper-org/hopper-interfaces` | `walsall-proto`, `walsall-client` | `com.hopper.interfaces` | Walsall (event sourcing) gRPC interface and client |
| `hopper-org/hopper-interfaces` | `orange-proto`, `orange-client` | `com.hopper.interfaces` | Orange service gRPC interface and client |
| `hopper-org/hopper-interfaces` | `chicago-proto`, `chicago-client` | `com.hopper.interfaces` | Chicago service gRPC interface and client |
| `hopper-org/hopper-interfaces` | `generic-disruption-products-proto`, `-client` | `com.hopper.interfaces` | Generic disruption products gRPC interface |
| `hopper-org/hopper-interfaces` | `b2b-coordinators-proto`, `-client` | `com.hopper.interfaces` | B2B product coordinators gRPC interface |
| `hopper-org/hopper-proto` | `hopper-proto`, `hopper-proto-transformers` | `com.hopper.proto` | Shared protobuf types and transformers |

## Flights

| Repo | Module (maven artifact) | Package | Description |
|---|---|---|---|
| `hopper-org/flights-common` | `flights-model` | `com.hopper.model` | Select flights models migrated from Helpers |
| `hopper-org/flights-common` | `flights-provider` | `com.hopper.provider` | Provider API for orchestrators (Lexington, Brooklyn) |
| `hopper-org/flights-common` | `flights-air` | `com.hopper.air` | Shared code between Newark and Brooklyn; air messaging |
| `hopper-org/flights-common` | `flights-brooklyn` | `com.hopper.brooklyn` | Brooklyn client types |
| `hopper-org/flights-common` | `flights-bff` | `com.hopper.bff` | Flights backend-for-frontend types |
| `hopper-org/flights-common` | `flights-ancillary-shop` | `com.hopper.ancillaryShop` | Ancillary shopping flow types |
| `hopper-org/flights-common` | `flights-provider-proto` | `com.hopper.provider.proto` | Protobuf/gRPC definitions for provider API |
| `hopper-org/flights-distribution-api` | `flights-distribution-models` | `com.hopper.flights.distribution` | Flights forward distribution OpenAPI models |
| `hopper-org/vi-core` | `vi-domain`, `vi-helpers`, `vi-shopping`, etc. | `com.hopper.vi` | Vertical integration domain models (10 library modules) |
| `hopper-org/flights-meet-or-beat` | library modules | `com.hopper.flights.mob` | Flights meet-or-beat models |

## Lodging / Homes

| Repo | Module (maven artifact) | Package | Description |
|---|---|---|---|
| `hopper-org/lodging-common` | `lodging-model`, `lodging-config`, `lodging-businesslogic`, `lodging-tracking` | `com.hopper.lodging` | Shared lodging domain models, config, and business logic |
| `hopper-org/lodging-distribution-api` | `lodging-distribution-models` | `com.hopper.lodging.distribution` | Lodging distribution OpenAPI models |
| `hopper-org/homes-common` | `homes-common-api`, `homes-common-proto` | `com.hopper.homes` | Homes vertical shared API models and proto definitions |
| `hopper-org/copper` | `copper` | `com.hopper.lodging.pricing` | Lodging pricing/monetary amount library |
| `hopper-org/lodging-meet-or-beat` | library modules | `com.hopper.lodging.mob` | Lodging meet-or-beat models |
| `hopper-org/lodging-price-freeze` | library modules | `com.hopper.lodging.pricefreeze` | Lodging price freeze ancillary product |

## Cars

| Repo | Module (maven artifact) | Package | Description |
|---|---|---|---|
| `hopper-org/cars-common` | `cars-model`, `cars-provider-api`, `cars-provider-common`, `cars-tracking` | `com.hopper.cars` | Shared cars domain models and provider integration |
| `hopper-org/cars-distribution-api` | `cars-distribution-models` | `com.hopper.cars.distribution` | Cars forward distribution OpenAPI models |

## Fintech / Payments

| Repo | Module (maven artifact) | Package | Description |
|---|---|---|---|
| `hopper-org/fintech-models` | various | `com.hopper.fintech` | Fintech pricing models (mono-repo) |
| `hopper-org/fintech-offers` | `fintech-offers-api`, `fintech-offers-variant` | `com.hopper.fintech.offers` | Fintech offers library |
| `hopper-org/fintech-analytics-events` | various | `com.hopper.fintech.analytics` | Fintech analytics event definitions and serialization |
| `hopper-org/fintech-analytics` | library modules | `com.hopper.fintech.analytics` | Fintech analytics pipeline components |
| `hopper-org/commerce-api` | various | `com.hopper.commerce` | Commerce platform APIs (shopping cart, checkout) |
| `hopper-org/payments-common` | `payments-common-model`, `payments-common-proto` | `com.hopper.payments` | Shared payments domain models and proto definitions |
| `hopper-org/payments-provider-platform` | `payments-platform-core` | `com.hopper.payments` | Multi-provider payment platform core models |
| `hopper-org/mvwc-common` | `mvwc-common-core` | `com.hopper.mvwc` | Multi-vertical working capital models |
| `hopper-org/installments-service` | library modules | `com.hopper.installments` | Installments/BNPL models |

## B2B / Partners

| Repo | Module (maven artifact) | Package | Description |
|---|---|---|---|
| `hopper-org/b2b-interfaces` | various | `com.hopper.interfaces` | Standard abstract APIs across B2B tenants (air, chfar, disruption, packages, price-prediction) |
| `hopper-org/b2b-coordinators` | various | `com.hopper.b2b` | B2B product coordinators (core coordination logic) |

## Disruption

| Repo | Module (maven artifact) | Package | Description |
|---|---|---|---|
| `hopper-org/disruption-common` | `disruption-common-core`, `disruption-common-proto` | `com.hopper.disruption` | Shared disruption domain models and proto definitions |
| `hopper-org/disruption-platform` | `disruption-platform-core`, `disruption-platform-proto` | `com.hopper.disruption` | Disruption product platform (booking/fulfillment) |
| `hopper-org/cfar-lodging` | library modules | `com.hopper.cfar.lodging` | Cancel For Any Reason lodging logic |

## Incentives / Loyalty

| Repo | Module (maven artifact) | Package | Description |
|---|---|---|---|
| `hopper-org/Scranton` | `scranton-client`, `scranton-core`, `scranton-proto-api` | `com.hopper.scranton` | Incentives (Carrot Cash) and loyalty platform |

## Infrastructure / Cross-Cutting

| Repo | Module (maven artifact) | Package | Description |
|---|---|---|---|
| `hopper-org/proto-encryption` | `proto-encryption-model`, `proto-encryption-core` | `com.hopper.proto.encryption` | Protobuf encryption and key management |
| `hopper-org/proto-observability` | `proto-observability-core`, `proto-observability-utils` | `com.hopper.proto.observability` | Protobuf observability instrumentation |
| `hopper-org/config-store` | `config-store-client` | `com.hopper.config.store` | Config store gRPC client |
| `hopper-org/feature-flags` | `feature-flags-client` | `com.hopper.featureflags` | Feature flags gRPC client |
| `hopper-org/Walsall` | `walsall-core`, `walsall-proto`, `walsall-avro` | `com.hopper.walsall` | Event sourcing as a service |
| `hopper-org/platform-singleton` | `platform-singleton-client` | `com.hopper.platform.singleton` | Distributed singleton coordination |
| `hopper-org/exchange-rates` | `exchange-rates-core`, `exchange-rates-client` | `com.hopper.exchangerates` | Currency exchange rates service and client |
| `hopper-org/intl-localization-toolbox` | `intl-localization-core`, `intl-localization-rosetta`, etc. | `com.hopper.intl.localization` | I18n/localization library (8 modules) |
| `hopper-org/remoteui` | `remoteui-core`, `remoteui-proto` | `com.hopper.remoteui` | RemoteUI framework for server-driven UI |
| `hopper-org/platform-data-common` | `platform-data-common` | `com.hopper.platform.data` | Platform-level data patterns and utilities |
| `hopper-org/datadog-event-emitter` | `datadog-events-emitter` | `com.hopper.datadog` | Datadog metrics and events emission |
| `hopper-org/Delos` | library modules | `com.hopper.delos` | ML model deployment and serving |
| `hopper-org/algomerch` | library modules | `com.hopper.algomerch` | Algorithmic merchandising model |
| `hopper-org/secure-logs` | library modules | `com.hopper.securelogs` | Secure logging for external service requests |

## How to identify the source repo from build.sbt

In a service's `build.sbt`, dependencies are declared as:

```scala
helper("model")           // → "com.hopper" %% "helpers-model"       (from Helpers repo)
helper("http-server")     // → "com.hopper" %% "helpers-http-server" (from helpers-stable repo)
helperStable("play-json") // → "com.hopper" %% "helpers-play-json"   (from helpers-stable repo)

// Direct dependency
"com.hopper" %% "flights-air" % version    // from flights-common repo
"com.hopper" %% "homes-common-api" % version // from homes-common repo
```

The `helper(...)` function is defined in the project's sbt plugins and maps to `"com.hopper" %% "helpers-{name}"`. Modules from `helpers-stable` are the stable core, while modules from `Helpers` (non-stable) are the extended helpers that may change more frequently.
