---
name: type-discovery
description: >-
  Use when encountering unknown or external Scala types in a Hopper service
  codebase. Triggers: missing type definition, unresolved import, external
  dependency type, case class not found locally, need to expand a type from
  helpers or flights-common, following type aliases.
---

# Type Discovery

Find and fully expand Scala type definitions across Hopper's multi-repo codebase.

## When to Use

- A case class, sealed trait, or type alias is referenced but not defined in the current repo
- You need the full field-level definition of a type from `helpers-model`, `flights-common`, or another shared library
- You need to follow a type alias chain (e.g., `type AlertKey = TripGrouping.AlertGroupingKey`)
- You need enum values from a sealed trait or `AEnum`


## Step 1: Identify the Source Package

Read the import statements in the file that uses the type. Check `build.sbt` for the dependency that provides it (`helper("model")`, `helperStable("play-json")`, or direct `"com.hopper" %% "artifact"` entries).

See `references/shared-model-repos.md` for a comprehensive list of repos, maven artifacts, packages, and descriptions. The most commonly encountered ones:

| Import pattern | Repo | Module |
|---|---|---|
| `com.hopper.common.model.*` | `Helpers` | `helpers-model` |
| `com.hopper.common.lang.*` | `helpers-stable` | `helpers-core` |
| `com.hopper.common.json.*` | `helpers-stable` | `helpers-play-json` |
| `com.hopper.common.finatra.*` | `helpers-stable` | `helpers-http-server` |
| `com.hopper.common.format.*` | `helpers-stable` | `helpers-format` |
| `com.hopper.air.*`, `com.hopper.provider.*` | `flights-common` | `flights-air`, `flights-provider` |
| `com.hopper.lodging.*` | `lodging-common` | `lodging-model`, etc. |
| `com.hopper.cars.*` | `cars-common` | `cars-model`, etc. |
| `com.hopper.homes.*` | `homes-common` | `homes-common-api` |
| `com.hopper.commerce.*` | `commerce-api` | various |
| `com.hopper.payments.*` | `payments-common` | `payments-common-model` |
| `com.hopper.disruption.*` | `disruption-common` | `disruption-common-core` |
| `com.hopper.interfaces.*` | `hopper-interfaces`, `b2b-interfaces` | various |
| `com.hopper.scranton.*` | `Scranton` | `scranton-client` |
| `com.hopper.walsall.*` | `Walsall` | `walsall-core` |

## Step 2: Search Locally First

If the type might be in the current repo:

```
Grep: "case class TypeName|sealed trait TypeName|type TypeName"
```

## Step 3: Search Across Hopper Repos

Use the GitHub MCP `search_code` tool to find the type definition across all hopper-org repos:

```
mcp__github__search_code
  query: "case class AlertGroupingKey org:hopper-org language:Scala"
```

Useful query patterns:

| What you need | Query |
|---|---|
| Case class definition | `"case class TypeName" org:hopper-org language:Scala` |
| Sealed trait | `"sealed trait TypeName" org:hopper-org language:Scala` |
| Type alias | `"type TypeName =" org:hopper-org language:Scala` |
| Enum / AEnum | `"object TypeName extends AEnum" org:hopper-org language:Scala` |
| Companion object | `"object TypeName" org:hopper-org language:Scala` |
| Specific repo | `"case class TypeName" repo:hopper-org/Helpers language:Scala` |

## Step 4: Read the Full Definition

Once you find the file, use the GitHub MCP `get_file_contents` tool to read it:

```
mcp__github__get_file_contents
  owner: "hopper-org"
  repo: "Helpers"
  path: "helpers-model/src/main/scala/com/hopper/common/model/TripGrouping.scala"
```

If you have the repo cloned locally (in `~/hopper/`), prefer reading from disk — it's faster.

## Step 5: Follow the Chain

Types often reference other types. Repeat steps 2–4 for each dependency:

1. **Type aliases** — `type AlertKey = TripGrouping.AlertGroupingKey` → find `AlertGroupingKey`
2. **Case class fields** — each field type may itself need expansion
3. **Sealed trait subtypes** — find all `extends TypeName` in the same file/object
4. **Generic wrappers** — `AlertResponse[MigrationOutcome]` → expand both `AlertResponse` and `MigrationOutcome`

## Common Pitfalls

- **Type aliases hide location** — `type AlertKey = TripGrouping.AlertGroupingKey` means `AlertKey` is defined in `TripGrouping`, not `Houston`
- **Types spread across API files** — `Houston.scala`, `Mumbai.scala`, `Moscow.scala`, `Hartford.scala` in helpers-model each define types for different domains
- **Nested objects** — a companion object may contain inner case classes and sealed traits; read the full enclosing object, not just the line that matched
- **Wildcard imports** — `import Houston._` pulls in all types from the `Houston` object; check the object for every type that seems unresolved
