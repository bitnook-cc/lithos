# hopper-commerce

Skills for Hopper Commerce team — partner performance reporting, finance analytics, booking analysis.

## Skills

| Skill | Purpose |
|---|---|
| `commerce-monthly-report` | Generate monthly commerce performance reports |
| `channel-slack-update` | Generate monthly tenant Slack channel updates with performance metrics |
| `commerce-bug-router` | Extend platform-ai with AI-powered bug routing for Commerce platform |

## Install

```
/plugin marketplace add hopper-org/hopper-ai-common
/plugin install hopper-commerce@hopper-ai-common
```
