---
name: commerce-bug-router
description: >
  Extend platform-ai with Commerce bug routing capability. Use when adding bug reporting to
  platform-ai, implementing a /commerce-bug slash command, building AI-powered Jira routing for commerce
  bugs, or setting up automated duplicate detection for the commerce platform.
allowed-tools: mcp__slack__*, mcp__atlassian__*
---

# Commerce Bug Router

Extend platform-ai with a `/commerce-bug` slash command that intelligently routes Commerce platform bugs to the correct Jira project, detects duplicates, and provides feedback when bugs are resolved.

## Bundled Resources

| Resource | Purpose |
|---|---|
| `references/platform-ai-architecture.md` | How platform-ai works (routes, handlers, agent SDK) |
| `references/slash-command-handler.md` | Adding new Slack slash commands to platform-ai |
| `references/commerce-bug-routing-logic.md` | Claude-based routing + duplicate detection algorithm |
| `references/jira-webhook-setup.md` | Jira webhook configuration for resolution updates |
| `references/team-routing-rules.md` | Commerce team routing matrix (URL patterns → projects) |
| `references/testing-guide.md` | Local dev with platform-ai CLI, integration tests |
| `scripts/example-queries/duplicate-search.jql` | Example JQL for duplicate detection |
| `scripts/example-queries/route-test-cases.json` | Test cases for routing logic validation |
| `assets/platform-ai-pr-template/` | Complete code changes for platform-ai repo |

## Context

The Commerce platform has no consistent way to report bugs. Reports are scattered across DMs, random Slack channels, and ad-hoc Jira tickets across multiple projects (CAC, CCG, COF, STAYS, Corporate). This creates three problems:

1. **Bugs get lost** - DMs to wrong engineers, tickets filed in wrong projects
2. **Bugs get duplicated** - Same issue reported multiple times across channels
3. **No feedback loop** - Reporters never know if bugs were fixed

This skill guides you through extending platform-ai with a `/commerce-bug` slash command that:
- Routes bugs to the correct Jira project using Claude-based classification
- Detects duplicates before creating tickets
- Generates AI summaries for Jira (structured STR format)
- Posts to #commerce-bugs channel
- Updates Slack when bugs are resolved via Jira webhooks

**Critical Constraint**: Per Platform team security policy, all Slack integrations **must** be built into platform-ai (no standalone bots allowed).

## Prerequisites

- Access to platform-ai repository (hopper-org/platform-ai)
- Jira admin access to configure webhooks (or coordinate with Jira admin)
- Familiarity with TypeScript, Express, and Slack API concepts
- Local development environment with Node.js and gcloud CLI

## Workflow

### Step 1: Understand platform-ai Architecture

Before making changes, understand how platform-ai works:

1. **Clone platform-ai** (if not already local):
   ```bash
   gh repo clone hopper-org/platform-ai
   cd platform-ai
   ```

2. **Read architecture documentation**:
   - `docs/architecture.md` - Server structure, routes, agent SDK
   - `src/routes/slack.ts` - Existing Slack event handler
   - `src/agent/plugins.ts` - How hopper-ai-common plugins are loaded
   - `system-prompts/slack.md` - Current agent instructions

3. **Review key concepts** (see `references/platform-ai-architecture.md`):
   - Express server on port 7070 with mode-based routing (slack vs cli)
   - Slack events flow through `POST /slack/events` → verified → routed
   - Agent SDK orchestration via `src/agent.ts` (Vertex AI backend)
   - Session management with Redis
   - Security hooks in `src/security/security-hook.ts`

4. **Check existing slash command patterns**:
   ```bash
   cd platform-ai
   grep -r "command.*/" src/routes/
   ```
   Currently platform-ai handles `app_mention` and DMs, but likely no custom slash commands yet.

### Step 2: Configure Slack Slash Command

Add `/commerce-bug` command to platform-ai's Slack app:

1. **Go to Slack App configuration**: https://api.slack.com/apps (find platform-ai app)

2. **Add slash command**:
   - Navigate to "Slash Commands" → "Create New Command"
   - **Command**: `/commerce-bug`
   - **Request URL**: `https://platform-ai.cicd.h4r.io/slack/events` (same endpoint as other events)
   - **Short Description**: "Report a Commerce platform bug"
   - **Usage Hint**: `[optional quick description]`

3. **Verify OAuth scopes** (should already exist):
   - `commands` - handle slash commands
   - `chat:write` - post messages
   - `files:read` - read uploaded screenshots
   - `channels:read` - read channel info
   - `users:read` - get user info

4. **Test command**:
   - Type `/commerce-bug` in any Slack channel
   - Should trigger platform-ai event handler (currently will fail since handler doesn't exist yet)

### Step 3: Implement Bug Router Handler in platform-ai

Create the slash command handler and modal form:

1. **Create route handler** - `src/routes/commerce-bug-router.ts`:

   Use `assets/platform-ai-pr-template/src/routes/commerce-bug-router.ts` as template. Key responsibilities:

   - Handle `POST /slack/events` when `command === '/commerce-bug'`
   - Open modal form with fields:
     - **Title** (short_text, required, max 150 chars)
     - **Description** (plain_text_input, required, multiline)
     - **URL** (url_text_input, optional, placeholder: "https://app.hopper.com/...")
     - **Severity** (static_select, options: Critical/High/Medium/Low)
     - **Device/Browser** (short_text, optional, placeholder: "iPhone 15, Safari")
     - **Screenshot** (file upload via Slack API)
   - Store modal submission callback in session (Redis)

2. **Handle modal submission**:

   - Extract form values from `view.state.values`
   - Call bug routing service (next step)
   - Show loading message to user
   - Create Jira ticket + post to #commerce-bugs
   - Respond with confirmation (ephemeral message)

3. **Register route in `src/server.ts`**:

   ```typescript
   if (config.mode === 'slack') {
     app.post('/slack/events', slackRouter);
     app.post('/slack/commerce-bug', bugRouter);  // Add this line
   }
   ```

See `references/slash-command-handler.md` for complete implementation details.

### Step 4: Implement Routing & Duplicate Detection

Create the bug classification and Jira integration services:

1. **Create `src/services/commerce-bug-routing.ts`**:

   Use `assets/platform-ai-pr-template/src/services/commerce-bug-routing.ts` as template. Implements:

   - **URL pattern matching**: Extract `/air`, `/stays`, `/checkout`, etc.
   - **Keyword extraction**: Parse description for "flight", "CFAR", "hotel", "wallet", etc.
   - **Claude-based classification**:
     ```typescript
     const prompt = `Given a bug report, determine the correct Jira project:
     URL: ${bugUrl}
     Description: ${description}

     Options: CAC (Air & Cars), CCG (Checkout & Growth), COF (Foundation), STAYS (Stays & Packages)

     Return: {"project": "CAC", "confidence": 0.95, "reasoning": "..."}`;
     ```
   - **Confidence scoring**: >80% = auto-route, <80% = post to #commerce-bugs and tag @commerce-ems
   - **Priority mapping**: Severity + keywords → P0/P1/P2/P3

2. **Create `src/services/jira-bug.ts`**:

   Use `assets/platform-ai-pr-template/src/services/jira-bug.ts` as template. Implements:

   - **Duplicate detection**:
     - Generate search keywords from title + description (use Claude)
     - Execute JQL via Atlassian MCP: `text ~ "keywords" AND project = CAC AND status != Done`
     - Compare similarity of descriptions (simple keyword overlap or embedding-based)
     - If >70% similar, return existing ticket key

   - **AI summary generation**:
     ```typescript
     const summaryPrompt = `Convert this bug report to structured format:

     **Steps to Reproduce:**
     1. ...

     **Expected Behavior:**
     ...

     **Actual Behavior:**
     ...`;
     ```

   - **Jira ticket creation** via Atlassian MCP:
     - Project: from routing logic
     - Issue Type: Bug
     - Summary: bug title (truncated to 255 chars)
     - Description: AI-generated summary
     - Labels: `source:bug-router`, `severity:{level}`
     - Custom field: Store Slack metadata (channel_id, message_ts, reporter_email) as issue property

3. **Post to #commerce-bugs**:

   Use Slack MCP to post structured message:
   ```
   🐛 New Bug: [JIRA-123] Payment fails on checkout

   Reporter: @username
   Team: Checkout & Growth (CCG)
   Priority: P1 (High)
   Severity: Critical

   [View in Jira](https://hopper-jira.atlassian.net/browse/JIRA-123)
   ```

See `references/commerce-bug-routing-logic.md` and `references/team-routing-rules.md` for detailed routing matrix.

### Step 5: Configure Jira Webhooks

Set up webhooks to update Slack when bugs are resolved:

1. **Add webhook endpoint to platform-ai** - `src/routes/commerce-bug-webhook.ts`:

   - Handle `POST /jira/commerce-bug-resolved`
   - Verify webhook signature (HMAC-SHA256)
   - Parse payload: extract issue key, status, transition
   - Filter: only handle transitions to "Done" or "Resolved"
   - Retrieve Slack metadata from Jira issue properties
   - Update original Slack message with resolution status:
     ```
     ✅ Resolved by @engineer_name on 2026-03-31
     ```

2. **Configure Jira webhook** (coordinate with Jira admin):

   - URL: `https://platform-ai.cicd.h4r.io/jira/commerce-bug-resolved`
   - Events: `jira:issue_updated`
   - JQL filter: `project in (CAC, CCG, COF, STAYS) AND labels = source:bug-router`
   - Secret: Generate shared secret, store in GCP Secret Manager

3. **Register route in `src/server.ts`**:

   ```typescript
   app.post('/jira/commerce-bug-resolved', bugWebhookRouter);
   ```

See `references/jira-webhook-setup.md` for complete webhook configuration.

### Step 6: Test and Deploy

Test locally, create PR, and deploy:

1. **Standalone test server** (recommended first step):

   Before modifying platform-ai, validate the UX and routing logic with the standalone test server:

   ```bash
   cd test-server/
   npm install
   cp .env.example .env
   # Edit .env with Slack bot token and signing secret
   npm start
   ```

   In a separate terminal, expose with ngrok:
   ```bash
   ngrok http 3000
   ```

   Update Slack app `/commerce-bug` command URL to point to ngrok URL. This lets you:
   - ✅ Test Slack modal UI/UX
   - ✅ Validate routing logic (heuristic only)
   - ✅ Test priority calculation
   - ✅ Verify end-to-end flow without platform-ai changes

   See `test-server/README.md` for complete setup and test cases.

2. **Local testing with platform-ai CLI**:

   ```bash
   cd platform-ai
   bin/platform-ai  # Starts REPL
   ```

   Simulate slash command payload:
   ```typescript
   // In REPL or test file
   const payload = {
     command: '/commerce-bug',
     text: '',
     user_id: 'U123',
     channel_id: 'C123',
     response_url: 'https://...'
   };
   ```

   See `references/testing-guide.md` for ngrok tunnel setup and integration testing.

3. **Unit tests**:

   Create `tests/commerce-bug-routing.test.ts` (see `assets/platform-ai-pr-template/tests/`):

   ```typescript
   describe('Bug Router', () => {
     it('routes /air bugs to CAC', () => {
       const result = routeBug({ url: 'https://app.hopper.com/air/search', description: 'Flight search broken' });
       expect(result.project).toBe('CAC');
       expect(result.confidence).toBeGreaterThan(0.8);
     });

     it('detects duplicates', async () => {
       // Mock Jira MCP response
       const duplicate = await detectDuplicate('Payment fails on checkout');
       expect(duplicate).toBe('CCG-123');
     });
   });
   ```

4. **Create PR to platform-ai**:

   ```bash
   cd platform-ai
   git checkout -b feature/commerce-bug-router
   git add src/routes/commerce-bug-router.ts src/services/commerce-bug-routing.ts src/services/jira-bug.ts tests/
   git commit -m "feat: add /commerce-bug slash command for Commerce platform

   Implements bug router with AI-powered Jira routing, duplicate detection, and resolution updates.

   - Slash command handler with modal form
   - Claude-based routing to CAC/CCG/COF/STAYS projects
   - Duplicate detection via JQL + similarity scoring
   - Jira webhook for resolution updates
   - Posts to #commerce-bugs channel

   Co-Authored-By: <your-email>@hopper.com
   Slack-Thread: https://hopchat.slack.com/archives/CFZKFUR99/p1774899262259249"

   gh pr create --title "feat: add /commerce-bug slash command for Commerce platform" \
     --body "See Confluence RFC: https://hopper-jira.atlassian.net/wiki/spaces/COF/pages/8498020425"
   ```

4. **Deployment**:

   - Platform team reviews PR
   - After merge, automatic deployment via Harness (existing platform-ai pipeline)
   - Monitor rollout in Datadog
   - Verify `/commerce-bug` command works in Slack

5. **Update Confluence doc** with final routing rules for future maintenance.

## Testing

Use `scripts/example-queries/route-test-cases.json` to validate routing logic:

- Test all URL patterns (/air, /stays, /checkout, /cars)
- Test keyword-based routing (no URL provided)
- Test edge cases (unknown URLs, multi-team issues)
- Test duplicate detection (create duplicate bug reports)
- Test Jira webhook (manually transition ticket to Done)

## Success Criteria

After following this skill, you will have:

- ✅ Understanding of platform-ai architecture and extension points
- ✅ Working `/commerce-bug` slash command in Slack
- ✅ Claude-based bug routing to correct Jira projects (CAC, CCG, COF, STAYS)
- ✅ Duplicate detection reducing redundant tickets
- ✅ AI-generated Jira summaries in structured format
- ✅ #commerce-bugs channel receiving all bug notifications
- ✅ Jira webhook updating Slack when bugs are resolved
- ✅ PR merged to platform-ai and deployed to production

## Troubleshooting

Common issues:

1. **Slash command not triggering**: Check Slack app configuration, verify request URL
2. **Modal not opening**: Check Slack API scopes, verify trigger_id hasn't expired
3. **Routing confidence low**: Review routing rules, add more keywords to classification prompt
4. **Duplicate detection fails**: Check JQL syntax, verify Atlassian MCP server connectivity
5. **Jira webhook not firing**: Verify webhook URL, check JQL filter, review Jira admin settings
6. **Slack message update fails**: Verify issue property contains correct channel_id and message_ts

See `references/testing-guide.md` for debugging with Datadog logs and traces.

## Team Ownership

- **Maintenance**: commerce-dev team
- **Questions**: #commerce-bugs channel or @commerce-ems
- **Platform-ai support**: Platform team (#platform-ai-support)
