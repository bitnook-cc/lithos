# Testing Guide

This guide shows how to test the commerce bug router locally and in CI/CD.

## Local Development with platform-ai CLI

### Setup

1. **Clone platform-ai**:
   ```bash
   gh repo clone hopper-org/platform-ai
   cd platform-ai
   ```

2. **Install dependencies**:
   ```bash
   npm install
   ```

3. **Configure environment** (`.env.local`):
   ```bash
   PLATFORM_AI_MODE=slack
   PORT=7070
   ANTHROPIC_VERTEX_PROJECT_ID=gcp-hopper-cicd
   CLOUD_ML_REGION=us-east5
   SLACK_SIGNING_SECRET=your-secret
   SLACK_BOT_TOKEN=xoxb-your-token
   REDIS_HOST=localhost
   REDIS_PORT=6379
   ATLASSIAN_API_TOKEN=your-token
   JIRA_WEBHOOK_SECRET=test-secret
   ```

4. **Start local Redis** (required for session management):
   ```bash
   docker run -d -p 6379:6379 redis:7-alpine
   ```

5. **Start platform-ai**:
   ```bash
   npm run dev
   # Server listening on http://localhost:7070
   ```

### Testing Slash Commands with ngrok

ngrok creates a public URL that tunnels to your local platform-ai instance:

1. **Install ngrok**:
   ```bash
   brew install ngrok
   ```

2. **Start ngrok tunnel**:
   ```bash
   ngrok http 7070
   ```

   Output:
   ```
   Forwarding  https://abc123.ngrok.io -> http://localhost:7070
   ```

3. **Update Slack app**:
   - Go to https://api.slack.com/apps/[APP_ID]/slash-commands
   - Edit `/commerce-bug` command
   - Change **Request URL** to: `https://abc123.ngrok.io/slack/commerce-bug`
   - Save

4. **Test in Slack**:
   ```
   /commerce-bug Payment fails during checkout
   ```

5. **Watch logs**:
   ```bash
   # In platform-ai directory
   npm run dev
   # Should see:
   # POST /slack/commerce-bug 200 OK
   # Modal opened for user U123456
   ```

6. **Clean up**:
   - Stop ngrok (Ctrl+C)
   - Revert Slack app URL to production: `https://platform-ai.cicd.h4r.io/slack/commerce-bug`

### Using platform-ai CLI (REPL)

For testing without Slack integration:

1. **Start CLI mode**:
   ```bash
   cd platform-ai
   bin/platform-ai
   ```

2. **Test routing logic**:
   ```typescript
   // In REPL
   const bug = {
     title: "Flight search broken",
     description: "Searching for YYZ to LAX returns no results",
     url: "https://app.hopper.com/air/search?from=YYZ&to=LAX",
     severity: "high"
   };

   const routing = await routeBug(bug);
   console.log(routing);
   // { project: 'CAC', team: 'Air & Cars', confidence: 0.95, reasoning: 'URL contains /air' }
   ```

3. **Test duplicate detection**:
   ```typescript
   const duplicate = await detectDuplicate(bug, 'CAC');
   console.log(duplicate);
   // null (no duplicate) or 'CAC-123' (duplicate found)
   ```

## Unit Testing

### Test Structure

```
platform-ai/
└── tests/
    ├── bug-routing.test.ts      # Routing logic tests
    ├── duplicate-detection.test.ts  # Duplicate detection tests
    ├── jira-webhook.test.ts     # Webhook handler tests
    └── slack-modal.test.ts      # Modal form tests
```

### Example: Routing Tests

Create `tests/commerce-bug-routing.test.ts`:

```typescript
import { routeBug } from '../src/services/commerce-bug-routing';

describe('Bug Routing', () => {
  describe('URL-based routing', () => {
    it('routes /air bugs to CAC', async () => {
      const bug = {
        title: 'Flight search broken',
        description: 'Search returns empty',
        url: 'https://app.hopper.com/air/search',
        severity: 'high' as const
      };

      const result = await routeBug(bug);

      expect(result.project).toBe('CAC');
      expect(result.team).toBe('Air & Cars');
      expect(result.confidence).toBeGreaterThanOrEqual(0.95);
    });

    it('routes /stays bugs to STAYS', async () => {
      const bug = {
        title: 'Hotel search broken',
        description: 'No results for NYC',
        url: 'https://app.hopper.com/stays/search?city=NYC',
        severity: 'medium' as const
      };

      const result = await routeBug(bug);

      expect(result.project).toBe('STAYS');
      expect(result.team).toBe('Stays & Packages');
      expect(result.confidence).toBeGreaterThanOrEqual(0.95);
    });

    it('routes /checkout bugs to CCG', async () => {
      const bug = {
        title: 'Payment fails',
        description: 'Credit card declined',
        url: 'https://app.hopper.com/checkout',
        severity: 'critical' as const
      };

      const result = await routeBug(bug);

      expect(result.project).toBe('CCG');
      expect(result.team).toBe('Checkout & Growth');
      expect(result.confidence).toBeGreaterThanOrEqual(0.95);
    });
  });

  describe('Keyword-based routing', () => {
    it('routes flight keywords to CAC', async () => {
      const bug = {
        title: 'CFAR claim not processing',
        description: 'Flight protection claim stuck for booking ABC123',
        severity: 'high' as const
      };

      const result = await routeBug(bug);

      expect(result.project).toBe('CAC');
      expect(result.confidence).toBeGreaterThanOrEqual(0.80);
    });

    it('routes payment keywords to CCG', async () => {
      const bug = {
        title: 'Hopper Cash not applied',
        description: 'Wallet balance shows $50 but not deducted at checkout',
        severity: 'medium' as const
      };

      const result = await routeBug(bug);

      expect(result.project).toBe('CCG');
      expect(result.confidence).toBeGreaterThanOrEqual(0.80);
    });
  });

  describe('Default routing', () => {
    it('defaults to COF for unclear bugs', async () => {
      const bug = {
        title: 'Page not loading',
        description: 'Generic error message shown',
        severity: 'low' as const
      };

      const result = await routeBug(bug);

      expect(result.project).toBe('COF');
      expect(result.confidence).toBeLessThan(0.80);
    });
  });
});
```

### Example: Duplicate Detection Tests

Create `tests/duplicate-detection.test.ts`:

```typescript
import { detectDuplicate } from '../src/services/jira-bug';
import { searchJiraIssues } from '../src/clients/jira';

jest.mock('../src/clients/jira');

describe('Duplicate Detection', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('finds duplicate with high similarity', async () => {
    const bug = {
      title: 'Flight search broken',
      description: 'Searching for flights from YYZ to LAX returns no results',
      url: 'https://app.hopper.com/air/search',
      severity: 'high' as const
    };

    // Mock Jira search result
    (searchJiraIssues as jest.Mock).mockResolvedValue([
      {
        key: 'CAC-123',
        fields: {
          summary: 'Flight search broken',
          description: 'YYZ to LAX search showing empty results'
        }
      }
    ]);

    const duplicate = await detectDuplicate(bug, 'CAC');

    expect(duplicate).toBe('CAC-123');
  });

  it('returns null when no duplicates found', async () => {
    const bug = {
      title: 'New unique bug',
      description: 'This bug has never been reported before',
      severity: 'medium' as const
    };

    (searchJiraIssues as jest.Mock).mockResolvedValue([]);

    const duplicate = await detectDuplicate(bug, 'CAC');

    expect(duplicate).toBeNull();
  });

  it('ignores low similarity matches', async () => {
    const bug = {
      title: 'Payment fails',
      description: 'Credit card payment not working',
      severity: 'high' as const
    };

    (searchJiraIssues as jest.Mock).mockResolvedValue([
      {
        key: 'CCG-456',
        fields: {
          summary: 'Login fails',
          description: 'Cannot log in with password' // Low similarity
        }
      }
    ]);

    const duplicate = await detectDuplicate(bug, 'CCG');

    expect(duplicate).toBeNull();
  });
});
```

### Running Tests

```bash
cd platform-ai
npm test                          # Run all tests
npm test -- bug-routing.test.ts  # Run specific test file
npm test -- --watch               # Watch mode
npm test -- --coverage            # Generate coverage report
```

## Integration Testing

Test complete flow: Slack command → Jira ticket → Webhook update:

### Setup Test Environment

1. **Create test Slack workspace** (optional):
   - Use separate workspace for testing
   - Install platform-ai app in test workspace

2. **Create test Jira project**:
   - Use existing test project or create `TEST` project
   - Configure webhook to point to ngrok URL

3. **Mock external dependencies**:
   ```typescript
   // tests/setup.ts
   import nock from 'nock';

   beforeAll(() => {
     // Mock Slack API
     nock('https://slack.com')
       .persist()
       .post('/api/views.open')
       .reply(200, { ok: true });

     // Mock Jira API
     nock('https://hopper-jira.atlassian.net')
       .persist()
       .post('/rest/api/3/issue')
       .reply(201, { key: 'TEST-123', id: '12345' });
   });
   ```

### Test Scenarios

Create `tests/integration/commerce-bug-router.test.ts`:

```typescript
describe('Bug Router Integration', () => {
  it('creates Jira ticket from Slack slash command', async () => {
    // 1. Simulate /commerce-bug command
    const slackPayload = {
      command: '/commerce-bug',
      text: 'Payment fails',
      user_id: 'U123',
      channel_id: 'C456',
      trigger_id: 'test-trigger'
    };

    const response = await request(app)
      .post('/slack/commerce-bug')
      .send(slackPayload)
      .expect(200);

    // 2. Verify modal opened
    expect(mockSlack.views.open).toHaveBeenCalled();

    // 3. Submit modal form
    const modalSubmission = {
      type: 'view_submission',
      view: {
        callback_id: 'bug_report_modal',
        state: {
          values: {
            title_block: { title: { value: 'Payment fails at checkout' } },
            description_block: { description: { value: 'CC declined with error 1234' } },
            url_block: { url: { value: 'https://app.hopper.com/checkout' } },
            severity_block: { severity: { selected_option: { value: 'high' } } }
          }
        }
      },
      user: { id: 'U123', name: 'jdoe' }
    };

    await request(app)
      .post('/slack/interactions')
      .send({ payload: JSON.stringify(modalSubmission) })
      .expect(200);

    // 4. Verify Jira ticket created
    expect(mockCreateJiraIssue).toHaveBeenCalledWith({
      fields: expect.objectContaining({
        project: { key: 'CCG' },
        summary: 'Payment fails at checkout'
      })
    });

    // 5. Verify Slack notification posted
    expect(mockSlack.chat.postMessage).toHaveBeenCalledWith({
      channel: expect.any(String),
      text: expect.stringContaining('[CCG-'),
      blocks: expect.any(Array)
    });
  });

  it('updates Slack message when Jira issue resolved', async () => {
    // 1. Simulate Jira webhook
    const webhookPayload = {
      webhookEvent: 'jira:issue_updated',
      issue: {
        key: 'CCG-123',
        fields: {
          summary: 'Payment fails',
          status: { name: 'Done' },
          assignee: { displayName: 'Jane Doe' }
        }
      },
      changelog: {
        items: [{ field: 'status', toString: 'Done' }]
      }
    };

    // Mock Jira issue property retrieval
    mockGetIssueProperty.mockResolvedValue({
      value: {
        channelId: 'C789',
        messageTs: '1234567890.123',
        reporterUserId: 'U123'
      }
    });

    await request(app)
      .post('/jira/commerce-bug-resolved')
      .send(webhookPayload)
      .set('x-hub-signature-256', generateSignature(webhookPayload))
      .expect(200);

    // 2. Verify Slack message updated
    expect(mockSlack.chat.update).toHaveBeenCalledWith({
      channel: 'C789',
      ts: '1234567890.123',
      text: expect.stringContaining('✅ Bug Resolved'),
      blocks: expect.arrayContaining([
        expect.objectContaining({
          text: expect.objectContaining({
            text: expect.stringContaining('Jane Doe')
          })
        })
      ])
    });
  });
});
```

## Test Data

Use `scripts/example-queries/route-test-cases.json`:

```json
[
  {
    "input": {
      "title": "Flight search broken",
      "description": "YYZ to LAX returns no results",
      "url": "https://app.hopper.com/air/search?from=YYZ&to=LAX",
      "severity": "high"
    },
    "expected": {
      "project": "CAC",
      "team": "Air & Cars",
      "confidence": 0.95
    }
  },
  {
    "input": {
      "title": "Hotel images not loading",
      "description": "Property photos show broken image icon",
      "url": "https://app.hopper.com/stays/hotel/12345",
      "severity": "medium"
    },
    "expected": {
      "project": "STAYS",
      "team": "Stays & Packages",
      "confidence": 0.95
    }
  },
  {
    "input": {
      "title": "Payment declined",
      "description": "Credit card fails with error code 1234",
      "url": "https://app.hopper.com/checkout",
      "severity": "critical"
    },
    "expected": {
      "project": "CCG",
      "team": "Checkout & Growth",
      "confidence": 0.95
    }
  },
  {
    "input": {
      "title": "CFAR claim stuck",
      "description": "Flight protection claim not processing",
      "severity": "high"
    },
    "expected": {
      "project": "CAC",
      "confidence": 0.85
    }
  },
  {
    "input": {
      "title": "Login page blank",
      "description": "Auth page shows white screen",
      "url": "https://app.hopper.com/auth/login",
      "severity": "high"
    },
    "expected": {
      "project": "COF",
      "team": "Foundation",
      "confidence": 0.95
    }
  },
  {
    "input": {
      "title": "Generic error",
      "description": "Something went wrong",
      "severity": "low"
    },
    "expected": {
      "project": "COF",
      "confidence": 0.60
    }
  }
]
```

Load test cases in tests:

```typescript
import testCases from '../scripts/example-queries/route-test-cases.json';

describe('Routing Test Cases', () => {
  testCases.forEach((testCase) => {
    it(`routes "${testCase.input.title}" correctly`, async () => {
      const result = await routeBug(testCase.input);

      expect(result.project).toBe(testCase.expected.project);
      if (testCase.expected.team) {
        expect(result.team).toBe(testCase.expected.team);
      }
      expect(result.confidence).toBeGreaterThanOrEqual(testCase.expected.confidence);
    });
  });
});
```

## CI/CD Testing

Add test job to `.github/workflows/test.yml`:

```yaml
name: Test

on: [push, pull_request]

jobs:
  test:
    runs-on: gh-runner-medium
    if: github.repository_owner == 'hopper-org'

    steps:
      - uses: actions/checkout@v4

      - uses: actions/setup-node@v4
        with:
          node-version: '20'

      - name: Install dependencies
        run: npm ci

      - name: Run linter
        run: npm run lint

      - name: Run tests
        run: npm test -- --coverage

      - name: Upload coverage
        uses: codecov/codecov-action@v4
        with:
          files: ./coverage/lcov.info
```

## Debugging

### Common Issues

| Issue | Cause | Solution |
|-------|-------|----------|
| Modal doesn't open | trigger_id expired (>3s) | Respond faster, check network latency |
| Routing confidence low | Missing keywords | Add more keywords to routing logic |
| Duplicate not detected | JQL too restrictive | Broaden search query |
| Webhook not received | Signature mismatch | Verify JIRA_WEBHOOK_SECRET |
| Slack update fails | Message deleted | Add error handling, log and skip |

### Datadog Logs

Search Datadog for errors:

```
service:platform-ai env:development status:error
```

Filter by specific routes:

```
service:platform-ai @http.url_details.path:/slack/commerce-bug
service:platform-ai @http.url_details.path:/jira/commerce-bug-resolved
```

### Datadog Traces

View full request traces in APM:

1. Go to Datadog APM
2. Filter: `service:platform-ai` `operation:/slack/commerce-bug`
3. Click trace to see full execution timeline
4. Check spans for:
   - Slack API calls
   - Jira MCP tool calls
   - Claude agent.query() calls

## Performance Testing

Test routing performance under load:

```bash
npm install -g artillery

# Create artillery config
cat > artillery-config.yml <<EOF
config:
  target: http://localhost:7070
  phases:
    - duration: 60
      arrivalRate: 10  # 10 requests/second
scenarios:
  - name: Bug routing
    flow:
      - post:
          url: /slack/commerce-bug
          json:
            command: /commerce-bug
            text: Payment fails
            user_id: U123
            trigger_id: test-trigger
EOF

# Run load test
artillery run artillery-config.yml
```

Expected results:
- p95 latency: <500ms
- Error rate: <1%
- Throughput: 10 req/s

## Resources

- **Jest Docs**: https://jestjs.io/
- **Supertest**: https://github.com/ladjs/supertest (HTTP testing)
- **nock**: https://github.com/nock/nock (HTTP mocking)
- **Artillery**: https://www.artillery.io/ (Load testing)
