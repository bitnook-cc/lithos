# Jira Webhook Setup

This guide shows how to configure Jira webhooks to notify platform-ai when bugs are resolved, enabling automatic Slack message updates.

## Overview

Workflow:
```
Bug filed → Jira ticket created → Engineer fixes → Changes status to "Done" → Jira webhook fires → platform-ai → Update Slack message
```

## Step 1: Add Webhook Endpoint to platform-ai

Create `src/routes/jira-webhook.ts`:

```typescript
import { Router, Request, Response } from 'express';
import crypto from 'node:crypto';
import { WebClient } from '@slack/web-api';

const router = Router();
const slack = new WebClient(process.env.SLACK_BOT_TOKEN);

// Verify Jira webhook signature
function verifyJiraWebhook(req: Request): boolean {
  const signature = req.headers['x-hub-signature-256'] as string;
  if (!signature) return false;

  const payload = JSON.stringify(req.body);
  const expectedSignature = 'sha256=' + crypto
    .createHmac('sha256', process.env.JIRA_WEBHOOK_SECRET!)
    .update(payload)
    .digest('hex');

  return crypto.timingSafeEqual(
    Buffer.from(signature),
    Buffer.from(expectedSignature)
  );
}

router.post('/jira/commerce-bug-resolved', async (req: Request, res: Response) => {
  // 1. Verify webhook signature
  if (!verifyJiraWebhook(req)) {
    console.warn('Invalid Jira webhook signature');
    return res.status(401).send('Unauthorized');
  }

  // 2. Acknowledge immediately (Jira timeout is 10 seconds)
  res.status(200).send('OK');

  // 3. Process webhook asynchronously
  try {
    await handleBugResolution(req.body);
  } catch (error) {
    console.error('Failed to handle Jira webhook:', error);
  }
});

async function handleBugResolution(payload: any) {
  const { issue, changelog, webhookEvent } = payload;

  // Filter: Only handle status transitions to Done or Resolved
  if (webhookEvent !== 'jira:issue_updated') {
    return;
  }

  const statusChange = changelog?.items?.find(
    (item: any) => item.field === 'status' &&
    ['Done', 'Resolved'].includes(item.toString)
  );

  if (!statusChange) {
    return; // Not a resolution event
  }

  // Get Slack metadata from Jira issue properties
  const slackMetadata = await getSlackMetadata(issue.key);

  if (!slackMetadata) {
    console.warn(`No Slack metadata found for ${issue.key}`);
    return;
  }

  // Update original Slack message
  await updateSlackMessage(slackMetadata, issue, statusChange);
}

export default router;
```

## Step 2: Store Slack Metadata in Jira

When creating the Jira ticket, store Slack channel + message timestamp as issue property:

```typescript
import { createJiraIssue, setIssueProperty } from '../clients/jira'; // Atlassian MCP

async function createJiraTicket(bug: BugReport, routing: RoutingResult): Promise<JiraIssue> {
  // 1. Create issue
  const issue = await createJiraIssue({
    fields: {
      project: { key: routing.project },
      issuetype: { name: 'Bug' },
      summary: bug.title,
      description: await generateJiraSummary(bug),
      priority: { name: calculatePriority(bug, routing) },
      labels: ['source:bug-router', `severity:${bug.severity}`]
    }
  });

  // 2. Post to #commerce-bugs
  const slackMessage = await slack.chat.postMessage({
    channel: 'C_COMMERCE_BUGS',
    text: `🐛 New Bug: [${issue.key}] ${bug.title}`,
    blocks: buildBugNotification(bug, issue, routing)
  });

  // 3. Store Slack metadata in Jira issue property
  await setIssueProperty(issue.key, 'slack-metadata', {
    channelId: slackMessage.channel,
    messageTs: slackMessage.ts,
    reporterUserId: bug.reporterId,
    reportedAt: new Date().toISOString()
  });

  return issue;
}
```

## Step 3: Retrieve Slack Metadata

```typescript
import { getIssueProperty } from '../clients/jira'; // Atlassian MCP

interface SlackMetadata {
  channelId: string;
  messageTs: string;
  reporterUserId: string;
  reportedAt: string;
}

async function getSlackMetadata(issueKey: string): Promise<SlackMetadata | null> {
  try {
    const property = await getIssueProperty(issueKey, 'slack-metadata');
    return property.value as SlackMetadata;
  } catch (error) {
    if (error.status === 404) {
      return null; // Property not found (issue not created via bug router)
    }
    throw error;
  }
}
```

## Step 4: Update Slack Message

```typescript
async function updateSlackMessage(
  metadata: SlackMetadata,
  issue: any,
  statusChange: any
) {
  const resolver = issue.fields.assignee?.displayName || 'Unknown';
  const resolvedAt = new Date().toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric'
  });

  try {
    // Update the original message
    await slack.chat.update({
      channel: metadata.channelId,
      ts: metadata.messageTs,
      text: `✅ Bug Resolved: [${issue.key}] ${issue.fields.summary}`,
      blocks: [
        {
          type: 'section',
          text: {
            type: 'mrkdwn',
            text: `✅ *Bug Resolved:* <https://hopper-jira.atlassian.net/browse/${issue.key}|${issue.key}> ${issue.fields.summary}\n\n*Resolved by:* ${resolver}\n*Date:* ${resolvedAt}\n*Status:* ${statusChange.toString}`
          }
        }
      ]
    });

    // Also notify the original reporter (optional)
    await slack.chat.postEphemeral({
      channel: metadata.channelId,
      user: metadata.reporterUserId,
      text: `✅ Your bug ${issue.key} has been resolved by ${resolver}!`
    });
  } catch (error) {
    // Message may have been deleted or channel archived
    console.error(`Failed to update Slack message for ${issue.key}:`, error);
  }
}
```

## Step 5: Configure Jira Webhook

This requires Jira admin access. Coordinate with Jira admin or do yourself if you have permissions:

### 5.1 Create Webhook

1. **Navigate to Jira Admin**:
   - https://hopper-jira.atlassian.net/secure/admin/WebHooks.jspa

2. **Create webhook**:
   - **Name**: `platform-ai Bug Resolution Notifier`
   - **URL**: `https://platform-ai.cicd.h4r.io/jira/commerce-bug-resolved`
   - **Secret**: Generate random secret (save to GCP Secret Manager)
   - **Description**: Notifies platform-ai when bugs filed via /commerce-bug are resolved

3. **Configure events**:
   - Select "Issue updated" (jira:issue_updated)

4. **Add JQL filter** (only fire for bug router issues):
   ```sql
   project IN (CAC, CCG, COF, STAYS) AND labels = "source:bug-router"
   ```

5. **Save and test**:
   - Click "Test" → Should see 200 OK response from platform-ai

### 5.2 Store Webhook Secret

```bash
# Add to GCP Secret Manager
echo -n "your-random-secret" | gcloud secrets create jira-webhook-secret \
  --data-file=- \
  --project=gcp-hopper-cicd

# Grant platform-ai service account access
gcloud secrets add-iam-policy-binding jira-webhook-secret \
  --member=serviceAccount:platform-ai@gcp-hopper-cicd.iam.gserviceaccount.com \
  --role=roles/secretmanager.secretAccessor \
  --project=gcp-hopper-cicd
```

### 5.3 Update platform-ai Config

Add environment variable to deployment config:

```bash
# deployment/workloads/unit/BUILD
env = {
  "JIRA_WEBHOOK_SECRET": "gcp-secret://jira-webhook-secret",
  # ... existing env vars
}
```

## Step 6: Register Webhook Route

In `src/server.ts`:

```typescript
import jiraWebhookRouter from './routes/jira-webhook';

// Register for all modes (webhook can come anytime)
app.use('/jira', jiraWebhookRouter);
```

## Webhook Payload Structure

Example payload when issue transitions to Done:

```json
{
  "timestamp": 1711234567890,
  "webhookEvent": "jira:issue_updated",
  "issue_event_type_name": "issue_generic",
  "issue": {
    "id": "12345",
    "key": "CAC-789",
    "fields": {
      "summary": "Flight search broken",
      "status": {
        "name": "Done",
        "id": "10001"
      },
      "assignee": {
        "displayName": "Jane Doe",
        "emailAddress": "jdoe@hopper.com"
      },
      "priority": {
        "name": "P1"
      }
    }
  },
  "changelog": {
    "items": [
      {
        "field": "status",
        "fieldtype": "jira",
        "from": "3",
        "fromString": "In Progress",
        "to": "10001",
        "toString": "Done"
      }
    ]
  }
}
```

## Error Handling

### 1. Webhook Retries

Jira retries failed webhooks (5xx errors) up to 10 times with exponential backoff:

```typescript
// Always respond 200 immediately, process async
router.post('/jira/commerce-bug-resolved', async (req, res) => {
  res.status(200).send('OK'); // Acknowledge first

  try {
    await handleBugResolution(req.body);
  } catch (error) {
    // Log error but don't re-throw (already responded 200)
    console.error('Webhook processing failed:', error);
    // Could send to error tracking (Datadog, Sentry)
  }
});
```

### 2. Slack API Failures

If Slack message update fails (message deleted, channel archived):

```typescript
try {
  await slack.chat.update({ ... });
} catch (error) {
  if (error.data?.error === 'message_not_found') {
    console.warn(`Slack message not found for ${issue.key}, skipping update`);
  } else if (error.data?.error === 'channel_not_found') {
    console.warn(`Channel archived for ${issue.key}, skipping update`);
  } else {
    throw error; // Re-throw unexpected errors
  }
}
```

### 3. Missing Issue Property

If Jira issue doesn't have Slack metadata (created outside bug router):

```typescript
const slackMetadata = await getSlackMetadata(issue.key);

if (!slackMetadata) {
  // Not a bug router issue, ignore webhook
  return;
}
```

## Testing

### Local Testing with ngrok

1. **Start ngrok tunnel**:
   ```bash
   ngrok http 7070
   ```

2. **Update Jira webhook URL temporarily**:
   - Change URL to `https://[ngrok-id].ngrok.io/jira/commerce-bug-resolved`

3. **Manually transition test issue**:
   - Create test issue in Jira: `CAC-TEST-123`
   - Add `source:bug-router` label
   - Manually add issue property with Slack metadata
   - Transition to "Done"

4. **Check platform-ai logs**:
   ```bash
   # Should see webhook received and Slack updated
   POST /jira/commerce-bug-resolved 200 OK
   Updated Slack message for CAC-TEST-123
   ```

### Unit Testing

Mock Jira webhook payload:

```typescript
describe('Jira Webhook Handler', () => {
  it('updates Slack when bug is resolved', async () => {
    const webhookPayload = {
      webhookEvent: 'jira:issue_updated',
      issue: {
        key: 'CAC-789',
        fields: {
          summary: 'Test bug',
          status: { name: 'Done' },
          assignee: { displayName: 'Jane Doe' }
        }
      },
      changelog: {
        items: [
          { field: 'status', toString: 'Done' }
        ]
      }
    };

    // Mock Slack metadata retrieval
    mockGetIssueProperty.mockResolvedValue({
      value: {
        channelId: 'C123',
        messageTs: '1234567890.123456',
        reporterUserId: 'U456'
      }
    });

    await handleBugResolution(webhookPayload);

    expect(mockSlack.chat.update).toHaveBeenCalledWith({
      channel: 'C123',
      ts: '1234567890.123456',
      text: expect.stringContaining('✅ Bug Resolved')
    });
  });
});
```

## Monitoring

Add Datadog metrics for webhook health:

```typescript
import { incrementMetric } from '../datadog/metrics';

router.post('/jira/commerce-bug-resolved', async (req, res) => {
  incrementMetric('jira.webhook.received', 1);

  if (!verifyJiraWebhook(req)) {
    incrementMetric('jira.webhook.unauthorized', 1);
    return res.status(401).send('Unauthorized');
  }

  res.status(200).send('OK');

  try {
    await handleBugResolution(req.body);
    incrementMetric('jira.webhook.processed', 1);
  } catch (error) {
    incrementMetric('jira.webhook.failed', 1);
    console.error('Webhook processing failed:', error);
  }
});
```

## Security Considerations

1. **Always verify webhook signature** - Prevents unauthorized webhook calls
2. **Use HTTPS only** - Webhook URL must be https://
3. **Store secret in Secret Manager** - Never hardcode in code
4. **Limit webhook scope with JQL** - Only fire for relevant issues
5. **Validate payload structure** - Check for required fields before processing
6. **Rate limit** - Prevent DoS via webhook spam (use Express rate-limit middleware)

## Troubleshooting

| Issue | Cause | Solution |
|-------|-------|----------|
| Webhook not firing | JQL filter too restrictive | Check label exists on issue |
| 401 Unauthorized | Signature verification failed | Verify secret matches |
| Message update fails | Slack message deleted | Add try/catch, log and skip |
| Duplicate updates | Multiple status transitions | Filter for final status only (Done, Resolved) |
| Webhook timeout | Processing takes >10s | Respond 200 immediately, process async |

## Resources

- **Jira Webhooks Docs**: https://developer.atlassian.com/server/jira/platform/webhooks/
- **Atlassian MCP Server**: Used for issue property storage/retrieval
- **Slack Web API - chat.update**: https://api.slack.com/methods/chat.update
