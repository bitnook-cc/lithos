# Bug Routing Logic

This document describes the algorithm for routing Commerce platform bugs to the correct Jira project using Claude-based classification.

## Overview

The bug router uses a two-stage approach:

1. **Heuristic routing** - Fast pattern matching on URL and keywords
2. **AI-powered routing** - Claude classifies ambiguous cases

**Goal**: Route bugs to the correct Jira project (CAC, CCG, COF, STAYS) with >80% confidence.

## Routing Decision Table

| Signal | Team | Jira Project | Confidence |
|--------|------|--------------|------------|
| `/air`, `/flights`, "flight", "CFAR" | Air & Cars | CAC | 95% |
| `/cars`, "car rental", "ground transport" | Air & Cars | CAC | 95% |
| `/stays`, `/hotel`, "hotel", "property", "room" | Stays & Packages | STAYS | 95% |
| `/checkout`, `/wallet`, `/trips`, "payment", "loyalty" | Checkout & Growth | CCG | 95% |
| "auth", "session", "config", "SDK", "tracking" | Foundation | COF | 90% |
| No clear match | Foundation (default) | COF | 60% |

## Implementation: src/services/commerce-bug-routing.ts

### Stage 1: Heuristic Routing

```typescript
interface BugReport {
  title: string;
  description: string;
  url?: string;
  severity: 'critical' | 'high' | 'medium' | 'low';
  device?: string;
}

interface RoutingResult {
  project: 'CAC' | 'CCG' | 'COF' | 'STAYS';
  team: string;
  confidence: number;
  reasoning: string;
}

export function routeBug(bug: BugReport): Promise<RoutingResult> {
  // 1. Extract URL path
  const urlPath = bug.url ? new URL(bug.url).pathname : '';

  // 2. Check URL patterns (highest confidence)
  if (urlPath.includes('/air') || urlPath.includes('/flights')) {
    return {
      project: 'CAC',
      team: 'Air & Cars',
      confidence: 0.95,
      reasoning: 'URL contains /air or /flights'
    };
  }

  if (urlPath.includes('/cars')) {
    return {
      project: 'CAC',
      team: 'Air & Cars',
      confidence: 0.95,
      reasoning: 'URL contains /cars'
    };
  }

  if (urlPath.includes('/stays') || urlPath.includes('/hotel')) {
    return {
      project: 'STAYS',
      team: 'Stays & Packages',
      confidence: 0.95,
      reasoning: 'URL contains /stays or /hotel'
    };
  }

  if (urlPath.includes('/checkout') || urlPath.includes('/wallet') || urlPath.includes('/trips')) {
    return {
      project: 'CCG',
      team: 'Checkout & Growth',
      confidence: 0.95,
      reasoning: 'URL contains /checkout, /wallet, or /trips'
    };
  }

  // 3. Check keywords (medium confidence)
  const text = `${bug.title} ${bug.description}`.toLowerCase();

  const keywords = {
    CAC: ['flight', 'airline', 'cfar', 'airport', 'baggage', 'seat', 'car rental', 'rental car'],
    STAYS: ['hotel', 'property', 'room', 'accommodation', 'lodging', 'vacation rental', 'check-in', 'check-out'],
    CCG: ['payment', 'checkout', 'wallet', 'credit', 'loyalty', 'hopper cash', 'refund', 'price freeze'],
    COF: ['auth', 'login', 'session', 'config', 'sdk', 'tracking', 'analytics', 'tenant', 'theme']
  };

  for (const [project, words] of Object.entries(keywords)) {
    const matchCount = words.filter(word => text.includes(word)).length;
    if (matchCount >= 2) {
      return {
        project: project as 'CAC' | 'CCG' | 'COF' | 'STAYS',
        team: getTeamName(project),
        confidence: 0.85,
        reasoning: `Keywords: ${words.filter(w => text.includes(w)).join(', ')}`
      };
    }
  }

  // 4. Single keyword match (lower confidence)
  for (const [project, words] of Object.entries(keywords)) {
    const match = words.find(word => text.includes(word));
    if (match) {
      return {
        project: project as 'CAC' | 'CCG' | 'COF' | 'STAYS',
        team: getTeamName(project),
        confidence: 0.70,
        reasoning: `Keyword: ${match}`
      };
    }
  }

  // 5. Fall through to AI classification
  return classifyWithClaude(bug);
}

function getTeamName(project: string): string {
  const teams = {
    CAC: 'Air & Cars',
    CCG: 'Checkout & Growth',
    COF: 'Foundation',
    STAYS: 'Stays & Packages'
  };
  return teams[project] || 'Foundation';
}
```

### Stage 2: Claude-Based Classification

```typescript
import { query } from '../agent';

async function classifyWithClaude(bug: BugReport): Promise<RoutingResult> {
  const prompt = `You are a bug router for the Hopper Commerce platform. Given the bug report below, determine which team should handle it.

**Bug Report:**
Title: ${bug.title}
Description: ${bug.description}
URL: ${bug.url || 'N/A'}
Severity: ${bug.severity}

**Teams and their responsibilities:**

1. **Air & Cars (CAC)** - Flight search, booking, CFAR insurance, car rentals, airline partnerships
2. **Stays & Packages (STAYS)** - Hotel search, hotel booking, vacation rentals, property listings
3. **Checkout & Growth (CCG)** - Payment processing, wallet, trips dashboard, loyalty, Hopper Cash, price freeze
4. **Foundation (COF)** - Authentication, session management, SDKs, configuration, tracking, tenant management, design system, shared components

**Instructions:**
- Return ONLY valid JSON in this exact format: {"project": "CAC"|"CCG"|"COF"|"STAYS", "confidence": 0.0-1.0, "reasoning": "brief explanation"}
- Confidence should be 0.0 to 1.0
- If unsure, default to "COF" (Foundation) with low confidence

**Example:**
{"project": "CCG", "confidence": 0.92, "reasoning": "Payment failure during checkout flow"}`;

  const response = await query(prompt, { mode: 'cli' });

  try {
    // Parse JSON from response
    const jsonMatch = response.match(/\{.*\}/s);
    if (!jsonMatch) {
      throw new Error('No JSON found in response');
    }

    const result = JSON.parse(jsonMatch[0]);

    return {
      project: result.project,
      team: getTeamName(result.project),
      confidence: result.confidence,
      reasoning: result.reasoning
    };
  } catch (error) {
    console.error('Failed to parse Claude response:', error);
    // Default to Foundation
    return {
      project: 'COF',
      team: 'Foundation',
      confidence: 0.50,
      reasoning: 'Classification failed, defaulting to Foundation'
    };
  }
}
```

## Duplicate Detection

Prevent duplicate Jira tickets:

```typescript
import { searchJiraIssues } from '../clients/jira'; // Use Atlassian MCP

async function detectDuplicate(bug: BugReport, project: string): Promise<string | null> {
  // 1. Generate search keywords with Claude
  const keywords = await generateSearchKeywords(bug);

  // 2. Search Jira with JQL
  const jql = `
    project = ${project}
    AND status NOT IN (Done, Resolved, Closed)
    AND (
      summary ~ "${keywords.slice(0, 5).join(' ')}"
      OR description ~ "${keywords.slice(0, 5).join(' ')}"
    )
  `;

  const issues = await searchJiraIssues(jql, { maxResults: 10 });

  if (issues.length === 0) {
    return null;
  }

  // 3. Calculate similarity scores
  for (const issue of issues) {
    const similarity = calculateSimilarity(bug.description, issue.fields.description);

    if (similarity > 0.70) {
      return issue.key; // Found duplicate
    }
  }

  return null;
}

async function generateSearchKeywords(bug: BugReport): Promise<string[]> {
  const prompt = `Extract 5-10 search keywords from this bug report:

Title: ${bug.title}
Description: ${bug.description}

Return ONLY a JSON array of keywords (no extra text):
["keyword1", "keyword2", ...]`;

  const response = await query(prompt, { mode: 'cli' });
  const jsonMatch = response.match(/\[.*\]/s);
  return jsonMatch ? JSON.parse(jsonMatch[0]) : [bug.title.split(' ')[0]];
}

function calculateSimilarity(text1: string, text2: string): number {
  // Simple word overlap similarity (can be improved with embeddings)
  const words1 = new Set(text1.toLowerCase().split(/\s+/));
  const words2 = new Set(text2.toLowerCase().split(/\s+/));

  const intersection = new Set([...words1].filter(w => words2.has(w)));
  const union = new Set([...words1, ...words2]);

  return intersection.size / union.size;
}
```

## AI Summary Generation

Convert raw bug reports to structured Jira format:

```typescript
async function generateJiraSummary(bug: BugReport): Promise<string> {
  const prompt = `Convert this bug report into a structured format for Jira:

**Bug Report:**
Title: ${bug.title}
Description: ${bug.description}
URL: ${bug.url || 'N/A'}
Severity: ${bug.severity}
Device: ${bug.device || 'N/A'}

**Required format:**

h3. Steps to Reproduce
# Step 1
# Step 2
# Step 3

h3. Expected Behavior
What should happen

h3. Actual Behavior
What actually happens

h3. Environment
* URL: ${bug.url || 'N/A'}
* Device: ${bug.device || 'Unknown'}
* Severity: ${bug.severity}

If Steps to Reproduce are not clear from the description, infer reasonable steps based on the URL and description.`;

  const response = await query(prompt, { mode: 'cli' });

  return response.trim();
}
```

## Priority Mapping

Map severity + keywords to Jira priority:

```typescript
function calculatePriority(bug: BugReport, routing: RoutingResult): string {
  const text = `${bug.title} ${bug.description}`.toLowerCase();

  // Critical keywords override severity
  const criticalKeywords = ['down', 'outage', 'data loss', 'security', 'crash', 'cannot book', 'payment fails'];
  if (criticalKeywords.some(kw => text.includes(kw))) {
    return 'P0'; // Highest
  }

  // Severity-based mapping
  const priorityMap = {
    critical: 'P0',
    high: 'P1',
    medium: 'P2',
    low: 'P3'
  };

  return priorityMap[bug.severity] || 'P2';
}
```

## Handling Low Confidence (<80%)

When confidence is below 80%, post to #commerce-bugs and ask human to route:

```typescript
async function handleLowConfidence(bug: BugReport, routing: RoutingResult) {
  await slack.chat.postMessage({
    channel: 'C_COMMERCE_BUGS',
    text: `⚠️ Bug needs manual routing (confidence: ${Math.round(routing.confidence * 100)}%)`,
    blocks: [
      {
        type: 'section',
        text: {
          type: 'mrkdwn',
          text: `*Bug Report:* ${bug.title}\n\n${bug.description.slice(0, 200)}...`
        }
      },
      {
        type: 'section',
        text: {
          type: 'mrkdwn',
          text: `*Auto-routing suggestion:* ${routing.team} (${routing.project}) - ${routing.reasoning}\n\n<@commerce-ems> Please review and assign to correct team.`
        }
      },
      {
        type: 'actions',
        elements: [
          {
            type: 'button',
            text: { type: 'plain_text', text: 'Route to CAC' },
            value: `route:${bug.id}:CAC`
          },
          {
            type: 'button',
            text: { type: 'plain_text', text: 'Route to CCG' },
            value: `route:${bug.id}:CCG`
          },
          {
            type: 'button',
            text: { type: 'plain_text', text: 'Route to COF' },
            value: `route:${bug.id}:COF`
          },
          {
            type: 'button',
            text: { type: 'plain_text', text: 'Route to STAYS' },
            value: `route:${bug.id}:STAYS`
          }
        ]
      }
    ]
  });
}
```

## Testing

Use `scripts/example-queries/route-test-cases.json` for validation:

```typescript
const testCases = [
  {
    input: {
      title: 'Flight search returns no results',
      description: 'Searching for flights from YYZ to LAX shows empty results',
      url: 'https://app.hopper.com/air/search?from=YYZ&to=LAX'
    },
    expected: { project: 'CAC', confidence: 0.95 }
  },
  {
    input: {
      title: 'Payment failed',
      description: 'Credit card declined during checkout',
      url: 'https://app.hopper.com/checkout'
    },
    expected: { project: 'CCG', confidence: 0.95 }
  },
  // Add more test cases...
];

for (const testCase of testCases) {
  const result = await routeBug(testCase.input);
  console.assert(result.project === testCase.expected.project, `Failed: ${testCase.input.title}`);
  console.assert(result.confidence >= testCase.expected.confidence, `Low confidence: ${testCase.input.title}`);
}
```

## CODEOWNERS Integration (Advanced)

Parse commerce-portals CODEOWNERS file for authoritative routing:

```typescript
import { Octokit } from '@octokit/rest';

async function getCodeownersMapping(): Promise<Record<string, string>> {
  const octokit = new Octokit({ auth: process.env.GITHUB_TOKEN });

  const { data } = await octokit.repos.getContent({
    owner: 'hopper-org',
    repo: 'commerce-portals',
    path: 'CODEOWNERS'
  });

  const content = Buffer.from(data.content, 'base64').toString();
  const lines = content.split('\n');

  const mapping: Record<string, string> = {};

  for (const line of lines) {
    if (line.startsWith('#') || !line.trim()) continue;

    // Example: /src/air/ @hopper-org/air-cars-team
    const match = line.match(/^([\w\/]+)\s+@hopper-org\/([\w-]+)/);
    if (match) {
      const [, path, team] = match;
      mapping[path] = teamToProject(team); // Map GitHub team to Jira project
    }
  }

  return mapping;
}

function teamToProject(githubTeam: string): string {
  const teamMap = {
    'air-cars-team': 'CAC',
    'checkout-growth-team': 'CCG',
    'foundation-team': 'COF',
    'stays-packages-team': 'STAYS'
  };
  return teamMap[githubTeam] || 'COF';
}
```

## Resources

- **Team Routing Rules**: `references/team-routing-rules.md`
- **Jira Projects**: CAC, CCG, COF, STAYS
- **Confidence Threshold**: 80% (configurable)
- **Default Project**: COF (Foundation)
