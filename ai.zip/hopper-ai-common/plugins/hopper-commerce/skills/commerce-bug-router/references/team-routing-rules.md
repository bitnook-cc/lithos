# Team Routing Rules

This document defines the authoritative routing matrix for Commerce platform bugs.

## Routing Matrix

| Signal | Team | Jira Project | Examples |
|--------|------|--------------|----------|
| `/air`, `/flights` URL path | Air & Cars | CAC | Flight search, booking, airline pages |
| `/cars` URL path | Air & Cars | CAC | Car rental search, booking |
| Flight/CFAR keywords | Air & Cars | CAC | "flight delayed", "CFAR claim", "airline" |
| `/stays`, `/hotel` URL path | Stays & Packages | STAYS | Hotel search, property details, booking |
| Hotel/property keywords | Stays & Packages | STAYS | "room unavailable", "check-in", "property" |
| `/checkout`, `/wallet`, `/trips` URL path | Checkout & Growth | CCG | Payment, loyalty, trips dashboard |
| Payment/wallet keywords | Checkout & Growth | CCG | "payment failed", "Hopper Cash", "refund" |
| Auth/config keywords | Foundation | COF | "login", "session expired", "SDK error" |
| Unknown/unclear | Foundation (default) | COF | Catch-all for ambiguous cases |

## Detailed Routing Rules

### Air & Cars (CAC)

**URL Patterns**:
- `https://app.hopper.com/air/*`
- `https://app.hopper.com/flights/*`
- `https://app.hopper.com/cars/*`

**Keywords**:
- Flight-related: flight, airline, airport, baggage, seat, boarding, departure, arrival, CFAR, trip protection
- Car-related: car rental, rental car, ground transport, vehicle, driver

**Examples**:
- "Flight search shows no results for YYZ to LAX"
- "CFAR claim not processing for booking ABC123"
- "Airline logo not displaying on confirmation page"
- "Car rental pickup location incorrect"

**Jira Project**: CAC

**Team Slack Channel**: #air-cars-team

---

### Stays & Packages (STAYS)

**URL Patterns**:
- `https://app.hopper.com/stays/*`
- `https://app.hopper.com/hotel/*`
- `https://app.hopper.com/vacation-rentals/*`

**Keywords**:
- Hotel-related: hotel, property, room, accommodation, lodging, vacation rental
- Booking-related: check-in, check-out, reservation, guest, amenities, housekeeping

**Examples**:
- "Hotel search results show incorrect prices"
- "Room photos not loading on property details page"
- "Cannot filter by amenities"
- "Booking confirmation email missing hotel address"

**Jira Project**: STAYS

**Team Slack Channel**: #stays-packages-team

---

### Checkout & Growth (CCG)

**URL Patterns**:
- `https://app.hopper.com/checkout/*`
- `https://app.hopper.com/wallet/*`
- `https://app.hopper.com/trips/*`
- `https://app.hopper.com/loyalty/*`

**Keywords**:
- Payment-related: payment, credit card, billing, refund, charge, transaction, checkout
- Wallet-related: Hopper Cash, wallet, balance, credit, loyalty, points, rewards
- Trips-related: trips dashboard, upcoming trips, past bookings, itinerary

**Examples**:
- "Payment fails with credit card ending in 1234"
- "Hopper Cash not applied at checkout"
- "Trips dashboard shows canceled trip as active"
- "Loyalty points not credited after booking"

**Jira Project**: CCG

**Team Slack Channel**: #checkout-growth-team

---

### Foundation (COF)

**URL Patterns**:
- `https://app.hopper.com/auth/*`
- `https://app.hopper.com/login/*`
- `https://app.hopper.com/config/*`

**Keywords**:
- Auth-related: login, logout, session, authentication, password, 2FA, account
- Platform-related: SDK, tracking, analytics, tenant, theme, design system, config, API error
- Generic errors: 500, server error, timeout, crash

**Examples**:
- "Login page shows blank screen"
- "Session expired unexpectedly"
- "Tracking events not firing"
- "Design system button colors incorrect on tenant XYZ"

**Jira Project**: COF (default for unclear cases)

**Team Slack Channel**: #foundation-team

---

## Edge Cases

### Corporate Team

**Scenario**: Corporate-specific tenant bugs (e.g., custom branding, SSO)

**Action**: Post to #commerce-bugs and tag @commerce-ems for manual routing

**Why**: No dedicated Jira project specified in original requirements

---

### Localization Team

**Scenario**: Translation errors, locale-specific bugs, i18n issues

**Action**: Post to #commerce-bugs and tag @commerce-ems for manual routing

**Why**: No dedicated Jira project specified in original requirements

---

### Multi-Team Issues

**Scenario**: Bug affects multiple teams (e.g., "Payment fails for flight bookings")

**Action**:
1. Route to the team that owns the failing component (Checkout for payment issues)
2. Add comment noting cross-team dependency
3. Post to #commerce-bugs mentioning both teams

**Example**:
- "Payment fails for hotel bookings" → Route to CCG (payment is the failure point)
- "Flight search crashes during checkout" → Route to CAC (search is the failure point)

---

### Partner-Specific Bugs

**Scenario**: Bug only affects specific partner tenant (e.g., CommBank, NuBank)

**Action**:
1. Route based on product area (air/stays/checkout)
2. Add `tenant:partner-name` label
3. Mention partner name in summary

**Example**: "Flight search broken on CommBank tenant" → Route to CAC, label `tenant:commbank`

---

## Confidence Thresholds

| Confidence Level | Action |
|------------------|--------|
| ≥ 95% | Auto-create Jira ticket, post to #commerce-bugs |
| 80-94% | Auto-create Jira ticket, post to #commerce-bugs |
| 60-79% | Post to #commerce-bugs with routing suggestion, tag @commerce-ems for manual review |
| < 60% | Post to #commerce-bugs as "Needs Manual Routing", tag @commerce-ems |

**Rationale**: 80% threshold balances automation (reduce manual routing) with accuracy (avoid mis-routed tickets).

---

## CODEOWNERS Integration

For authoritative routing, parse the commerce-portals repository CODEOWNERS file:

**Repository**: https://github.com/hopper-org/commerce-portals

**Example CODEOWNERS entries**:
```
/src/air/           @hopper-org/air-cars-team
/src/stays/         @hopper-org/stays-packages-team
/src/checkout/      @hopper-org/checkout-growth-team
/src/shared/auth/   @hopper-org/foundation-team
```

**Mapping**:
| GitHub Team | Jira Project |
|-------------|--------------|
| `air-cars-team` | CAC |
| `stays-packages-team` | STAYS |
| `checkout-growth-team` | CCG |
| `foundation-team` | COF |

**Implementation**: See `references/commerce-bug-routing-logic.md` for code example.

---

## Notification Channel

**Single channel strategy**: All bug notifications go to #commerce-bugs

**Rationale**:
- Centralized visibility across all teams
- Easier to track bug volume and trends
- Reduces notification noise in team-specific channels

**Message format**:
```
🐛 New Bug: [CAC-123] Flight search shows no results

Reporter: @jdoe
Team: Air & Cars (CAC)
Priority: P1 (High)
Severity: Critical

[View in Jira](https://hopper-jira.atlassian.net/browse/CAC-123)
```

---

## Routing Decision Tree

```
1. Does bug URL contain path pattern?
   YES → Route to team based on URL (95% confidence)
   NO → Go to step 2

2. Does description contain 2+ keywords for a team?
   YES → Route to that team (85% confidence)
   NO → Go to step 3

3. Does description contain 1 keyword for a team?
   YES → Route to that team (70% confidence)
   NO → Go to step 4

4. Use Claude to classify bug
   Confidence ≥ 80% → Route to suggested team
   Confidence < 80% → Post to #commerce-bugs, tag @commerce-ems

5. No match found
   → Default to Foundation (COF) with 60% confidence
   → Post to #commerce-bugs, tag @commerce-ems for manual routing
```

---

## Priority Mapping

| Severity (User-Selected) | Keywords | Jira Priority |
|---------------------------|----------|---------------|
| Critical | "down", "outage", "data loss", "security", "cannot book", "payment fails" | P0 |
| High | "broken", "error", "crash", "fail" | P1 |
| Medium | (default) | P2 |
| Low | "cosmetic", "typo", "minor", "improvement" | P3 |

**Override rule**: Critical keywords override user-selected severity

**Example**: User selects "Low" but description says "payment fails" → P0

---

## Future Enhancements

1. **Machine learning model**: Train on historical bug reports for better classification
2. **Dynamic routing**: Update routing rules based on team availability, oncall rotation
3. **Smart duplicate detection**: Use embeddings for semantic similarity (better than keyword overlap)
4. **Auto-prioritization**: Analyze sentiment, urgency keywords for automatic priority adjustment
5. **Partner routing**: Dedicated routing rules per partner tenant
6. **SLA tracking**: Monitor time-to-resolution by team, severity

---

## Maintenance

**Ownership**: commerce-dev team

**Update frequency**: Review quarterly or when team structure changes

**Contact**: #commerce-bugs channel or @commerce-ems

**Source of truth**: This document + commerce-portals CODEOWNERS file
