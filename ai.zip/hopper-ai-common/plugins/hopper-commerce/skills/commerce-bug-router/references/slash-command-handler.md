# Slack Slash Command Handler

This guide shows how to add a new slash command to platform-ai using the Slack API and modal forms.

## Overview

Slack slash commands follow this flow:

```
User types /commerce-bug → Slack → POST /slack/events → platform-ai → Open modal → User submits → Handle submission → Create Jira ticket
```

## Slash Command Event Structure

When a user types `/commerce-bug [optional text]`, Slack sends a POST request:

```json
{
  "token": "verification-token",
  "team_id": "T0WBE0M6D",
  "team_domain": "hopchat",
  "channel_id": "C789ABC",
  "channel_name": "commerce-bugs",
  "user_id": "U123456",
  "user_name": "jdoe",
  "command": "/commerce-bug",
  "text": "optional text typed after command",
  "api_app_id": "A012345",
  "is_enterprise_install": "false",
  "response_url": "https://hooks.slack.com/commands/...",
  "trigger_id": "123.456.abc-def-ghi"
}
```

**Critical fields**:
- `command` - Which command was typed (`/commerce-bug`)
- `text` - Any text after the command
- `user_id` - Who invoked it
- `channel_id` - Where it was invoked
- `trigger_id` - **Valid for only 3 seconds**, used to open modals
- `response_url` - Use this to send delayed responses

## Step 1: Create Route Handler

Create `src/routes/commerce-bug-router.ts`:

```typescript
import { Router, Request, Response } from 'express';
import crypto from 'node:crypto';
import { WebClient } from '@slack/web-api';

const router = Router();
const slack = new WebClient(process.env.SLACK_BOT_TOKEN);

// Verify Slack request signature
function verifySlackRequest(req: Request): boolean {
  const signature = req.headers['x-slack-signature'] as string;
  const timestamp = req.headers['x-slack-request-timestamp'] as string;
  const body = JSON.stringify(req.body);

  // Prevent replay attacks
  if (Math.abs(Date.now() / 1000 - parseInt(timestamp)) > 60 * 5) {
    return false;
  }

  const sigBaseString = `v0:${timestamp}:${body}`;
  const mySignature = `v0=${crypto
    .createHmac('sha256', process.env.SLACK_SIGNING_SECRET!)
    .update(sigBaseString)
    .digest('hex')}`;

  return crypto.timingSafeEqual(
    Buffer.from(mySignature),
    Buffer.from(signature)
  );
}

router.post('/slack/commerce-bug', async (req: Request, res: Response) => {
  // 1. Verify request is from Slack
  if (!verifySlackRequest(req)) {
    return res.status(401).send('Unauthorized');
  }

  const { trigger_id, user_id, channel_id, text } = req.body;

  // 2. Open modal (must respond within 3 seconds)
  try {
    await slack.views.open({
      trigger_id,
      view: buildBugModal(text) // See below
    });

    // 3. Acknowledge slash command (prevents timeout message)
    res.status(200).send();
  } catch (error) {
    console.error('Failed to open modal:', error);
    res.status(500).json({ error: 'Failed to open bug form' });
  }
});

export default router;
```

## Step 2: Build Modal Form

Create the modal with input fields:

```typescript
function buildBugModal(prefillText?: string) {
  return {
    type: 'modal',
    callback_id: 'bug_report_modal',
    title: {
      type: 'plain_text',
      text: 'Report a Bug'
    },
    submit: {
      type: 'plain_text',
      text: 'Submit'
    },
    close: {
      type: 'plain_text',
      text: 'Cancel'
    },
    blocks: [
      // Title field
      {
        type: 'input',
        block_id: 'title_block',
        label: {
          type: 'plain_text',
          text: 'Bug Title'
        },
        element: {
          type: 'plain_text_input',
          action_id: 'title',
          placeholder: {
            type: 'plain_text',
            text: 'Brief summary of the issue'
          },
          max_length: 150
        }
      },

      // Description field
      {
        type: 'input',
        block_id: 'description_block',
        label: {
          type: 'plain_text',
          text: 'Description'
        },
        element: {
          type: 'plain_text_input',
          action_id: 'description',
          multiline: true,
          placeholder: {
            type: 'plain_text',
            text: 'What happened? What did you expect to happen?'
          },
          initial_value: prefillText || ''
        }
      },

      // URL field (optional)
      {
        type: 'input',
        block_id: 'url_block',
        label: {
          type: 'plain_text',
          text: 'URL (optional)'
        },
        element: {
          type: 'url_text_input',
          action_id: 'url',
          placeholder: {
            type: 'plain_text',
            text: 'https://app.hopper.com/...'
          }
        },
        optional: true
      },

      // Severity select
      {
        type: 'input',
        block_id: 'severity_block',
        label: {
          type: 'plain_text',
          text: 'Severity'
        },
        element: {
          type: 'static_select',
          action_id: 'severity',
          placeholder: {
            type: 'plain_text',
            text: 'Select severity'
          },
          options: [
            {
              text: { type: 'plain_text', text: 'Critical - Service down or data loss' },
              value: 'critical'
            },
            {
              text: { type: 'plain_text', text: 'High - Major feature broken' },
              value: 'high'
            },
            {
              text: { type: 'plain_text', text: 'Medium - Feature partially broken' },
              value: 'medium'
            },
            {
              text: { type: 'plain_text', text: 'Low - Cosmetic issue or minor bug' },
              value: 'low'
            }
          ],
          initial_option: {
            text: { type: 'plain_text', text: 'Medium - Feature partially broken' },
            value: 'medium'
          }
        }
      },

      // Device/Browser field (optional)
      {
        type: 'input',
        block_id: 'device_block',
        label: {
          type: 'plain_text',
          text: 'Device/Browser (optional)'
        },
        element: {
          type: 'plain_text_input',
          action_id: 'device',
          placeholder: {
            type: 'plain_text',
            text: 'e.g., iPhone 15, Safari 17.2'
          }
        },
        optional: true
      }
    ]
  };
}
```

### Screenshot Upload

Slack modals don't support native file uploads. Two options:

**Option A: Prompt for screenshot in modal submission response**
```typescript
// After modal submission
await slack.chat.postEphemeral({
  channel: channelId,
  user: userId,
  text: 'Bug report created! To add a screenshot, reply to this thread with your image.'
});

// Listen for file_shared events in the thread
```

**Option B: Ask user to attach before invoking /commerce-bug**
```typescript
// In modal text
{
  type: 'section',
  text: {
    type: 'mrkdwn',
    text: '*Tip:* To attach a screenshot, upload it to this channel before using /commerce-bug, then paste the file URL in the description.'
  }
}
```

## Step 3: Handle Modal Submission

Add a handler for `view_submission` interactivity event:

```typescript
router.post('/slack/interactions', async (req: Request, res: Response) => {
  const payload = JSON.parse(req.body.payload);

  if (payload.type !== 'view_submission') {
    return res.status(200).send();
  }

  if (payload.view.callback_id !== 'bug_report_modal') {
    return res.status(200).send();
  }

  // Extract form values
  const values = payload.view.state.values;
  const bugReport = {
    title: values.title_block.title.value,
    description: values.description_block.description.value,
    url: values.url_block?.url?.value || null,
    severity: values.severity_block.severity.selected_option.value,
    device: values.device_block?.device?.value || null,
    reporterId: payload.user.id,
    reporterName: payload.user.name,
    channelId: payload.view.private_metadata.channelId, // Pass via private_metadata
  };

  // 1. Show loading message
  res.status(200).json({
    response_action: 'update',
    view: buildLoadingView()
  });

  // 2. Process bug report asynchronously
  processBugReport(bugReport).catch(console.error);
});

function buildLoadingView() {
  return {
    type: 'modal',
    title: { type: 'plain_text', text: 'Processing...' },
    blocks: [
      {
        type: 'section',
        text: {
          type: 'mrkdwn',
          text: '⏳ Analyzing bug report and creating Jira ticket...'
        }
      }
    ]
  };
}

async function processBugReport(bug: BugReport) {
  // 1. Route to team/project (see bug-routing-logic.md)
  const routing = await routeBug(bug);

  // 2. Check for duplicates (see bug-routing-logic.md)
  const duplicate = await detectDuplicate(bug, routing.project);
  if (duplicate) {
    await notifyDuplicate(bug, duplicate);
    return;
  }

  // 3. Create Jira ticket (see jira-webhook-setup.md)
  const jiraIssue = await createJiraTicket(bug, routing);

  // 4. Post to #commerce-bugs
  await slack.chat.postMessage({
    channel: 'C_COMMERCE_BUGS', // Replace with actual channel ID
    text: `🐛 New Bug: [${jiraIssue.key}] ${bug.title}`,
    blocks: buildBugNotification(bug, jiraIssue, routing)
  });

  // 5. Notify reporter
  await slack.chat.postEphemeral({
    channel: bug.channelId,
    user: bug.reporterId,
    text: `✅ Bug report created: ${jiraIssue.key}`,
    blocks: [
      {
        type: 'section',
        text: {
          type: 'mrkdwn',
          text: `✅ Your bug has been filed as *${jiraIssue.key}* in the ${routing.team} team's backlog.`
        }
      },
      {
        type: 'actions',
        elements: [
          {
            type: 'button',
            text: { type: 'plain_text', text: 'View in Jira' },
            url: `https://hopper-jira.atlassian.net/browse/${jiraIssue.key}`
          }
        ]
      }
    ]
  });
}
```

## Step 4: Register Route

In `src/server.ts`:

```typescript
import bugRouter from './routes/commerce-bug-router';

if (config.mode === 'slack') {
  app.use('/slack', slackRouter);
  app.use('/slack', bugRouter); // Add this line
}
```

## Handling Edge Cases

### 1. Modal Timeout

If modal doesn't open within 3 seconds (trigger_id expires):

```typescript
// Send ephemeral message instead
await slack.chat.postEphemeral({
  channel: channelId,
  user: userId,
  text: '⚠️ Command timed out. Please try /commerce-bug again.'
});
```

### 2. Validation Errors

Return validation errors in modal:

```typescript
res.status(200).json({
  response_action: 'errors',
  errors: {
    title_block: 'Title must be at least 10 characters',
    url_block: 'Invalid URL format'
  }
});
```

### 3. User Cancels Modal

No action needed - Slack handles cancel automatically.

### 4. Rate Limiting

Slack API has rate limits (1 req/sec for modals). Use exponential backoff:

```typescript
import pRetry from 'p-retry';

await pRetry(
  () => slack.views.open({ trigger_id, view }),
  {
    retries: 3,
    onFailedAttempt: (error) => {
      if (error.data?.error === 'ratelimited') {
        console.warn(`Rate limited, retrying...`);
      }
    }
  }
);
```

## Testing

### Local Testing with ngrok

1. **Start ngrok tunnel**:
   ```bash
   ngrok http 7070
   ```

2. **Update Slack app request URL**:
   - Go to https://api.slack.com/apps/[APP_ID]/slash-commands
   - Change URL to `https://[ngrok-id].ngrok.io/slack/commerce-bug`

3. **Test in Slack**:
   ```
   /commerce-bug Payment fails on checkout
   ```

4. **Check logs**:
   ```bash
   cd platform-ai
   npm run dev
   # Watch for POST /slack/commerce-bug logs
   ```

### Unit Testing

Mock Slack API responses:

```typescript
import { WebClient } from '@slack/web-api';

jest.mock('@slack/web-api');

describe('Bug Router', () => {
  let mockSlack: jest.Mocked<WebClient>;

  beforeEach(() => {
    mockSlack = new WebClient() as jest.Mocked<WebClient>;
    mockSlack.views.open = jest.fn().mockResolvedValue({ ok: true });
  });

  it('opens modal when /commerce-bug is invoked', async () => {
    const req = {
      body: {
        trigger_id: 'test-trigger',
        command: '/commerce-bug',
        text: 'Test bug'
      },
      headers: {
        'x-slack-signature': 'valid-signature',
        'x-slack-request-timestamp': Math.floor(Date.now() / 1000).toString()
      }
    };

    await handleBugCommand(req);

    expect(mockSlack.views.open).toHaveBeenCalledWith({
      trigger_id: 'test-trigger',
      view: expect.objectContaining({
        type: 'modal',
        callback_id: 'bug_report_modal'
      })
    });
  });
});
```

## Resources

- **Slack Block Kit Builder**: https://api.slack.com/block-kit/building
- **Slack API - Modals**: https://api.slack.com/surfaces/modals
- **Slack API - Slash Commands**: https://api.slack.com/interactivity/slash-commands
- **@slack/web-api Docs**: https://slack.dev/node-slack-sdk/web-api
