# platform-ai Architecture

This document explains how platform-ai works so you can extend it with new functionality.

## Overview

platform-ai is Hopper's centralized AI harness running on GKE. It serves three roles:

1. **Slack integration** - Handles app mentions, DMs, and slash commands
2. **GitHub integration** - Automated PR compliance reviews
3. **CLI** - Local development and ad-hoc tasks

**Repository**: https://github.com/hopper-org/platform-ai

## Architecture Diagram

```
Slack Event → platform-ai → Agent SDK (Vertex AI) → Tools (MCP, GCP CLI) → Response
                ↓
            Redis Session Store
```

## Project Structure

```
platform-ai/
├── src/
│   ├── server.ts           # Express server, mode-based routing
│   ├── agent.ts            # Agent SDK orchestration (ONLY vendor-specific code)
│   ├── config.ts           # Environment configuration
│   ├── routes/
│   │   ├── slack.ts        # Slack event handlers
│   │   ├── github.ts       # GitHub webhook handlers
│   │   └── cli.ts          # CLI streaming endpoint
│   ├── clients/
│   │   ├── gcp.ts          # GCP access token management
│   │   └── github-token.ts # GitHub App token management
│   ├── security/
│   │   └── security-hook.ts # Pre-tool-use security controls
│   ├── session/
│   │   ├── session-store.ts     # Redis session persistence
│   │   └── cancellation.ts      # PubSub-based cancellation
│   └── slack/
│       ├── slack-cache.ts      # User/channel cache
│       └── slack-reaction.ts   # Reaction helpers
├── system-prompts/
│   ├── slack.md            # Agent instructions for Slack mode
│   ├── cli.md              # Agent instructions for CLI mode
│   └── triage.md           # GitHub PR triage instructions
├── deployment/             # Bazel deployment configs (rules_hopper)
├── bin/platform-ai         # Local container runner
└── Dockerfile
```

## How Slack Events Flow

### Request Path

```
1. Slack → POST /slack/events
2. src/routes/slack.ts receives event
3. Verify request signature (HMAC-SHA256)
4. Extract event type (app_mention, message, command)
5. Route to appropriate handler
6. Call agent.query() with prompt + context
7. Agent SDK executes tools via MCP servers
8. Post response back to Slack thread
```

### Slack Event Types Handled

| Event Type | Trigger | Handler Location |
|------------|---------|------------------|
| `app_mention` | @Hopper AI mentioned | `src/routes/slack.ts` |
| `message` (DM) | Direct message to bot | `src/routes/slack.ts` |
| `slash_command` | User types `/command` | **Not yet implemented** (you will add this!) |

### Slash Command Event Structure

When a user types `/commerce-bug`, Slack sends:

```json
{
  "type": "slash_command",
  "command": "/commerce-bug",
  "text": "optional text after command",
  "user_id": "U123456",
  "user_name": "jdoe",
  "channel_id": "C789",
  "channel_name": "commerce-bugs",
  "team_id": "T0WBE0M6D",
  "team_domain": "hopchat",
  "response_url": "https://hooks.slack.com/commands/...",
  "trigger_id": "123.456.abc" // Valid for 3 seconds, used to open modals
}
```

## Agent SDK Integration

`src/agent.ts` is the ONLY vendor-specific code. It wraps the Claude Agent SDK:

```typescript
import { query as agentSdkQuery } from '@anthropic-ai/claude-agent-sdk';

export async function query(prompt: string, context: any) {
  const response = await agentSdkQuery({
    prompt,
    systemPrompt: await loadSystemPrompt(context.mode), // slack.md or cli.md
    env: {
      CLAUDE_CODE_USE_VERTEX: '1',
      ANTHROPIC_VERTEX_PROJECT_ID: process.env.ANTHROPIC_VERTEX_PROJECT_ID,
      CLOUD_ML_REGION: process.env.CLOUD_ML_REGION,
    },
    plugins: loadPlugins(), // From hopper-ai-common
    securityHook: securityCheck, // src/security/security-hook.ts
  });

  return response;
}
```

## How hopper-ai-common Plugins Are Loaded

`src/agent/plugins.ts`:

```typescript
const HOPPER_PLUGINS_DIR = join(ROOT_DIR, "hopper-ai-common", "plugins");

export function loadPlugins(): SdkPluginConfig[] {
  const plugins: SdkPluginConfig[] = [];

  if (existsSync(HOPPER_PLUGINS_DIR)) {
    for (const d of readdirSync(HOPPER_PLUGINS_DIR, { withFileTypes: true })) {
      if (d.isDirectory() && existsSync(join(HOPPER_PLUGINS_DIR, d.name, ".claude-plugin"))) {
        plugins.push({ type: "local", path: join(HOPPER_PLUGINS_DIR, d.name) });
      }
    }
  }

  return plugins;
}
```

This means:
- All MCP servers defined in hopper-ai-common plugins are available
- All skills from hopper-ai-common plugins are loaded
- No code changes needed to platform-ai for new skills (only for new routes/handlers)

## Session Management

Each Slack thread gets an isolated session:

- **Session ID**: UUID generated from thread_ts
- **Workspace**: `/app/workspace/<session-id>/` (persistent Filestore)
- **Redis store**: Session metadata, modal callbacks, cancellation state

```typescript
// src/session/session-store.ts
interface Session {
  id: string;
  channelId: string;
  threadTs: string;
  userId: string;
  workspaceDir: string;
  createdAt: Date;
  lastActivityAt: Date;
}
```

## Security Hooks

`src/security/security-hook.ts` runs BEFORE every tool execution:

- Block access to private Slack channels/DMs outside session
- Block cross-project conversation history
- Warn on workspace directory changes (detect repo contamination)

**For bug router**: You don't need to modify this - existing hooks are sufficient.

## Environment Variables

| Variable | Purpose | Source |
|----------|---------|--------|
| `PLATFORM_AI_MODE` | `slack` or `cli` | Deployment config |
| `PORT` | HTTP server port (default: 7070) | Deployment config |
| `ANTHROPIC_VERTEX_PROJECT_ID` | GCP project for Vertex AI | Secret Manager |
| `CLOUD_ML_REGION` | GCP region (us-east5) | Deployment config |
| `SLACK_SIGNING_SECRET` | Verify Slack requests | Secret Manager |
| `SLACK_CLIENT_ID` | Slack OAuth app ID | Secret Manager |
| `SLACK_CLIENT_SECRET` | Slack OAuth secret | Secret Manager |
| `INITIAL_SLACK_ACCESS_TOKEN` | Bootstrap access token | Secret Manager |
| `INITIAL_SLACK_REFRESH_TOKEN` | Bootstrap refresh token | Secret Manager |
| `REDIS_HOST` | Redis session store host | Deployment config |
| `REDIS_PORT` | Redis port (default: 6379) | Deployment config |
| `ATLASSIAN_API_TOKEN` | Jira/Confluence MCP server | Secret Manager |

## Deployment

platform-ai uses Bazel (rules_hopper) + Harness CI/CD:

```
deployment/
├── BUILD            # Release versioning, Harness project
├── vars.bzl         # Deploy plan (namespace, sites, application)
└── workloads/unit/  # Workload blueprint, secrets, container
```

Deployment flow:
1. Merge to master → release-me computes version
2. GitHub Actions builds container → pushes to Artifact Registry
3. Harness pipeline deploys to GKE (dev → staging → prod)

**For bug router**: No deployment changes needed - existing pipeline handles it.

## Adding a New Route

To add a new Slack slash command route:

1. **Create route handler** - `src/routes/your-handler.ts`:
   ```typescript
   import { Router } from 'express';

   const router = Router();

   router.post('/slack/your-command', async (req, res) => {
     // Verify Slack signature
     // Handle command
     // Call agent.query() if needed
     // Respond to Slack
   });

   export default router;
   ```

2. **Register in `src/server.ts`**:
   ```typescript
   import yourHandler from './routes/your-handler';

   if (config.mode === 'slack') {
     app.use(yourHandler);
   }
   ```

3. **Add tests** - `tests/your-handler.test.ts`

## System Prompts

`system-prompts/slack.md` defines the agent's behavior in Slack mode:

- Identity (Hopper AI, not Claude)
- Available tools (MCP servers, GCP CLI, GitHub)
- Context injection (channel, thread, user)
- Formatting (Slack mrkdwn, not GitHub markdown)
- Conventions (direct, concise, confirm before actions)

**For bug router**: You may want to add a supplementary prompt in `system-prompts/commerce-bug-router-instructions.md` with routing rules, but this is optional (routing logic can live entirely in service code).

## Key Files for Bug Router Implementation

You will modify:

- `src/routes/commerce-bug-router.ts` (NEW) - Slash command handler
- `src/services/commerce-bug-routing.ts` (NEW) - Routing logic
- `src/services/jira-bug.ts` (NEW) - Jira integration
- `src/server.ts` - Register new route
- `tests/commerce-bug-routing.test.ts` (NEW) - Unit tests

You will NOT modify:
- `src/agent.ts` - Agent SDK wrapper (no changes needed)
- `src/security/security-hook.ts` - Existing hooks are sufficient
- `deployment/` - Existing deployment config works
- `system-prompts/slack.md` - Optional, not required

## Resources

- **RFC**: https://hopper-jira.atlassian.net/wiki/spaces/PLATFORM/pages/8358756371/Platform+AI
- **Repo**: https://github.com/hopper-org/platform-ai
- **Docs**: `platform-ai/docs/architecture.md`, `docs/cli.md`, `docs/deployment.md`
- **Support**: #platform-ai-support channel
