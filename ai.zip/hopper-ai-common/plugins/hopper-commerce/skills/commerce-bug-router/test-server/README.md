# Commerce Bug Router Test Server

Standalone test server for the `/commerce-bug` Slack command. This lets you test the complete user flow **without modifying platform-ai**.

## What This Tests

✅ **Slack modal UI/UX** - The bug report form
✅ **Routing logic** - URL patterns + keyword matching (heuristic only, no Claude API)
✅ **Priority calculation** - Severity + critical keyword detection
✅ **End-to-end flow** - Command → Modal → Submission → Results

❌ **NOT tested** (requires platform-ai):
- Claude AI classification for ambiguous cases
- Actual Jira ticket creation
- Duplicate detection (requires Jira search)
- Jira webhooks for resolution updates

## Setup

### 1. Install Dependencies

```bash
cd test-server
npm install
```

### 2. Configure Environment

```bash
cp .env.example .env
# Edit .env and add your Slack tokens
```

**Get Slack credentials:**
1. Go to https://api.slack.com/apps
2. Select the platform-ai app (or create a test app)
3. **Bot Token**: OAuth & Permissions → Bot User OAuth Token (`xoxb-...`)
4. **Signing Secret**: Basic Information → App Credentials → Signing Secret

### 3. Start Server

```bash
npm start
```

Server runs on http://localhost:3000

### 4. Expose with ngrok

```bash
# In a separate terminal
ngrok http 3000
```

Copy the ngrok URL (e.g., `https://abc123.ngrok.io`)

### 5. Configure Slack App

Go to https://api.slack.com/apps → Your App:

**A. Add Slash Command:**
1. Features → Slash Commands → Create New Command
2. **Command**: `/commerce-bug`
3. **Request URL**: `https://YOUR-NGROK-ID.ngrok.io/slack/commerce-bug`
4. **Short Description**: "Report a Commerce platform bug (TEST)"
5. Save

**B. Enable Interactivity:**
1. Features → Interactivity & Shortcuts
2. **Interactivity**: On
3. **Request URL**: `https://YOUR-NGROK-ID.ngrok.io/slack/interactions`
4. Save

### 6. Test in Slack

```
/commerce-bug Payment fails during checkout
```

You should see:
1. Modal form opens
2. Fill out the form and submit
3. Results sent to you as DM (ephemeral message) showing:
   - Routing result (team, project, confidence)
   - Priority
   - What would happen (Jira ticket creation, etc.)

## Example Test Cases

Try these to test different routing scenarios:

```
/commerce-bug Flight search returns no results
URL: https://app.hopper.com/air/search
→ Should route to CAC (Air & Cars)

/commerce-bug Hotel images not loading
URL: https://app.hopper.com/stays/hotel/12345
→ Should route to STAYS (Stays & Packages)

/commerce-bug Payment declined at checkout
URL: https://app.hopper.com/checkout
→ Should route to CCG (Checkout & Growth)

/commerce-bug Login page shows blank screen
URL: https://app.hopper.com/auth/login
→ Should route to COF (Foundation)

/commerce-bug CFAR claim stuck in pending
(no URL, keyword-based)
→ Should route to CAC (Air & Cars)

/commerce-bug Generic error message
(no URL, no keywords)
→ Should route to COF (Foundation) with low confidence
```

## How It Works

1. **Slash Command** → Server receives POST to `/slack/commerce-bug`
2. **Open Modal** → Uses Slack Web API to show bug report form
3. **Submit Form** → Server receives POST to `/slack/interactions`
4. **Simulate Routing** → Runs heuristic routing logic (URL + keywords)
5. **Send Results** → DMs you the routing decision (no Jira ticket created)

## Limitations

This test server uses **heuristic routing only** (URL patterns + keywords). It does NOT:
- Call Claude API for AI classification
- Search Jira for duplicates
- Create actual Jira tickets
- Set up webhooks

For full testing, you'll need to implement in platform-ai.

## Cleanup

When done testing:

1. **Stop ngrok**: Ctrl+C in ngrok terminal
2. **Revert Slack app URLs** (or delete test app if you created one)
3. **Stop test server**: Ctrl+C

## Troubleshooting

**Modal doesn't open:**
- Check ngrok URL is correct in Slack app config
- Check SLACK_BOT_TOKEN is valid
- Check server logs for errors

**Results not sent:**
- Check SLACK_BOT_TOKEN has `chat:write` scope
- Check server logs for errors

**"Unauthorized" error:**
- Check SLACK_SIGNING_SECRET is correct
- Check request timestamp (ngrok tunnel should be < 5 min old)

## Next Steps

After validating the UX:
1. Gather feedback from test users
2. Adjust routing rules if needed
3. Implement in platform-ai using the code templates
4. Add Claude AI classification for ambiguous cases
5. Enable Jira integration (tickets, duplicates, webhooks)
