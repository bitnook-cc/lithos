/**
 * Test routing for a real bug from Slack
 * Source: https://hopchat.slack.com/archives/C0997Q7BJDB/p1774647777547009
 */

function simulateRouting(bug) {
  const urlPath = bug.url ? new URL(bug.url).pathname : '';
  const text = `${bug.title} ${bug.description}`.toLowerCase();

  // URL-based routing
  if (urlPath.includes('/air') || urlPath.includes('/flights')) {
    return { project: 'CAC', team: 'Air & Cars', confidence: 0.95, reasoning: 'URL contains /air or /flights' };
  }
  if (urlPath.includes('/cars')) {
    return { project: 'CAC', team: 'Air & Cars', confidence: 0.95, reasoning: 'URL contains /cars' };
  }
  if (urlPath.includes('/stays') || urlPath.includes('/hotel')) {
    return { project: 'STAYS', team: 'Stays & Packages', confidence: 0.95, reasoning: 'URL contains /stays or /hotel' };
  }
  if (urlPath.includes('/checkout') || urlPath.includes('/wallet') || urlPath.includes('/trips')) {
    return { project: 'CCG', team: 'Checkout & Growth', confidence: 0.95, reasoning: 'URL contains /checkout, /wallet, or /trips' };
  }

  // Keyword-based routing
  const keywords = {
    CAC: ['flight', 'airline', 'cfar', 'airport', 'car rental'],
    STAYS: ['hotel', 'property', 'room', 'accommodation', 'lodging'],
    CCG: ['payment', 'checkout', 'wallet', 'credit', 'loyalty', 'hopper cash', 'traveler', 'traveller'],
    COF: ['auth', 'login', 'session', 'config', 'sdk', 'tracking']
  };

  for (const [project, words] of Object.entries(keywords)) {
    const matchCount = words.filter(word => text.includes(word)).length;
    if (matchCount >= 2) {
      const matched = words.filter(w => text.includes(w)).join(', ');
      return {
        project,
        team: getTeamName(project),
        confidence: 0.85,
        reasoning: `Keywords: ${matched}`
      };
    }
  }

  // Default to Foundation
  return { project: 'COF', team: 'Foundation', confidence: 0.60, reasoning: 'No clear match, defaulting to Foundation' };
}

function getTeamName(project) {
  const teams = {
    CAC: 'Air & Cars',
    CCG: 'Checkout & Growth',
    COF: 'Foundation',
    STAYS: 'Stays & Packages'
  };
  return teams[project] || 'Foundation';
}

function calculatePriority(bug) {
  const text = `${bug.title} ${bug.description}`.toLowerCase();
  const criticalKeywords = ['down', 'outage', 'data loss', 'security', 'crash', 'cannot book', 'payment fails'];

  if (criticalKeywords.some(kw => text.includes(kw))) {
    return 'P0';
  }

  const priorityMap = {
    critical: 'P0',
    high: 'P1',
    medium: 'P2',
    low: 'P3'
  };

  return priorityMap[bug.severity] || 'P2';
}

// Real bug from Slack
const realBug = {
  title: 'Yahoo bug - Mobile interactions are getting cutoff',
  description: `Biggest issue is when I add a traveller I can't see the input I'm typing in.
Other issues include funny anchoring on country selection for payment and overlapping carrot and icon in country selection on phone.
Device: iPhone 17 Pro
Reporter: Catherine (U05E1MYE080)
Original thread: https://hopchat.slack.com/archives/C0997Q7BJDB/p1774647777547009`,
  url: null, // No URL provided in original bug
  severity: 'high', // Originally marked P0, corrected to P1
  device: 'iPhone 17 Pro',
  reporterId: 'U05E1MYE080',
  reporterName: 'Catherine'
};

console.log('\n🔍 Real Bug Report Analysis\n');
console.log('='.repeat(80));
console.log('\n📝 Original Report:');
console.log(`Title: ${realBug.title}`);
console.log(`Description: ${realBug.description}`);
console.log(`Device: ${realBug.device}`);
console.log(`Severity: ${realBug.severity}`);

const routing = simulateRouting(realBug);
const priority = calculatePriority(realBug);

console.log('\n🎯 Routing Result:');
console.log(`Project: ${routing.project}`);
console.log(`Team: ${routing.team}`);
console.log(`Confidence: ${(routing.confidence * 100).toFixed(0)}%`);
console.log(`Reasoning: ${routing.reasoning}`);
console.log(`Calculated Priority: ${priority}`);

console.log('\n📋 What Would Happen:');
console.log(`1. Create Jira ticket: ${routing.project}-XXX`);
console.log(`2. Post to #commerce-bugs with details`);
console.log(`3. Notify reporter when resolved`);

console.log('\n💬 Mock #commerce-bugs Post:');
console.log('='.repeat(80));
console.log(`
🐛 New Bug Reported: ${routing.project}-XXX

*${realBug.title}*

*Team:* ${routing.team}
*Priority:* ${priority}
*Reporter:* Catherine
*Device:* ${realBug.device}

*Description:*
${realBug.description.split('\n')[0]}

*Routing confidence:* ${(routing.confidence * 100).toFixed(0)}%
${routing.confidence < 0.80 ? '⚠️ Low confidence - Please review routing' : ''}

🎫 View in Jira: https://hopper-jira.atlassian.net/browse/${routing.project}-XXX
💬 Original report: https://hopchat.slack.com/archives/C0997Q7BJDB/p1774647777547009
`);

console.log('\n='.repeat(80));

console.log('\n📊 Comparison with Actual:');
console.log(`Actual Jira ticket created: CCG-987`);
console.log(`Our routing prediction: ${routing.project}`);
console.log(`Match: ${routing.project === 'CCG' ? '✅ CORRECT' : '❌ INCORRECT'}`);
console.log();
