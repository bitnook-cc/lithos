/**
 * Standalone test server for /commerce-bug command
 *
 * This allows testing the Slack modal and routing logic WITHOUT
 * modifying platform-ai code.
 *
 * Usage:
 * 1. npm install
 * 2. Set SLACK_BOT_TOKEN in .env
 * 3. npm start
 * 4. Use ngrok: ngrok http 3000
 * 5. Update Slack app /commerce-bug URL to ngrok URL
 * 6. Test in Slack!
 */

import express from 'express';
import crypto from 'node:crypto';
import { WebClient } from '@slack/web-api';

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

const slack = new WebClient(process.env.SLACK_BOT_TOKEN);
const SLACK_SIGNING_SECRET = process.env.SLACK_SIGNING_SECRET;

// Verify Slack signature
function verifySlackRequest(req) {
  const signature = req.headers['x-slack-signature'];
  const timestamp = req.headers['x-slack-request-timestamp'];
  const body = JSON.stringify(req.body);

  if (Math.abs(Date.now() / 1000 - parseInt(timestamp)) > 60 * 5) {
    return false;
  }

  const sigBaseString = `v0:${timestamp}:${body}`;
  const mySignature = `v0=${crypto
    .createHmac('sha256', SLACK_SIGNING_SECRET)
    .update(sigBaseString)
    .digest('hex')}`;

  return crypto.timingSafeEqual(
    Buffer.from(mySignature),
    Buffer.from(signature)
  );
}

// Simulate bug routing (heuristic only, no Claude API)
function simulateRouting(bug) {
  const urlPath = bug.url ? new URL(bug.url).pathname : '';
  const text = `${bug.title} ${bug.description}`.toLowerCase();

  // URL-based routing
  if (urlPath.includes('/air') || urlPath.includes('/flights')) {
    return { project: 'CAC', team: 'Air & Cars', confidence: 0.95, reasoning: 'URL contains /air or /flights' };
  }
  if (urlPath.includes('/cars')) {
    return { project: 'CAC', team: 'Air & Cars', confidence: 0.95, reasoning: 'URL contains /cars' };
  }
  if (urlPath.includes('/stays') || urlPath.includes('/hotel')) {
    return { project: 'STAYS', team: 'Stays & Packages', confidence: 0.95, reasoning: 'URL contains /stays or /hotel' };
  }
  if (urlPath.includes('/checkout') || urlPath.includes('/wallet') || urlPath.includes('/trips')) {
    return { project: 'CCG', team: 'Checkout & Growth', confidence: 0.95, reasoning: 'URL contains /checkout, /wallet, or /trips' };
  }

  // Keyword-based routing
  const keywords = {
    CAC: ['flight', 'airline', 'cfar', 'airport', 'car rental'],
    STAYS: ['hotel', 'property', 'room', 'accommodation', 'lodging'],
    CCG: ['payment', 'checkout', 'wallet', 'credit', 'loyalty', 'hopper cash'],
    COF: ['auth', 'login', 'session', 'config', 'sdk', 'tracking']
  };

  for (const [project, words] of Object.entries(keywords)) {
    const matchCount = words.filter(word => text.includes(word)).length;
    if (matchCount >= 2) {
      const matched = words.filter(w => text.includes(w)).join(', ');
      return {
        project,
        team: getTeamName(project),
        confidence: 0.85,
        reasoning: `Keywords: ${matched}`
      };
    }
  }

  // Default to Foundation
  return { project: 'COF', team: 'Foundation', confidence: 0.60, reasoning: 'No clear match, defaulting to Foundation' };
}

function getTeamName(project) {
  const teams = {
    CAC: 'Air & Cars',
    CCG: 'Checkout & Growth',
    COF: 'Foundation',
    STAYS: 'Stays & Packages'
  };
  return teams[project] || 'Foundation';
}

function calculatePriority(bug) {
  const text = `${bug.title} ${bug.description}`.toLowerCase();
  const criticalKeywords = ['down', 'outage', 'data loss', 'security', 'crash', 'cannot book', 'payment fails'];

  if (criticalKeywords.some(kw => text.includes(kw))) {
    return 'P0';
  }

  const priorityMap = {
    critical: 'P0',
    high: 'P1',
    medium: 'P2',
    low: 'P3'
  };

  return priorityMap[bug.severity] || 'P2';
}

// Build modal
function buildBugModal(prefillText = '') {
  return {
    type: 'modal',
    callback_id: 'bug_report_modal',
    title: { type: 'plain_text', text: 'Report a Bug' },
    submit: { type: 'plain_text', text: 'Submit' },
    close: { type: 'plain_text', text: 'Cancel' },
    blocks: [
      {
        type: 'input',
        block_id: 'title_block',
        label: { type: 'plain_text', text: 'Bug Title' },
        element: {
          type: 'plain_text_input',
          action_id: 'title',
          placeholder: { type: 'plain_text', text: 'Brief summary of the issue' },
          max_length: 150
        }
      },
      {
        type: 'input',
        block_id: 'description_block',
        label: { type: 'plain_text', text: 'Description' },
        element: {
          type: 'plain_text_input',
          action_id: 'description',
          multiline: true,
          placeholder: { type: 'plain_text', text: 'What happened? What did you expect to happen?' },
          initial_value: prefillText
        }
      },
      {
        type: 'input',
        block_id: 'url_block',
        label: { type: 'plain_text', text: 'URL (optional)' },
        element: {
          type: 'url_text_input',
          action_id: 'url',
          placeholder: { type: 'plain_text', text: 'https://app.hopper.com/...' }
        },
        optional: true
      },
      {
        type: 'input',
        block_id: 'severity_block',
        label: { type: 'plain_text', text: 'Severity' },
        element: {
          type: 'static_select',
          action_id: 'severity',
          placeholder: { type: 'plain_text', text: 'Select severity' },
          options: [
            { text: { type: 'plain_text', text: 'Critical - Service down or data loss' }, value: 'critical' },
            { text: { type: 'plain_text', text: 'High - Major feature broken' }, value: 'high' },
            { text: { type: 'plain_text', text: 'Medium - Feature partially broken' }, value: 'medium' },
            { text: { type: 'plain_text', text: 'Low - Cosmetic issue or minor bug' }, value: 'low' }
          ],
          initial_option: { text: { type: 'plain_text', text: 'Medium - Feature partially broken' }, value: 'medium' }
        }
      },
      {
        type: 'input',
        block_id: 'device_block',
        label: { type: 'plain_text', text: 'Device/Browser (optional)' },
        element: {
          type: 'plain_text_input',
          action_id: 'device',
          placeholder: { type: 'plain_text', text: 'e.g., iPhone 15, Safari 17.2' }
        },
        optional: true
      }
    ]
  };
}

// Handle slash command
app.post('/slack/commerce-bug', async (req, res) => {
  console.log('📨 Received /commerce-bug command');

  if (!verifySlackRequest(req)) {
    console.error('❌ Invalid signature');
    return res.status(401).send('Unauthorized');
  }

  const { trigger_id, text, user_id, channel_id } = req.body;

  try {
    await slack.views.open({
      trigger_id,
      view: buildBugModal(text)
    });

    console.log('✅ Modal opened for user', user_id);
    res.status(200).send();
  } catch (error) {
    console.error('❌ Failed to open modal:', error);
    res.status(500).json({ error: 'Failed to open bug form' });
  }
});

// Handle modal submission
app.post('/slack/interactions', async (req, res) => {
  const payload = JSON.parse(req.body.payload);

  if (payload.type !== 'view_submission' || payload.view.callback_id !== 'bug_report_modal') {
    return res.status(200).send();
  }

  console.log('📝 Processing bug report submission');

  // Extract form values
  const values = payload.view.state.values;
  const bug = {
    title: values.title_block.title.value,
    description: values.description_block.description.value,
    url: values.url_block?.url?.value || null,
    severity: values.severity_block.severity.selected_option.value,
    device: values.device_block?.device?.value || null,
    reporterId: payload.user.id,
    reporterName: payload.user.name
  };

  // Simulate routing
  const routing = simulateRouting(bug);
  const priority = calculatePriority(bug);

  console.log('🎯 Routing result:', routing);
  console.log('⚡ Priority:', priority);

  // Show results in Slack (ephemeral message)
  try {
    // Close modal with success
    res.status(200).json({ response_action: 'clear' });

    // Post test results to user (ephemeral)
    await slack.chat.postEphemeral({
      channel: payload.user.id, // DM to user
      user: payload.user.id,
      text: '✅ Bug report test completed!',
      blocks: [
        {
          type: 'section',
          text: {
            type: 'mrkdwn',
            text: `*✅ Bug Report Test Results*\n\n*Title:* ${bug.title}\n*Severity:* ${bug.severity}`
          }
        },
        {
          type: 'section',
          text: {
            type: 'mrkdwn',
            text: `*🎯 Routing Result:*\n• *Team:* ${routing.team}\n• *Jira Project:* ${routing.project}\n• *Confidence:* ${Math.round(routing.confidence * 100)}%\n• *Reasoning:* ${routing.reasoning}\n• *Priority:* ${priority}`
          }
        },
        {
          type: 'section',
          text: {
            type: 'mrkdwn',
            text: `*📋 What would happen:*\n1. Create Jira ticket: \`${routing.project}-XXX\`\n2. Post to #commerce-bugs\n3. Notify you when resolved\n\n_This is a test - no actual Jira ticket created._`
          }
        }
      ]
    });

    console.log('✅ Test results sent to user');
  } catch (error) {
    console.error('❌ Failed to send results:', error);
  }
});

// Health check
app.get('/health', (req, res) => {
  res.json({ status: 'ok', message: 'Test server running' });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`\n🚀 Test server running on http://localhost:${PORT}`);
  console.log('\n📝 Setup steps:');
  console.log('1. Start ngrok: ngrok http 3000');
  console.log('2. Update Slack app /commerce-bug URL to: https://YOUR-NGROK-ID.ngrok.io/slack/commerce-bug');
  console.log('3. Update Slack app Interactivity URL to: https://YOUR-NGROK-ID.ngrok.io/slack/interactions');
  console.log('4. Test in Slack: /commerce-bug Payment fails on checkout\n');
});
