/**
 * Direct test of routing logic - simplified version
 */

// Simplified routing logic for testing (copied from server.js)
function simulateRouting(bug) {
  const urlPath = bug.url ? new URL(bug.url).pathname : '';
  const text = `${bug.title} ${bug.description}`.toLowerCase();

  // URL-based routing
  if (urlPath.includes('/air') || urlPath.includes('/flights')) {
    return { project: 'CAC', team: 'Air & Cars', confidence: 0.95, reasoning: 'URL contains /air or /flights' };
  }
  if (urlPath.includes('/cars')) {
    return { project: 'CAC', team: 'Air & Cars', confidence: 0.95, reasoning: 'URL contains /cars' };
  }
  if (urlPath.includes('/stays') || urlPath.includes('/hotel')) {
    return { project: 'STAYS', team: 'Stays & Packages', confidence: 0.95, reasoning: 'URL contains /stays or /hotel' };
  }
  if (urlPath.includes('/checkout') || urlPath.includes('/wallet') || urlPath.includes('/trips')) {
    return { project: 'CCG', team: 'Checkout & Growth', confidence: 0.95, reasoning: 'URL contains /checkout, /wallet, or /trips' };
  }

  // Keyword-based routing
  const keywords = {
    CAC: ['flight', 'airline', 'cfar', 'airport', 'car rental'],
    STAYS: ['hotel', 'property', 'room', 'accommodation', 'lodging'],
    CCG: ['payment', 'checkout', 'wallet', 'credit', 'loyalty', 'hopper cash'],
    COF: ['auth', 'login', 'session', 'config', 'sdk', 'tracking']
  };

  for (const [project, words] of Object.entries(keywords)) {
    const matchCount = words.filter(word => text.includes(word)).length;
    if (matchCount >= 2) {
      const matched = words.filter(w => text.includes(w)).join(', ');
      return {
        project,
        team: getTeamName(project),
        confidence: 0.85,
        reasoning: `Keywords: ${matched}`
      };
    }
  }

  // Default to Foundation
  return { project: 'COF', team: 'Foundation', confidence: 0.60, reasoning: 'No clear match, defaulting to Foundation' };
}

function getTeamName(project) {
  const teams = {
    CAC: 'Air & Cars',
    CCG: 'Checkout & Growth',
    COF: 'Foundation',
    STAYS: 'Stays & Packages'
  };
  return teams[project] || 'Foundation';
}

function calculatePriority(bug) {
  const text = `${bug.title} ${bug.description}`.toLowerCase();
  const criticalKeywords = ['down', 'outage', 'data loss', 'security', 'crash', 'cannot book', 'payment fails'];

  if (criticalKeywords.some(kw => text.includes(kw))) {
    return 'P0';
  }

  const priorityMap = {
    critical: 'P0',
    high: 'P1',
    medium: 'P2',
    low: 'P3'
  };

  return priorityMap[bug.severity] || 'P2';
}

const testCases = [
  {
    name: 'URL-based: Flight search',
    bug: {
      title: 'Search not working',
      description: 'Flight search returns no results',
      url: 'https://app.hopper.com/air/search',
      severity: 'high'
    },
    expected: { project: 'CAC', team: 'Air & Cars' }
  },
  {
    name: 'URL-based: Hotel booking',
    bug: {
      title: 'Images not loading',
      description: 'Hotel images not displaying',
      url: 'https://app.hopper.com/stays/hotel/12345',
      severity: 'medium'
    },
    expected: { project: 'STAYS', team: 'Stays & Packages' }
  },
  {
    name: 'URL-based: Checkout flow',
    bug: {
      title: 'Payment declined',
      description: 'Payment fails at checkout',
      url: 'https://app.hopper.com/checkout',
      severity: 'critical'
    },
    expected: { project: 'CCG', team: 'Checkout & Growth' }
  },
  {
    name: 'Keyword-based: CFAR claim',
    bug: {
      title: 'CFAR claim stuck',
      description: 'CFAR claim is stuck in pending status for my flight booking',
      url: null,
      severity: 'high'
    },
    expected: { project: 'CAC', team: 'Air & Cars' }
  },
  {
    name: 'Keyword-based: Hotel property',
    bug: {
      title: 'Room availability wrong',
      description: 'The hotel property shows available rooms but they are actually sold out',
      url: null,
      severity: 'medium'
    },
    expected: { project: 'STAYS', team: 'Stays & Packages' }
  },
  {
    name: 'Keyword-based: Payment and wallet',
    bug: {
      title: 'Wallet balance incorrect',
      description: 'My payment wallet shows wrong Hopper Cash balance after checkout',
      url: null,
      severity: 'high'
    },
    expected: { project: 'CCG', team: 'Checkout & Growth' }
  },
  {
    name: 'Default: Ambiguous bug',
    bug: {
      title: 'Generic error',
      description: 'I see an error message',
      url: null,
      severity: 'low'
    },
    expected: { project: 'COF', team: 'Foundation' }
  },
  {
    name: 'Priority: Critical keyword override',
    bug: {
      title: 'Service down',
      description: 'The entire flight search is down and users cannot book',
      url: 'https://app.hopper.com/air/search',
      severity: 'medium'
    },
    expectedPriority: 'P0'
  }
];

console.log('\n🧪 Testing Commerce Bug Routing Logic\n');
console.log('='.repeat(80));

let passed = 0;
let failed = 0;

testCases.forEach((test, index) => {
  console.log(`\nTest ${index + 1}: ${test.name}`);
  console.log('-'.repeat(80));

  const routing = simulateRouting(test.bug);
  const priority = calculatePriority(test.bug);

  console.log(`Input:`);
  console.log(`  Title: ${test.bug.title}`);
  console.log(`  Description: ${test.bug.description}`);
  console.log(`  URL: ${test.bug.url || '(none)'}`);
  console.log(`  Severity: ${test.bug.severity}`);

  console.log(`\nRouting Result:`);
  console.log(`  Project: ${routing.project}`);
  console.log(`  Team: ${routing.team}`);
  console.log(`  Confidence: ${(routing.confidence * 100).toFixed(0)}%`);
  console.log(`  Reasoning: ${routing.reasoning}`);
  console.log(`  Priority: ${priority}`);

  let testPassed = true;

  if (test.expected) {
    if (routing.project !== test.expected.project || routing.team !== test.expected.team) {
      console.log(`\n❌ FAILED: Expected ${test.expected.project} (${test.expected.team})`);
      testPassed = false;
      failed++;
    } else {
      console.log(`\n✅ PASSED`);
      passed++;
    }
  }

  if (test.expectedPriority) {
    if (priority !== test.expectedPriority) {
      console.log(`❌ FAILED: Expected priority ${test.expectedPriority}, got ${priority}`);
      testPassed = false;
      if (testPassed) failed++; // Only count once per test
    } else {
      console.log(`✅ PASSED (Priority)`);
      if (testPassed) passed++;
    }
  }
});

console.log('\n' + '='.repeat(80));
console.log(`\n📊 Results: ${passed} passed, ${failed} failed out of ${testCases.length} tests\n`);

if (failed === 0) {
  console.log('✅ All routing tests passed!\n');
  process.exit(0);
} else {
  console.log('❌ Some tests failed\n');
  process.exit(1);
}
