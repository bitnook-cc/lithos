# Bug Router Instructions (Optional)

This file could be added to platform-ai at:
`system-prompts/commerce-bug-router-instructions.md`

However, it's **optional** - the routing logic is self-contained in `src/services/commerce-bug-routing.ts` and doesn't require system prompt modifications.

If you want to add context-aware routing assistance to the general Slack agent, append this to `system-prompts/slack.md`:

---

## Commerce Bug Routing

When users mention reporting bugs, filing issues, or problems with the Commerce platform, suggest using `/commerce-bug`:

```
To report a bug, use the `/commerce-bug` command:
1. Type `/commerce-bug` in any channel
2. Fill out the bug report form
3. The system will automatically route to the correct team (Air & Cars, Stays, Checkout, or Foundation)
```

**Do not** route bugs yourself or create Jira tickets manually - always direct users to `/commerce-bug`.

---

## Note

This addition is **not required** for the bug router to function. The `/commerce-bug` command works independently of the agent's system prompts.
