# platform-ai PR Template

This directory contains complete code examples for adding the commerce bug router to platform-ai.

## Files Overview

| File | Destination in platform-ai | Purpose |
|------|----------------------------|---------|
| `src/routes/commerce-bug-router.ts` | `src/routes/commerce-bug-router.ts` | Slash command handler for `/commerce-bug` |
| `src/services/commerce-bug-routing.ts` | `src/services/commerce-bug-routing.ts` | Routing logic (URL + keywords + Claude AI) |
| `src/services/jira-bug.ts` | `src/services/jira-bug.ts` | Jira integration (duplicate detection, ticket creation) |
| `tests/commerce-bug-routing.test.ts` | `tests/commerce-bug-routing.test.ts` | Unit tests for routing logic |

## Usage

1. **Copy files to platform-ai**:
   ```bash
   cd platform-ai
   cp /path/to/hopper-ai-common/plugins/hopper-commerce/skills/commerce-bug-router/assets/platform-ai-pr-template/src/routes/commerce-bug-router.ts src/routes/
   cp /path/to/hopper-ai-common/plugins/hopper-commerce/skills/commerce-bug-router/assets/platform-ai-pr-template/src/services/commerce-bug-routing.ts src/services/
   cp /path/to/hopper-ai-common/plugins/hopper-commerce/skills/commerce-bug-router/assets/platform-ai-pr-template/src/services/jira-bug.ts src/services/
   cp /path/to/hopper-ai-common/plugins/hopper-commerce/skills/commerce-bug-router/assets/platform-ai-pr-template/tests/commerce-bug-routing.test.ts tests/
   ```

2. **Register route in `src/server.ts`**:
   ```typescript
   import bugRouter from './routes/commerce-bug-router';

   if (config.mode === 'slack') {
     app.use('/slack', slackRouter);
     app.use('/slack', bugRouter); // Add this line
   }
   ```

3. **Update TODOs in code**:
   - Replace `C_COMMERCE_BUGS` with actual #commerce-bugs channel ID
   - Implement Atlassian MCP calls (currently placeholders)
   - Add Slack message timestamp storage for webhook lookups

4. **Test locally**:
   ```bash
   npm test
   npm run dev
   ```

5. **Create PR**:
   ```bash
   git checkout -b feature/commerce-bug-router
   git add src/routes/commerce-bug-router.ts src/services/*.ts tests/*.ts src/server.ts
   git commit -m "feat: add /commerce-bug slash command for Commerce platform"
   gh pr create
   ```

## Integration Points

### Atlassian MCP Server

These functions use the Atlassian MCP server (already available in platform-ai):

- `createJiraIssue(payload)` - Create Jira ticket
- `searchJiraIssues(jql, options)` - Search for duplicates
- `setIssueProperty(key, propertyKey, value)` - Store Slack metadata
- `getIssueProperty(key, propertyKey)` - Retrieve Slack metadata

### Claude Agent SDK

These functions use the platform-ai agent:

- `query(prompt, context)` - Call Claude for classification, summary generation, keyword extraction

### Slack Web API

Uses `@slack/web-api` for:

- `slack.views.open()` - Open modal form
- `slack.chat.postMessage()` - Post to #commerce-bugs
- `slack.chat.postEphemeral()` - Notify reporter
- `slack.chat.update()` - Update message when bug resolved

## Testing

Run tests:
```bash
npm test -- bug-routing.test.ts
```

Test locally with ngrok:
```bash
ngrok http 7070
# Update Slack app URL to ngrok URL
# Test: /commerce-bug Payment fails
```

## Deployment

After PR is merged, automatic deployment via existing Harness pipeline.

## Resources

- **SKILL.md**: Full step-by-step implementation guide
- **Reference docs**: Architecture, routing logic, Jira webhooks, testing
- **Test cases**: `scripts/example-queries/route-test-cases.json`
