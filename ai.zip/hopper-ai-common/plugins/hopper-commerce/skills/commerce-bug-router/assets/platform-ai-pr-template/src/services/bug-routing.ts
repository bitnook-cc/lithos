/**
 * Bug Routing Service - Claude-based classification
 *
 * This file should be added to platform-ai at:
 * src/services/commerce-bug-routing.ts
 */

import { query } from '../agent';

export interface BugReport {
  title: string;
  description: string;
  url?: string;
  severity: 'critical' | 'high' | 'medium' | 'low';
  device?: string;
}

export interface RoutingResult {
  project: 'CAC' | 'CCG' | 'COF' | 'STAYS';
  team: string;
  confidence: number;
  reasoning: string;
}

/**
 * Route a bug report to the correct Jira project
 */
export async function routeBug(bug: BugReport): Promise<RoutingResult> {
  // Stage 1: Heuristic routing (URL patterns + keywords)
  const heuristicResult = heuristicRouting(bug);

  if (heuristicResult.confidence >= 0.80) {
    return heuristicResult;
  }

  // Stage 2: AI-powered routing for ambiguous cases
  return await classifyWithClaude(bug);
}

/**
 * Heuristic routing based on URL patterns and keywords
 */
function heuristicRouting(bug: BugReport): RoutingResult {
  const urlPath = bug.url ? new URL(bug.url).pathname : '';
  const text = `${bug.title} ${bug.description}`.toLowerCase();

  // 1. URL pattern matching (highest confidence)
  if (urlPath.includes('/air') || urlPath.includes('/flights')) {
    return {
      project: 'CAC',
      team: 'Air & Cars',
      confidence: 0.95,
      reasoning: 'URL contains /air or /flights'
    };
  }

  if (urlPath.includes('/cars')) {
    return {
      project: 'CAC',
      team: 'Air & Cars',
      confidence: 0.95,
      reasoning: 'URL contains /cars'
    };
  }

  if (urlPath.includes('/stays') || urlPath.includes('/hotel')) {
    return {
      project: 'STAYS',
      team: 'Stays & Packages',
      confidence: 0.95,
      reasoning: 'URL contains /stays or /hotel'
    };
  }

  if (urlPath.includes('/checkout') || urlPath.includes('/wallet') || urlPath.includes('/trips')) {
    return {
      project: 'CCG',
      team: 'Checkout & Growth',
      confidence: 0.95,
      reasoning: 'URL contains /checkout, /wallet, or /trips'
    };
  }

  // 2. Keyword matching (medium confidence)
  const keywords = {
    CAC: ['flight', 'airline', 'cfar', 'airport', 'baggage', 'seat', 'car rental', 'rental car'],
    STAYS: ['hotel', 'property', 'room', 'accommodation', 'lodging', 'vacation rental', 'check-in', 'check-out'],
    CCG: ['payment', 'checkout', 'wallet', 'credit', 'loyalty', 'hopper cash', 'refund', 'price freeze'],
    COF: ['auth', 'login', 'session', 'config', 'sdk', 'tracking', 'analytics', 'tenant', 'theme']
  };

  // Multiple keyword matches
  for (const [project, words] of Object.entries(keywords)) {
    const matchCount = words.filter(word => text.includes(word)).length;
    if (matchCount >= 2) {
      return {
        project: project as 'CAC' | 'CCG' | 'COF' | 'STAYS',
        team: getTeamName(project),
        confidence: 0.85,
        reasoning: `Keywords: ${words.filter(w => text.includes(w)).join(', ')}`
      };
    }
  }

  // Single keyword match
  for (const [project, words] of Object.entries(keywords)) {
    const match = words.find(word => text.includes(word));
    if (match) {
      return {
        project: project as 'CAC' | 'CCG' | 'COF' | 'STAYS',
        team: getTeamName(project),
        confidence: 0.70,
        reasoning: `Keyword: ${match}`
      };
    }
  }

  // 3. Default to low confidence - will trigger AI classification
  return {
    project: 'COF',
    team: 'Foundation',
    confidence: 0.50,
    reasoning: 'No clear match, needs AI classification'
  };
}

/**
 * Claude-based classification for ambiguous cases
 */
async function classifyWithClaude(bug: BugReport): Promise<RoutingResult> {
  const prompt = `You are a bug router for the Hopper Commerce platform. Given the bug report below, determine which team should handle it.

**Bug Report:**
Title: ${bug.title}
Description: ${bug.description}
URL: ${bug.url || 'N/A'}
Severity: ${bug.severity}

**Teams and their responsibilities:**

1. **Air & Cars (CAC)** - Flight search, booking, CFAR insurance, car rentals, airline partnerships
2. **Stays & Packages (STAYS)** - Hotel search, hotel booking, vacation rentals, property listings
3. **Checkout & Growth (CCG)** - Payment processing, wallet, trips dashboard, loyalty, Hopper Cash, price freeze
4. **Foundation (COF)** - Authentication, session management, SDKs, configuration, tracking, tenant management, design system, shared components

**Instructions:**
- Return ONLY valid JSON in this exact format: {"project": "CAC"|"CCG"|"COF"|"STAYS", "confidence": 0.0-1.0, "reasoning": "brief explanation"}
- Confidence should be 0.0 to 1.0
- If unsure, default to "COF" (Foundation) with low confidence

**Example:**
{"project": "CCG", "confidence": 0.92, "reasoning": "Payment failure during checkout flow"}`;

  try {
    const response = await query(prompt, { mode: 'cli' });

    // Parse JSON from response
    const jsonMatch = response.match(/\{.*\}/s);
    if (!jsonMatch) {
      throw new Error('No JSON found in response');
    }

    const result = JSON.parse(jsonMatch[0]);

    return {
      project: result.project,
      team: getTeamName(result.project),
      confidence: result.confidence,
      reasoning: result.reasoning
    };
  } catch (error) {
    console.error('Failed to parse Claude response:', error);
    // Default to Foundation
    return {
      project: 'COF',
      team: 'Foundation',
      confidence: 0.50,
      reasoning: 'Classification failed, defaulting to Foundation'
    };
  }
}

/**
 * Map project code to team name
 */
function getTeamName(project: string): string {
  const teams: Record<string, string> = {
    CAC: 'Air & Cars',
    CCG: 'Checkout & Growth',
    COF: 'Foundation',
    STAYS: 'Stays & Packages'
  };
  return teams[project] || 'Foundation';
}

/**
 * Calculate Jira priority based on severity and keywords
 */
export function calculatePriority(bug: BugReport, routing: RoutingResult): string {
  const text = `${bug.title} ${bug.description}`.toLowerCase();

  // Critical keywords override severity
  const criticalKeywords = ['down', 'outage', 'data loss', 'security', 'crash', 'cannot book', 'payment fails'];
  if (criticalKeywords.some(kw => text.includes(kw))) {
    return 'P0';
  }

  // Severity-based mapping
  const priorityMap: Record<string, string> = {
    critical: 'P0',
    high: 'P1',
    medium: 'P2',
    low: 'P3'
  };

  return priorityMap[bug.severity] || 'P2';
}
