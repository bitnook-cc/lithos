/**
 * Bug Router - Slack slash command handler for /commerce-bug
 *
 * This file should be added to platform-ai at:
 * src/routes/commerce-bug-router.ts
 */

import { Router, Request, Response } from 'express';
import crypto from 'node:crypto';
import { WebClient } from '@slack/web-api';
import { routeBug } from '../services/commerce-bug-routing';
import { createJiraTicket, detectDuplicate } from '../services/jira-bug';

const router = Router();
const slack = new WebClient(process.env.SLACK_BOT_TOKEN);

// Verify Slack request signature
function verifySlackRequest(req: Request): boolean {
  const signature = req.headers['x-slack-signature'] as string;
  const timestamp = req.headers['x-slack-request-timestamp'] as string;
  const body = JSON.stringify(req.body);

  // Prevent replay attacks (reject requests older than 5 minutes)
  if (Math.abs(Date.now() / 1000 - parseInt(timestamp)) > 60 * 5) {
    return false;
  }

  const sigBaseString = `v0:${timestamp}:${body}`;
  const mySignature = `v0=${crypto
    .createHmac('sha256', process.env.SLACK_SIGNING_SECRET!)
    .update(sigBaseString)
    .digest('hex')}`;

  return crypto.timingSafeEqual(
    Buffer.from(mySignature),
    Buffer.from(signature)
  );
}

// Build modal form for bug report
function buildBugModal(prefillText?: string) {
  return {
    type: 'modal',
    callback_id: 'bug_report_modal',
    title: {
      type: 'plain_text',
      text: 'Report a Bug'
    },
    submit: {
      type: 'plain_text',
      text: 'Submit'
    },
    close: {
      type: 'plain_text',
      text: 'Cancel'
    },
    blocks: [
      {
        type: 'input',
        block_id: 'title_block',
        label: {
          type: 'plain_text',
          text: 'Bug Title'
        },
        element: {
          type: 'plain_text_input',
          action_id: 'title',
          placeholder: {
            type: 'plain_text',
            text: 'Brief summary of the issue'
          },
          max_length: 150
        }
      },
      {
        type: 'input',
        block_id: 'description_block',
        label: {
          type: 'plain_text',
          text: 'Description'
        },
        element: {
          type: 'plain_text_input',
          action_id: 'description',
          multiline: true,
          placeholder: {
            type: 'plain_text',
            text: 'What happened? What did you expect to happen?'
          },
          initial_value: prefillText || ''
        }
      },
      {
        type: 'input',
        block_id: 'url_block',
        label: {
          type: 'plain_text',
          text: 'URL (optional)'
        },
        element: {
          type: 'url_text_input',
          action_id: 'url',
          placeholder: {
            type: 'plain_text',
            text: 'https://app.hopper.com/...'
          }
        },
        optional: true
      },
      {
        type: 'input',
        block_id: 'severity_block',
        label: {
          type: 'plain_text',
          text: 'Severity'
        },
        element: {
          type: 'static_select',
          action_id: 'severity',
          placeholder: {
            type: 'plain_text',
            text: 'Select severity'
          },
          options: [
            {
              text: { type: 'plain_text', text: 'Critical - Service down or data loss' },
              value: 'critical'
            },
            {
              text: { type: 'plain_text', text: 'High - Major feature broken' },
              value: 'high'
            },
            {
              text: { type: 'plain_text', text: 'Medium - Feature partially broken' },
              value: 'medium'
            },
            {
              text: { type: 'plain_text', text: 'Low - Cosmetic issue or minor bug' },
              value: 'low'
            }
          ],
          initial_option: {
            text: { type: 'plain_text', text: 'Medium - Feature partially broken' },
            value: 'medium'
          }
        }
      },
      {
        type: 'input',
        block_id: 'device_block',
        label: {
          type: 'plain_text',
          text: 'Device/Browser (optional)'
        },
        element: {
          type: 'plain_text_input',
          action_id: 'device',
          placeholder: {
            type: 'plain_text',
            text: 'e.g., iPhone 15, Safari 17.2'
          }
        },
        optional: true
      }
    ]
  };
}

// Handle /commerce-bug slash command
router.post('/commerce-bug', async (req: Request, res: Response) => {
  // 1. Verify request is from Slack
  if (!verifySlackRequest(req)) {
    console.warn('Invalid Slack signature for /commerce-bug command');
    return res.status(401).send('Unauthorized');
  }

  const { trigger_id, text } = req.body;

  // 2. Open modal (must respond within 3 seconds)
  try {
    await slack.views.open({
      trigger_id,
      view: buildBugModal(text)
    });

    // 3. Acknowledge slash command
    res.status(200).send();
  } catch (error) {
    console.error('Failed to open bug modal:', error);
    res.status(500).json({ error: 'Failed to open bug form' });
  }
});

// Handle modal submission
router.post('/interactions', async (req: Request, res: Response) => {
  const payload = JSON.parse(req.body.payload);

  if (payload.type !== 'view_submission') {
    return res.status(200).send();
  }

  if (payload.view.callback_id !== 'bug_report_modal') {
    return res.status(200).send();
  }

  // Extract form values
  const values = payload.view.state.values;
  const bugReport = {
    title: values.title_block.title.value,
    description: values.description_block.description.value,
    url: values.url_block?.url?.value || null,
    severity: values.severity_block.severity.selected_option.value as 'critical' | 'high' | 'medium' | 'low',
    device: values.device_block?.device?.value || null,
    reporterId: payload.user.id,
    reporterName: payload.user.name,
  };

  // Show loading state
  res.status(200).json({
    response_action: 'update',
    view: {
      type: 'modal',
      title: { type: 'plain_text', text: 'Processing...' },
      blocks: [
        {
          type: 'section',
          text: {
            type: 'mrkdwn',
            text: '⏳ Analyzing bug report and creating Jira ticket...'
          }
        }
      ]
    }
  });

  // Process bug report asynchronously
  processBugReport(bugReport).catch((error) => {
    console.error('Failed to process bug report:', error);
  });
});

// Process bug report
async function processBugReport(bug: any) {
  // 1. Route to team/project
  const routing = await routeBug(bug);

  // 2. Check for duplicates
  const duplicate = await detectDuplicate(bug, routing.project);
  if (duplicate) {
    await notifyDuplicate(bug, duplicate);
    return;
  }

  // 3. Create Jira ticket
  const jiraIssue = await createJiraTicket(bug, routing);

  // 4. Post to #commerce-bugs
  await slack.chat.postMessage({
    channel: 'C_COMMERCE_BUGS', // TODO: Replace with actual channel ID
    text: `🐛 New Bug: [${jiraIssue.key}] ${bug.title}`,
    blocks: buildBugNotification(bug, jiraIssue, routing)
  });

  // 5. Notify reporter
  await slack.chat.postEphemeral({
    channel: bug.channelId,
    user: bug.reporterId,
    text: `✅ Bug report created: ${jiraIssue.key}`
  });
}

// Build notification blocks
function buildBugNotification(bug: any, jiraIssue: any, routing: any) {
  return [
    {
      type: 'section',
      text: {
        type: 'mrkdwn',
        text: `🐛 *New Bug:* <https://hopper-jira.atlassian.net/browse/${jiraIssue.key}|${jiraIssue.key}> ${bug.title}\n\n*Reporter:* <@${bug.reporterId}>\n*Team:* ${routing.team} (${routing.project})\n*Priority:* ${jiraIssue.fields.priority.name}\n*Severity:* ${bug.severity}`
      }
    },
    {
      type: 'actions',
      elements: [
        {
          type: 'button',
          text: { type: 'plain_text', text: 'View in Jira' },
          url: `https://hopper-jira.atlassian.net/browse/${jiraIssue.key}`
        }
      ]
    }
  ];
}

// Notify about duplicate
async function notifyDuplicate(bug: any, duplicateKey: string) {
  await slack.chat.postEphemeral({
    channel: bug.channelId,
    user: bug.reporterId,
    text: `⚠️ This bug may be a duplicate of existing issue ${duplicateKey}`,
    blocks: [
      {
        type: 'section',
        text: {
          type: 'mrkdwn',
          text: `⚠️ *Possible Duplicate Found*\n\nYour bug report looks similar to <https://hopper-jira.atlassian.net/browse/${duplicateKey}|${duplicateKey}>.\n\nPlease check if this is the same issue before creating a new ticket.`
        }
      }
    ]
  });
}

export default router;
