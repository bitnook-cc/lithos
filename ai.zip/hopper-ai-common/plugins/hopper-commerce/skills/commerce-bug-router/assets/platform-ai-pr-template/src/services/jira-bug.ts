/**
 * Jira Bug Service - Ticket creation and duplicate detection
 *
 * This file should be added to platform-ai at:
 * src/services/jira-bug.ts
 */

import { query } from '../agent';
import type { BugReport, RoutingResult } from './commerce-bug-routing';
import { calculatePriority } from './commerce-bug-routing';

// NOTE: These functions use the Atlassian MCP server (already available in platform-ai)
// Import these from wherever you expose MCP tools:
// import { createJiraIssue, searchJiraIssues, setIssueProperty } from '../clients/jira';

/**
 * Detect if a similar bug already exists
 */
export async function detectDuplicate(bug: BugReport, project: string): Promise<string | null> {
  // 1. Generate search keywords with Claude
  const keywords = await generateSearchKeywords(bug);

  // 2. Search Jira with JQL
  const jql = `
    project = ${project}
    AND status NOT IN (Done, Resolved, Closed)
    AND (
      summary ~ "${keywords.slice(0, 5).join(' ')}"
      OR description ~ "${keywords.slice(0, 5).join(' ')}"
    )
    AND created >= -30d
  `;

  // TODO: Replace with actual Atlassian MCP call
  // const issues = await searchJiraIssues(jql, { maxResults: 10 });
  const issues: any[] = []; // Placeholder

  if (issues.length === 0) {
    return null;
  }

  // 3. Calculate similarity scores
  for (const issue of issues) {
    const similarity = calculateSimilarity(bug.description, issue.fields.description);

    if (similarity > 0.70) {
      console.log(`Found duplicate: ${issue.key} (similarity: ${similarity.toFixed(2)})`);
      return issue.key;
    }
  }

  return null;
}

/**
 * Generate search keywords using Claude
 */
async function generateSearchKeywords(bug: BugReport): Promise<string[]> {
  const prompt = `Extract 5-10 search keywords from this bug report:

Title: ${bug.title}
Description: ${bug.description}

Return ONLY a JSON array of keywords (no extra text):
["keyword1", "keyword2", ...]`;

  try {
    const response = await query(prompt, { mode: 'cli' });
    const jsonMatch = response.match(/\[.*\]/s);
    return jsonMatch ? JSON.parse(jsonMatch[0]) : [bug.title.split(' ')[0]];
  } catch (error) {
    console.error('Failed to generate search keywords:', error);
    // Fallback: use title words
    return bug.title.toLowerCase().split(/\s+/).slice(0, 5);
  }
}

/**
 * Calculate similarity between two text strings (simple word overlap)
 */
function calculateSimilarity(text1: string, text2: string): number {
  const words1 = new Set(text1.toLowerCase().split(/\s+/));
  const words2 = new Set(text2.toLowerCase().split(/\s+/));

  const intersection = new Set([...words1].filter(w => words2.has(w)));
  const union = new Set([...words1, ...words2]);

  return intersection.size / union.size;
}

/**
 * Generate AI summary in Jira format
 */
export async function generateJiraSummary(bug: BugReport): Promise<string> {
  const prompt = `Convert this bug report into a structured format for Jira:

**Bug Report:**
Title: ${bug.title}
Description: ${bug.description}
URL: ${bug.url || 'N/A'}
Severity: ${bug.severity}
Device: ${bug.device || 'N/A'}

**Required format:**

h3. Steps to Reproduce
# Step 1
# Step 2
# Step 3

h3. Expected Behavior
What should happen

h3. Actual Behavior
What actually happens

h3. Environment
* URL: ${bug.url || 'N/A'}
* Device: ${bug.device || 'Unknown'}
* Severity: ${bug.severity}

If Steps to Reproduce are not clear from the description, infer reasonable steps based on the URL and description.`;

  try {
    const response = await query(prompt, { mode: 'cli' });
    return response.trim();
  } catch (error) {
    console.error('Failed to generate Jira summary:', error);
    // Fallback: basic format
    return `h3. Description\n\n${bug.description}\n\nh3. Environment\n* URL: ${bug.url || 'N/A'}\n* Device: ${bug.device || 'Unknown'}\n* Severity: ${bug.severity}`;
  }
}

/**
 * Create Jira ticket
 */
export async function createJiraTicket(bug: BugReport, routing: RoutingResult): Promise<any> {
  const summary = await generateJiraSummary(bug);
  const priority = calculatePriority(bug, routing);

  // TODO: Replace with actual Atlassian MCP call
  // const issue = await createJiraIssue({
  //   fields: {
  //     project: { key: routing.project },
  //     issuetype: { name: 'Bug' },
  //     summary: bug.title.slice(0, 255), // Jira summary max length
  //     description: summary,
  //     priority: { name: priority },
  //     labels: ['source:bug-router', `severity:${bug.severity}`]
  //   }
  // });

  // Placeholder
  const issue = {
    key: `${routing.project}-123`,
    id: '12345',
    fields: {
      summary: bug.title,
      priority: { name: priority }
    }
  };

  console.log(`Created Jira ticket: ${issue.key}`);

  // Store Slack metadata in issue property for webhook lookups
  // TODO: Implement this once we have Slack message timestamp
  // await setIssueProperty(issue.key, 'slack-metadata', {
  //   channelId: slackChannelId,
  //   messageTs: slackMessageTs,
  //   reporterUserId: bug.reporterId,
  //   reportedAt: new Date().toISOString()
  // });

  return issue;
}
