/**
 * Bug Routing Tests
 *
 * This file should be added to platform-ai at:
 * tests/commerce-bug-routing.test.ts
 */

import { routeBug, calculatePriority } from '../src/services/commerce-bug-routing';
import type { BugReport } from '../src/services/commerce-bug-routing';

describe('Bug Routing', () => {
  describe('URL-based routing', () => {
    it('routes /air bugs to CAC', async () => {
      const bug: BugReport = {
        title: 'Flight search broken',
        description: 'Search returns empty',
        url: 'https://app.hopper.com/air/search',
        severity: 'high'
      };

      const result = await routeBug(bug);

      expect(result.project).toBe('CAC');
      expect(result.team).toBe('Air & Cars');
      expect(result.confidence).toBeGreaterThanOrEqual(0.95);
    });

    it('routes /stays bugs to STAYS', async () => {
      const bug: BugReport = {
        title: 'Hotel search broken',
        description: 'No results for NYC',
        url: 'https://app.hopper.com/stays/search?city=NYC',
        severity: 'medium'
      };

      const result = await routeBug(bug);

      expect(result.project).toBe('STAYS');
      expect(result.team).toBe('Stays & Packages');
      expect(result.confidence).toBeGreaterThanOrEqual(0.95);
    });

    it('routes /checkout bugs to CCG', async () => {
      const bug: BugReport = {
        title: 'Payment fails',
        description: 'Credit card declined',
        url: 'https://app.hopper.com/checkout',
        severity: 'critical'
      };

      const result = await routeBug(bug);

      expect(result.project).toBe('CCG');
      expect(result.team).toBe('Checkout & Growth');
      expect(result.confidence).toBeGreaterThanOrEqual(0.95);
    });
  });

  describe('Keyword-based routing', () => {
    it('routes flight keywords to CAC', async () => {
      const bug: BugReport = {
        title: 'CFAR claim not processing',
        description: 'Flight protection claim stuck for booking ABC123',
        severity: 'high'
      };

      const result = await routeBug(bug);

      expect(result.project).toBe('CAC');
      expect(result.confidence).toBeGreaterThanOrEqual(0.70);
    });

    it('routes payment keywords to CCG', async () => {
      const bug: BugReport = {
        title: 'Hopper Cash not applied',
        description: 'Wallet balance shows $50 but not deducted at checkout',
        severity: 'medium'
      };

      const result = await routeBug(bug);

      expect(result.project).toBe('CCG');
      expect(result.confidence).toBeGreaterThanOrEqual(0.70);
    });
  });

  describe('Default routing', () => {
    it('defaults to COF for unclear bugs', async () => {
      const bug: BugReport = {
        title: 'Page not loading',
        description: 'Generic error message shown',
        severity: 'low'
      };

      const result = await routeBug(bug);

      expect(result.project).toBe('COF');
      expect(result.confidence).toBeLessThan(0.80);
    });
  });

  describe('Priority calculation', () => {
    it('assigns P0 for critical severity', () => {
      const bug: BugReport = {
        title: 'Service down',
        description: 'Cannot access app',
        severity: 'critical'
      };

      const routing = { project: 'COF' as const, team: 'Foundation', confidence: 0.95, reasoning: 'test' };
      const priority = calculatePriority(bug, routing);

      expect(priority).toBe('P0');
    });

    it('assigns P0 for critical keywords', () => {
      const bug: BugReport = {
        title: 'Payment fails',
        description: 'Cannot book flights, payment always fails',
        severity: 'medium' // User says medium, but keywords override
      };

      const routing = { project: 'CCG' as const, team: 'Checkout & Growth', confidence: 0.95, reasoning: 'test' };
      const priority = calculatePriority(bug, routing);

      expect(priority).toBe('P0'); // Overridden by "payment fails" keyword
    });

    it('assigns P2 for medium severity', () => {
      const bug: BugReport = {
        title: 'Button misaligned',
        description: 'Cosmetic issue on search page',
        severity: 'medium'
      };

      const routing = { project: 'CAC' as const, team: 'Air & Cars', confidence: 0.95, reasoning: 'test' };
      const priority = calculatePriority(bug, routing);

      expect(priority).toBe('P2');
    });
  });
});
