# Commerce Transactional Data Reference

Use these data sources for root cause analysis when investigating significant metric changes.
These tables provide transactional-level detail beyond what the consolidated finance tables offer.

## Tenant ID Mapping

When switching from finance tables to transactional tables, map the tenant name:

| Finance `tenant` | Transactional `tenant_id` |
|---|---|
| CommBank | commbank-au |
| Virgin Australia - Stays | virgin-au |
| SMCC | smcc |
| HSBC | hsbc-sg, hsbc-in, hsbc-qa, hsbc-uae (multiple tenants) |
| Hopper-App | hopper-app |
| TripAdvisor | tripadvisor |
| NuBank | nubank |
| Uber | uber |
| Lloyds | lloyds |
| MVW | marriott-vc |
| Perkspot | perkspot |
| Lotte | lotte |

---

## Data Sources

### 1. Frontend Events

`gcp-hopper-etldata-production.casablanca.frontend_events`

Captures all user interaction events from web and mobile platforms.

**Key Fields:**
- `name` - Event name (e.g., 'hotel_entry', 'hotel_tapped_entry', 'hotel_complete_buy', 'air_entry', 'complete_buy_air', 'cars_entry', 'complete_buy_car')
- `user_id`, `session_id` - User/session identifiers
- `ts` - Timestamp
- `extra_properties` - JSON field with metadata
  - `$.tenant` - Tenant identifier (extract with `JSON_VALUE(extra_properties, '$.tenant')`)

**Common Events:**
- `launched_application` - App/website opened
- `hotel_entry` or `hotel_tapped_entry` - User initiated hotel search
- `hotel_complete_buy` - User completed hotel booking
- `air_entry` - User initiated flight search
- `complete_buy_air` - User completed flight booking
- `cars_entry` - User initiated car search
- `complete_buy_car` - User completed car rental

**Frontend Event Mapping by Tenant:**

Different tenants use different event names. Use the correct events when querying:

| Event Type | Hopper-App | TripAdvisor | All Other B2B Partners |
|---|---|---|---|
| App Launch | `launched_app` | `launched_app` | `launched_application` |
| Air Search | `air_tapped_entry` + `air_entry` | N/A (no search events) | `air_entry` |
| Air Booking | `complete_buy_air` | N/A | `complete_buy_air` |
| Hotel Search | `hotel_tapped_entry` + `hotel_entry` | N/A (no search events) | `hotel_entry` |
| Hotel Booking | `hotel_complete_buy` | `hotel_complete_buy` | `hotel_complete_buy` |
| Car Search | `cars_entry` | N/A | `cars_entry` |
| Car Booking | `complete_buy_car` | N/A | `complete_buy_car` |

**Important notes:**
- For **Hopper-App**: Use `launched_app` (NOT `launched_application`), and include both `air_tapped_entry` + `air_entry` for air searchers and both `hotel_tapped_entry` + `hotel_entry` for hotel searchers. The `tapped_entry` events capture 5-10x more users than `entry` events.
- For **booking events**: Always filter `JSON_VALUE(extra_properties, '$.success') = 'true'` to count only successful bookings.
- For **TripAdvisor**: Only `hotel_complete_buy` events are available. No search or app launch events are tracked.

### 2. Hotel Bookings

`h4r-common-lodging-bi-prd.wholeco__fulfillment__gld.fact_lodging_bookings_with_revenue`

**Key Fields:**
- **Identifiers**: `reservation_id`, `booking_session_id`, `user_id`, `lodging_id`, `tenant_id`
- **Dates**: `booked_at_datetime`, `check_in_date`, `check_out_date`
- **Financial**: `sell_gbv` (what customer pays), `total_provider_revenue` (what Hopper earns), `sell_adr` (avg daily rate)
- **Categorization**: `channel` (web/ios/android), `lodging_provider`
- **Status**: `reservation_status`, `cancelled_at_date`, `is_refundable`, `nth_bookings`
- **Stay details**: `length_of_stay`, `booking_advance`

**Notes:**
- Use `tenant_id` to filter by partner
- `reservation_status = 'completed'` for travelled bookings

### 3. Hotel Dimensions

**Gold:** `h4r-common-lodging-bi-prd.supply__gld.dim_lodgings`
- `lodging_id`, `lodging_name`, `country_name`, `city_name`, `chain_name`
- Always filter `is_active_version = TRUE`

**SCD:** `h4r-common-lodging-bi-prd.supply__slv.dim_lodgings_junk_scd`
- `lodging_id`, `market_name`, `star_rating`, `sf_is_key_account`, `contracted_status`
- Always filter `is_current = TRUE`

### 4. Flight Bookings

`gcp-hopper-etldata-production.warehouse.tickets_with_revenue`

**Key Fields:**
- **Identifiers**: `user_id`, `tenant_id`, `session_id`
- **Dates**: `booking_date`, `departure_date`, `return_date`
- **Financial**: `selling_gbv` (what customer pays)
- **Flight details**: `trip_type`, `ticket_provider`, `validating_carrier`, `origin_code`, `destination_code`
- **Status**: `cancel_status`, `nth_bookings`

### 5. Car Rentals

`gcp-hopper-etldata-production.warehouse.car_bookings_facts`

**Key Fields:**
- **Identifiers**: `hopper_user_id`, `tenant_id`, `hopper_session_id`
- **Dates**: `transaction_date`, `pick_up_date`, `drop_off_date`
- **Financial**: `total_price_usd` (what customer pays)
- **Details**: `pick_up_country`, `pick_up_city`, `pay_type`, `provider`, `brand`

### 6. Package Bookings

`h4r-common-bi-prd.package_shopping_cart__slv.package_reservations`

**Key Fields:**
- `user_id`, `tenant_id`, `lodging_customer_confirmation_id`, `flight_reservation_id`
- `created_at`, `start_date`, `end_date`, `status`

### 7. Marketing Offers & Campaigns

`gcp-hopper-etldata-production.warehouse.uou_offers_ledger`

Tracks the full lifecycle of marketing offers/promotions (create → confirm/claim → redeem/expire/cancel). Use this table to analyze campaign performance, redemption rates, and the revenue impact of promotions.

**Key Fields:**
- **Identifiers**: `user_id`, `offer_id`, `offer_name`, `tenant`
- **Lifecycle**: `action` (`create`, `confirm`, `redeem`, `expire`, `cancel`), `action_ts`
- **Financial**: `offer_amount`, `offer_currency`, `offer_amount_usd`, `redeemed_offer_amount`, `redeemed_offer_amount_usd`
- **Offer details**: `offer_kind`, `offer_type`, `offer_percentage_discount`, `expiration_dt_utc`
- **Booking linkage**: `reservation_id`, `ground_booking_id`, `agent_locator`, `redeemed_product`
- **Provenance**: `creation_reason`, `creation_user_team`, `creation_user_name`, `action_reason`
- **Applicability**: `applicability_string`, `is_lodging`, `is_air`

**Important Notes:**
- Use `tenant` (NOT `tenant_id`) to filter by partner
- Offer lifecycle: `create` → `confirm` (user claims) → `redeem` (used on booking) or `expire`/`cancel`
- Join on `reservation_id` to link redeemed offers to hotel bookings
- Join on `user_id` to connect offer recipients to their booking behavior
- `offer_name` contains the campaign name (e.g., "HTS Promotion: Offer Wallet 50 Aud Off Feb 2026")

---

## Example Query Patterns

### Conversion Rate (Hotels)

```sql
WITH users AS (
  SELECT
    COUNT(DISTINCT CASE WHEN name IN ('hotel_entry','hotel_tapped_entry') THEN user_id END) AS unique_searchers,
    COUNTIF(name = 'hotel_complete_buy') AS bookings
  FROM `gcp-hopper-etldata-production.casablanca.frontend_events`
  WHERE ts >= TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 30 DAY)
    AND JSON_VALUE(extra_properties, '$.tenant') = '{tenant_id}'
)
SELECT unique_searchers, bookings,
  ROUND(SAFE_DIVIDE(bookings, unique_searchers) * 100, 2) AS conversion_rate_pct
FROM users
```

### GBV by Vertical

```sql
SELECT tenant_id, 'hotels' AS vertical,
  COUNT(DISTINCT booking_session_id) AS total_bookings,
  SUM(sell_gbv) AS total_gbv,
  SUM(sell_gbv)/COUNT(DISTINCT booking_session_id) AS aov
FROM `h4r-common-lodging-bi-prd.wholeco__fulfillment__gld.fact_lodging_bookings_with_revenue`
WHERE DATE(booked_at_datetime) >= DATE_SUB(CURRENT_DATE(), INTERVAL 30 DAY)
  AND tenant_id = '{tenant_id}'
GROUP BY tenant_id
UNION ALL
SELECT tenant_id, 'air' AS vertical,
  COUNT(DISTINCT session_id) AS total_bookings,
  SUM(selling_gbv) AS total_gbv,
  SUM(selling_gbv)/COUNT(DISTINCT session_id) AS aov
FROM `gcp-hopper-etldata-production.warehouse.tickets_with_revenue`
WHERE DATE(booking_date) >= DATE_SUB(CURRENT_DATE(), INTERVAL 30 DAY)
  AND tenant_id = '{tenant_id}'
GROUP BY tenant_id
UNION ALL
SELECT tenant_id, 'cars' AS vertical,
  COUNT(DISTINCT hopper_session_id) AS total_bookings,
  SUM(total_price_usd) AS total_gbv,
  SUM(total_price_usd)/COUNT(DISTINCT hopper_session_id) AS aov
FROM `gcp-hopper-etldata-production.warehouse.car_bookings_facts`
WHERE DATE(transaction_date) >= DATE_SUB(CURRENT_DATE(), INTERVAL 30 DAY)
  AND tenant_id = '{tenant_id}'
GROUP BY tenant_id
```

### Monthly Booking Trend (Hotels)

```sql
SELECT
  FORMAT_DATETIME('%Y-%m', booked_at_datetime) AS booking_month,
  COUNT(DISTINCT booking_session_id) AS total_bookings,
  COUNT(DISTINCT user_id) AS unique_bookers,
  SUM(sell_gbv) AS total_gbv,
  SUM(sell_gbv)/COUNT(DISTINCT booking_session_id) AS aov,
  AVG(sell_adr) AS adr,
  AVG(length_of_stay) AS avg_los,
  AVG(booking_advance) AS avg_booking_advance,
  SUM(total_provider_revenue) AS total_revenue
FROM `h4r-common-lodging-bi-prd.wholeco__fulfillment__gld.fact_lodging_bookings_with_revenue`
WHERE tenant_id = '{tenant_id}'
  AND DATE(booked_at_datetime) >= DATE_SUB(CURRENT_DATE(), INTERVAL 12 MONTH)
GROUP BY booking_month
ORDER BY booking_month DESC
```

### Geographic Performance (Hotels)

```sql
SELECT
  d.country_name, j.market_name,
  COUNT(DISTINCT f.booking_session_id) AS bookings,
  SUM(f.sell_gbv) AS total_gbv,
  AVG(f.sell_adr) AS avg_adr,
  SUM(f.total_provider_revenue) AS total_revenue
FROM `h4r-common-lodging-bi-prd.wholeco__fulfillment__gld.fact_lodging_bookings_with_revenue` f
JOIN `h4r-common-lodging-bi-prd.supply__gld.dim_lodgings` d ON f.lodging_id = d.lodging_id
JOIN `h4r-common-lodging-bi-prd.supply__slv.dim_lodgings_junk_scd` j ON f.lodging_id = j.lodging_id AND j.is_current = TRUE
WHERE f.tenant_id = '{tenant_id}'
  AND DATE(f.booked_at_datetime) >= DATE_SUB(CURRENT_DATE(), INTERVAL 30 DAY)
GROUP BY d.country_name, j.market_name
ORDER BY bookings DESC
LIMIT 100
```

### Campaign Performance (Offer Funnel)

```sql
SELECT
  offer_name,
  COUNTIF(action = 'create') AS offers_created,
  COUNTIF(action = 'confirm') AS offers_claimed,
  COUNTIF(action = 'redeem') AS offers_redeemed,
  COUNTIF(action = 'expire') AS offers_expired,
  ROUND(SAFE_DIVIDE(COUNTIF(action = 'redeem'), COUNTIF(action = 'confirm')) * 100, 2) AS redemption_rate_pct,
  SUM(CASE WHEN action = 'redeem' THEN redeemed_offer_amount_usd ELSE 0 END) AS total_redeemed_usd
FROM `gcp-hopper-etldata-production.warehouse.uou_offers_ledger`
WHERE action_ts >= TIMESTAMP('{start_date}')
  AND tenant = '{tenant_id}'
GROUP BY offer_name
ORDER BY offers_created DESC
```

---

## Important Field Differences

**Tenant Identifier:**
- `frontend_events`: `JSON_VALUE(extra_properties, '$.tenant')`
- Booking tables: `tenant_id` (direct column)

**Revenue Fields (Hotel bookings):**
- `sell_gbv` = What customer pays (GBV)
- `total_provider_revenue` = What Hopper earns (commission + markup)

## Best Practices

- Always filter by date to avoid full table scans
- Use `SAFE_DIVIDE` to avoid division by zero
- Use `FORMAT_DATETIME('%Y-%m', booked_at_datetime)` for monthly aggregation
- Exclude cancelled bookings with `cancelled_at_date IS NULL` when needed
