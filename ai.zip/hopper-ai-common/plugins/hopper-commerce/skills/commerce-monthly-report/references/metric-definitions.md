# Metric Definitions

Exact definitions for all metrics used in commerce monthly reports. These are deterministic — do not deviate from these formulas.

## Overall Metrics

| Metric | Definition | Formula |
|---|---|---|
| MAUs | Monthly Active Users | `SUM(amount) WHERE account_category = 'Metrics' AND Line_of_Business = 'Total' AND Account_SubCategory = 'MAUs'` |
| Bookings | Total bookings across all LoB | `SUM(amount) WHERE account_category = 'Metrics' AND Account_SubCategory = 'Bookings'` |
| Conversion Rate (CVR) | Bookings as percentage of MAUs | `Bookings / MAUs * 100` |
| GBV | Gross Booking Value — what customers pay | `SUM(amount) WHERE account_category = 'Metrics' AND Account_SubCategory = 'GBV'` |
| Gross Revenue (GR) | Revenue earned by Hopper | `SUM(amount) WHERE account_category = 'Gross Revenue'` |
| Gross Revenue Take Rate (GR TR) | Gross Revenue as percentage of GBV | `Gross Revenue / GBV * 100` |
| Gross Profit (GP) | Revenue minus cost of revenue | `SUM(amount) WHERE account_category = 'Gross Profit'` |
| Contribution Profit (CP) | Gross Profit minus variable costs | `SUM(amount) WHERE account_category = 'Contribution Profit'` |
| CP Take Rate (CP TR) | Contribution Profit as percentage of GBV | `Contribution Profit / GBV * 100` |

## Percentage Change Formula

For all MoM and AvF percentage changes, use:

```
% Change = (Current - Previous) / ABS(Previous) * 100
```

Use `SAFE_DIVIDE` in BigQuery to handle zero denominators. Use `ABS(Previous)` in the denominator to ensure correct sign when the previous value is negative.

**Special cases:**
- If previous value is 0 or NULL: report as "N/A"
- If metric crosses from positive to negative (or vice versa): report as "N/A" for the percentage, but still show absolute values

## Line of Business Breakdown Metrics

Per-LoB metrics use the same formulas as overall metrics, but grouped by `Line_of_Business` and excluding `Line_of_Business IN ('Total', '*')`.

**Per-LoB MAUs**: Use `Account_SubCategory = 'MAUs'` WITHOUT `Line_of_Business = 'Total'` filter. Each LoB has its own MAU count.

**Per-LoB CVR**: `LoB Bookings / LoB MAUs * 100`

## Actuals vs Forecast

Both actuals and forecast data come from `h4r-common-bi-prd.hts_finance_data__gld.fact_consolidated_wholeco_public`.

| Concept | Actuals | Forecast |
|---|---|---|
| Version filter | `version = 'RunRate'` | `version = 'Base'` (default) or `'Upside'` |
| Metrics (MAUs, Bookings, GBV) | No entity filter needed | `Entity = 'HTS'` required (avoids duplicate rows across `actualized` values) |
| Financial categories (GR, GP, CP) | No extra filter | No extra filter |

The `Entity = 'HTS'` filter on Metrics in the forecast CTE is required because Metrics rows are duplicated across `actualized = '-'` and `actualized = 'N'` for most tenants. Financial rows (Gross Revenue, Contribution Profit, etc.) use different `actualized` values for different line items and should NOT be filtered by `actualized`.

## Standard Filters

Applied to both actuals and forecast via the shared `base` CTE:

```sql
AND Tenant NOT IN ('Santander (ES/MX)','Woori','Banorte','Flair','Forward Dist','HTS Assist','Nequi','Marriott','Capital One')
AND Amount != 0 AND Amount IS NOT NULL
AND Distribution_Channel NOT IN ('Fintech Ancillary', '3P', 'Audiences', 'API')
AND Sub_Entity != 'Assist'
AND (
  Intercompany = 'F'
  OR (Tenant = 'Hopper-App' AND Account_Subcategory = 'MAUs' AND Intercompany = 'T')
)
```

The SQL templates filter to the relevant tenants via the `WHERE ... IN (...)` tenant inclusion list in the final SELECT. The tenant inclusion list in the skill (see SKILL.md "Commerce Partner Tenants") is the source of truth — no separate exclusion list is needed in the SQL.

## Data Transformations

The SQL templates apply these transformations via a `base` CTE before aggregation. These align with the canonical reporting query.

### Payment Processing & Fraud entity reassignment

`Payment Processing & Fraud` rows are reassigned from `HTS` to `Hopper Travel` entity, **except** for:
- Tenants: RBC, Perkspot, Yahoo, Gilded, HSBC-UAE, HSBC-QA (always keep original entity)
- CommBank and NuBank from 2026-01-01 onward (keep original entity)

### Profit Share reclassification

`Contra Revenue` rows with `Account_SubCategory = 'Profit Share'` for `Hopper Travel` entity are reclassified as `OPEX`. This prevents Profit Share from reducing Net Revenue / Gross Profit for Hopper Travel.

### Consumer MAU → Commerce reassignment

`Sub_Entity = 'Consumer'` rows with `Account_Category = 'Metrics'` and `Account_SubCategory = 'MAUs'` (RunRate version only) are reassigned to `Sub_Entity = 'Commerce'`.

### Account subcategory rename

`Account_SubCategory = 'Payments'` is renamed to `'Payment'` for consistency.

## Formatting Standards

| Type | Format | Example |
|---|---|---|
| Currency | `$` with commas, no decimals | `$1,234,567` |
| Percentages | 1 decimal place with sign | `+12.3%`, `-4.5%` |
| Take rates | 2 decimal places with sign | `+2.40%` |
| Large numbers (MAUs) | Commas, no decimals | `1,065,127` |
| Negative CP | Flag as concern in summary | `-$73,882` |
