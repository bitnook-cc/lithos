---
name: commerce-monthly-report
description: >
  Generate monthly commerce partner performance reports as Google Docs. Use when asked to
  create a "monthly report", "commerce report", "partner report", compare "month over month",
  "actuals vs forecast", or investigate metric changes for commerce partners like
  CommBank, Virgin AU, SMCC, HSBC, NuBank, Uber, Lloyds, Lotte, MVW, Perkspot, or TripAdvisor.
allowed-tools: mcp__bigquery__execute_sql, mcp__google-workspace__search_drive_files, mcp__google-workspace__list_drive_items, mcp__google-workspace__create_drive_folder, mcp__google-workspace__import_to_google_doc, mcp__google-workspace__update_drive_file, mcp__google-workspace__batch_update_doc, mcp__google-workspace__inspect_doc_structure
---

# Commerce Monthly Report

Generate a monthly performance report for commerce partners, saved as Google Docs.

## Bundled Resources

| Resource | Purpose |
|---|---|
| `scripts/sql/mom_overall.sql` | MoM overall comparison query — read, substitute parameters, execute via BigQuery MCP |
| `scripts/sql/mom_lob.sql` | MoM line-of-business breakdown query |
| `scripts/sql/avf_overall.sql` | Actual vs Forecast overall comparison query |
| `references/metric-definitions.md` | Exact metric definitions, formulas, formatting standards, and table differences |
| `references/commerce-data-reference.md` | Transactional data sources for deep dive investigations |
| `assets/report-template.md` | Markdown template for the Google Doc output — substitute placeholders with query results |
| `channel-slack-update/authorized-users.yaml` | Slack User ID → tenant authorization mapping (shared with [channel-slack-update](hopper-commerce:channel-slack-update)) |

## Workflow

When the user says something like "generate the monthly commerce report for March 2026 for CommBank and NuBank":

1. Parse the **report month** (e.g., March 2026 → `current_month = '2026-03-01'`, `previous_month = '2026-02-01'`) and **tenant list**
2. Authorize the user (Step 0)
3. For **each authorized tenant** (sequentially, one at a time), run queries and generate the report

### Step 0: Authorize Tenant Access

Before running any query, verify the requesting user is authorized:

1. **Read** `channel-slack-update/authorized-users.yaml` from the sibling skill's resources
2. Get the requesting user's Slack ID from `<slack-context>`
3. For each requested tenant:
   a. If user is in `leadership` → allow
   b. If user is in `per_tenant.{requested_tenant}` → allow
   c. Otherwise → skip that tenant
4. If **all** tenants were skipped → reject with:
   `"You don't have access to financial data for {tenants}. Contact #commerce-partner-ops for access."`
5. If **some** tenants were skipped → proceed with allowed tenants and notify:
   `"You have access to {allowed}. Skipping {skipped} — you're not authorized for those tenants."`
6. If all tenants allowed → proceed normally

### Step 1: Run Queries

Read the SQL templates from `scripts/sql/`, substitute the parameters, and execute via `mcp__bigquery__execute_sql`:

1. **Read** `scripts/sql/mom_overall.sql` → replace `@PREVIOUS_MONTH` and `@CURRENT_MONTH` with quoted date literals (e.g., `'2026-02-01'`) → execute
2. **Read** `scripts/sql/mom_lob.sql` → replace `@PREVIOUS_MONTH`, `@CURRENT_MONTH`, `@TENANT_NAME` with quoted literals → execute. If only one LoB returned, skip LoB tables.
3. **Read** `scripts/sql/avf_overall.sql` → replace `@REPORT_MONTH` with quoted date literal → execute
4. Check if any MoM metric has >20% change. If yes, run deep dive queries per Step 3 below.

### Step 2: Generate Google Doc

**Prerequisites:** Requires the **Google Workspace MCP server** ([setup instructions](https://github.com/taylorwilsdon/google_workspace_mcp)). Use the **user's Google Workspace email** for all calls — ask if not known.

**Parent folder ID:** `1JNclFzgQSlaIbLzP75g5tWQC_Br8AZ9L`

1. **Check/create month folder** — search for folder named `"{Month YYYY}"` under parent. Create if missing.
2. **Check for existing doc** — search for `"Monthly Commerce Report - {Tenant} - {Mon YYYY}"` in month folder. Trash if found.
3. **Read** `assets/report-template.md` and substitute all `{placeholders}` with query results, applying formatting per `references/metric-definitions.md`.
4. **Import** the filled markdown as a Google Doc:
   ```
   mcp__google-workspace__import_to_google_doc(file_name=..., source_format="md", folder_id=..., content=...)
   ```
5. **Apply font** — inspect doc structure to get `total_length`, then apply Proxima Nova globally (font family only, no font_size):
   ```
   {"type": "format_text", "start_index": 1, "end_index": {total_length - 1}, "font_family": "Proxima Nova"}
   ```

**IMPORTANT:** Use `import_to_google_doc` instead of `create_doc` + `create_table_with_data`. The import converts markdown tables in a single API call, avoiding the 60 writes/min rate limit.

### Step 3: Deep Dive (MoM Changes Only)

Trigger when any MoM metric has >20% change. Do NOT trigger from Actual vs Forecast variance. The 20% threshold is an internal trigger — do not mention it in the report.

**The deep dive MUST be data-driven.** Read `references/commerce-data-reference.md` for available transactional tables and query patterns. Run queries BEFORE writing the analysis. Do NOT write narrative based solely on finance table numbers.

**Required investigation queries** (adapt to the tenant and time period):

1. **Weekly booking trends** — bookings, GBV, AOV, ADR, LOS, booking advance over past 3 months
2. **Provider/channel mix** — bookings, GBV, revenue, margin % by provider and channel for both months
3. **Geographic performance** — bookings and GBV by country for both months
4. **Frontend conversion funnel** (if available) — check `references/commerce-data-reference.md` for tenant-specific event names

**Write findings based on actual data:** each finding should reference specific numbers. Structure around: what changed, when it changed (weekly trends), why it matters (sustainable or one-time).

### Report Content Rules

- **Summary** comes first — brief narrative of key findings and takeaways. Flag negative CP as a concern.
- **LoB breakdown** — only include if tenant has >1 LoB. Split into "Top Line" (Bookings, CVR) and "P&L" (GBV, Gross Revenue) sub-tables.
- **Deep Dive** — only include when MoM triggers it. Omit entirely for stable partners.
- **Formatting** — see `references/metric-definitions.md` for exact formatting standards (currency, percentages, sign conventions).
- Use "+" prefix for positive changes, "-" for negative (standard sign convention).
- Generate reports **sequentially** (one tenant at a time) to avoid API rate limits.

## Commerce Partner Tenants

```
'Hopper-App', 'TripAdvisor', 'MVW', 'NuBank', 'Perkspot', 'Uber', 'Lloyds',
'Virgin Australia - Stays', 'CommBank', 'SMCC', 'HSBC', 'Lotte'
```

### Region Classification

| Region | Tenants |
|---|---|
| APAC | Virgin Australia - Stays, HSBC, CommBank, SMCC, Lotte |
| Atlantic | Lloyds, NuBank, TripAdvisor, Perkspot, Uber, Fox, Dollar, MVW |
