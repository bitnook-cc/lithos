# Monthly Commerce Report - {TENANT} - {MON YYYY}

## Summary

{SUMMARY}

## Month-over-Month: {PREV_MON} vs {CURR_MON}

| Metric | {PREV_MON} | {CURR_MON} | % Change |
|---|---|---|---|
| MAUs | {prev_mau} | {curr_mau} | {mau_pct_chg} |
| Bookings | {prev_bookings} | {curr_bookings} | {bookings_pct_chg} |
| Conversion Rate | {prev_cvr} | {curr_cvr} | {cvr_pct_chg} |
| GBV | {prev_gbv} | {curr_gbv} | {gbv_pct_chg} |
| Gross Revenue | {prev_gross_rev} | {curr_gross_rev} | {gross_rev_pct_chg} |
| GR Take Rate | {prev_gr_take_rate} | {curr_gr_take_rate} | {gr_take_rate_pct_chg} |
| Gross Profit | {prev_gross_profit} | {curr_gross_profit} | {gross_profit_pct_chg} |
| Contribution Profit | {prev_contrib_profit} | {curr_contrib_profit} | {contrib_profit_pct_chg} |
| CP Take Rate | {prev_cp_take_rate} | {curr_cp_take_rate} | {cp_take_rate_pct_chg} |

### By Line of Business — Top Line

| LoB | {PREV_MON} Bookings | {CURR_MON} Bookings | % Chg | {PREV_MON} CVR | {CURR_MON} CVR | % Chg |
|---|---|---|---|---|---|---|
| {lob_1} | {lob_1_prev_bkg} | {lob_1_curr_bkg} | {lob_1_bkg_chg} | {lob_1_prev_cvr} | {lob_1_curr_cvr} | {lob_1_cvr_chg} |
| {lob_2} | {lob_2_prev_bkg} | {lob_2_curr_bkg} | {lob_2_bkg_chg} | {lob_2_prev_cvr} | {lob_2_curr_cvr} | {lob_2_cvr_chg} |

### By Line of Business — P&L

| LoB | {PREV_MON} GBV | {CURR_MON} GBV | % Chg | {PREV_MON} Gross Rev | {CURR_MON} Gross Rev | % Chg |
|---|---|---|---|---|---|---|
| {lob_1} | {lob_1_prev_gbv} | {lob_1_curr_gbv} | {lob_1_gbv_chg} | {lob_1_prev_gr} | {lob_1_curr_gr} | {lob_1_gr_chg} |
| {lob_2} | {lob_2_prev_gbv} | {lob_2_curr_gbv} | {lob_2_gbv_chg} | {lob_2_prev_gr} | {lob_2_curr_gr} | {lob_2_gr_chg} |

## Actual vs Forecast: {CURR_MON}

| Metric | Actual | Forecast (Base) | Variance % |
|---|---|---|---|
| MAUs | {actual_mau} | {forecast_mau} | {mau_var_pct} |
| Bookings | {actual_bookings} | {forecast_bookings} | {bookings_var_pct} |
| Conversion Rate | {actual_cvr} | {forecast_cvr} | {cvr_var_pct} |
| GBV | {actual_gbv} | {forecast_gbv} | {gbv_var_pct} |
| Gross Revenue | {actual_gross_rev} | {forecast_gross_rev} | {gross_rev_var_pct} |
| GR Take Rate | {actual_gr_take_rate} | {forecast_gr_take_rate} | {gr_take_rate_var_pct} |
| Gross Profit | {actual_gross_profit} | {forecast_gross_profit} | {gross_profit_var_pct} |
| Contribution Profit | {actual_contrib_profit} | {forecast_contrib_profit} | {contrib_profit_var_pct} |
| CP Take Rate | {actual_cp_take_rate} | {forecast_cp_take_rate} | {cp_take_rate_var_pct} |

### By Line of Business — Top Line

| LoB | Actual Bookings | Forecast Bookings | Var % | Actual CVR | Forecast CVR | Var % |
|---|---|---|---|---|---|---|
| {lob_1} | ... | ... | ... | ... | ... | ... |

### By Line of Business — P&L

| LoB | Actual GBV | Forecast GBV | Var % | Actual Gross Rev | Forecast Gross Rev | Var % |
|---|---|---|---|---|---|---|
| {lob_1} | ... | ... | ... | ... | ... | ... |

## Deep Dive

{DEEP_DIVE_CONTENT}
