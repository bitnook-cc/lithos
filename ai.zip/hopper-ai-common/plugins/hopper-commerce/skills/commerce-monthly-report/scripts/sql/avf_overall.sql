-- Actual vs Forecast Overall Comparison
-- Parameters: @REPORT_MONTH (format: 'YYYY-MM-01')
-- Default forecast version is 'Base'. Replace with 'Upside' only when explicitly requested.
-- Filters for specific tenant: add AND tenant = @TENANT_NAME to both CTEs
-- Both actuals (RunRate) and forecast (Base) come from fact_consolidated_wholeco_public.
WITH base AS (
  SELECT
    CASE WHEN (
      NOT Tenant IN ('RBC','Perkspot','Yahoo','Gilded','HSBC-UAE','HSBC-QA')
      AND NOT (Tenant IN ('NuBank','CommBank') AND Month >= '2026-01-01')
    ) AND Account_Subcategory = 'Payment Processing & Fraud'
    THEN 'Hopper Travel' ELSE Entity END AS Entity,
    CASE
      WHEN Sub_Entity = 'Consumer' AND Account_Category = 'Metrics'
        AND Account_Subcategory = 'MAUs' AND Version = 'RunRate'
      THEN 'Commerce'
      ELSE Sub_Entity
    END AS Sub_Entity,
    CASE
      WHEN UPPER(Tenant) LIKE '%HSBC%' THEN 'HSBC'
      ELSE Tenant
    END AS Tenant,
    Distribution_Channel,
    Line_of_Business,
    CASE
      WHEN Entity = 'Hopper Travel'
        AND Account_Subcategory = 'Profit Share'
        AND Account_Category = 'Contra Revenue' THEN 'OPEX'
      ELSE Account_Category
    END AS Account_Category,
    Account_Subcategory,
    Version,
    Month,
    Amount
  FROM `h4r-common-bi-prd.hts_finance_data__gld.fact_consolidated_wholeco_public`
  WHERE Tenant NOT IN ('Santander (ES/MX)','Woori','Banorte','Flair','Forward Dist','HTS Assist','Nequi','Marriott','Capital One')
    AND Amount != 0 AND Amount IS NOT NULL
    AND Distribution_Channel NOT IN ('Fintech Ancillary', '3P', 'Audiences', 'API')
    AND Sub_Entity != 'Assist'
    AND (
      Intercompany = 'F'
      OR (Tenant = 'Hopper-App' AND Account_Subcategory = 'MAUs' AND Intercompany = 'T')
    )
),
actuals AS (
  SELECT tenant,
    SUM(CASE WHEN account_category = 'Metrics' AND Line_of_Business = 'Total' AND Account_Subcategory = 'MAUs' THEN amount ELSE 0 END) AS mau,
    SUM(CASE WHEN account_category = 'Metrics' AND Account_Subcategory = 'Bookings' THEN amount ELSE 0 END) AS bookings,
    SUM(CASE WHEN account_category = 'Metrics' AND Account_Subcategory = 'GBV' THEN amount ELSE 0 END) AS gbv,
    SUM(CASE WHEN account_category = 'Gross Revenue' THEN amount ELSE 0 END) AS gross_revenue,
    SUM(CASE WHEN account_category = 'Gross Profit' THEN amount ELSE 0 END) AS gross_profit,
    SUM(CASE WHEN account_category = 'Contribution Profit' THEN amount ELSE 0 END) AS contribution_profit
  FROM base
  WHERE month = @REPORT_MONTH AND version = 'RunRate'
  GROUP BY tenant
),
forecast AS (
  SELECT tenant,
    SUM(CASE WHEN Entity = 'HTS' AND account_category = 'Metrics' AND Line_of_Business = 'Total' AND Account_Subcategory = 'MAUs' THEN amount ELSE 0 END) AS mau,
    SUM(CASE WHEN Entity = 'HTS' AND account_category = 'Metrics' AND Account_Subcategory = 'Bookings' THEN amount ELSE 0 END) AS bookings,
    SUM(CASE WHEN Entity = 'HTS' AND account_category = 'Metrics' AND Account_Subcategory = 'GBV' THEN amount ELSE 0 END) AS gbv,
    SUM(CASE WHEN account_category = 'Gross Revenue' THEN amount ELSE 0 END) AS gross_revenue,
    SUM(CASE WHEN account_category = 'Gross Profit' THEN amount ELSE 0 END) AS gross_profit,
    SUM(CASE WHEN account_category = 'Contribution Profit' THEN amount ELSE 0 END) AS contribution_profit
  FROM base
  WHERE month = @REPORT_MONTH AND version = 'Base'
  GROUP BY tenant
)
SELECT
  COALESCE(a.tenant, f.tenant) AS tenant,
  ROUND(a.mau, 0) AS actual_mau, ROUND(f.mau, 0) AS forecast_mau,
  ROUND(SAFE_DIVIDE(a.mau - f.mau, ABS(f.mau)) * 100, 1) AS mau_var_pct,
  ROUND(a.bookings, 0) AS actual_bookings, ROUND(f.bookings, 0) AS forecast_bookings,
  ROUND(SAFE_DIVIDE(a.bookings - f.bookings, ABS(f.bookings)) * 100, 1) AS bookings_var_pct,
  ROUND(SAFE_DIVIDE(a.bookings, a.mau) * 100, 2) AS actual_cvr,
  ROUND(SAFE_DIVIDE(f.bookings, f.mau) * 100, 2) AS forecast_cvr,
  ROUND(a.gbv, 0) AS actual_gbv, ROUND(f.gbv, 0) AS forecast_gbv,
  ROUND(SAFE_DIVIDE(a.gbv - f.gbv, ABS(f.gbv)) * 100, 1) AS gbv_var_pct,
  ROUND(a.gross_revenue, 0) AS actual_gross_rev, ROUND(f.gross_revenue, 0) AS forecast_gross_rev,
  ROUND(SAFE_DIVIDE(a.gross_revenue - f.gross_revenue, ABS(f.gross_revenue)) * 100, 1) AS gross_rev_var_pct,
  ROUND(SAFE_DIVIDE(a.gross_revenue, a.gbv) * 100, 2) AS actual_gr_take_rate,
  ROUND(SAFE_DIVIDE(f.gross_revenue, f.gbv) * 100, 2) AS forecast_gr_take_rate,
  ROUND(a.gross_profit, 0) AS actual_gross_profit, ROUND(f.gross_profit, 0) AS forecast_gross_profit,
  ROUND(SAFE_DIVIDE(a.gross_profit - f.gross_profit, ABS(f.gross_profit)) * 100, 1) AS gross_profit_var_pct,
  ROUND(a.contribution_profit, 0) AS actual_contrib_profit, ROUND(f.contribution_profit, 0) AS forecast_contrib_profit,
  ROUND(SAFE_DIVIDE(a.contribution_profit - f.contribution_profit, ABS(f.contribution_profit)) * 100, 1) AS contrib_profit_var_pct,
  ROUND(SAFE_DIVIDE(a.contribution_profit, a.gbv) * 100, 2) AS actual_cp_take_rate,
  ROUND(SAFE_DIVIDE(f.contribution_profit, f.gbv) * 100, 2) AS forecast_cp_take_rate
FROM actuals a
FULL OUTER JOIN forecast f ON a.tenant = f.tenant
WHERE COALESCE(a.tenant, f.tenant) IN (
  'Hopper-App', 'TripAdvisor', 'MVW', 'NuBank', 'Perkspot', 'Uber', 'Lloyds',
  'Virgin Australia - Stays', 'CommBank', 'SMCC', 'HSBC', 'Lotte')
ORDER BY tenant
