-- Month-over-Month Overall Comparison
-- Parameters: @PREVIOUS_MONTH, @CURRENT_MONTH (format: 'YYYY-MM-01')
-- Filters for specific tenant: add AND tenant = @TENANT_NAME to both CTEs
WITH base AS (
  SELECT
    CASE WHEN (
      NOT Tenant IN ('RBC','Perkspot','Yahoo','Gilded','HSBC-UAE','HSBC-QA')
      AND NOT (Tenant IN ('NuBank','CommBank') AND Month >= '2026-01-01')
    ) AND Account_Subcategory = 'Payment Processing & Fraud'
    THEN 'Hopper Travel' ELSE Entity END AS Entity,
    CASE
      WHEN Sub_Entity = 'Consumer' AND Account_Category = 'Metrics'
        AND Account_Subcategory = 'MAUs' AND Version = 'RunRate'
      THEN 'Commerce'
      ELSE Sub_Entity
    END AS Sub_Entity,
    CASE
      WHEN UPPER(Tenant) LIKE '%HSBC%' THEN 'HSBC'
      ELSE Tenant
    END AS Tenant,
    Distribution_Channel,
    Line_of_Business,
    CASE
      WHEN Entity = 'Hopper Travel'
        AND Account_Subcategory = 'Profit Share'
        AND Account_Category = 'Contra Revenue' THEN 'OPEX'
      ELSE Account_Category
    END AS Account_Category,
    Account_Subcategory,
    Version,
    Month,
    Amount
  FROM `h4r-common-bi-prd.hts_finance_data__gld.fact_consolidated_wholeco_public`
  WHERE Tenant NOT IN ('Santander (ES/MX)','Woori','Banorte','Flair','Forward Dist','HTS Assist','Nequi','Marriott','Capital One')
    AND Amount != 0 AND Amount IS NOT NULL
    AND Distribution_Channel NOT IN ('Fintech Ancillary', '3P', 'Audiences', 'API')
    AND Sub_Entity != 'Assist'
    AND (
      Intercompany = 'F'
      OR (Tenant = 'Hopper-App' AND Account_Subcategory = 'MAUs' AND Intercompany = 'T')
    )
),
prev AS (
  SELECT tenant,
    SUM(CASE WHEN account_category = 'Metrics' AND Line_of_Business = 'Total' AND Account_Subcategory = 'MAUs' THEN amount ELSE 0 END) AS mau,
    SUM(CASE WHEN account_category = 'Metrics' AND Account_Subcategory = 'Bookings' THEN amount ELSE 0 END) AS bookings,
    SUM(CASE WHEN account_category = 'Metrics' AND Account_Subcategory = 'GBV' THEN amount ELSE 0 END) AS gbv,
    SUM(CASE WHEN account_category = 'Gross Revenue' THEN amount ELSE 0 END) AS gross_revenue,
    SUM(CASE WHEN account_category = 'Gross Profit' THEN amount ELSE 0 END) AS gross_profit,
    SUM(CASE WHEN account_category = 'Contribution Profit' THEN amount ELSE 0 END) AS contribution_profit
  FROM base
  WHERE month = @PREVIOUS_MONTH AND version = 'RunRate'
  GROUP BY tenant
),
curr AS (
  SELECT tenant,
    SUM(CASE WHEN account_category = 'Metrics' AND Line_of_Business = 'Total' AND Account_Subcategory = 'MAUs' THEN amount ELSE 0 END) AS mau,
    SUM(CASE WHEN account_category = 'Metrics' AND Account_Subcategory = 'Bookings' THEN amount ELSE 0 END) AS bookings,
    SUM(CASE WHEN account_category = 'Metrics' AND Account_Subcategory = 'GBV' THEN amount ELSE 0 END) AS gbv,
    SUM(CASE WHEN account_category = 'Gross Revenue' THEN amount ELSE 0 END) AS gross_revenue,
    SUM(CASE WHEN account_category = 'Gross Profit' THEN amount ELSE 0 END) AS gross_profit,
    SUM(CASE WHEN account_category = 'Contribution Profit' THEN amount ELSE 0 END) AS contribution_profit
  FROM base
  WHERE month = @CURRENT_MONTH AND version = 'RunRate'
  GROUP BY tenant
)
SELECT
  COALESCE(p.tenant, c.tenant) AS tenant,
  ROUND(p.mau, 0) AS prev_mau, ROUND(c.mau, 0) AS curr_mau,
  ROUND(SAFE_DIVIDE(c.mau - p.mau, ABS(p.mau)) * 100, 1) AS mau_pct_chg,
  ROUND(p.bookings, 0) AS prev_bookings, ROUND(c.bookings, 0) AS curr_bookings,
  ROUND(SAFE_DIVIDE(c.bookings - p.bookings, ABS(p.bookings)) * 100, 1) AS bookings_pct_chg,
  ROUND(SAFE_DIVIDE(p.bookings, p.mau) * 100, 2) AS prev_cvr,
  ROUND(SAFE_DIVIDE(c.bookings, c.mau) * 100, 2) AS curr_cvr,
  ROUND(SAFE_DIVIDE(SAFE_DIVIDE(c.bookings, c.mau) - SAFE_DIVIDE(p.bookings, p.mau), SAFE_DIVIDE(p.bookings, p.mau)) * 100, 1) AS cvr_pct_chg,
  ROUND(p.gbv, 0) AS prev_gbv, ROUND(c.gbv, 0) AS curr_gbv,
  ROUND(SAFE_DIVIDE(c.gbv - p.gbv, ABS(p.gbv)) * 100, 1) AS gbv_pct_chg,
  ROUND(p.gross_revenue, 0) AS prev_gross_rev, ROUND(c.gross_revenue, 0) AS curr_gross_rev,
  ROUND(SAFE_DIVIDE(c.gross_revenue - p.gross_revenue, ABS(p.gross_revenue)) * 100, 1) AS gross_rev_pct_chg,
  ROUND(SAFE_DIVIDE(p.gross_revenue, p.gbv) * 100, 2) AS prev_gr_take_rate,
  ROUND(SAFE_DIVIDE(c.gross_revenue, c.gbv) * 100, 2) AS curr_gr_take_rate,
  ROUND(p.gross_profit, 0) AS prev_gross_profit, ROUND(c.gross_profit, 0) AS curr_gross_profit,
  ROUND(SAFE_DIVIDE(c.gross_profit - p.gross_profit, ABS(p.gross_profit)) * 100, 1) AS gross_profit_pct_chg,
  ROUND(p.contribution_profit, 0) AS prev_contrib_profit, ROUND(c.contribution_profit, 0) AS curr_contrib_profit,
  ROUND(SAFE_DIVIDE(c.contribution_profit - p.contribution_profit, ABS(p.contribution_profit)) * 100, 1) AS contrib_profit_pct_chg,
  ROUND(SAFE_DIVIDE(p.contribution_profit, p.gbv) * 100, 2) AS prev_cp_take_rate,
  ROUND(SAFE_DIVIDE(c.contribution_profit, c.gbv) * 100, 2) AS curr_cp_take_rate
FROM prev p
FULL OUTER JOIN curr c ON p.tenant = c.tenant
WHERE COALESCE(p.tenant, c.tenant) IN (
  'Hopper-App', 'TripAdvisor', 'MVW', 'NuBank', 'Perkspot', 'Uber', 'Lloyds',
  'Virgin Australia - Stays', 'CommBank', 'SMCC', 'HSBC', 'Lotte')
ORDER BY tenant
