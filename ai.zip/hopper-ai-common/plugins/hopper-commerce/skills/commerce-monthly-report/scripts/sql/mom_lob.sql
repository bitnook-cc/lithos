-- Month-over-Month Line of Business Breakdown
-- Parameters: @PREVIOUS_MONTH, @CURRENT_MONTH (format: 'YYYY-MM-01'), @TENANT_NAME
-- Run per tenant. If only one LoB returned, skip the breakdown table.
WITH base AS (
  SELECT
    CASE WHEN (
      NOT Tenant IN ('RBC','Perkspot','Yahoo','Gilded','HSBC-UAE','HSBC-QA')
      AND NOT (Tenant IN ('NuBank','CommBank') AND Month >= '2026-01-01')
    ) AND Account_Subcategory = 'Payment Processing & Fraud'
    THEN 'Hopper Travel' ELSE Entity END AS Entity,
    CASE
      WHEN Sub_Entity = 'Consumer' AND Account_Category = 'Metrics'
        AND Account_Subcategory = 'MAUs' AND Version = 'RunRate'
      THEN 'Commerce'
      ELSE Sub_Entity
    END AS Sub_Entity,
    CASE
      WHEN UPPER(Tenant) LIKE '%HSBC%' THEN 'HSBC'
      ELSE Tenant
    END AS Tenant,
    Distribution_Channel,
    Line_of_Business,
    CASE
      WHEN Entity = 'Hopper Travel'
        AND Account_Subcategory = 'Profit Share'
        AND Account_Category = 'Contra Revenue' THEN 'OPEX'
      ELSE Account_Category
    END AS Account_Category,
    Account_Subcategory,
    Version,
    Month,
    Amount
  FROM `h4r-common-bi-prd.hts_finance_data__gld.fact_consolidated_wholeco_public`
  WHERE Tenant NOT IN ('Santander (ES/MX)','Woori','Banorte','Flair','Forward Dist','HTS Assist','Nequi','Marriott','Capital One')
    AND Amount != 0 AND Amount IS NOT NULL
    AND Distribution_Channel NOT IN ('Fintech Ancillary', '3P', 'Audiences', 'API')
    AND Sub_Entity != 'Assist'
    AND (
      Intercompany = 'F'
      OR (Tenant = 'Hopper-App' AND Account_Subcategory = 'MAUs' AND Intercompany = 'T')
    )
),
prev AS (
  SELECT tenant, Line_of_Business,
    SUM(CASE WHEN account_category = 'Metrics' AND Account_Subcategory = 'MAUs' THEN amount ELSE 0 END) AS mau,
    SUM(CASE WHEN account_category = 'Metrics' AND Account_Subcategory = 'Bookings' THEN amount ELSE 0 END) AS bookings,
    SUM(CASE WHEN account_category = 'Metrics' AND Account_Subcategory = 'GBV' THEN amount ELSE 0 END) AS gbv,
    SUM(CASE WHEN account_category = 'Gross Revenue' THEN amount ELSE 0 END) AS gross_revenue
  FROM base
  WHERE month = @PREVIOUS_MONTH AND version = 'RunRate'
    AND Line_of_Business NOT IN ('Total', '*')
    AND tenant = @TENANT_NAME
  GROUP BY tenant, Line_of_Business
),
curr AS (
  SELECT tenant, Line_of_Business,
    SUM(CASE WHEN account_category = 'Metrics' AND Account_Subcategory = 'MAUs' THEN amount ELSE 0 END) AS mau,
    SUM(CASE WHEN account_category = 'Metrics' AND Account_Subcategory = 'Bookings' THEN amount ELSE 0 END) AS bookings,
    SUM(CASE WHEN account_category = 'Metrics' AND Account_Subcategory = 'GBV' THEN amount ELSE 0 END) AS gbv,
    SUM(CASE WHEN account_category = 'Gross Revenue' THEN amount ELSE 0 END) AS gross_revenue
  FROM base
  WHERE month = @CURRENT_MONTH AND version = 'RunRate'
    AND Line_of_Business NOT IN ('Total', '*')
    AND tenant = @TENANT_NAME
  GROUP BY tenant, Line_of_Business
)
SELECT
  COALESCE(p.Line_of_Business, c.Line_of_Business) AS line_of_business,
  ROUND(p.mau, 0) AS prev_mau, ROUND(c.mau, 0) AS curr_mau,
  ROUND(p.bookings, 0) AS prev_bookings, ROUND(c.bookings, 0) AS curr_bookings,
  ROUND(SAFE_DIVIDE(c.bookings - p.bookings, ABS(p.bookings)) * 100, 1) AS bookings_pct_chg,
  ROUND(SAFE_DIVIDE(p.bookings, p.mau) * 100, 2) AS prev_cvr,
  ROUND(SAFE_DIVIDE(c.bookings, c.mau) * 100, 2) AS curr_cvr,
  ROUND(p.gbv, 0) AS prev_gbv, ROUND(c.gbv, 0) AS curr_gbv,
  ROUND(SAFE_DIVIDE(c.gbv - p.gbv, ABS(p.gbv)) * 100, 1) AS gbv_pct_chg,
  ROUND(p.gross_revenue, 0) AS prev_gross_rev, ROUND(c.gross_revenue, 0) AS curr_gross_rev,
  ROUND(SAFE_DIVIDE(c.gross_revenue - p.gross_revenue, ABS(p.gross_revenue)) * 100, 1) AS gross_rev_pct_chg,
  ROUND(SAFE_DIVIDE(p.gross_revenue, p.gbv) * 100, 2) AS prev_gr_take_rate,
  ROUND(SAFE_DIVIDE(c.gross_revenue, c.gbv) * 100, 2) AS curr_gr_take_rate
FROM prev p
FULL OUTER JOIN curr c ON p.Line_of_Business = c.Line_of_Business
ORDER BY line_of_business
