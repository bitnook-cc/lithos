---
name: sprint-demo-recordings
description: |
  Sprint Demo Recordings Collector - Gathers demo recordings, images, and PR links from a specific sprint.

  Trigger keywords: "sprint demos", "demo recordings", "sprint review", "collect demos", "sprint recordings"

  This skill:
  - Discovers recent closed sprints for a Jira project and lets the user pick one
  - Finds all completed issues from the selected sprint
  - Discovers PRs using GitHub CLI search
  - Extracts demo recordings (Loom) and images from PR descriptions
  - Presents a formatted summary with all demos and media links

  Perfect for product managers preparing sprint reviews or retrospectives.
allowed-tools: Bash, Read, Write, mcp__atlassian__*
---

# Sprint Demo Recordings Collector

Collects and presents sprint demo recordings and media from completed sprint work. Discovers sprints, finds PRs, extracts recordings and images, and presents a formatted summary.

## When to Use This Skill

Use this skill when:
- Preparing for sprint reviews or retrospectives
- Collecting demos from a previous sprint
- Generating sprint demo summary for stakeholders
- Archiving sprint deliverables and demos
- Sharing team accomplishments with product leadership

## How to Invoke

The skill requires one input:

1. **Jira Project Key** (e.g., `CCG`, `STAYSVA`, `CAC`)

Optionally, the user can provide:

2. **Sprint name** (e.g., `CCG Sprint 14`) — skips sprint selection

### Example Invocations

```
Can you collect sprint demos for project CCG?
```

```
Get sprint demo recordings for CCG Sprint 14
```

```
Collect demos from the last sprint for STAYSVA
```

## Step-by-Step Workflow

### Step 1: Gather Inputs

Collect the **Project Key** from the user (e.g., `CCG`).

If the user also provided a specific sprint name, note it for Step 2.

### Step 2: Sprint Discovery and Selection

Sprint discovery uses a multi-strategy approach because the Atlassian MCP tools do not expose the Jira Agile REST API (board/sprint endpoints).

#### If the user provided a sprint name

Validate it by running a JQL query:

```
Use searchJiraIssuesUsingJql with:
  cloudId: "c5551a32-a87d-4739-93d7-fbf1a838a70e"
  jql: "project = {PROJECT_KEY} AND sprint = \"{SPRINT_NAME}\" AND status in (Done, Closed, Resolved)"
  maxResults: 1
```

If results come back, the sprint is valid. If zero results, tell the user:

> "I couldn't find any completed issues in sprint '{SPRINT_NAME}'. Please double-check the sprint name — it must match exactly as it appears in Jira (e.g., 'CCG Sprint 14')."

#### If the user did NOT provide a sprint name

Use the following strategies in order:

**Strategy 1: Confluence retrospective pages**

Search for retrospective pages that typically follow the naming convention `Retrospective: {PROJECT_KEY} Sprint N`:

```
Use searchAtlassian with:
  query: "{PROJECT_KEY} Sprint retrospective"
```

Parse sprint names from page titles (e.g., "Retrospective: CCG Sprint 12" → sprint name is "CCG Sprint 12").

**Strategy 2: Sprint name probing via JQL**

If Confluence search yields sprint names, extract the naming pattern (e.g., `CCG Sprint N`) and the highest N found. Then probe for higher sprint numbers by running JQL queries:

```
jql: "project = CCG AND sprint = \"CCG Sprint {N+1}\" AND status in (Done, Closed, Resolved)"
jql: "project = CCG AND sprint = \"CCG Sprint {N+2}\" AND status in (Done, Closed, Resolved)"
```

Continue incrementing until a query returns zero results.

Run these probes in parallel (batch 3-4 queries at once using multiple `searchJiraIssuesUsingJql` calls) for speed.

**IMPORTANT — Active sprint detection:** For each sprint that has completed issues, run a *second* query to check for non-completed (open) issues:

```
jql: "project = CCG AND sprint = \"CCG Sprint {N}\" AND status not in (Done, Closed, Resolved)"
```

If this query returns results, the sprint still has open work and is likely the *active* sprint — not a closed one. Mark it accordingly when presenting options to the user (see "Present Sprint Options" below).

Do NOT auto-select the highest sprint number with completed issues. An active sprint can have completed issues while still being in progress — the JQL `status in (Done, Closed, Resolved)` filter only checks issue status, not sprint state. The Jira Agile API (which exposes sprint state) is not available through the Atlassian MCP tools, so active sprint detection relies on this heuristic.

**Strategy 3: Explicit failure**

If neither strategy yields sprint names, tell the user explicitly:

> "I couldn't automatically discover sprints for project {PROJECT_KEY}. The Jira Agile API isn't accessible through my current tools, and I didn't find retrospective pages in Confluence to infer sprint names.
>
> Please provide either:
> - The exact sprint name as it appears in Jira (e.g., 'CCG Sprint 14')
> - The sprint naming convention your team uses (e.g., '{PROJECT_KEY} Sprint N')"

Do NOT proceed without a sprint name. Do NOT silently fall back to querying all closed sprints.

#### Present Sprint Options (MANDATORY)

**You MUST always present sprint options and ask the user to select one.** Never auto-select a sprint, even if you think you know which one is the latest closed sprint.

Present the discovered sprints as a numbered list, newest first. Mark any sprint that has open issues as likely active:

```
I found these recent sprints for CCG:

1. CCG Sprint 16 ⚠️ (likely active — has open issues)
2. CCG Sprint 15
3. CCG Sprint 14
4. CCG Sprint 13

Which sprint would you like to collect demos for?
```

If date ranges are available (from Confluence pages), include them:

```
1. CCG Sprint 16 ⚠️ (likely active — has open issues)
2. CCG Sprint 15 (Mar 22 – Apr 4)
3. CCG Sprint 14 (Mar 8 – Mar 21)
4. CCG Sprint 13 (Feb 22 – Mar 7)
```

**Wait for the user to select a sprint before proceeding.** Do NOT skip this step. Do NOT assume the user wants the latest or second-latest sprint.

### Step 3: Collect Completed Issues

Query all completed issues for the selected sprint:

```
Use searchJiraIssuesUsingJql with:
  cloudId: "c5551a32-a87d-4739-93d7-fbf1a838a70e"
  jql: "project = {PROJECT_KEY} AND sprint = \"{SELECTED_SPRINT}\" AND status in (Done, Closed, Resolved) ORDER BY key ASC"
  maxResults: 50
  fields: ["summary", "status", "issuetype"]
```

If the result is saved to a file (large response), use `jq` via Bash to extract issue keys and summaries:

```bash
cat {RESULT_FILE} | jq -r '.issues.nodes[] | "\(.key)|\(.fields.summary)"'
```

If more than 50 issues exist, use `nextPageToken` to paginate and collect all of them.

### Step 4: Discover PRs for Each Issue

For each issue key, search GitHub for PRs that reference it. Use a bash script for efficiency:

```bash
#!/bin/bash
# Search for PRs mentioning the issue key across team repos
REPOS=("hopper-org/commerce-api" "hopper-org/commerce-portals" "hopper-org/oklahoma" "hopper-org/traveler-api" "hopper-org/payments-incentives")

for ISSUE_KEY in "$@"; do
  for REPO in "${REPOS[@]}"; do
    PRS=$(gh pr list --repo "$REPO" \
      --search "$ISSUE_KEY" --state all --limit 5 \
      --json number,title,url,body 2>/dev/null)

    if [ -n "$PRS" ] && [ "$PRS" != "[]" ]; then
      echo "$PRS" | jq -c --arg key "$ISSUE_KEY" '.[] | {issue_key: $key, pr: .}'
    fi
  done
done
```

**Important:** The list of repos to search should be adapted based on the project. For CCG, the repos above are correct. For other projects, ask the user which repos to search or use `searchAtlassian` to find the team's repos.

**Batching:** Process issues in batches (e.g., 20 at a time) to avoid timeouts. Run batches in parallel when possible.

### Step 5: Extract Media from PR Descriptions

For each PR found, extract demo media from the PR body:

- **Loom recordings**: `https://www.loom.com/share/[id]`
- **GitHub user-attachments**: `https://github.com/user-attachments/assets/[uuid]`
- **GitHub repo assets**: `https://github.com/[org]/[repo]/assets/[id]/[filename].(mp4|mov|webm|png|jpg|jpeg|gif|webp)`

Use grep patterns:

```bash
# Loom links
grep -oE 'https://www\.loom\.com/share/[a-zA-Z0-9-]+' <<< "$PR_BODY"

# GitHub user-attachments
grep -oE 'https://github\.com/user-attachments/assets/[a-f0-9-]+' <<< "$PR_BODY"

# GitHub repo assets with media extensions
grep -oE 'https://github\.com/[^)"[:space:]]+\.(mp4|mov|webm|png|jpg|jpeg|gif|webp)' <<< "$PR_BODY"
```

Only include PRs that have at least one media URL.

### Step 6: Categorize Issues by Theme

Before presenting results, group the completed issues into thematic categories. This turns a flat list into a narrative sprint recap.

**How to categorize:**

1. Read all issue summaries collected in Step 3.
2. Identify recurring themes or functional areas (e.g., "Payment Methods", "Checkout Flow", "Insurance", "Bug Fixes", "Infrastructure", "Analytics").
3. Group issues into 3–7 categories. Use your judgment based on the issue summaries — common patterns include:
   - Feature area (e.g., "Alternative Payment Methods", "Loyalty Program")
   - Work type (e.g., "Bug Fixes", "Infrastructure", "Testing")
   - Domain (e.g., "Insurance Checkout", "Price Display")
4. Assign a relevant emoji to each category. Pick emojis that visually represent the theme:
   - `:credit_card:` for payments
   - `:shield:` for insurance/security
   - `:bug:` for bug fixes
   - `:gear:` for infrastructure/tooling
   - `:bar_chart:` for analytics/tracking
   - `:art:` for UI/UX
   - `:dollar:` for pricing/revenue
   - `:rocket:` for new features
   - `:test_tube:` for testing
   - `:warning:` for error handling
5. Place each issue into exactly one category. If an issue could fit multiple categories, pick the most specific one.

**Also identify:**
- **Work in Progress (WIP):** Search for open (unmerged) PRs in the same repos that reference sprint issue keys. These represent work that started but didn't complete in the sprint.
- **Looking Ahead:** Check Jira for issues in the *next* sprint (e.g., if presenting Sprint 19, check Sprint 20) to preview upcoming work. Use:
  ```
  jql: "project = {PROJECT_KEY} AND sprint = \"{PROJECT_KEY} Sprint {N+1}\" ORDER BY key ASC"
  maxResults: 10
  fields: ["summary"]
  ```
  If no next sprint is found, omit this section.

### Step 7: Present Results as Sprint Recap

Format the results as a *narrative sprint recap* in Slack mrkdwn. This is the primary output format — it should read like a team update, not a raw data dump.

**Template:**

```
:green_alert: *{PROJECT_NAME} — {SPRINT_NAME} Recap*

:trophy: *Sprint Accomplishments*

:{emoji}: *{Category 1 Name}*
- <JIRA_URL|ISSUE-123>: Feature description — <PR_URL|PR #N> (repo-name)
  📹 https://www.loom.com/share/abc123
- <JIRA_URL|ISSUE-124>: Another item — <PR_URL|PR #M> (repo-name)

:{emoji}: *{Category 2 Name}*
- <JIRA_URL|ISSUE-125>: Item description — <PR_URL|PR #O>, <PR_URL|PR #P> (repo-name)
  📹 https://github.com/user-attachments/assets/uuid

:{emoji}: *{Category 3 Name}*
- <JIRA_URL|ISSUE-126>: Item description — <PR_URL|PR #Q> (repo-name)

:fast_forward: *Work In Progress*
- <PR_URL|PR #R> (repo-name): PR title — still open
- <PR_URL|PR #S> (repo-name): PR title — in review

:telescope: *Looking Ahead ({NEXT_SPRINT_NAME})*
- <JIRA_URL|ISSUE-200>: Upcoming feature
- <JIRA_URL|ISSUE-201>: Planned improvement

Great sprint, team! :muscle:

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
_X issues completed · Y PRs across {repo-list} · Z demo recordings_
```

**Formatting rules:**
- Use Slack mrkdwn (not GitHub markdown): `*bold*`, `_italic_`, `<url|text>` for links
- Each completed issue is a single bullet with: Jira link, summary, PR link(s), and repo name
- Demo media (Loom, video URLs) appear indented under the issue they belong to — only when media exists
- Keep each bullet concise — the issue summary from Jira is usually sufficient, no need to elaborate
- Deduplicate PRs that appear for multiple issues — show all related issue keys together
- If a category has only 1 item, still show it — it highlights breadth of work
- Omit the "Work In Progress" section if no open PRs are found
- Omit the "Looking Ahead" section if no next sprint issues are found
- The closing line with stats uses `_italic_` and summarizes: issues completed, PR count, repos touched, demo count
- Use `:green_alert:` for the header (matches the Commerce Foundation convention)

**Example output (real sprint):**

```
:green_alert: *Commerce - Checkout & Growth (CCG) — Sprint 19 Recap*

:trophy: *Sprint Accomplishments*

:credit_card: *Alternative Payment Methods (APMs)*
- <https://hopper-jira.atlassian.net/browse/CCG-1254|CCG-1254>: Enable iDEAL for NL market — <https://github.com/hopper-org/commerce-api/pull/2900|PR #2900>, <https://github.com/hopper-org/commerce-api/pull/2905|PR #2905> (commerce-api)
  📹 https://www.loom.com/share/abc123

:shield: *Insurance Checkout*
- <https://hopper-jira.atlassian.net/browse/CCG-1389|CCG-1389>: Insurance price display fix — <https://github.com/hopper-org/commerce-portals/pull/1723|PR #1723> (commerce-portals)

:warning: *Payment Error Handling*
- <https://hopper-jira.atlassian.net/browse/CCG-174|CCG-174>: Improve payment error messages — <https://github.com/hopper-org/commerce-api/pull/2918|PR #2918> (commerce-api)
  📹 https://github.com/user-attachments/assets/uuid

:bug: *Bug Fixes*
- <https://hopper-jira.atlassian.net/browse/CCG-1440|CCG-1440>: Fix checkout race condition — <https://github.com/hopper-org/commerce-api/pull/2910|PR #2910> (commerce-api)

:gear: *Infrastructure*
- <https://hopper-jira.atlassian.net/browse/CCG-1456|CCG-1456>: Add Datadog monitors for APM endpoints

:fast_forward: *Work In Progress*
- <https://github.com/hopper-org/commerce-api/pull/2920|PR #2920> (commerce-api): Add Bancontact support — in review

:telescope: *Looking Ahead (Sprint 20)*
- <https://hopper-jira.atlassian.net/browse/CCG-1500|CCG-1500>: Expand APM coverage to Belgium
- <https://hopper-jira.atlassian.net/browse/CCG-1501|CCG-1501>: Checkout performance optimization

Great sprint, team! :muscle:

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
_11 issues completed · 15 PRs across commerce-api and commerce-portals · 3 demo recordings_
```

### Step 8: Offer Next Steps

After presenting results, offer:

- "Would you like me to collect demos for a different sprint?"
- "Should I re-run with additional repos?"
- "Want me to post this recap to a specific channel?"

## Troubleshooting

### Sprint discovery selects the wrong (active) sprint

**Possible causes:**
- The active sprint has issues already marked Done, so JQL `status in (Done, Closed, Resolved)` returns results for it
- The algorithm picked the highest sprint number with completed issues without checking if the sprint is still open

**Solution:** Always run the active sprint detection query (`status not in (Done, Closed, Resolved)`) and always present options to the user. Never auto-select.

### Sprint discovery returns no results

**Possible causes:**
- Team doesn't have Confluence retrospective pages
- Sprint naming convention doesn't match `{PROJECT_KEY} Sprint N` pattern
- Sprint isn't closed in Jira yet (still active)

**Solution:** Ask the user for the exact sprint name. They can find it in their Jira board settings.

### No demos found for any issues

**Possible causes:**
- PRs don't contain Loom/media links in descriptions
- PRs aren't linked or don't mention issue keys
- Searching the wrong repos

**Solution:** Check a few PRs manually. Ask the user which repos the team uses. Expand the repo search list.

### JQL sprint filter returns zero results

**Possible causes:**
- Sprint name doesn't match exactly (case-sensitive, spacing matters)
- Issues were completed but not in a "Done/Closed/Resolved" status

**Solution:** Try broadening the status filter: `status in (Done, Closed, Resolved, "In Review", "Acceptance Testing")`. Or ask the user what statuses their board uses for completed work.

---

**Created:** 2026-03-22 | **Updated:** 2026-04-13 | **Author:** Pablo Mincz | **Use Case:** Sprint Review Preparation
