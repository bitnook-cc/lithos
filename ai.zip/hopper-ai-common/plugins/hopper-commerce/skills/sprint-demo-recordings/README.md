# Sprint Demo Recordings Collector

A reusable skill for product managers to automatically collect and share demo recordings, images, and PR links from the most recent closed sprint.

**Use Case:** Sprint reviews, retrospectives, stakeholder updates - whenever you need to gather all sprint demos and media from completed work.

## How It Works

The skill implements a **3-tier PR discovery approach** to maximize coverage of sprint work:

### Step 1: Sprint Identification

Automatically finds the most recent closed sprint for your Jira project:

```bash
# Get board ID for project
BOARD_ID=$(curl -s -u "$JIRA_AUTH" \
  "https://hopper-jira.atlassian.net/rest/agile/1.0/board?projectKeyOrId=$PROJECT_KEY" \
  | jq -r '.values[0].id')

# Get most recent closed sprint (sorted by ID descending)
SPRINT_DATA=$(curl -s -u "$JIRA_AUTH" \
  "https://hopper-jira.atlassian.net/rest/agile/1.0/board/$BOARD_ID/sprint?state=closed&maxResults=100" \
  | jq -r '.values | sort_by(.id) | reverse | .[0]')
```

**Why ID descending?** Ensures you always get the latest sprint, not just the first closed sprint in the list.

### Step 2: Issue Discovery

Finds all completed issues from the sprint using Jira JQL:

```bash
JQL="project = $PROJECT_KEY AND sprint in closedSprints() ORDER BY sprint DESC"
```

**Important:** Uses `closedSprints()` function (not date ranges) to ensure accuracy regardless of when the query runs.

### Step 3: 3-Tier PR Discovery

For each issue, attempts to find PRs using three methods in order:

#### Tier 1: Jira Development Section (dev-status API)

```bash
curl -s -u "$JIRA_AUTH" \
  "https://hopper-jira.atlassian.net/rest/dev-status/1.0/issue/detail?issueId=$ISSUE_ID&applicationType=GitHub&dataType=pullrequest" \
  | jq -r '.detail[0].pullRequests[]?.url // empty'
```

**Best for:** Issues with PRs properly linked via Jira-GitHub integration.

#### Tier 2: GitHub Search by Issue Key

```bash
gh pr list --repo hopper-org/commerce-api \
  --search "$ISSUE_KEY in:title,body" \
  --state merged \
  --json number,url,title
```

**Best for:** PRs that mention the issue key but aren't formally linked in Jira.

#### Tier 3: Timeframe + Summary Match

```bash
gh pr list --repo hopper-org/commerce-api \
  --search "merged:>=$SPRINT_START_DATE merged:<=$SPRINT_END_DATE $ISSUE_SUMMARY" \
  --state merged \
  --limit 3
```

**Best for:** PRs merged during sprint that match issue description but lack explicit issue reference.

### Step 4: Media Extraction

Extracts demo recordings and images from PR descriptions using regex patterns:

```bash
# Loom recordings
LOOM_URLS=$(echo "$PR_BODY" | grep -oE 'https://www\.loom\.com/share/[a-zA-Z0-9\-]+')

# GitHub user-attachments (videos/images)
USER_ATTACHMENTS=$(echo "$PR_BODY" | grep -oE 'https://github\.com/user-attachments/assets/[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}')

# GitHub repo assets (videos/images)
REPO_MEDIA=$(echo "$PR_BODY" | grep -oE 'https://github\.com/[^/]+/[^/]+/assets/[0-9]+/[a-zA-Z0-9\-]+\.(mp4|mov|webm|png|jpg|jpeg|gif|webp)')
```

**Fallback strategy:** If Jira issue description is sparse, uses PR description instead to find media.

### Step 5: Slack Message Delivery

Sends a single formatted message to the specified Slack user with:
- Project name and sprint name
- Issue keys with clickable Jira links
- PR links for each demo
- Direct media URLs for download
- Clean formatting with proper sections

## Quick Start

### Prerequisites

Set up authentication credentials as environment variables:

```bash
export JIRA_EMAIL="your.email@hopper.com"
export JIRA_API_TOKEN="your_jira_token"
export SLACK_TOKEN="xoxc-your-slack-token"
```

**Get Jira API token:**
- Go to: https://id.atlassian.com/manage-profile/security/api-tokens
- Click "Create API token"
- Copy the token

**Get Slack token:**
- Open Slack in browser (https://hopchat.slack.com)
- Open Developer Tools (F12)
- Go to Network tab
- Navigate to any channel
- Find API request and copy the `xoxc-` token from the form data

### Basic Usage

Simply ask Claude to collect sprint demos:

```
Can you collect sprint demos for project CCG and send to @pmincz?
```

Or with explicit Slack user ID:

```
Get sprint demo recordings for STAYSVA and send to U01ABC123XY
```

### What You'll Get

A single Slack DM with this format:

```
🎬 Sprint Demo Recordings - Commerce - Checkout & Growth

Sprint: CCG Sprint 13 | Generated: March 22, 2026

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

<https://hopper-jira.atlassian.net/browse/CCG-321|CCG-321>: feat: Add Loyalty to Checkout
🔗 <https://github.com/hopper-org/commerce-portals/pull/1565|View PR #1565>
  📹 https://www.loom.com/share/abc123def456
  📹 https://github.com/user-attachments/assets/55b70448-da8f-40fd-87bc-93458aa99f9e
  🖼️ https://github.com/user-attachments/assets/9002f72c-a00a-4be5-bc9f-a84d3e944bae

<https://hopper-jira.atlassian.net/browse/CCG-345|CCG-345>: feat: Price breakdown improvements
🔗 <https://github.com/hopper-org/commerce-api/pull/789|View PR #789>
  📹 https://www.loom.com/share/xyz789abc123

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Found 32 issues with demos out of 50 total sprint issues
```

## Real-World Example: CCG Sprint 13

**Scenario:** Product manager needs to prepare for sprint review meeting on Friday, wants all demos from the completed sprint.

**Input:**
```
Can you collect sprint demos for CCG and send to @pmincz?
```

**Process:**
1. Identifies "Commerce - Checkout & Growth Sprint 13" (March 8-21, 2026)
2. Finds 50 completed issues from the sprint
3. Uses 3-tier PR discovery:
   - 15 PRs found via dev-status API (Tier 1)
   - 10 PRs found via GitHub issue key search (Tier 2)
   - 7 PRs found via timeframe + summary match (Tier 3)
   - **Total: 32 issues with PRs**
4. Extracts media from PR descriptions:
   - 28 Loom recordings
   - 12 GitHub user-attachments (videos)
   - 5 GitHub user-attachments (images)
5. Sends single Slack message with all 32 demos

**Results from actual run:**
- Input: 50 sprint issues
- Output: 32 issues with demos (64% coverage)
- Media: 45 total media items (28 Loom + 17 GitHub attachments)
- Not found: 18 issues without demos (list provided for manual review)

## Input/Output Format

### Input Requirements

**Required:**
1. **Jira Project Key** - Project abbreviation (e.g., `CCG`, `STAYSVA`, `CAC`)
2. **Slack User** - Either handle (e.g., `@pmincz`) or user ID (e.g., `U01ABC123XY`)

**Optional (configured in script):**
- GitHub repositories to search (default: `commerce-api`, `commerce-portals`)
- Jira issue status filter (default: any status from closed sprint)

### Output Format

**Slack Message Structure:**

```markdown
🎬 Sprint Demo Recordings - [Full Project Name]

Sprint: [Sprint Name] | Generated: [ISO Date]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

[For each issue with demos:]

<Jira URL|ISSUE-KEY>: [Issue summary/title]
🔗 <GitHub PR URL|View PR #[number]>
  📹 [Loom or video URL]
  📹 [Additional video URL]
  🖼️ [Image URL]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Found X issues with demos out of Y total sprint issues
```

**Media URL Types:**
- **Loom**: `📹 https://www.loom.com/share/[id]`
- **Videos**: `📹 https://github.com/user-attachments/assets/[uuid]`
- **Images**: `🖼️ https://github.com/user-attachments/assets/[uuid]`

**Additional Output:**

A markdown file with issues that don't have demos (for manual review):

```markdown
# Issues Without Demos - CCG Sprint 13

The following 18 issues from the sprint do not have demo recordings or media:

- [CCG-123: Bug fix for checkout flow](https://hopper-jira.atlassian.net/browse/CCG-123)
- [CCG-456: Performance optimization](https://hopper-jira.atlassian.net/browse/CCG-456)
...
```

## When to Use This Tool

### ✅ Use This Skill When:
- Preparing for sprint reviews or retrospectives
- Collecting demos from the most recent closed sprint
- Generating sprint summary for stakeholders
- Archiving sprint deliverables and demos
- Sharing team accomplishments with leadership
- Onboarding new team members (show them previous sprint demos)

### ❌ Use Alternative Methods When:
- You need demos from a specific date range (not sprint-based)
  - **Alternative:** Custom script with date-based Jira JQL
- You need to pull recordings from Loom API directly
  - **Alternative:** Use Loom API integration for video analytics
- You want to filter by specific developers or labels
  - **Alternative:** Modify Jira JQL to include assignee/label filters
- You need to search repositories outside commerce-api/commerce-portals
  - **Alternative:** Extend the script to include additional repos
- You need embedded videos in Slack (not just links)
  - **Alternative:** Use Slack file upload API (requires different auth)

## Files

- `skill.md` - Main skill definition with YAML frontmatter
- `README.md` - This file
- `sprint_demo_collector.sh` - Standalone bash script (optional for testing)

## Configuration

### Repositories Searched

By default, searches these repositories:
```bash
REPOS=(
  "hopper-org/commerce-api"
  "hopper-org/commerce-portals"
)
```

To add more repositories, extend the array:
```bash
REPOS=(
  "hopper-org/commerce-api"
  "hopper-org/commerce-portals"
  "hopper-org/commerce-web"
  "hopper-org/commerce-mobile"
)
```

### Media URL Patterns

Supported media types and URL patterns:

| Type | Pattern | Example |
|------|---------|---------|
| Loom | `https://www.loom.com/share/[id]` | `https://www.loom.com/share/abc123def456` |
| User Attachments | `https://github.com/user-attachments/assets/[uuid]` | `https://github.com/user-attachments/assets/55b70448-da8f-40fd-87bc-93458aa99f9e` |
| Repo Assets | `https://github.com/[org]/[repo]/assets/[id]/[file].[ext]` | `https://github.com/hopper-org/commerce-api/assets/123/demo.mp4` |

Supported file extensions: `.mp4`, `.mov`, `.webm`, `.png`, `.jpg`, `.jpeg`, `.gif`, `.webp`

### Jira Status Filtering

By default, includes all issues from the closed sprint regardless of status. To filter by specific statuses:

```bash
JQL="project = $PROJECT_KEY AND sprint in closedSprints() AND status = Done ORDER BY sprint DESC"
```

Common status values:
- `Done`
- `Closed`
- `Resolved`
- `Deployed`

## Key Characteristics

**Sprint-based:**
- Always targets the most recent closed sprint
- No manual date entry required
- Uses Jira's `closedSprints()` function for accuracy

**Comprehensive PR Discovery:**
- 3-tier approach maximizes coverage
- Falls back gracefully when PRs aren't linked
- Searches multiple repositories

**Media-rich:**
- Supports videos (Loom, MP4, MOV, WebM)
- Supports images (PNG, JPG, GIF, WebP)
- Extracts from both Jira and PR descriptions

**Clean Output:**
- Single Slack message (not multiple)
- Proper formatting with sections and emojis
- Clickable links for all resources
- Direct media URLs for download

## Tips

- **Re-run anytime** - Skill is idempotent, can run multiple times without side effects
- **Check "no demos" list** - Review the markdown file of issues without demos to catch missing work
- **Add repo context** - If PRs are in other repos, extend the `REPOS` array
- **PR description matters** - Encourage team to include media URLs in PR descriptions
- **Link PRs properly** - Jira-GitHub integration (Tier 1) is most reliable when configured

## Common Use Cases

### 1. Weekly Sprint Review Prep
```
Every Friday before sprint review:
Can you collect sprint demos for CCG and send to @pmincz?
```

### 2. Stakeholder Update
```
Prepare executive summary:
Get sprint demos for STAYSVA and send to @director
```

### 3. Retrospective Input
```
Gather artifacts for retro:
Collect sprint demos for CAC and send to @scrum-master
```

### 4. Documentation Archive
```
Save for future reference:
Get sprint demos for CCG Sprint 13 and send to @pmincz
(Then save to Confluence or Google Drive)
```

## Troubleshooting

### Issue: No demos found

**Possible causes:**
1. Sprint has no completed issues with "Done" status
2. PRs aren't merged yet or aren't linked to issues
3. PR descriptions don't contain media URLs
4. Wrong project key specified

**Solutions:**
- Check Jira board to verify sprint status
- Verify PRs are merged and linked
- Check PR descriptions for Loom links or attachments
- Verify project key matches Jira project

### Issue: Wrong sprint selected

**Possible causes:**
1. Board ID is incorrect for the project
2. Sprint isn't actually closed in Jira
3. Sprint dates aren't properly set

**Solutions:**
- Verify board ID: `https://hopper-jira.atlassian.net/rest/agile/1.0/board?projectKeyOrId=$PROJECT_KEY`
- Check sprint status in Jira
- Ensure sprint has end date set

### Issue: Slack message not sent

**Possible causes:**
1. SLACK_TOKEN expired (tokens expire ~daily)
2. User ID/handle is incorrect
3. Workspace mismatch

**Solutions:**
- Refresh Slack token (see Quick Start)
- Verify user ID: Open Slack → Click user → View profile → Copy member ID
- Ensure workspace is hopchat.slack.com

### Issue: Media URLs don't work

**Possible causes:**
1. GitHub user-attachments require authentication
2. Loom links are private (not shared publicly)
3. URLs extracted incorrectly

**Solutions:**
- GitHub user-attachments: Open in authenticated browser or download directly
- Loom links: Share video publicly or with specific people
- Check URL format matches expected patterns

## Advanced Usage

### Custom Jira JQL

Modify the JQL query to filter by additional criteria:

```bash
# Only bugs
JQL="project = $PROJECT_KEY AND sprint in closedSprints() AND type = Bug ORDER BY sprint DESC"

# Specific assignee
JQL="project = $PROJECT_KEY AND sprint in closedSprints() AND assignee = john.doe ORDER BY sprint DESC"

# Specific labels
JQL="project = $PROJECT_KEY AND sprint in closedSprints() AND labels = frontend ORDER BY sprint DESC"
```

### Multiple Projects

Run for multiple projects sequentially:

```
Collect sprint demos for CCG and send to @pmincz
Then collect sprint demos for STAYSVA and send to @pmincz
```

### Export to File

Instead of Slack, save to markdown file:

```bash
# Modify the script to write to file instead of Slack API
cat "$MESSAGE_FILE" > ~/Downloads/sprint_demos.md
```

## Additional Resources

- [Jira Agile REST API Documentation](https://developer.atlassian.com/cloud/jira/software/rest/intro/)
- [Jira dev-status API Documentation](https://developer.atlassian.com/server/jira/platform/jira-dev-status-rest-api/)
- [GitHub CLI Search Syntax](https://docs.github.com/en/search-github/searching-on-github/searching-issues-and-pull-requests)
- [Slack API Documentation](https://api.slack.com/methods)
- [Slack Block Kit Builder](https://api.slack.com/block-kit)
- [Loom API Documentation](https://developers.loom.com/)

---

**Created:** 2026-03-22 | **Author:** Pablo Mincz | **Use Case:** Sprint Review Preparation
