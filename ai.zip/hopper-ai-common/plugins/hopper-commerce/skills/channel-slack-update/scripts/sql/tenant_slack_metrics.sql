-- Tenant Slack Update Metrics
-- Returns MoM and AvF metrics for a SINGLE tenant, optimized for Slack update generation.
-- Also includes a 13-month lookback for record-month detection (GBV and CP).
--
-- SECURITY: This template uses BigQuery named parameters (@PARAM syntax).
-- It MUST be executed with parameterized binding (e.g., bq --parameter flags).
-- NEVER substitute @PARAM placeholders via string replacement or interpolation.
--
-- Parameters (bind via --parameter='NAME:TYPE:VALUE'):
--   @TENANT_NAME    STRING  (e.g., 'CommBank')
--   @CURRENT_MONTH  STRING  (format: 'YYYY-MM-01')
--   @PREVIOUS_MONTH STRING  (format: 'YYYY-MM-01')
--
-- Improvement over the original approach: filters by tenant inside the CTEs
-- instead of fetching all tenants and filtering afterwards.

WITH base AS (
  SELECT
    CASE WHEN (
      NOT Tenant IN ('RBC','Perkspot','Yahoo','Gilded','HSBC-UAE','HSBC-QA')
      AND NOT (Tenant IN ('NuBank','CommBank') AND Month >= '2026-01-01')
    ) AND Account_SubCategory = 'Payment Processing & Fraud'
    THEN 'Hopper Travel' ELSE Entity END AS Entity,
    CASE
      WHEN Sub_Entity = 'Consumer' AND Account_Category = 'Metrics'
        AND Account_SubCategory = 'MAUs' AND Version = 'RunRate'
      THEN 'Commerce'
      ELSE Sub_Entity
    END AS Sub_Entity,
    Tenant,
    Distribution_Channel,
    Line_of_Business,
    CASE
      WHEN Entity = 'Hopper Travel'
        AND Account_SubCategory = 'Profit Share'
        AND Account_Category = 'Contra Revenue' THEN 'OPEX'
      ELSE Account_Category
    END AS Account_Category,
    CASE
      WHEN Account_SubCategory = 'Payments' THEN 'Payment'
      ELSE Account_SubCategory
    END AS Account_SubCategory,
    Version,
    Month,
    Amount
  FROM `h4r-common-bi-prd.hts_finance_data__gld.fact_consolidated_wholeco_public`
  WHERE Tenant = @TENANT_NAME
    AND Amount != 0 AND Amount IS NOT NULL
    AND Distribution_Channel NOT IN ('Fintech Ancillary', '3P', 'Audiences')
    AND Sub_Entity != 'Assist'
    AND (
      Intercompany = 'F'
      OR (Tenant = 'Hopper-App' AND Account_SubCategory = 'MAUs' AND Intercompany = 'T')
    )
),

-- Current month actuals
curr AS (
  SELECT
    SUM(CASE WHEN account_category = 'Metrics' AND Line_of_Business = 'Total' AND Account_SubCategory = 'MAUs' THEN amount ELSE 0 END) AS mau,
    SUM(CASE WHEN account_category = 'Metrics' AND Account_SubCategory = 'Bookings' THEN amount ELSE 0 END) AS bookings,
    SUM(CASE WHEN account_category = 'Metrics' AND Account_SubCategory = 'GBV' THEN amount ELSE 0 END) AS gbv,
    SUM(CASE WHEN account_category = 'Contribution Profit' THEN amount ELSE 0 END) AS contribution_profit
  FROM base
  WHERE month = @CURRENT_MONTH AND version = 'RunRate'
),

-- Previous month actuals
prev AS (
  SELECT
    SUM(CASE WHEN account_category = 'Metrics' AND Line_of_Business = 'Total' AND Account_SubCategory = 'MAUs' THEN amount ELSE 0 END) AS mau,
    SUM(CASE WHEN account_category = 'Metrics' AND Account_SubCategory = 'Bookings' THEN amount ELSE 0 END) AS bookings,
    SUM(CASE WHEN account_category = 'Metrics' AND Account_SubCategory = 'GBV' THEN amount ELSE 0 END) AS gbv,
    SUM(CASE WHEN account_category = 'Contribution Profit' THEN amount ELSE 0 END) AS contribution_profit
  FROM base
  WHERE month = @PREVIOUS_MONTH AND version = 'RunRate'
),

-- Forecast (Base version)
forecast AS (
  SELECT
    SUM(CASE WHEN Entity = 'HTS' AND Line_of_Business = 'Total' AND Account_Category = 'MAUs' THEN Amount ELSE 0 END) AS mau,
    SUM(CASE WHEN Entity = 'HTS' AND Account_Category = 'Bookings' THEN Amount ELSE 0 END) AS bookings,
    SUM(CASE WHEN Entity = 'HTS' AND Account_Category = 'GBV' THEN Amount ELSE 0 END) AS gbv,
    SUM(CASE WHEN Account_Category = 'Contribution Profit' THEN Amount ELSE 0 END) AS contribution_profit
  FROM `gcp-hopper-finance-research.hopper_travel_reporting.consolidated_financials`
  WHERE Tenant = @TENANT_NAME
    AND Month = @CURRENT_MONTH AND Version = 'Base'
    AND Amount != 0 AND Amount IS NOT NULL
    AND Distribution_Channel NOT IN ('Fintech Ancillary', '3P', 'Audiences')
    AND Sub_Entity != 'Assist' AND Intercompany = 'N'
),

-- 13-month lookback for record-month check (GBV and CP by month)
-- Includes the 12 months preceding @CURRENT_MONTH plus @CURRENT_MONTH itself
lookback AS (
  SELECT
    month,
    SUM(CASE WHEN account_category = 'Metrics' AND Account_SubCategory = 'GBV' THEN amount ELSE 0 END) AS gbv,
    SUM(CASE WHEN account_category = 'Contribution Profit' THEN amount ELSE 0 END) AS contribution_profit
  FROM base
  WHERE version = 'RunRate'
    AND month BETWEEN DATE_SUB(CAST(@CURRENT_MONTH AS DATE), INTERVAL 12 MONTH)
                   AND CAST(@CURRENT_MONTH AS DATE)
  GROUP BY month
)

SELECT
  -- Current month actuals
  ROUND(c.gbv, 0) AS curr_gbv,
  ROUND(c.bookings, 0) AS curr_bookings,
  ROUND(SAFE_DIVIDE(c.bookings, c.mau) * 100, 1) AS curr_cvr,
  ROUND(c.mau, 0) AS curr_mau,
  ROUND(SAFE_DIVIDE(c.gbv, c.bookings), 0) AS curr_aov,
  ROUND(c.contribution_profit, 0) AS curr_cp,
  ROUND(SAFE_DIVIDE(c.contribution_profit, c.gbv) * 100, 1) AS curr_cp_margin,

  -- MoM % changes
  ROUND(SAFE_DIVIDE(c.gbv - p.gbv, ABS(p.gbv)) * 100, 1) AS gbv_mom_pct,
  ROUND(SAFE_DIVIDE(c.bookings - p.bookings, ABS(p.bookings)) * 100, 1) AS bookings_mom_pct,
  -- CVR change in basis points (bps)
  ROUND((SAFE_DIVIDE(c.bookings, c.mau) - SAFE_DIVIDE(p.bookings, p.mau)) * 10000, 0) AS cvr_mom_bps,
  ROUND(SAFE_DIVIDE(c.mau - p.mau, ABS(p.mau)) * 100, 1) AS mau_mom_pct,
  ROUND(SAFE_DIVIDE(SAFE_DIVIDE(c.gbv, c.bookings) - SAFE_DIVIDE(p.gbv, p.bookings), ABS(SAFE_DIVIDE(p.gbv, p.bookings))) * 100, 1) AS aov_mom_pct,
  ROUND(SAFE_DIVIDE(c.contribution_profit - p.contribution_profit, ABS(p.contribution_profit)) * 100, 1) AS cp_mom_pct,

  -- vs Forecast % changes
  ROUND(SAFE_DIVIDE(c.gbv - f.gbv, ABS(f.gbv)) * 100, 1) AS gbv_avf_pct,
  ROUND(SAFE_DIVIDE(c.bookings - f.bookings, ABS(f.bookings)) * 100, 1) AS bookings_avf_pct,
  -- CVR vs forecast in basis points (bps)
  ROUND((SAFE_DIVIDE(c.bookings, c.mau) - SAFE_DIVIDE(f.bookings, f.mau)) * 10000, 0) AS cvr_avf_bps,
  ROUND(SAFE_DIVIDE(c.mau - f.mau, ABS(f.mau)) * 100, 1) AS mau_avf_pct,
  ROUND(SAFE_DIVIDE(SAFE_DIVIDE(c.gbv, c.bookings) - SAFE_DIVIDE(f.gbv, f.bookings), ABS(SAFE_DIVIDE(f.gbv, f.bookings))) * 100, 1) AS aov_avf_pct,
  ROUND(SAFE_DIVIDE(c.contribution_profit - f.contribution_profit, ABS(f.contribution_profit)) * 100, 1) AS cp_avf_pct,

  -- Record-month check (13-month window)
  -- Rank 1 = highest in window, Rank 2 = second highest
  (SELECT COUNT(*) + 1 FROM lookback l WHERE l.gbv > c.gbv AND l.month != CAST(@CURRENT_MONTH AS DATE)) AS gbv_13m_rank,
  (SELECT COUNT(*) + 1 FROM lookback l WHERE l.contribution_profit > c.contribution_profit AND l.month != CAST(@CURRENT_MONTH AS DATE)) AS cp_13m_rank,
  -- Month name of the higher-ranked month (only meaningful when rank = 2)
  (SELECT FORMAT_DATE('%B %Y', l.month) FROM lookback l WHERE l.gbv > c.gbv AND l.month != CAST(@CURRENT_MONTH AS DATE) ORDER BY l.gbv DESC LIMIT 1) AS gbv_higher_month,
  (SELECT FORMAT_DATE('%B %Y', l.month) FROM lookback l WHERE l.contribution_profit > c.contribution_profit AND l.month != CAST(@CURRENT_MONTH AS DATE) ORDER BY l.contribution_profit DESC LIMIT 1) AS cp_higher_month

FROM curr c
CROSS JOIN prev p
CROSS JOIN forecast f
