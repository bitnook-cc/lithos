# Slack Message Template

This is the Slack mrkdwn template for generating tenant channel updates.
Replace all `{PLACEHOLDER}` values with query results.

## Template

```
*{TENANT} | {MONTH} {YEAR} Update*

*Profitability:* {PROFITABILITY_EMOJI} {PROFITABILITY_LABEL}  |  *Relationship:* :pencil2: [Relationship status, please update]

*TL;DR:* {TLDR_NARRATIVE}

-------------------------

*Performance Metrics*
• *GBV:* {CURR_GBV} ({GBV_MOM_PCT} MoM, {GBV_AVF_PCT} vs forecast)
• *Bookings:* {CURR_BOOKINGS} ({BOOKINGS_MOM_PCT} MoM, {BOOKINGS_AVF_PCT} vs forecast)
• *CVR:* {CURR_CVR} ({CVR_MOM_BPS} bps MoM, {CVR_AVF_BPS} bps vs forecast)
• *MAUs:* {CURR_MAUS} ({MAU_MOM_PCT} MoM, {MAU_AVF_PCT} vs forecast)
• *AOV:* {CURR_AOV} ({AOV_MOM_PCT} MoM, {AOV_AVF_PCT} vs forecast)

*Profitability*
• *CP:* {CURR_CP} ({CP_MARGIN} CP margin)
• {CP_COMMENTARY}

*Wins*
• {WIN_1}

*Flags*
• {FLAG_1}

*Next Steps*
:pencil2: [Next steps, please update]
```

## Formatting Rules

### Numbers
- GBV: `$X.XM` if >= $1M, `$XXXK` if < $1M (e.g., `$9.3M`, `$673K`)
- Bookings: `X.XXK` if >= 1000 (e.g., `3.96K`, `19.3K`)
- CVR: `X.X%` (e.g., `12.2%`, `19.1%`)
- MAUs: `X.XK` if >= 1000 (e.g., `33.5K`, `102.5K`)
- AOV: `$XXX` no decimals (e.g., `$673`, `$485`)
- CP: `$X.XK` or `$XXXK` (e.g., `$66.6K`, `$205.3K`)
- CP Margin: `X.X%` (e.g., `27.9%`, `26.1%`)

### Change Values
- Percentages: always include sign (`+12.3%`, `-4.5%`)
- CVR changes: report in basis points with sign (`+9 bps`, `-181 bps`)

### Profitability Status
- CP > $50K: `:large_green_circle: Profitable`
- $0 < CP <= $50K: `:large_yellow_circle: Neutral`
- CP < $0: `:red_circle: Unprofitable`

Never reference the $50K threshold in the message text.

### Record-Month Wins
When the query returns `gbv_13m_rank` or `cp_13m_rank`:
- Rank 1: _"GBV of $X.XM is the highest in the past 12 months."_
- Rank 2: _"GBV of $X.XM is the second highest in the past 12 months, after {gbv_higher_month}."_
- Rank >= 3: not notable, do not mention
- Check GBV and CP independently — both can be wins in the same message

### TL;DR
Auto-generate a 1-2 sentence narrative covering:
1. The single most important signal — do not summarize everything
2. The headline GBV number and its AvF variance
3. The primary driver or notable event
Keep it concise and data-driven. If causal context is unconfirmed, append `:pencil2: [Reason, please update]`.
