# Amplitude ID Generator

A reusable Python tool for generating Amplitude user IDs from Hopper user IDs using the same deterministic algorithm as cx-dashboard.

**Use Case:** SEV incident analysis, user cohort tracking, revenue loss calculations - whenever you have Hopper user IDs and need their corresponding Amplitude tracking IDs.

## How It Works

The script implements the exact same algorithm used by `cx-dashboard` to generate Amplitude IDs:

```python
def calculate_amplitude_id(user_id: str) -> str:
    SALT = "A9SURUWHRDQ4N5IYX31UCBPDA9T674"

    # 1. Concatenate user_id + salt
    input_string = user_id + SALT

    # 2. SHA-256 hash
    hash_bytes = hashlib.sha256(input_string.encode('UTF-8')).digest()

    # 3. URL-safe Base64 encode
    encoded = base64.urlsafe_b64encode(hash_bytes).decode('UTF-8')

    # 4. Strip padding
    return encoded.rstrip('=')
```

**Source:** `hopper-org/cx-dashboard` → `user/src/main/scala/com/hopper/cxdashboard/service/user/User.scala` → `TrackingUserId.apply()` (lines 123-133)

**Important:** The salt is the same for all tenants. User IDs are globally unique across Hopper, so the same user ID always produces the same Amplitude ID regardless of tenant.

## Quick Start

### Single User Lookup

```bash
python3 amplitude_id_generator.py --user-id "48a623a5-7e3d-4d0b-9ad8-a2aee849ef63"
```

**Output:**
```
User ID:      48a623a5-7e3d-4d0b-9ad8-a2aee849ef63
Amplitude ID: po6AUpHzg7gsZ0y4cv3bwq7pOoNZNTVVFmIqP4gph7k
```

### Batch Processing (CSV)

```bash
# Process CSV file with user_id column
python3 amplitude_id_generator.py users.csv output.csv

# Auto-generate output filename
python3 amplitude_id_generator.py impacted_users.csv
# Creates: impacted_users_amplitude.csv
```

## Real-World Example: SEV-2 Incident Analysis

**Scenario:** Guest checkout bug affected 112 user sessions, need Amplitude IDs for revenue analysis.

```bash
# Input: impacted_users.csv with columns: device_id, user_id, trace_id_hex
python3 amplitude_id_generator.py /tmp/impacted_users.csv /tmp/amplitude_ids.csv

# Output: 106 unique users with Amplitude IDs
# Result: Can now cross-reference with booking data to calculate revenue loss
```

**Results from actual SEV-2:**
- Input: 112 rows (with 6 duplicate user_ids)
- Output: 106 unique users
- Validation: 100% match with Datadog RUM trace data (60/60 users)

## Input/Output Format

### Input CSV Requirements

- **Required:** Header row with column names
- **Required:** Column containing user IDs (default: `user_id`)
- **Optional:** Any other columns (will be preserved in output)

**Example input:**
```csv
user_id,device_id
48a623a5-7e3d-4d0b-9ad8-a2aee849ef63,671df0e6-8050-4eb8-a562-2cd6a80930c6
63447d3c-b111-45f8-9682-f3bdd35b11f0,8c95073c-2a18-474d-b823-70884ea6b6bd
```

### Output CSV Format

Columns are ordered: `user_id`, `amplitude_user_id`, then all other input columns

**Example output:**
```csv
user_id,amplitude_user_id,device_id
48a623a5-7e3d-4d0b-9ad8-a2aee849ef63,po6AUpHzg7gsZ0y4cv3bwq7pOoNZNTVVFmIqP4gph7k,671df0e6-8050-4eb8-a562-2cd6a80930c6
63447d3c-b111-45f8-9682-f3bdd35b11f0,uI5iP4j-F-zZ6yqGOLMeyLx59CTHYECFrG7EsqoW8i8,8c95073c-2a18-474d-b823-70884ea6b6bd
```

## Command-Line Options

```bash
# Show help
python3 amplitude_id_generator.py --help

# Single user ID
python3 amplitude_id_generator.py --user-id "USER_ID_HERE"

# CSV with custom column name
python3 amplitude_id_generator.py users.csv output.csv --user-column uid

# Keep duplicate user_ids (default: deduplicate)
python3 amplitude_id_generator.py users.csv output.csv --no-deduplicate
```

| Flag | Description | Example |
|------|-------------|---------|
| `--user-id` | Single user lookup | `--user-id "abc-123"` |
| `--user-column` | Custom column name | `--user-column uid` |
| `--no-deduplicate` | Keep duplicate user_ids | `--no-deduplicate` |
| `--help` | Show help message | `--help` |

## Deduplication Behavior

**Default:** Removes duplicate `user_id` values, keeping first occurrence

**Why?** Common in SEV incidents:
- User has multiple sessions (duplicate user_ids in trace data)
- User has multiple devices (same user_id, different device_ids)

**When to disable:** Use `--no-deduplicate` when you need session-level data or want to preserve all rows for joins.

## When to Use This Tool

### ✅ Use This Tool When:
- You have Hopper user IDs and need Amplitude IDs
- Datadog RUM traces are unavailable (>7 days old, no trace data)
- You need deterministic, reproducible results
- Processing batch data (incident analysis, cohort studies)
- Cross-referencing with other datasets that use Amplitude IDs

### ❌ Use Alternative Methods When:
- You need device IDs (not derivable from user ID - use RUM traces)
- You need actual Amplitude event data (use Amplitude API directly)
- You need real-time tracking data (use Amplitude SDK/Datadog RUM)

## Files

- `amplitude_id_generator.py` - Main executable script
- `README.md` - This file

## Additional Resources

- [Confluence Documentation](https://hopper-jira.atlassian.net/wiki/spaces/~627e92d466eb58006980f329/pages/8419868720/Amplitude+ID+Generator+-+User+ID+to+Amplitude+ID+Tool)
- [cx-dashboard Source Code](https://github.com/hopper-org/cx-dashboard/blob/master/user/src/main/scala/com/hopper/cxdashboard/service/user/User.scala#L123-L133)

---

**Created:** 2026-03-16 | **Author:** Pablo Mincz | **Use Case:** SEV-2 Guest Checkout Incident Analysis
