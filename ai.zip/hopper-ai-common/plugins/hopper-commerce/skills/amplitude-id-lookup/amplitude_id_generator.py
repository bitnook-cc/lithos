#!/usr/bin/env python3
"""
Amplitude ID Generator for Hopper Users

This script generates Amplitude user IDs from Hopper user IDs using the same
deterministic algorithm that cx-dashboard uses.

Algorithm (from cx-dashboard User.scala TrackingUserId.apply()):
1. Concatenate user_id + salt
2. SHA-256 hash
3. URL-safe Base64 encode (strip padding)

Usage:
    python3 amplitude_id_generator.py <input_csv> [output_csv]

    # Single user ID
    python3 amplitude_id_generator.py --user-id "48a623a5-7e3d-4d0b-9ad8-a2aee849ef63"

    # From CSV with user_id column
    python3 amplitude_id_generator.py users.csv output.csv

    # From CSV with custom column name
    python3 amplitude_id_generator.py users.csv output.csv --user-column uid

Input CSV format:
    Must have a header row with a column containing user IDs.
    Default column name: "user_id"

Example input CSV:
    user_id,device_id
    48a623a5-7e3d-4d0b-9ad8-a2aee849ef63,671df0e6-8050-4eb8-a562-2cd6a80930c6
    63447d3c-b111-45f8-9682-f3bdd35b11f0,8c95073c-2a18-474d-b823-70884ea6b6bd

Output CSV format:
    user_id,amplitude_user_id,[...other columns from input...]
"""

import csv
import hashlib
import base64
import sys
import argparse
from typing import Dict, List

# Salt used by cx-dashboard TrackingUserId
# Source: /cx-dashboard/user/src/main/scala/com/hopper/cxdashboard/service/user/User.scala
USER_SALT = "A9SURUWHRDQ4N5IYX31UCBPDA9T674"


def calculate_amplitude_id(user_id: str) -> str:
    """
    Calculate Amplitude user ID from Hopper user ID.

    This uses the exact same algorithm as cx-dashboard's TrackingUserId.apply()
    to ensure consistency across systems.

    Args:
        user_id: Hopper user UUID (e.g., "48a623a5-7e3d-4d0b-9ad8-a2aee849ef63")

    Returns:
        Amplitude user ID (URL-safe base64 encoded SHA-256 hash)

    Example:
        >>> calculate_amplitude_id("48a623a5-7e3d-4d0b-9ad8-a2aee849ef63")
        'po6AUpHzg7gsZ0y4cv3bwq7pOoNZNTVVFmIqP4gph7k'
    """
    # Concatenate user_id + salt
    s = user_id + USER_SALT

    # SHA-256 hash
    m = hashlib.sha256(s.encode('UTF-8')).digest()

    # URL-safe base64 encode (replaces + with -, / with _)
    amplitude_id = base64.urlsafe_b64encode(m).decode('UTF-8')

    # Strip trailing padding to match cx-dashboard format
    return amplitude_id.rstrip('=')


def process_csv(input_file: str, output_file: str, user_column: str = 'user_id',
                deduplicate: bool = True) -> Dict[str, any]:
    """
    Process a CSV file and add Amplitude IDs.

    Args:
        input_file: Path to input CSV file
        output_file: Path to output CSV file
        user_column: Name of the column containing user IDs
        deduplicate: If True, keep only first occurrence of each user_id

    Returns:
        Dictionary with statistics about the processing
    """
    # Read input CSV
    with open(input_file, 'r') as f:
        reader = csv.DictReader(f)
        rows = list(reader)

        if not rows:
            raise ValueError(f"Input file {input_file} is empty or has no data rows")

        if user_column not in rows[0]:
            available = ', '.join(rows[0].keys())
            raise ValueError(
                f"Column '{user_column}' not found in CSV. "
                f"Available columns: {available}"
            )

    # Process rows
    seen_users = set()
    results = []
    duplicates = 0

    for row in rows:
        user_id = row[user_column]

        # Check for duplicates
        if deduplicate and user_id in seen_users:
            duplicates += 1
            continue

        seen_users.add(user_id)

        # Calculate Amplitude ID
        amplitude_id = calculate_amplitude_id(user_id)

        # Add to results
        result = dict(row)
        result['amplitude_user_id'] = amplitude_id
        results.append(result)

    # Write output CSV
    if results:
        # Put user_id and amplitude_user_id first, then other columns
        fieldnames = ['user_id', 'amplitude_user_id']
        for key in results[0].keys():
            if key not in fieldnames:
                fieldnames.append(key)

        with open(output_file, 'w') as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(results)

    return {
        'total_input': len(rows),
        'unique_output': len(results),
        'duplicates': duplicates,
        'output_file': output_file
    }


def main():
    parser = argparse.ArgumentParser(
        description='Generate Amplitude user IDs from Hopper user IDs',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Process CSV file
  %(prog)s users.csv output.csv

  # Single user ID
  %(prog)s --user-id "48a623a5-7e3d-4d0b-9ad8-a2aee849ef63"

  # Custom column name
  %(prog)s users.csv output.csv --user-column uid

  # Keep duplicates
  %(prog)s users.csv output.csv --no-deduplicate
        """
    )

    parser.add_argument('input_file', nargs='?', help='Input CSV file path')
    parser.add_argument('output_file', nargs='?', help='Output CSV file path (default: input_file with _amplitude.csv suffix)')
    parser.add_argument('--user-id', help='Generate Amplitude ID for a single user ID')
    parser.add_argument('--user-column', default='user_id', help='Name of column containing user IDs (default: user_id)')
    parser.add_argument('--no-deduplicate', action='store_true', help='Keep duplicate user IDs in output')

    args = parser.parse_args()

    # Single user ID mode
    if args.user_id:
        amplitude_id = calculate_amplitude_id(args.user_id)
        print(f"User ID:      {args.user_id}")
        print(f"Amplitude ID: {amplitude_id}")
        return 0

    # CSV processing mode
    if not args.input_file:
        parser.print_help()
        return 1

    # Set default output file if not provided
    output_file = args.output_file
    if not output_file:
        if args.input_file.endswith('.csv'):
            output_file = args.input_file.replace('.csv', '_amplitude.csv')
        else:
            output_file = args.input_file + '_amplitude.csv'

    try:
        stats = process_csv(
            args.input_file,
            output_file,
            user_column=args.user_column,
            deduplicate=not args.no_deduplicate
        )

        print(f"✓ Processing complete")
        print(f"  Input rows:    {stats['total_input']}")
        print(f"  Output rows:   {stats['unique_output']}")
        if stats['duplicates'] > 0:
            print(f"  Duplicates:    {stats['duplicates']} (removed)")
        print(f"  Output file:   {stats['output_file']}")

        return 0

    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1


if __name__ == '__main__':
    sys.exit(main())
