# Tenant Maintenance Flag Registry

This file maps each B2B/HTS tenant to its LaunchDarkly project and maintenance flag(s). It is the source of truth for the incident-banners skill.

## How to Read This Table

- **LD Project**: the LaunchDarkly project key
- **Flag Key**: the feature flag key within that project
- **Flag Kind**: `boolean` (toggle on/off) or `multivariate` (set a specific variation)
- **Product**: which product funnel this flag controls (`all` = entire portal)
- **Behavior**: what happens when the flag is enabled:
  - `blocking` — full-page maintenance screen replaces the portal/funnel, users cannot proceed
  - `blocking (per-funnel)` — blocks a specific funnel while others remain accessible
  - `blocking (post-auth only)` — blocks logged-in users only; pre-auth maintenance requires a separate config change + deploy
  - `unknown` — behavior not confirmed from code (flag exists in LD but frontend consumption not verified)
- **Enable Variation**: the variation value or index to serve when enabling
- **Disable Variation**: the variation value or index to serve when disabling
- **Enable Index**: the zero-based variation index to pass to `update-rollout` for enabling
- **Disable Index**: the zero-based variation index to pass to `update-rollout` for disabling

> **Important**: as of 2026-04-17, every confirmed tenant maintenance flag is **blocking** — it replaces the portal with a maintenance page. APAC tenants (Lotte, SMCC, HSBC, Commbank AU) have a **dual maintenance system**: the LD flag controls post-auth maintenance only (logged-in users), while pre-auth maintenance (blocking the login page) uses `VITE_ENABLE_PRE_AUTH_MAINTENANCE` and requires a config change + deploy. There are currently no informational-only banners.

## Tenants

### TripAdvisor

| LD Project | Flag Key | Flag Kind | Product | Behavior | Enable Variation | Enable Index | Disable Variation | Disable Index |
|---|---|---|---|---|---|---|---|---|
| multi-tenant | hts-tripadvisor-maintenance-page | multivariate | all | unknown | FullMaintenance | 1 | Control | 0 |
| multi-tenant | hts-tripadvisor-maintenance-page | multivariate | checkout | unknown | CheckoutMaintenance | 2 | Control | 0 |
| multi-tenant | hts-tripadvisor-maintenance-page | multivariate | trips | unknown | TripsMaintenance | 3 | Control | 0 |

> **Warning**: TripAdvisor's frontend is owned by TripAdvisor, not Hopper. This flag is consumed in their code. Behavior (blocking vs informational) cannot be confirmed from Hopper repos. The deprecated `tripadvisor-maintenance` flag in the `tripadvisor` LD project should NOT be used.

### Lotte

| LD Project | Flag Key | Flag Kind | Product | Behavior | Enable Variation | Enable Index | Disable Variation | Disable Index |
|---|---|---|---|---|---|---|---|---|
| lotte | maintenance | multivariate | all | blocking (post-auth only) | available | 0 | control | 1 |

> Confirmed blocking (post-auth): `useBooleanFlag(FeatureFlagNames.ENABLE_MAINTENANCE_MODE)` in `apps/lotte/src/App.tsx` renders `<Maintenance />` replacing all authenticated routes. **Note — dual maintenance system**: pre-auth maintenance uses `VITE_ENABLE_PRE_AUTH_MAINTENANCE` and requires a config change + deploy.

### SMCC

| LD Project | Flag Key | Flag Kind | Product | Behavior | Enable Variation | Enable Index | Disable Variation | Disable Index |
|---|---|---|---|---|---|---|---|---|
| smcc | smcc-maintenance | multivariate | all | blocking (post-auth only) | Available | 0 | Control | 1 |

> Confirmed blocking (post-auth): `useBooleanFlag(FeatureFlagNames.SMCC_MAINTENANCE)` in `AppContentOrPostAuthMaintenance` component in `apps/smcc/src/App.tsx` renders `<Maintenance />` replacing all authenticated routes. **Note — dual maintenance system**: pre-auth maintenance uses `VITE_ENABLE_PRE_AUTH_MAINTENANCE` and requires a config change + deploy.

### HSBC India

| LD Project | Flag Key | Flag Kind | Product | Behavior | Enable Variation | Enable Index | Disable Variation | Disable Index |
|---|---|---|---|---|---|---|---|---|
| hsbc-in | hsbc-maintenance | boolean | all | blocking (post-auth only) | true (on) | — | false (off) | — |

> Confirmed blocking (post-auth): `useBooleanFlag(FeatureFlagNames.MAINTENANCE)` in `useUnavailableRedirect` hook redirects logged-in users to the maintenance page. **Note — dual maintenance system**: this LD flag only controls post-auth maintenance. Pre-auth maintenance (blocking the login page) uses `VITE_ENABLE_PRE_AUTH_MAINTENANCE` and requires a config change + deploy.

### HSBC Singapore

| LD Project | Flag Key | Flag Kind | Product | Behavior | Enable Variation | Enable Index | Disable Variation | Disable Index |
|---|---|---|---|---|---|---|---|---|
| hsbc-sg | hsbc-maintenance | boolean | all | blocking (post-auth only) | true (on) | — | false (off) | — |

> Confirmed blocking (post-auth): same as HSBC India — `useUnavailableRedirect` hook consumes this flag. Pre-auth maintenance requires config change + deploy.

### HSBC UAE

| LD Project | Flag Key | Flag Kind | Product | Behavior | Enable Variation | Enable Index | Disable Variation | Disable Index |
|---|---|---|---|---|---|---|---|---|
| hsbc-uae | hsbc-maintenance | boolean | all | blocking (post-auth only) | true (on) | — | false (off) | — |

> Confirmed blocking (post-auth): same as HSBC India — `useUnavailableRedirect` hook consumes this flag. Pre-auth maintenance requires config change + deploy.

### HSBC Qatar

| LD Project | Flag Key | Flag Kind | Product | Behavior | Enable Variation | Enable Index | Disable Variation | Disable Index |
|---|---|---|---|---|---|---|---|---|
| hsbc-qa | hsbc-maintenance | boolean | all | blocking (post-auth only) | true (on) | — | false (off) | — |

> Confirmed blocking (post-auth): same as HSBC India — `useUnavailableRedirect` hook consumes this flag. Pre-auth maintenance requires config change + deploy.

### Commbank AU

| LD Project | Flag Key | Flag Kind | Product | Behavior | Enable Variation | Enable Index | Disable Variation | Disable Index |
|---|---|---|---|---|---|---|---|---|
| commbank-au | commbank-au-maintenance | multivariate | all | blocking (post-auth only) | available | 0 | control | 1 |
| commbank-au | commbank-au-flights-maintenance | multivariate | flights | blocking (per-funnel, post-auth only) | available | 0 | control | 1 |
| commbank-au | commbank-au-hotels-maintenance | multivariate | hotels | blocking (per-funnel, post-auth only) | available | 0 | control | 1 |
| commbank-au | commbank-au-trips-maintenance | multivariate | trips | blocking (per-funnel, post-auth only) | available | 0 | control | 1 |
| commbank-au | commbank-au-cars-maintenance | multivariate | cars | blocking (per-funnel, post-auth only) | available | 0 | control | 1 |

> Confirmed blocking (post-auth): global flag via `useFeatureFlag(FEATURE_FLAGS.MAINTENANCE)` in `Body.tsx` renders `<Maintenance />` replacing all authenticated routes. Per-funnel flags block individual product routes while other funnels remain accessible. **Note — dual maintenance system**: pre-auth maintenance uses `VITE_ENABLE_PRE_AUTH_MAINTENANCE` and requires a config change + deploy.

### Lloyds

| LD Project | Flag Key | Flag Kind | Product | Behavior | Enable Variation | Enable Index | Disable Variation | Disable Index |
|---|---|---|---|---|---|---|---|---|
| multi-tenant | hts-lloyds-maintenance | multivariate | all | blocking | Available | 0 | Control | 1 |

> Confirmed blocking: `useKillSwitches(KillSwitchNames.MAINTENANCE)` in `apps/lloyds/src/Routes/AppRoutes.tsx` renders `<Maintenance />` (an `ErrorScreen` component) replacing all routes.

### PerkSpot

| LD Project | Flag Key | Flag Kind | Product | Behavior | Enable Variation | Enable Index | Disable Variation | Disable Index |
|---|---|---|---|---|---|---|---|---|
| perkspot | EnableMaintenanceBanner | multivariate | all | blocking | Available | 0 | Control | 1 |

> Despite the flag name containing "Banner", the behavior is blocking based on the shared b2bportal maintenance pattern. The flag description says "Toggle maintenance banner in the home page."

### Nubank

| LD Project | Flag Key | Flag Kind | Product | Behavior | Enable Variation | Enable Index | Disable Variation | Disable Index |
|---|---|---|---|---|---|---|---|---|
| nubank | nubank-maintenance | multivariate | all | blocking | disable-everything | 1 | control | 0 |
| nubank | nubank-maintenance | multivariate | flights | blocking (per-funnel) | flights | 2 | control | 0 |
| nubank | nubank-maintenance | multivariate | hotels | blocking (per-funnel) | hotels | 3 | control | 0 |
| nubank | nubank-maintenance | multivariate | trips | blocking (per-funnel) | trips | 4 | control | 0 |

> Confirmed blocking: variant evaluation in `apps/nubank/src/App.tsx` sets `showMaintenance` which renders `<Maintenance />` (a full-page screen with a "close webview" CTA). `exclude-trips` (index 5) blocks everything except trips.

### Virgin Australia

> **No maintenance flag exists** for Virgin AU. This tenant is skipped during bulk operations. If a maintenance flag is added in the future, add it here.

## Tenants NOT Covered by This Skill

- **Capital One** — uses a separate mechanism (pre-auth config deploys in `capone-travel-portal` repo + post-auth flags in the `capital-one` LD project). Managed separately by the Cap1 team.

## Adding a New Tenant

When a new tenant portal is onboarded:

1. Find the tenant's LD project key and maintenance flag key
2. Determine the flag kind (boolean or multivariate) and variation indices
3. **Verify the flag is actually consumed in the portal frontend code** — check the tenant's app in the `b2bportal` repo for `useExperiment`, `useBooleanFlag`, `useFeatureFlag`, or `useKillSwitches` referencing the flag
4. Determine the behavior (blocking full-page vs informational banner)
5. Add a new section to this file following the format above
6. If the tenant has product-specific flags, add a row for each product
