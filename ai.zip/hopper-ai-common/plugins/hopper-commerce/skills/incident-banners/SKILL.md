---
name: incident-banners
description: >
  Use when enabling or disabling maintenance banners across B2B/HTS tenant portals during incidents.
  Triggers: "put up banners", "enable maintenance banners", "take down banners", "disable maintenance",
  "incident banners", "status page banners", "maintenance page", "tenant banners", "outage banners",
  "banner all tenants", "lodging banners", "flights banners", "hotels banners".
allowed-tools: mcp__launchdarkly__*, mcp__slack__*
---

# Incident Banners

Bulk-toggle maintenance banners across B2B/HTS tenant portals via LaunchDarkly during incidents. Replaces the manual process of toggling flags one-by-one across 10+ separate LD projects.

## When to Use

- A SEV-1 or SEV-2 incident is affecting B2B tenant portals
- On-call needs to put up or take down maintenance banners across multiple tenants
- Someone asks to "put up banners" or "enable maintenance" for portal funnels

## Tenant Flag Registry

Read [references/tenant-flags.md](references/tenant-flags.md) for the complete mapping of tenants to LaunchDarkly projects and flag keys. This file is the source of truth for which flags to toggle.

## How It Works

### Step 1: Understand the Request

Determine from the user's message:

1. **Action**: enable (put up) or disable (take down) banners
2. **Scope**: all tenants, or a specific subset (e.g., "only HSBC tenants")
3. **Product filter**: all products, or a specific product (e.g., "lodging only", "flights only")
4. **Environment**: defaults to `production` unless the user specifies `staging`

### Step 2: Build the Flag List

Read `references/tenant-flags.md` and filter based on the request:

- If a **product filter** is specified (e.g., "lodging"), select product-specific flags where available (e.g., `commbank-au-hotels-maintenance` for Commbank). For tenants without product-specific flags, fall back to their general maintenance flag.
- If **no product filter**, use the general maintenance flag for each tenant.
- If **specific tenants** are named, filter to only those tenants.
- **APAC tenants** (Lotte, SMCC, Commbank AU, HSBC IN/SG/UAE/QA) have a dual maintenance system. The LD flags control **post-auth maintenance only** — they block logged-in users. Pre-auth maintenance (blocking the login page) requires a separate config change + deploy (`VITE_ENABLE_PRE_AUTH_MAINTENANCE`). Include all APAC tenants in bulk toggles but warn the user that the LD flags only affect post-auth.
- **Skip Virgin Australia** — no maintenance flag exists.

**All maintenance flags are blocking** — they replace the portal with a full-page maintenance screen. For APAC tenants (Lotte, SMCC, Commbank AU, HSBC), the LD flags only affect **post-auth** (logged-in users). Pre-auth blocking requires a separate config deploy. Make sure the user understands this distinction.

### Step 3: Confirm with the User

Before toggling anything, present a summary and ask for explicit confirmation. Include the behavior for each flag:

```
I'm about to **enable** maintenance pages in **production** for:

⚠️ These are BLOCKING — users will NOT be able to use the affected portals/funnels.

- TripAdvisor (`multi-tenant` / `hts-tripadvisor-maintenance-page` -> FullMaintenance) [behavior unknown — TA-owned frontend]
- Lotte (`lotte` / `maintenance` -> available) [blocking, post-auth only]
- SMCC (`smcc` / `smcc-maintenance` -> Available) [blocking, post-auth only]
- Commbank AU (`commbank-au` / `commbank-au-maintenance` -> available) [blocking, post-auth only]
- Lloyds (`multi-tenant` / `hts-lloyds-maintenance` -> Available) [blocking]
- PerkSpot (`perkspot` / `EnableMaintenanceBanner` -> Available) [blocking]
- Nubank (`nubank` / `nubank-maintenance` -> disable-everything) [blocking]
- HSBC IN (`hsbc-in` / `hsbc-maintenance` -> true) [blocking, post-auth only]
- HSBC SG (`hsbc-sg` / `hsbc-maintenance` -> true) [blocking, post-auth only]
- HSBC UAE (`hsbc-uae` / `hsbc-maintenance` -> true) [blocking, post-auth only]
- HSBC QA (`hsbc-qa` / `hsbc-maintenance` -> true) [blocking, post-auth only]

⚠️ APAC tenants (Lotte, SMCC, Commbank AU, HSBC): LD flags only control post-auth maintenance. Pre-auth maintenance requires a config change + deploy (`VITE_ENABLE_PRE_AUTH_MAINTENANCE`).

Skipped:
- Virgin AU — no maintenance flag exists

Proceed? (yes/no)
```

**NEVER toggle flags without user confirmation.**

### Step 4: Toggle the Flags

For each flag in the list, use the appropriate LD MCP tool based on the flag type:

**Multivariate flags** (most tenants): use two calls:

1. First, ensure the flag is ON with `mcp__launchdarkly__toggle-flag`:
```
mcp__launchdarkly__toggle-flag:
  projectKey: "lotte"
  flagKey: "maintenance"
  env: "production"
  on: true
  comment: "Incident banner - enabled via Hopper AI"
```

2. Then set the fallthrough to serve the correct variation with `mcp__launchdarkly__update-rollout`:
```
mcp__launchdarkly__update-rollout:
  projectKey: "lotte"
  flagKey: "maintenance"
  env: "production"
  rolloutType: "variation"
  variationIndex: 0      # index of the "enable" variation — see tenant-flags.md
  comment: "Incident banner - enabled via Hopper AI"
```

**To disable** multivariate flags, set the fallthrough back to the "control" variation index.

### Step 5: Verify and Report Results

After all toggles complete, **verify each flag's actual state** by calling `mcp__launchdarkly__get-flag` for every flag that was toggled. Compare the actual state against the intended state and report:

```
mcp__launchdarkly__get-flag:
  projectKey: "lotte"
  flagKey: "maintenance"
  env: "production"
```

Check that:
- For boolean flags: `environments.production.on` matches the intended state
- For multivariate flags: `environments.production.fallthrough.variation` matches the intended variation index

Report the **verified** summary:

```
Maintenance pages **enabled** in production (verified via API):

✅ TripAdvisor: FullMaintenance (variation 1) — confirmed
✅ Lotte: available (variation 0, post-auth only) — confirmed
✅ SMCC: Available (variation 0, post-auth only) — confirmed
✅ Commbank AU: available (variation 0, post-auth only) — confirmed
✅ Lloyds: Available (variation 0) — confirmed
✅ PerkSpot: Available (variation 0) — confirmed
✅ Nubank: disable-everything (variation 1) — confirmed
✅ HSBC IN: on (post-auth only) — confirmed
✅ HSBC SG: on (post-auth only) — confirmed
✅ HSBC UAE: on (post-auth only) — confirmed
✅ HSBC QA: on (post-auth only) — confirmed

⚠️ APAC tenants: pre-auth maintenance requires separate config change + deploy

Skipped:
⚠️ Virgin AU — no maintenance flag

Failed:
- (none)
```

If any flag's actual state does not match the intended state, report it as a mismatch and suggest manual intervention. If any toggle call fails, report the error but continue with the remaining flags — do not stop on first failure.

## Read-Only Fallback (Hopper AI via Slack)

The LaunchDarkly integration in Hopper AI (Slack) is configured with `reader` scope only — write operations will fail. If a `toggle-flag` or `update-rollout` call fails with a permissions error, switch to **command output mode**:

1. Build the flag list and confirm with the user as usual (Steps 1-3)
2. Instead of executing the toggles, output the LD dashboard links for each flag so the user can toggle them manually:

```
I can't toggle flags directly (LD integration is read-only in Slack). Here are the direct links to toggle each flag:

- TripAdvisor: https://app.launchdarkly.com/projects/multi-tenant/flags/hts-tripadvisor-maintenance-page/targeting?env=production
- Lotte: https://app.launchdarkly.com/projects/lotte/flags/maintenance/targeting?env=production
- SMCC: https://app.launchdarkly.com/projects/smcc/flags/smcc-maintenance/targeting?env=production
- Commbank AU: https://app.launchdarkly.com/projects/commbank-au/flags/commbank-au-maintenance/targeting?env=production
- Lloyds: https://app.launchdarkly.com/projects/multi-tenant/flags/hts-lloyds-maintenance/targeting?env=production
- PerkSpot: https://app.launchdarkly.com/projects/perkspot/flags/EnableMaintenanceBanner/targeting?env=production
- Nubank: https://app.launchdarkly.com/projects/nubank/flags/nubank-maintenance/targeting?env=production
- HSBC IN: https://app.launchdarkly.com/projects/hsbc-in/flags/hsbc-maintenance/targeting?env=production
- HSBC SG: https://app.launchdarkly.com/projects/hsbc-sg/flags/hsbc-maintenance/targeting?env=production
- HSBC UAE: https://app.launchdarkly.com/projects/hsbc-uae/flags/hsbc-maintenance/targeting?env=production
- HSBC QA: https://app.launchdarkly.com/projects/hsbc-qa/flags/hsbc-maintenance/targeting?env=production

⚠️ APAC tenants (Lotte, SMCC, Commbank AU, HSBC): these LD flags only control post-auth maintenance. Pre-auth maintenance requires a config change + deploy.

For each flag, set the default variation to the "enable" value listed above.
```

When used locally via Claude Code or Cursor with the official LaunchDarkly MCP server (which authenticates with the user's own LD credentials), write operations work normally and the skill can toggle flags directly.

## Important Notes

- **All APAC tenant flags are post-auth only** — the LD flags control maintenance for logged-in users. Pre-auth maintenance (blocking the login page entirely) uses `VITE_ENABLE_PRE_AUTH_MAINTENANCE` and requires a config change + deploy. This dual pattern applies to Lotte, SMCC, Commbank AU, and all HSBC regions. Always warn the user that toggling LD flags only affects post-auth.
- **Capital One is out of scope** — Cap1 uses a separate mechanism (pre-auth config deploys + separate LD project). Do not attempt to toggle Cap1 banners with this skill.
- **Virgin Australia has no maintenance flag** — skip this tenant and note it in the summary.
- **Always include a comment** on every LD flag change for audit trail.
- **Environment awareness**: always confirm which environment (staging/production) before toggling. Default to production but support staging for testing.
- **TripAdvisor product-specific variations**: the `hts-tripadvisor-maintenance-page` flag supports `FullMaintenance` (all funnels), `CheckoutMaintenance` (checkout only), and `TripsMaintenance` (trips only). Use the appropriate variation based on the product filter. Note: TripAdvisor's frontend is owned by TripAdvisor — exact behavior cannot be confirmed from Hopper repos.
- **Nubank product-specific variations**: the `nubank-maintenance` flag supports `disable-everything` (all funnels), `flights`, `hotels`, `trips`, and `exclude-trips`. Use the appropriate variation based on the product filter.
