---
name: bigquery
description: >-
  Use when querying BigQuery, writing SQL for BigQuery, analyzing Hopper data
  in BigQuery, running bq commands, or investigating data in
  gcp-hopper-etldata or h4r-common-bi-prd tables/views. Triggers: "BigQuery",
  "bq query", "BQ", "etldata", "h4r-common-bi-prd", "__slv", "__gld",
  "silver", "gold", "data warehouse", "run a query", "look up data in".
---

# BigQuery — Querying Data at Hopper

## Billing Project

Always run BigQuery jobs in the `gcp-hopper-ds-research` project unless the user explicitly specifies a different project.

```bash
bq query --project_id=gcp-hopper-ds-research --use_legacy_sql=false '...'
```

This applies to all query types: interactive, dry-run, and scripting. The `--project_id` flag controls where the job runs and which project is billed — it does not restrict which datasets you can read from.

## Default to Production Data

Query production data unless the user explicitly requests a different environment. Use fully qualified table names in all queries.

### Data Architecture

Hopper has two generations of data infrastructure. Always prefer golden-path data when available.

#### Golden path (preferred): `h4r-common-bi-prd`

New data following the golden path lives in the `h4r-common-bi-prd` project, organized into medallion-style datasets:

| Dataset suffix | Layer | Description |
|----------------|-------|-------------|
| `__slv` (silver) | Service-aligned | Cleaned, dimensionally modeled data organized by source service. Start here when exploring data from a specific service or domain. |
| `__gld` (gold) | Use-case-driven | Aggregated, business-oriented views built on top of silver. Start here when answering a business question or building a report. |

```sql
-- Silver: service-aligned data
SELECT * FROM `h4r-common-bi-prd.bookings__slv.flights_bookings`
WHERE dt >= "2026-05-01"

-- Gold: use-case-driven data
SELECT * FROM `h4r-common-bi-prd.revenue__gld.daily_revenue_summary`
WHERE dt >= "2026-05-01"
```

#### Legacy: `gcp-hopper-etldata-production`

Many existing datasets and tables still live in `gcp-hopper-etldata-production`. This is the legacy data warehouse project. Data here may not follow consistent naming or modeling conventions.

```sql
SELECT * FROM `gcp-hopper-etldata-production.dataset_name.table_name`
WHERE dt >= "2026-05-01"
```

#### Choosing the right project

1. Check `h4r-common-bi-prd` first — if a `__slv` or `__gld` dataset covers what you need, use it
2. Fall back to `gcp-hopper-etldata-production` for data that hasn't been migrated to the golden path yet
3. If you're unsure which project has the data, query `INFORMATION_SCHEMA.SCHEMATA` in both projects. Exclude datasets ending in `_physical` — these are storage-layer duplicates and should not be queried directly.

```bash
# Golden path datasets
bq query --project_id=gcp-hopper-ds-research --use_legacy_sql=false \
  'SELECT schema_name
   FROM `h4r-common-bi-prd.INFORMATION_SCHEMA.SCHEMATA`
   WHERE schema_name NOT LIKE "%_physical"
   ORDER BY schema_name'

# Legacy datasets
bq query --project_id=gcp-hopper-ds-research --use_legacy_sql=false \
  'SELECT schema_name
   FROM `gcp-hopper-etldata-production.INFORMATION_SCHEMA.SCHEMATA`
   WHERE schema_name NOT LIKE "%_physical"
   ORDER BY schema_name'
```

#### Non-production environments

For development and staging data (rarely needed):

| Environment | Legacy project | Golden path project |
|-------------|---------------|---------------------|
| Development | `gcp-hopper-etldata-development` | — |
| Staging | `gcp-hopper-etldata-staging` | `h4r-common-bi-stg` |
| Production | `gcp-hopper-etldata-production` | `h4r-common-bi-prd` |

## Dry Run First — Always

Before executing any query, run it with the `--dry_run` flag to validate the SQL and estimate the amount of data scanned.

```bash
bq query \
  --project_id=gcp-hopper-ds-research \
  --use_legacy_sql=false \
  --dry_run \
  'SELECT col1, col2 FROM `gcp-hopper-etldata-production.dataset.table` WHERE dt = "2026-05-04"'
```

The dry-run output reports `totalBytesProcessed`. Use this to assess cost before executing:

| Bytes processed | Approximate cost | Action |
|-----------------|-----------------|--------|
| < 1 GB | ~$0.005 | Safe to run |
| 1 - 10 GB | $0.005 - $0.05 | Acceptable for most queries |
| 10 - 100 GB | $0.05 - $0.50 | Review filters — can you narrow the scan? |
| 100 GB - 1 TB | $0.50 - $5.00 | Add partition/clustering filters before running |
| > 1 TB | > $5.00 | Stop and confirm with the user before executing |

If the dry run reveals a large scan, revisit the query to add or tighten filters on partition and clustering columns before executing.

## Filter on Partition and Clustering Columns

Always attempt to include filters on partition columns and clustering columns to minimize the amount of data scanned.

### Partition columns

Most Hopper BigQuery tables are partitioned by a date or timestamp column (commonly `dt`, `date`, `created_at`, `event_timestamp`, or `_PARTITIONTIME`). Always include a filter on the partition column:

```sql
-- Good: filters on partition column
SELECT * FROM `gcp-hopper-etldata-production.dataset.table`
WHERE dt >= "2026-05-01" AND dt <= "2026-05-04"

-- Bad: full table scan
SELECT * FROM `gcp-hopper-etldata-production.dataset.table`
```

### Clustering columns

Many tables are also clustered on high-cardinality columns (e.g., `tenant_id`, `booking_id`, `user_id`, `provider`, `vertical`). Adding equality or range filters on clustering columns further reduces the data scanned:

```sql
-- Better: partition + clustering filter
SELECT * FROM `gcp-hopper-etldata-production.dataset.table`
WHERE dt >= "2026-05-01" AND dt <= "2026-05-04"
  AND tenant_id = "hopper"
```

### Discovering partition and clustering columns

If you don't know the table's partitioning or clustering scheme, check the table metadata before writing the query:

```bash
bq show --project_id=gcp-hopper-ds-research \
  'gcp-hopper-etldata-production:dataset.table'
```

Look for:
- `Time Partitioning` — shows the partition column and type
- `Clustering Fields` — lists clustering columns in order

Use this information to add the appropriate filters to your query.

## Full Workflow

When asked to query BigQuery data, follow this sequence:

1. *Identify the table* — check `h4r-common-bi-prd` (`__slv`/`__gld` datasets) first, then fall back to `gcp-hopper-etldata-production` for legacy data
2. *Inspect the table* — run `bq show` to check the schema, partition column, and clustering columns
3. *Write the query* — include filters on partition and clustering columns
4. *Dry run* — execute with `--dry_run` to validate SQL and check estimated bytes processed
5. *Assess cost* — if the scan is large (>100 GB), look for ways to narrow filters or confirm with the user
6. *Execute* — run the query without `--dry_run`

## Query Template

```bash
# Step 1: Inspect the table
bq show --project_id=gcp-hopper-ds-research \
  'gcp-hopper-etldata-production:dataset.table'

# Step 2: Dry run
bq query \
  --project_id=gcp-hopper-ds-research \
  --use_legacy_sql=false \
  --dry_run \
  'SELECT col1, col2
   FROM `gcp-hopper-etldata-production.dataset.table`
   WHERE dt >= "2026-05-01" AND dt <= "2026-05-04"
     AND clustering_col = "value"
   LIMIT 100'

# Step 3: Execute (after dry run passes and cost is acceptable)
bq query \
  --project_id=gcp-hopper-ds-research \
  --use_legacy_sql=false \
  --format=prettyjson \
  'SELECT col1, col2
   FROM `gcp-hopper-etldata-production.dataset.table`
   WHERE dt >= "2026-05-01" AND dt <= "2026-05-04"
     AND clustering_col = "value"
   LIMIT 100'
```

## Common Pitfalls

- *Forgetting `--project_id`* — without it, `bq` uses whatever project is set as default, which may not be `gcp-hopper-ds-research`
- *Using legacy SQL* — always pass `--use_legacy_sql=false`; Hopper tables use standard SQL
- *Querying without a date filter* — most tables are date-partitioned; omitting the date filter scans all partitions
- *Using `SELECT *` on wide tables* — select only the columns you need to reduce bytes processed
- *Wrong project* — prefer `h4r-common-bi-prd` (golden path) over `gcp-hopper-etldata-production` (legacy); only use legacy when the data hasn't been migrated
- *Wrong layer* — use `__gld` datasets for business questions and reports; use `__slv` datasets for service-level exploration

## Cross-References

- [gcp](hopper-developer:gcp) — GCP project landscape and naming conventions
