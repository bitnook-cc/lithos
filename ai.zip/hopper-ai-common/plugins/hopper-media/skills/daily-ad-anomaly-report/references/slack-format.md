# Slack Report Format Reference

## Formatting Helpers

| Type | Format | Example |
|------|--------|---------|
| Dollar | `$N,NNN` (no decimals) | `$24,189` |
| Percent change | `+N.N%` / `-N.N%` (sign always shown) | `+5.4%`, `-3.2%` |
| Z-score | `+N.NN` / `-N.NN` (sign always shown) | `+0.85`, `-4.30` |
| ROAS | `N.NNx` (2 decimals) | `5.16x` |
| Count | `N,NNN` (comma-separated) | `2,000,422` |
| CTR/CPM | `N.NN` (2 decimals) | `1.12` |

## Status Emojis

| Status | Emoji |
|--------|-------|
| ACTION NEEDED | `:red_circle:` |
| MONITOR | `:large_yellow_circle:` |
| ALL CLEAR | `:large_green_circle:` |

## Parent Message: Summary

```
*Ad Performance Report — {endDate}*
{status_emoji} *{STATUS}* — {status_summary}

```
Metric           Value          DoD    vs7d       z   Status
-----------------------------------------------------------------
Spend           $24,189      +5.4%   +3.2%   +0.85       OK
Impressions   2,000,422      +5.1%   +2.8%   +0.72       OK
Clicks           23,587      +5.6%  +28.1%   +1.52       OK
CTR                1.12      +2.3%  +24.0%   +0.97       OK
CPM              12.72       +7.9%   -7.2%   -0.61       OK
VTA Revenue    $416,848     +16.4%   +4.6%   +0.34       OK
CTA Revenue     $37,248     +20.0%  +17.6%   +1.04       OK
Total Revenue  $454,096     +16.7%   +5.6%   +0.42       OK
Total ROAS       16.96x      +4.8%  +11.3%   +1.29       OK
```

{For each ALERT/WARN KPI:}
:rotating_light: ALERT *{Metric}*: {value} (z={z}, vs 7d avg {vs7d}%)
:warning: WARN *{Metric}*: {value} (z={z}, vs 7d avg {vs7d}%)

*Pipeline Health:* {N} critical, {N} warning, {N} spike, {N} OK ({total} checks)
{If backfill: `:construction: _Bronze backfill in progress_`}

_Thread below: pipeline health detail, advertiser watchlist, channel summary._
```

KPI table column widths: Metric 16, Value 12 (right-aligned), DoD 8, vs7d 8, z 7, Status 8.

## Thread Reply 1: Pipeline Health Detail

```
*Pipeline Health Detail*
{N} critical · {N} warning · {N} spike · {N} OK

*Attribution (A / B / C)*
{non-OK alerts table or "All checks OK"}

*Managed Offers (D)*
{non-OK alerts table or "All checks OK"}

*Forecasting (E)*
{non-OK alerts table or "All checks OK"}

*Data Quality (F)*
{non-OK alerts table or "All checks OK"}
```

Alert table format (inside code block):
```
Check                Sev       Entity          Metric         Value     Base      Δ%
-------------------------------------------------------------------------------------
B1_bookings_wow      WARNING   vio-web/hotel   bookings       248.0    384.0   -35.4%
```

Alert table column widths: Check 20, Sev 9, Entity 15 (truncated), Metric 12 (truncated), Value 8, Base 8, Δ% 7.

Group checks by family:
- **Attribution (A / B / C)**: check_ids starting with A, B, or C
- **Managed Offers (D)**: check_ids starting with D
- **Forecasting (E)**: check_ids starting with E
- **Data Quality (F)**: check_ids starting with F

## Thread Reply 2: Detail

```
*Advertiser Watchlist*
```
Advertiser                Metric      Value       Mean       z  Sev       60d Spend
------------------------------------------------------------------------------------
Tourism Northern Territ   roas      269.03x     5.47x  +23.53  ALERT       $12,345
```

{or "No anomalies detected"}

*Channel Summary*
```
Channel              Spend      Revenue     ROAS   Share
------------------------------------------------------------
Hopper App         $24,697     $342,930   13.89x   92.2%
Capone Web          $1,859      $83,021   44.66x    6.9%
```

*7-Day Trend Signals*
```
Metric              Current     Prior Wk      WoW  Direction
--------------------------------------------------------------
Spend               $26,776      $32,150    -16.7%  ↓ Falling
Impressions       2,104,789    2,292,952     -8.2%  ↓ Falling
```

_Report date: {endDate} · {N} ad-performance rows · {N} pipeline checks_
```

Column widths for each table:
- Advertiser: Name 25 (truncated), Metric 8, Value 10, Mean 10, z 7, Sev 6, 60d Spend 10
- Channel: Name 16, Spend 12, Revenue 12, ROAS 8, Share 7
- Trends: Metric 16, Current 12, Prior Wk 12, WoW 8, Direction 10

For ROAS values use `N.NNx`. For dollar values use `$N,NNN`. For trend direction use arrows: `↑ Rising`, `↓ Falling`, `→ Stable`.

## Message Size Limits

Each Slack message must be ≤ 3,900 characters. If a message exceeds this:
1. Split at the nearest `\n\n` boundary (prefer section breaks)
2. If no section break within the last half, split at nearest `\n`
3. If splitting inside a code fence, close with ` ``` ` and reopen with ` ``` ` in the next chunk
