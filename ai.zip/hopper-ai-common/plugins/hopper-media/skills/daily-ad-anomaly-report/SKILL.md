---
name: daily-ad-anomaly-report
description: >
  Use when asked to run, generate, or check the daily ad performance anomaly report,
  pipeline health checks, or ad KPI anomalies for HTS Media. Covers z-score anomaly
  detection, attribution funnel monitoring, and Slack-formatted report output.
  Triggers: "ad anomaly report", "pipeline health", "ad performance report", "daily report"
---

# Daily Ad Anomaly Report

Ad performance anomaly detection and pipeline health monitoring for HTS Media. Queries BigQuery silver-layer tables in `h4r-common-bi-prd.ads_campaign_manager__slv`, computes z-score anomalies, and posts a threaded Slack report.

The report date is always **yesterday UTC** (`DATE_SUB(CURRENT_DATE('UTC'), INTERVAL 1 DAY)`) unless the user specifies a different date. Never include today — partial data triggers false alarms. All SQL below uses `CURRENT_DATE('UTC') - 1` directly rather than a parameter.

## Part 1: Pipeline Health Checks

Run each check below as a BigQuery query. Every check returns the same 8-column schema:

```
(check_id STRING, severity STRING, entity STRING, metric STRING,
 value FLOAT64, baseline FLOAT64, delta_pct FLOAT64, note STRING)
```

Combine all results into a single result set, sorted by severity (CRITICAL → WARNING → SPIKE → INFO → OK), then by `|delta_pct|` descending.

### Check A1 — Freshness

How many hours since the newest row in `fact_unattributed_conversions`:

```sql
SELECT 'A1_freshness' AS check_id,
  CASE
    WHEN TIMESTAMP_DIFF(CURRENT_TIMESTAMP(), MAX(added_at), HOUR) > 36 THEN 'CRITICAL'
    WHEN TIMESTAMP_DIFF(CURRENT_TIMESTAMP(), MAX(added_at), HOUR) > 24 THEN 'WARNING'
    WHEN TIMESTAMP_DIFF(CURRENT_TIMESTAMP(), MAX(added_at), HOUR) > 12 THEN 'INFO'
    ELSE 'OK'
  END AS severity,
  'slv.fact_unattributed_conversions' AS entity,
  'max_added_at_hours_ago' AS metric,
  CAST(TIMESTAMP_DIFF(CURRENT_TIMESTAMP(), MAX(added_at), HOUR) AS FLOAT64) AS value,
  CAST(24 AS FLOAT64) AS baseline,
  CAST(NULL AS FLOAT64) AS delta_pct,
  CAST(MAX(added_at) AS STRING) AS note
FROM `h4r-common-bi-prd.ads_campaign_manager__slv.fact_unattributed_conversions`
WHERE added_at >= TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 7 DAY)
```

**Backfill guard:** If A1 is CRITICAL, all B/C/D/E alerts are suppressed from overall status escalation (still shown in the report). F checks are always honored.

### Check A2 — Partition Gaps

For each table below, count rows for yesterday. Zero rows = CRITICAL, else OK.

| Table | Date column |
|-------|------------|
| `fact_campaign_matched_conversions` | `DATE(conversion_time)` |
| `fact_location_matched_conversions` | `DATE(conversion_time)` |
| `fact_conversion_events` | `DATE(occurred_at)` |
| `fact_hourly_advertiser_conversion_record` | `DATE(hour_utc)` |
| `fact_daily_redeemed_managed_offer_record` | `date_utc` |
| `fact_daily_offer_record` | `date_utc` |
| `fact_daily_campaign_offer_record` | `date_utc` |
| `stg_all_bookings_for_attribution` | `DATE(added_at)` |

```sql
SELECT 'A2_partition_gap' AS check_id,
       IF(COUNT(*) = 0, 'CRITICAL', 'OK') AS severity,
       '{table_name}' AS entity, 'rows_yesterday' AS metric,
       CAST(COUNT(*) AS FLOAT64) AS value,
       CAST(NULL AS FLOAT64) AS baseline, CAST(NULL AS FLOAT64) AS delta_pct,
       CAST(NULL AS STRING) AS note
FROM `h4r-common-bi-prd.ads_campaign_manager__slv.{table}`
WHERE {date_column} = DATE_SUB(CURRENT_DATE('UTC'), INTERVAL 1 DAY)
```

### Checks B1/B2 — Volume & GBV Week-over-Week

From `fact_unattributed_conversions`, compare yesterday vs same-day-last-week bookings (B1) and GBV (B2) per `channel_id`/`product_type` (hotel, flight only).

**Thresholds (apply to both B1 and B2):**

| Condition | Severity |
|-----------|----------|
| yesterday = 0 (baseline > 0) | CRITICAL |
| WoW Δ ≤ −40% | CRITICAL |
| WoW Δ ≤ −20% | WARNING |
| WoW Δ ≥ +50% | SPIKE |

**Volume floors:** B1 requires last-week bookings ≥ 10. B2 requires last-week GBV ≥ $1,000.

```sql
WITH daily AS (
  SELECT DATE(conversion_time) AS d, channel_id, product_type,
         COUNT(*) AS bookings, SUM(total_price_usd) AS gbv
  FROM `h4r-common-bi-prd.ads_campaign_manager__slv.fact_unattributed_conversions`
  WHERE added_at >= TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 10 DAY)
    AND product_type IN ('hotel','flight')
  GROUP BY 1,2,3
),
pivoted AS (
  SELECT channel_id, product_type,
    SUM(IF(d = DATE_SUB(CURRENT_DATE('UTC'), INTERVAL 1 DAY), bookings, 0)) AS yb,
    SUM(IF(d = DATE_SUB(CURRENT_DATE('UTC'), INTERVAL 8 DAY), bookings, 0)) AS wb,
    SUM(IF(d = DATE_SUB(CURRENT_DATE('UTC'), INTERVAL 1 DAY), gbv, 0)) AS yg,
    SUM(IF(d = DATE_SUB(CURRENT_DATE('UTC'), INTERVAL 8 DAY), gbv, 0)) AS wg
  FROM daily GROUP BY 1,2
)
-- For B1: entity = CONCAT(channel_id,'/',product_type), value = yb, baseline = wb,
--   delta_pct = SAFE_DIVIDE(yb - wb, wb). Filter: wb >= 10.
-- For B2: same but with yg/wg for GBV. Filter: wg >= 1000.
```

### Check C1 — Attribution Funnel

For yesterday, count rows at each pipeline stage per `channel_id`/`product_type`:

| Stage | Table | Count |
|-------|-------|-------|
| stg | `stg_all_bookings_for_attribution` | `COUNT(*)` where `DATE(conversion_time) = yesterday` |
| loc | `fact_location_matched_conversions` | `COUNT(*)` where `DATE(conversion_time) = yesterday` |
| cmp | `fact_campaign_matched_conversions` | `COUNT(*)` where `DATE(conversion_time) = yesterday` |
| cev | `fact_conversion_events` | `COUNT(DISTINCT campaign_id)` where `DATE(occurred_at) = yesterday` |

Campaign match rate = `cmp / stg`. Also compute prior-week `cmp` (same query for `DATE(conversion_time) = yesterday - 7`). Only flag if **both** `stg > 20` **and** prior-week `cmp ≥ 10` (channels with no active campaigns will naturally have near-zero match rates — that is expected, not an anomaly). Where both conditions met: rate < 1% → CRITICAL, < 5% → WARNING. Include funnel counts in `note` as `stg=N loc=N cmp=N cev=N`.

### Check D1 — Offer Redemptions WoW

From `fact_daily_redeemed_managed_offer_record`, compare yesterday vs last-week `SUM(redeemed_offer_count)` per `publisher_id`. Same WoW thresholds as B1/B2. Volume floor: last-week redemptions ≥ 5.

### Check E1 — Staging Bookings Volume WoW

From `stg_all_bookings_for_attribution`, compare yesterday vs last-week booking counts per `channel_id`/`product_type`. Same WoW thresholds as B1 (no SPIKE). Volume floor: last-week bookings ≥ 10.

### Checks F1/F2 — Data Quality

**F1:** In `fact_unattributed_conversions` (last 24h), compute null rates for `channel_id`, `product_type`, and `total_price_usd` (null or zero). WARNING if any rate > 5%.

**F2:** In `fact_unattributed_conversions` (last 24h), count `transaction_id` values appearing more than once. WARNING if > 10 duplicated IDs.

## Part 2: Ad Performance Analysis

Query 60 days of ad performance data from silver tables:

```sql
SELECT fact.date_utc, fact.channel, dim.advertiser_id, dim.advertiser_name,
       fact.impressions_total AS impressions, fact.clicks_total AS clicks,
       fact.spend_total AS spend,
       COALESCE(conv.hotel_impression_base_price_total, 0)
         + COALESCE(conv.flight_impression_base_price_total, 0) AS vta_revenue,
       COALESCE(conv.hotel_click_base_price_total, 0)
         + COALESCE(conv.flight_click_base_price_total, 0) AS cta_revenue
FROM `h4r-common-bi-prd.ads_campaign_manager__slv.fact_daily_ad_record` fact
LEFT JOIN `h4r-common-bi-prd.ads_campaign_manager__slv.dim_ad` dim ON fact.ad_id = dim.ad_id
LEFT JOIN `h4r-common-bi-prd.ads_campaign_manager__slv.fact_daily_ad_conversion_record` conv
  ON fact.date_utc = conv.date_utc AND fact.ad_id = conv.ad_id
  AND fact.channel = conv.channel_id AND fact.zone = conv.zone
WHERE fact.date_utc BETWEEN DATE_SUB(DATE_SUB(CURRENT_DATE('UTC'), INTERVAL 1 DAY), INTERVAL 60 DAY)
                        AND DATE_SUB(CURRENT_DATE('UTC'), INTERVAL 1 DAY)
```

Aggregate at three granularity levels: **overall** (all), **advertiser** (by advertiser_id/name), **channel** (by `fact.channel`). Note: when grouping by channel, qualify as `base.channel` or alias it in the CTE to avoid ambiguity with `conv.channel_id`.

### KPI Computation (from overall records)

For each of these 9 KPIs, compute for endDate:

| KPI | Formula |
|-----|---------|
| Spend | `spend` |
| Impressions | `impressions` |
| Clicks | `clicks` |
| CTR | `clicks / impressions * 100` |
| CPM | `spend / impressions * 1000` |
| VTA Revenue | `vta_revenue` |
| CTA Revenue | `cta_revenue` |
| Total Revenue | `vta_revenue + cta_revenue` |
| Total ROAS | `total_revenue / spend` |

**For each KPI:**
1. **DoD change** = `(endDate_value - priorDay_value) / priorDay_value * 100`
2. **7-day baseline** = mean and sample stddev of endDate-7 through endDate-1
3. **vs 7d avg** = `(value - mean) / mean * 100`
4. **z-score** = `(value - mean) / stddev` (0 if stddev = 0)
5. **Severity**: `|z| ≥ 2.5` → ALERT, `|z| ≥ 2.0` → WARN, else NORMAL

### Trend Signals

Compare endDate to endDate-7 for each KPI:
- WoW % = `(current - prior) / prior * 100`
- Direction: > +3% → Rising, < −3% → Falling, else Stable

### Advertiser Anomalies

From advertiser-granularity records:
1. Filter: 60-day total spend > $5,000
2. For spend, revenue (`vta + cta`), and roas (`revenue / spend`): compute z-score against 7-day baseline
3. Noise floor: spend/revenue absolute value ≥ $500 (roas has no floor)
4. Flag if `|z| ≥ 2.0`, sort by `|z|` descending

### Channel Summary

From channel-granularity records, aggregate 60-day totals per channel. Look up display names from `dim_zone` (`SELECT DISTINCT channel_id, channel_name FROM dim_zone`) rather than hardcoding — channels change over time. Examples: HopperApp → "Hopper App", capone-web → "Capital One Web", vio-web → "Vio Web".

### Overall Status

| Status | Condition |
|--------|-----------|
| ACTION NEEDED | Any KPI z-score ≥ 2.5, or unsuppressed pipeline CRITICAL |
| MONITOR | Any KPI z-score ≥ 2.0, or pipeline WARNING (no CRITICAL) |
| ALL CLEAR | Everything within normal range |

If either data source (pipeline or ad-perf) returned zero rows, override to MONITOR.

## Part 3: Format and Post to Slack

Post a threaded Slack message: parent (summary) + two thread replies (pipeline detail, then advertiser/channel/trends). See `references/slack-format.md` for exact message templates, column widths, and formatting rules.
