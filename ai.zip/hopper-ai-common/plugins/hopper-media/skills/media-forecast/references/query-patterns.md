# Forecast Query Patterns

## 1. Single City Market Forecast

```sql
SELECT publisher,
  ROUND(SUM(total_booking_revenue), 0) AS total_gbv,
  ROUND(SUM(hotel_revenue), 0) AS hotel_gbv,
  ROUND(SUM(air_revenue), 0) AS air_gbv,
  SUM(total_bookings) AS bookings,
  SUM(impressions) AS impressions, SUM(clicks) AS clicks,
  ROUND(SUM(available_ad_revenue), 0) AS ad_spend,
  ROUND(SUM(attributed_revenue), 0) AS attributed_revenue
FROM `h4r-common-bi-prd.ads_campaign_manager__gld.fact_forecast_base_record`
WHERE LOWER(market) = LOWER('Las Vegas')
  AND forecast_month BETWEEN '2026-04-01' AND '2027-03-01'
GROUP BY publisher
ORDER BY total_gbv DESC
```

## 2. Country or State Forecast

```sql
SELECT publisher,
  ROUND(SUM(total_booking_revenue), 0) AS total_gbv,
  ROUND(SUM(hotel_revenue), 0) AS hotel_gbv,
  ROUND(SUM(air_revenue), 0) AS air_gbv,
  SUM(total_bookings) AS bookings, SUM(impressions) AS impressions,
  SUM(clicks) AS clicks, ROUND(SUM(available_ad_revenue), 0) AS ad_spend
FROM `h4r-common-bi-prd.ads_campaign_manager__gld.fact_forecast_base_record`
WHERE market IN (
  SELECT DISTINCT market
  FROM `h4r-common-bi-prd.ads_campaign_manager__gld.dim_forecast_geo_hierarchy`
  WHERE country = 'Ireland'  -- or: state_or_province = 'British Columbia'
)
  AND forecast_month BETWEEN '2026-07-01' AND '2027-06-01'
GROUP BY publisher
ORDER BY total_gbv DESC
```

## 3. Monthly Breakdown (Actuals vs Projections)

```sql
SELECT forecast_month, data_source, is_actual,
  ROUND(SUM(total_booking_revenue), 0) AS total_gbv,
  ROUND(SUM(hotel_revenue), 0) AS hotel_gbv,
  ROUND(SUM(air_revenue), 0) AS air_gbv,
  SUM(total_bookings) AS bookings, SUM(impressions) AS impressions
FROM `h4r-common-bi-prd.ads_campaign_manager__gld.fact_forecast_base_record`
WHERE LOWER(market) = LOWER('Las Vegas')
GROUP BY forecast_month, data_source, is_actual
ORDER BY forecast_month
```

## 4. Max Available Ad Spend (Budget Scenario)

"What is the max a destination can spend at a given ROAS target?"

```sql
WITH market_forecast AS (
  SELECT publisher,
    ROUND(SUM(total_booking_revenue), 0) AS total_gbv,
    ROUND(SUM(attributed_revenue), 0) AS attributed_rev,
    SUM(impressions) AS impressions, SUM(clicks) AS clicks,
    ROUND(SUM(available_ad_revenue), 0) AS current_spend
  FROM `h4r-common-bi-prd.ads_campaign_manager__gld.fact_forecast_base_record`
  WHERE LOWER(market) = LOWER('Tampa')
    AND forecast_month BETWEEN '2026-07-01' AND '2026-09-01'
  GROUP BY publisher
),
with_config AS (
  SELECT f.*, c.benchmark_ctr, c.benchmark_cpc, c.benchmark_cpm, c.data_tier
  FROM market_forecast f
  JOIN `h4r-common-bi-prd.ads_campaign_manager__gld.dim_forecast_publisher_config` c USING (publisher)
)
SELECT publisher, total_gbv, data_tier,
  ROUND(SAFE_DIVIDE(total_gbv, 10), 0) AS max_spend_10x_roas,
  ROUND(SAFE_DIVIDE(total_gbv, 20), 0) AS max_spend_20x_roas,
  ROUND(SAFE_DIVIDE(total_gbv, 35), 0) AS max_spend_35x_roas,
  CASE WHEN benchmark_cpm > 0
    THEN ROUND(SAFE_DIVIDE(total_gbv, 10) / benchmark_cpm * 1000, 0) ELSE NULL
  END AS est_impressions_10x,
  CASE WHEN benchmark_cpc > 0
    THEN ROUND(SAFE_DIVIDE(total_gbv, 10) / benchmark_cpc, 0) ELSE NULL
  END AS est_clicks_10x
FROM with_config
ORDER BY total_gbv DESC
```

## 5. Origin Market Analysis

"Where do travelers to [destination] come from?"

```sql
-- For a single city market
SELECT origin_country_name, origin_region,
  ROUND(SUM(pct_of_dest_gbv) * 100, 1) AS pct_of_gbv,
  ROUND(SUM(pct_of_dest_flights) * 100, 1) AS pct_of_flights
FROM `h4r-common-bi-prd.ads_campaign_manager__slv.dim_forecast_origin_distribution`
WHERE dest_market = 'Dublin'
  AND pct_of_dest_flights > 0.001
GROUP BY origin_country_name, origin_region
ORDER BY pct_of_gbv DESC
LIMIT 15

-- For a country (multiple markets)
SELECT origin_country_name,
  ROUND(SUM(flight_gbv), 0) AS total_flight_gbv, SUM(flight_count) AS total_flights
FROM `h4r-common-bi-prd.ads_campaign_manager__slv.dim_forecast_origin_distribution`
WHERE dest_market IN ('Dublin', 'Cork', 'Galway')
GROUP BY origin_country_name
ORDER BY total_flight_gbv DESC
LIMIT 15
```

## 6. Flight Window Forecast (Custom Date Range)

For campaigns with specific start/end dates, use partial-month fractions:

```sql
WITH dest_markets AS (
  SELECT DISTINCT market
  FROM `h4r-common-bi-prd.ads_campaign_manager__gld.dim_forecast_geo_hierarchy`
  WHERE country = 'Colombia'
),
flight_months AS (
  SELECT forecast_month,
    SAFE_DIVIDE(
      DATE_DIFF(
        LEAST(DATE_ADD(forecast_month, INTERVAL 1 MONTH), DATE '2026-09-30'),
        GREATEST(forecast_month, DATE '2026-07-01'), DAY),
      DATE_DIFF(DATE_ADD(forecast_month, INTERVAL 1 MONTH), forecast_month, DAY)
    ) AS month_fraction
  FROM UNNEST(GENERATE_DATE_ARRAY('2026-07-01', '2026-09-01', INTERVAL 1 MONTH)) AS forecast_month
)
SELECT f.publisher,
  ROUND(SUM(f.total_booking_revenue * fm.month_fraction), 0) AS flight_gbv,
  ROUND(SUM(f.hotel_revenue * fm.month_fraction), 0) AS hotel_gbv,
  ROUND(SUM(f.impressions * fm.month_fraction), 0) AS impressions,
  ROUND(SUM(f.clicks * fm.month_fraction), 0) AS clicks
FROM `h4r-common-bi-prd.ads_campaign_manager__gld.fact_forecast_base_record` f
JOIN flight_months fm USING (forecast_month)
WHERE f.market IN (SELECT market FROM dest_markets) AND fm.month_fraction > 0
GROUP BY f.publisher
ORDER BY flight_gbv DESC
```

## 7. SOV (Share of Voice) Estimation

```sql
WITH market_data AS (
  SELECT ROUND(SUM(impressions), 0) AS total_impressions,
    ROUND(SUM(total_booking_revenue), 0) AS total_gbv,
    ROUND(SUM(available_ad_revenue), 0) AS total_spend
  FROM `h4r-common-bi-prd.ads_campaign_manager__gld.fact_forecast_base_record`
  WHERE LOWER(market) = LOWER('New Zealand')
    AND forecast_month BETWEEN '2026-04-01' AND '2026-06-01'
    AND publisher = 'hopper-app'
)
SELECT total_impressions, total_gbv,
  ROUND(SAFE_DIVIDE(50000, total_spend) * 100, 1) AS sov_pct_50k,
  ROUND(SAFE_DIVIDE(100000, total_spend) * 100, 1) AS sov_pct_100k,
  ROUND(50000 / NULLIF(total_spend, 0) * total_impressions, 0) AS est_impressions_50k,
  ROUND(100000 / NULLIF(total_spend, 0) * total_impressions, 0) AS est_impressions_100k
FROM market_data
```

## 8. Publisher Benchmark Lookup

```sql
SELECT publisher, data_tier,
  ROUND(benchmark_ctr, 6) AS ctr, ROUND(benchmark_cpc, 2) AS cpc,
  ROUND(benchmark_cpm, 2) AS cpm, ROUND(attribution_rate, 4) AS attr_rate,
  estimated_coverage_pct, data_source,
  has_impressions, has_clicks, has_spend, has_attribution,
  ROUND(total_gbv, 0) AS lifetime_gbv
FROM `h4r-common-bi-prd.ads_campaign_manager__gld.dim_forecast_publisher_config`
WHERE is_active = TRUE
ORDER BY total_gbv DESC
```

## 9. Multi-Publisher Comparison for a Region

```sql
SELECT publisher, COUNT(DISTINCT market) AS markets,
  ROUND(SUM(total_booking_revenue), 0) AS total_gbv,
  ROUND(SUM(hotel_revenue), 0) AS hotel_gbv,
  ROUND(SUM(air_revenue), 0) AS air_gbv,
  SUM(total_bookings) AS bookings, SUM(total_passengers) AS passengers,
  STRING_AGG(DISTINCT data_source ORDER BY data_source) AS data_sources
FROM `h4r-common-bi-prd.ads_campaign_manager__gld.fact_forecast_base_record`
WHERE LOWER(region) LIKE LOWER('%British Columbia%')
  AND forecast_month BETWEEN '2026-01-01' AND '2026-12-01'
GROUP BY publisher
ORDER BY total_gbv DESC
```

## 10. Custom CPC/CPM Budget Scenarios

When sales specifies a custom CPC/CPM instead of benchmarks:

```sql
WITH market_data AS (
  SELECT ROUND(SUM(total_booking_revenue), 0) AS total_gbv,
    ROUND(SUM(available_ad_revenue), 0) AS total_spend,
    ROUND(SUM(impressions), 0) AS total_impressions
  FROM `h4r-common-bi-prd.ads_campaign_manager__gld.fact_forecast_base_record`
  WHERE LOWER(market) = LOWER('San Diego')
    AND forecast_month BETWEEN '2026-07-01' AND '2027-06-01'
)
SELECT total_gbv,
  ROUND(SAFE_DIVIDE(total_gbv, 10), 0) AS max_spend_10x,
  ROUND(SAFE_DIVIDE(total_gbv, 10) / 2.50, 0) AS est_clicks_at_2_50_cpc,
  ROUND(SAFE_DIVIDE(total_gbv, 10) / 25 * 1000, 0) AS est_impressions_at_25_cpm,
  ROUND(SAFE_DIVIDE(total_gbv, 10) / 0.25, 0) AS est_clicks_at_0_25_cpc
FROM market_data
```
