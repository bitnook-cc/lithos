# Tables and Column Reference

## `fact_forecast_base_record` (Gold)

**Main forecast table.** Grain: `forecast_month × publisher × market × region × origin_code × country_code`.

| Column | Type | Description |
|--------|------|-------------|
| `forecast_month` | `DATE` | First day of month (e.g., `2026-04-01`) |
| `is_actual` | `BOOL` | `TRUE` for real/legacy data, `FALSE` for projections |
| `publisher` | `STRING` | Publisher ID: `hopper-app`, `capone`, `tripadvisor`, `smcc`, `vio`, `super` |
| `market` | `STRING` | Destination market — **always city-level** (e.g., `Las Vegas`, `Dublin`) |
| `region` | `STRING` | Geographic region (state/province or macro region) |
| `impressions` | `INT64` | Ad impressions (NULL for legacy-only publishers) |
| `clicks` | `INT64` | Ad clicks (NULL for legacy-only publishers) |
| `hotel_revenue` | `NUMERIC` | Hotel GBV in USD |
| `air_revenue` | `NUMERIC` | Flight GBV in USD |
| `total_booking_revenue` | `NUMERIC` | Total GBV = hotel + air |
| `available_ad_revenue` | `NUMERIC` | Ad spend (what the publisher paid) |
| `total_bookings` | `INT64` | Number of bookings |
| `total_room_nights` | `INT64` | Hotel room nights |
| `attributed_revenue` | `NUMERIC` | Revenue attributed to ad interactions (CTA + VTA) |
| `cta_revenue` | `NUMERIC` | Click-through attributed revenue |
| `vta_revenue` | `NUMERIC` | View-through attributed revenue |
| `total_passengers` | `INT64` | Flight passengers |
| `origin_code` | `STRING` | IATA origin airport code (for flight data) |
| `coverage_adjusted_total_booking_revenue` | `NUMERIC` | Currently equals `total_booking_revenue` (1:1 pass-through) |
| `data_source` | `STRING` | `pipeline` (real actuals), `projection` (future), or `legacy` (Google Sheet) |
| `country_code` | `STRING` | Destination country ISO code (NULL for legacy and projection rows) |

## `dim_forecast_publisher_config` (Gold)

| Column | Type | Description |
|--------|------|-------------|
| `publisher` | `STRING` | Publisher ID |
| `data_tier` | `STRING` | `full`, `clicks_only`, `clicks_no_spend`, `revenue_only`, `total_only`, or `legacy` |
| `has_impressions` | `BOOL` | Publisher has impression data |
| `has_clicks` | `BOOL` | Publisher has click data |
| `has_spend` | `BOOL` | Publisher has ad spend data |
| `has_attribution` | `BOOL` | Publisher has attribution (CTA/VTA) data |
| `benchmark_ctr` | `NUMERIC` | Click-through rate benchmark |
| `benchmark_cpc` | `NUMERIC` | Cost per click benchmark |
| `benchmark_cpm` | `NUMERIC` | Cost per mille benchmark |
| `attribution_rate` | `NUMERIC` | Fraction of GBV that is ad-attributed (~8-14%) |
| `estimated_coverage_pct` | `INT64` | % of publisher's true booking volume visible |
| `data_source` | `STRING` | `hts`, `publisher`, `hts+publisher`, or `legacy` |
| `first_data_month` | `DATE` | Earliest month with actual data |
| `last_actual_month` | `DATE` | Most recent month with actual data |

## `dim_forecast_geo_hierarchy` (Gold)

| Column | Type | Description |
|--------|------|-------------|
| `geo_type` | `STRING` | `destination` or `origin` |
| `country` | `STRING` | Country name |
| `country_code` | `STRING` | ISO country code |
| `macro_region` | `STRING` | North America, Europe, Asia Pacific, etc. |
| `state_or_province` | `STRING` | State or province |
| `market` | `STRING` | Market name (matches `fact_forecast_base_record.market`) |
| `city` | `STRING` | City name |
| `has_hotel_data` | `BOOL` | Market has hotel booking data |
| `has_flight_data` | `BOOL` | Market has flight booking data |
| `publisher_count` | `INT64` | Number of publishers with data in this market |
| `market_annual_gbv` | `NUMERIC` | Annual GBV for ranking markets |

## `dim_forecast_origin_distribution` (Silver)

| Column | Type | Description |
|--------|------|-------------|
| `dest_market` | `STRING` | Destination market name (city-level) |
| `dest_country_code` | `STRING` | Destination country ISO code |
| `origin_country_code` | `STRING` | Origin country ISO code |
| `origin_country_name` | `STRING` | Origin country name |
| `origin_region` | `STRING` | Origin macro region |
| `origin_market` | `STRING` | Origin market name |
| `flight_count` | `INT64` | Flights from origin to destination |
| `flight_gbv` | `NUMERIC` | Total flight GBV from origin |
| `pct_of_dest_flights` | `FLOAT64` | Fraction of destination's total flights from this origin |
| `pct_of_dest_gbv` | `FLOAT64` | Fraction of destination's total flight GBV from this origin |

## Silver Supporting Tables

| Table | Purpose |
|-------|---------|
| `fact_forecast_actuals` | Raw monthly actuals before coverage adjustment |
| `fact_forecast_projections` | Projected future months through Dec 2028 |
| `fact_forecast_combined` | Union of pipeline + projections + legacy with `data_source` tag |
| `fact_forecast_coverage_adjusted_bookings` | Actuals filtered to registered publishers |
| `fact_forecast_legacy_fallback` | Google Sheet annual forecasts distributed across months |
| `dim_forecast_market_normalization` | Maps raw market names to standardized legacy names |
| `dim_forecast_airport_geography` | IATA airport to city/country/market mapping |

## How the Forecast Engine Works

### Actuals
Raw bookings from HTS Hotel, HTS Flight, and publisher-reported sources, enriched with ad metrics and attribution.

### Projections
For each publisher × market: `projected = base × (1 + growth × decay)^months × seasonality_index` where base = 3-month rolling avg, growth capped [-3%, +5%], decay = 2%/month.

### Legacy Fallback
For publishers without pipeline data (Super.com) or pre-pipeline months: annual totals from Google Sheet distributed with fixed seasonality weights (Jan 7.5%, Feb 7.0%, Mar 8.2%, ..., Dec 6.5%).

### Data Source Priority
1. `pipeline` — Real coverage-adjusted actuals
2. `projection` — Model-projected future months
3. `legacy` — Google Sheet fallback (only where no pipeline or projection exists)
