---
name: media-forecast
description: >
  Use when asked to pull a forecast, max avails, budget scenario, ROAS projection,
  GBV by destination, or publisher revenue estimate for HTS Media.
  Triggers: "pull a forecast", "max avails", "forecast for", "what can we serve",
  "put together a forecast", "pull what the forecast numbers look like"
---

# HTS Media Forecasting

Revenue projections for publishers (Hopper App, Capital One, TripAdvisor, SMCC, VIO, Super.com) by destination market. Data flows from raw booking streams through a projection engine into gold-layer tables.

For column schemas, see `references/tables-and-columns.md`. For SQL query patterns, see `references/query-patterns.md`.

## Key Tables

All in `h4r-common-bi-prd`. Prefer **gold** tables for queries.

| Table | Dataset | Purpose |
|-------|---------|---------|
| `fact_forecast_base_record` | `ads_campaign_manager__gld` | **Main forecast table** — monthly actuals + projections + legacy. Always `SUM()` to aggregate. Grain: `forecast_month × publisher × market × region × origin_code`. |
| `dim_forecast_publisher_config` | `ads_campaign_manager__gld` | Publisher metadata: data tier, benchmarks (CTR/CPC/CPM), coverage |
| `dim_forecast_geo_hierarchy` | `ads_campaign_manager__gld` | Geography hierarchy for destination lookups |
| `dim_forecast_origin_distribution` | `ads_campaign_manager__slv` | Traveler origin distribution by destination (flight-based) |

## Critical: Market Name Resolution

**Markets are city-level, NOT country or state-level.** The `market` column contains city names like "Las Vegas", "Dublin", "Vancouver" — NOT "Ireland" or "British Columbia".

To query by country or state, **always resolve via `dim_forecast_geo_hierarchy` first**:

```sql
-- Country → markets
SELECT DISTINCT market
FROM `h4r-common-bi-prd.ads_campaign_manager__gld.dim_forecast_geo_hierarchy`
WHERE country = 'Ireland'

-- State → markets
SELECT DISTINCT market
FROM `h4r-common-bi-prd.ads_campaign_manager__gld.dim_forecast_geo_hierarchy`
WHERE state_or_province = 'British Columbia'
```

Small cities roll up to metros: Grand Prairie → Dallas, Scottsdale → Phoenix, Port Aransas → Corpus Christi.

If a destination isn't found, search broadly:

```sql
SELECT market, country, state_or_province, ROUND(MAX(market_annual_gbv), 0) AS annual_gbv
FROM `h4r-common-bi-prd.ads_campaign_manager__gld.dim_forecast_geo_hierarchy`
WHERE geo_type = 'destination'
  AND (LOWER(market) LIKE LOWER('%search_term%')
    OR LOWER(city) LIKE LOWER('%search_term%')
    OR LOWER(state_or_province) LIKE LOWER('%search_term%'))
GROUP BY market, country, state_or_province
ORDER BY annual_gbv DESC
```

## Publisher Coverage

| Publisher | ID | Data Tier | Coverage | Notes |
|-----------|----|-----------|----------|-------|
| Hopper App | `hopper-app` | `full` | 100% | Primary publisher, ~$1.78B lifetime GBV |
| Capital One | `capone` | `full` | 100% | Pipeline from 2026-03-12; legacy before |
| TripAdvisor | `tripadvisor` | `full` | 100% | ~$68M lifetime GBV |
| SMCC | `smcc` | `total_only` | 100% | GBV/bookings only — no impressions/clicks/spend |
| VIO | `vio` | `full` | 4% | Pipeline from 2026-03-10; legacy before |
| Super.com | `super` | `legacy` | 0% | Google Sheet only — no pipeline data |

## Handling Forecast Requests

Sales requests typically include: destination, campaign dates, budget, target ROAS, source markets, and goal (awareness vs conversion).

| Parameter | How to Handle |
|-----------|---------------|
| **Destination** | Filter `market`. Use `dim_forecast_geo_hierarchy` if not a city name. |
| **Campaign dates** | Use flight window pattern with partial-month fractions (see query patterns). |
| **Budget** | `clicks = budget / benchmark_cpc`, `impressions = clicks / benchmark_ctr`. |
| **Target ROAS** | `max_spend = total_gbv / target_roas`. Show at multiple tiers (5:1, 10:1, 20:1). |
| **Max avails** | Total impressions for market/date range. SOV = budget_impressions / total. |
| **Source markets** | Filter `origin_code` or use `dim_forecast_origin_distribution`. |
| **Hotel vs Flight** | Use `hotel_revenue` / `air_revenue` columns. Some markets are one-only. |
| **PAX / Bookings** | Use `total_bookings` and `total_passengers` columns. |
| **Publisher split** | Group by `publisher`. |
| **Custom CPC/CPM** | Replace benchmarks with sales-specified values in imputation formulas. |

### Imputation for Missing Metrics

When a publisher lacks metrics (e.g., SMCC has no impressions), impute from `dim_forecast_publisher_config`:

- Has impressions + clicks → use actuals
- Has clicks only → `impressions = clicks / benchmark_ctr`
- Revenue-only or legacy → `clicks = ad_spend / benchmark_cpc`, `impressions = clicks / benchmark_ctr`

## Default Output Formatting

Unless the requester asks for specific data or a different layout, present forecast results as a Slack table with the following columns in order:

| Column | Description |
|--------|-------------|
| Destination(s) | Market name(s) returned by the query |
| Forecast Flight Dates | Campaign or forecast date range |
| Publisher | Publisher name — *include only if the requester asks for a publisher breakdown* |
| CPC | Cost per click (benchmark or custom) |
| Forecasted GBV | Total forecasted gross booking value (`total_booking_revenue`) |
| Forecasted Ad Spend | Forecasted advertising spend (`available_ad_revenue`) |
| Bookings | Total bookings (`total_bookings`) |
| PAX | Total passengers (`total_passengers`) |
| Key Callouts / Notes | Data caveats, imputation notes, SOV highlights, or other relevant context |

- Format currency values with `$` and commas (e.g., `$1,234,567`).
- Format large numbers with commas.
- Round CPC to two decimal places.
- If a column has no data (e.g., PAX for hotel-only markets), show `—`.
- Add a short footer noting the data source (pipeline vs. projection vs. legacy) and any imputation applied.

## Pre-Response Validation

Before presenting results, verify every claim in your callouts and notes against the query results and current date:

- Do date ranges in your commentary match what was actually queried?
- Do summary numbers match the table totals?
- Are caveats (partial data, pro-rated, imputed) actually true for the returned data?
- Do returned markets belong to the requested geography? Cross-check against `dim_forecast_geo_hierarchy` when results seem off.

Remove any caveats you cannot confirm from the query output.

## Important Gotchas

1. **Markets are city-level**: "Ireland" → use `dim_forecast_geo_hierarchy` to get Dublin, Cork, Galway. Never filter `market = 'Ireland'`.

2. **Always `SUM()` when aggregating**: The grain includes `origin_code` — without aggregation you get duplicate-looking rows (e.g., 434 rows for capone/New York/2026-03).

3. **`country_code` is NULL for legacy/projection data**: Use `dim_forecast_geo_hierarchy` for country resolution, not the `country_code` column.

4. **Legacy data has no ad metrics**: Super.com and pre-pipeline months for Capital One/VIO have NULL impressions, clicks, spend, attribution.

5. **Current month is pro-rated**: Actuals scale the incomplete month to full-month estimate using `days_in_month / current_day`.

6. **`total_booking_revenue` is GBV, not net revenue**: This is what the traveler pays, not Hopper's margin. ROAS uses this as numerator.

7. **Bookings are market volume, not ad-driven**: `total_bookings` doesn't change with ad budget. More spend buys more impressions/clicks but bookings remain constant.

8. **No `target_roas` in V2 tables**: Default to 5:1 ROAS if the requester doesn't specify.

9. **Projection horizon through Dec 2028**: No forecast data beyond that.

10. **Legacy data expires after Dec 2026**: Super.com and pre-pipeline months only cover Jan 2024 - Dec 2026.
