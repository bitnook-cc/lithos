---
name: ccpa-opt-out
description: Use when updating the CCPA opt-out user ID list to exclude users from AppsFlyer data sharing. Triggers - "CCPA opt-out", "opt out users", "data sharing opt-out", "optOutUserIds", "AppsFlyer exclusion", "privacy opt-out", "Typeform CCPA responses", or when given a list of user UUIDs to add to the opt-out list.
---

# CCPA Data Sharing Opt-Out Update

Update the CCPA opt-out user ID list for AppsFlyer data sharing exclusion. All file paths in this skill are relative to the [`hopper-org/power-loader-amp`](https://github.com/hopper-org/power-loader-amp) repo — clone or `cd` into it before editing.

## Context

This is a **legal requirement** (CCPA). Users who request to opt-out of data sharing must have their events excluded from being sent to AppsFlyer and other third parties.

- Source of opt-out requests (contains PII): see Confluence docs for the current data source location
- Confluence docs: https://hopper-jira.atlassian.net/wiki/spaces/TM/pages/6987907183/User+Acquisition+Knowledge+Share#Data-Sharing-Opt-Out

## Steps

### 1. Get new user IDs

Ask the user to provide the new user IDs. They can either:
- Paste UUIDs directly
- Provide a list of user IDs in any format
- Provide a Typeform CSV file path (see "Typeform CSV import" below)

### 2. Validate and deduplicate

For each provided user ID:
- Validate it is a valid UUID format (xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx)
- Check if it already exists in `power-loader-amp/core/src/main/resources/optOutUserIds.conf`
- Report any invalid UUIDs or duplicates to the user
- If no new valid UUIDs remain, inform the user and stop

### 3. Update optOutUserIds.conf (in `power-loader-amp`)

Edit `power-loader-amp/core/src/main/resources/optOutUserIds.conf`:
- Add new user IDs in the section **before** the `# Real users, submitted from privacy@hopper.com` comment
- Each entry should be formatted as: `  "uuid-here",`
- Insert them right before the blank line that precedes the `# Real users, submitted from privacy@hopper.com` comment
- Update the timestamp on the `# User ID list up-to-date until:` line to the current date/time in `YYYY/MM/DD HH:MM:SS` format

### 4. Update optOutUserIds.py template (in `power-loader-amp`)

Edit `power-loader-amp/scripts/optOutUserIds.py`:
- Add the same new user IDs to the `file_template` string variable
- They go in the same position: before the `# Real users, submitted from privacy@hopper.com` comment
- Same format: `  "uuid-here",\n`
- Ensure the `{current_time}` placeholder is preserved (do NOT replace it with an actual timestamp; it is filled via Python string formatting)

### 5. Summary

After making changes, show the user:
- How many new user IDs were added
- How many were skipped (duplicates or invalid)
- List any invalid UUIDs that were skipped
- The files that were modified

### 6. Create PR

- Create a branch named `feat/update-ccpa-opt-out-YYYY-MM`
- Commit message: `feat: update CCPA opt out user IDs`
- Push the branch and create a PR
- PR title: `feat: update CCPA opt out user IDs`
- PR body should mention the number of new IDs added

## Typeform CSV import

The Typeform at https://admin.typeform.com/form/AqHz5lJD/results#responses collects opt-out requests. To use it:

1. Download all responses as CSV from Typeform
2. Provide the CSV file path to this skill

The CSV has these relevant columns:
- `user_id` — the user's UUID
- A consent column (long question text starting with "Do you want to opt-out of the use, sharing or "sale" of personal information...") — value `"1"` means opted out, `"0"` means not opted out

When parsing the CSV:
- Only include rows where the consent column value is `"1"`
- Extract the `user_id` column value
- Then continue with the normal validation and deduplication steps above

You can use `scripts/optOutUserIds.py` as a reference for the parsing logic (`get_user_id_dict` function).

## Important notes

- This contains PII - do not log or display email addresses
- `optOutUserIds.conf` is a HOCON config file included by `power-loader-amp/core/src/main/resources/base.conf`
- The two test user IDs at the bottom of the file (`5e46df95-b6e4-4b24-84b9-0c1effe12345` and `5e46df95-b6e4-4b24-84b9-0c1effe67890`) must always remain
- The Legal team handles removing users from Iterable marketing lists separately
