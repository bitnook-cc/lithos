---
name: analytics-events
description: >
  Use when looking up consumer analytics events, amplitude events, or backend events from
  casablanca.backend_events in BigQuery. Use for event lookups by name, user,
  or session. Triggers: "backend_events", "consumer events", "casablanca events",
  "amplitude events", "amplitude event", "subscription_renewed",
  "feature_flag_exposure", "backend_app_launch".
---

# Consumer Analytics Events

All consumer backend events (including Amplitude events) are stored in
`casablanca.backend_events`. This is the primary table for looking up
consumer-side analytics events in BigQuery.

## Data Sources

| Environment | Table |
|-------------|-------|
| Production  | `gcp-hopper-etldata-production.casablanca.backend_events` |

Default to **production** unless the user specifies otherwise.

## Table Schema

| Column | Type | Description |
|--------|------|-------------|
| `ts` | TIMESTAMP | When the event occurred |
| `id` | INT64 | Event ID |
| `name` | STRING | Event name (e.g. `subscription_renewed`, `feature_flag_exposure`) |
| `user_id` | STRING | Hopper user ID |
| `session_id` | STRING | Session ID |
| `campaign` | JSON | Campaign attribution data |
| `referrer` | STRING | Referrer information |
| `extra_properties` | JSON | Additional event-specific properties |
| `raw_event` | BYTES | Raw event payload |

## Querying

Always filter on `ts` to limit scan size.

**Look up events by name:**
```sql
SELECT *
FROM `gcp-hopper-etldata-production.casablanca.backend_events`
WHERE name = '{event_name}'
  AND ts >= DATE_SUB(CURRENT_TIMESTAMP(), INTERVAL 7 DAY)
LIMIT 100
```

**Look up events for a user:**
```sql
SELECT ts, name, session_id, extra_properties
FROM `gcp-hopper-etldata-production.casablanca.backend_events`
WHERE user_id = '{user_id}'
  AND ts >= DATE_SUB(CURRENT_TIMESTAMP(), INTERVAL 7 DAY)
ORDER BY ts
```

**List event names by volume:**
```sql
SELECT name, COUNT(*) AS cnt
FROM `gcp-hopper-etldata-production.casablanca.backend_events`
WHERE ts >= DATE_SUB(CURRENT_TIMESTAMP(), INTERVAL 1 DAY)
GROUP BY name
ORDER BY cnt DESC
```
