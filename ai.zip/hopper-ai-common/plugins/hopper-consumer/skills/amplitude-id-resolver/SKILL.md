---
name: amplitude-id-resolver
description: Use when you have a user's amplitude/tracking ID (43-char base64url string) and need their Hopper UUID, or vice versa. Triggers: encoded user ID, amplitude ID, tracking ID, "resolve user ID", non-UUID user identifier from CS tickets or Amplitude exports.
---

# Amplitude ID Resolver

## Overview

Hopper uses two user ID formats. CS agents, Amplitude exports, and some internal services use an amplitude/tracking ID (a 43-char base64url-encoded SHA-256 hash). Most backend services (fraud, referrals, bookings) use Hopper UUIDs. This skill resolves between the two formats.

## Identifying the Format

| Format | Example | Pattern |
|--------|---------|---------|
| Hopper UUID | `3c6f34bf-9a25-441a-be70-be236684ce52` | 36 chars, 8-4-4-4-12 hex with dashes |
| Amplitude ID | `AvqFJ168SrI2K_O3zs4FYelMvlxf01jD1CId2QsSnPA` | 43 chars, base64url (alphanumeric, `-`, `_`) |

## Forward: UUID → Amplitude ID (Local)

Deterministic hash — can be computed locally:

```python
import hashlib, base64

def to_amplitude_id(user_id: str) -> str:
    s = user_id + "A9SURUWHRDQ4N5IYX31UCBPDA9T674"
    m = hashlib.sha256(s.encode('UTF-8')).digest()
    return base64.urlsafe_b64encode(m).decode('UTF-8').rstrip('=')
```

Use this to verify a suspected UUID matches a known amplitude ID.

## Reverse: Amplitude ID → UUID (via Trenton)

SHA-256 is one-way — reverse lookup requires the Bifrost database via Trenton's admin API.

**Endpoint:** `POST https://dashboard-nopii.portal.hopper.com/api/v2/amplitude/user_ids`

**Request:** CSV body with a `user_id` column header:
```
curl -X POST https://dashboard-nopii.portal.hopper.com/api/v2/amplitude/user_ids \
  -H "Content-Type: text/csv" \
  -d "user_id
AvqFJ168SrI2K_O3zs4FYelMvlxf01jD1CId2QsSnPA"
```

**Response:** CSV with `(hopper_uuid, amplitude_id)` pairs.

Supports batch resolution — include multiple rows in the CSV for bulk lookups.

## When Trenton Is Unavailable

If the admin API is inaccessible, try these alternatives:

1. **Datadog log correlation**: Search `mumbai-user-event-consumer` or `power-loader-iterable-processor` for the amplitude ID, then look for correlated requests in other services using trace IDs.

2. **Forward verification**: If you have a candidate UUID from context (e.g., from a related booking or Kustomer ticket), compute its amplitude ID and compare.

## Source

Algorithm matches `TrackingId` generation in:
- `Helpers/helpers-model` — `Mumbai.Inbox.UserId.trackingId`
- `Trenton` — `UserController` tracking ID computation
- `hopper-ai-common/plugins/hopper-commerce/skills/amplitude-id-lookup/amplitude_id_generator.py`
