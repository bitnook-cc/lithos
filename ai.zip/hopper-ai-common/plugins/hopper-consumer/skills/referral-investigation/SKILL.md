---
name: referral-investigation
description: Use when investigating why a user cannot claim or receive referral rewards/credits. Triggers: "referral reward", "referral credit", "can't claim referral", "referral not working", "referral blocked", "referral voucher", "milestone reward", user ID with referral context.
---

# Referral Reward Investigation

## Overview

Investigate referral reward claim failures by querying Datadog logs and BigQuery referral data across the pipeline. Common causes include fraud policy blocks, milestone progression thresholds not yet reached, friend count limits, and referred users being existing accounts.

## Services & Data Sources

### Datadog Services

| Service | Role | What to Look For |
|---------|------|------------------|
| `fraud-user-trust-server` | Fraud risk evaluation | `ReferralsPolicy` rule evaluations, `RISK_DECISION_BLOCK` |
| `growth-friends-server` | Referral structure & rewards | Structure type, friend links, milestone rewards, rejection reasons |
| `scranton` | Incentives & vouchers | `PUT /api/v1/create` for voucher creation |
| `recaptcha-server` | Bot detection | Risk score for `confirm_referral_reward` action |
| `growth-social-commerce-remoteui` | Referral UI | Feature flag userId diffs (multi-account signals) |
| `feature-flags-evaluation` | Feature flag targeting | userId attribute mismatches in Spanner |
| `trenton` | API gateway | HTTP status for referral endpoints |

### BigQuery Datasets

| Dataset | Table | Key Columns | Purpose |
|---------|-------|-------------|---------|
| `ua_referral` | `internal__friend_links_structure` | `user_id`, `friend_id`, `used_friend_referral_code` | Friend link status |
| `ua_referral` | `internal__referral_reward_creation` | `user_id`, `reward_type`, `reward_name`, `created_amount` | Whether rewards were created |
| `ua_referral` | `internal__inviter_structure_history_with_invitee` | `user_id`, `has_fraud_signal`, `user_status`, `is_invitee` | Inviter status & fraud flags |
| `growth_social_commerce` | `social_link` | `from_user`, `to_user`, `campaign_name` | Social referral links |
| `growth_social_commerce` | `reward` | `user_id`, `reward_status`, `reason` | Reward status |

All BigQuery queries must use `gcp-hopper-ds-research` as the billing project and query from `gcp-hopper-etldata-production`.

## User ID Formats

CS tickets may provide user IDs in two formats:

| Format | Example | Used By |
|--------|---------|---------|
| Hopper UUID | `3c6f34bf-9a25-441a-be70-be236684ce52` | fraud-user-trust-server, growth-friends-server, trenton referral endpoints |
| Amplitude ID | `AvqFJ168SrI2K_O3zs4FYelMvlxf01jD1CId2QsSnPA` | 43-char base64url string, used by CS agents, Amplitude, mumbai-user-event-consumer |

**If the user ID is an amplitude ID (43 chars, lacks the `8-4-4-4-12` hyphen pattern of UUIDs)**, you MUST resolve it to a Hopper UUID before proceeding. The fraud and referral services only log Hopper UUIDs.

**REQUIRED SUB-SKILL:** Use [amplitude-id-resolver](hopper-consumer:amplitude-id-resolver) to convert amplitude IDs to Hopper UUIDs.

## Investigation Steps

### 1. Check BigQuery referral state (start here for full picture)

Query friend links to see all referrals and whether codes were used:

```sql
SELECT user_id, friend_id, structure_id, used_friend_referral_code, create_timestamp
FROM `gcp-hopper-etldata-production.ua_referral.internal__friend_links_structure`
WHERE user_id = '<userId>'
ORDER BY create_timestamp DESC
```

Check whether rewards were actually created:

```sql
SELECT user_id, friend_id, structure_id, is_invitee, reward_type, reward_name, created_amount, reward_create_ts
FROM `gcp-hopper-etldata-production.ua_referral.internal__referral_reward_creation`
WHERE user_id = '<userId>'
ORDER BY reward_create_ts DESC
```

Check inviter status and fraud signal:

```sql
SELECT user_id, user_status, is_invitee, structure_id, first_launch_date, country, has_fraud_signal, friend_id
FROM `gcp-hopper-etldata-production.ua_referral.internal__inviter_structure_history_with_invitee`
WHERE user_id = '<userId>'
```

**Key fields to check:**
- `used_friend_referral_code = false` → referred user did not use the referral code
- `has_fraud_signal = true` → system flagged user, may block rewards
- `reward_type / reward_name / created_amount = NULL` → no reward was created
- `structure_id` → identifies the reward structure (e.g. `MilestoneRewardD`)

### 2. Check growth-friends-server logs (detailed event timeline)

```
mcp__datadog__search_datadog_logs
  query: "service:growth-friends-server <userId>"
  from: "now-7d"
```

**Key log messages to look for:**

| Log Message | Meaning |
|-------------|---------|
| `Created friend link between users X and Y with status ADD_FRIEND_SUCCESS_ADDED` | Referral link created successfully |
| `Created friend link between users X and Y with status ADD_FRIEND_SUCCESS_UNCHANGED` | Duplicate friend-add attempt — link already exists, no-op |
| `gave referrer=X N milestone rewards (eligible for: List(...))` | Milestone reward issued — check if N > 0 |
| `gave referrer=X 0 milestone rewards (eligible for: List())` | Milestone threshold not reached — empty progression |
| `Successfully created Pending ReferredFriend reward for user X, friend Y with 0` | Pending reward created but with 0 value |
| `Not enough fraud data to confirm reward for [X, CanonicalizedCodeImpl(Y)], user should try again later` | *Fraud block* — `fraud-user-trust` returned `RISK_DECISION_BLOCK`. Despite the wording, this is often a permanent block (see AlwaysBlock below), not a transient issue |
| `Not granting user X reward for referring user Y, they already have 2 friends` | Friend count limit reached |
| `Not granting user X reward for referring user Y, they were already an existing user` | Referred user was not a new user |
| `Existing structure for userId = X structure = Y` | User's current referral structure (e.g. `MilestoneRewardG`) |
| `Localization param is empty` | Cosmetic warning, NOT a blocker |

**Milestone reward structures**: Rewards are granted at specific friend count thresholds, NOT per referral. A user may have several successful referrals but receive 0 rewards until hitting a milestone. When a milestone is reached, the log shows the reward details, e.g.:
`AllLodgingVoucherReward(CreditAmount(USD50.00), AllHotelVoucher, 365, List(), Some(USD120), None)` = $50 hotel voucher, 365-day validity, $120 min spend.

Known milestone structures and their tiers:

| Structure | Threshold | Reward |
|-----------|-----------|--------|
| `MilestoneRewardD` | 5 friends | USD50 AllHotelVoucher |
| `MilestoneRewardD` | 10 friends | USD125 AllHotelVoucher |
| `MilestoneRewardD` | 15 friends | USD250 AllHotelVoucher |
| `MilestoneRewardG` | 5 friends | USD50 AllHotelVoucher |
| `MilestoneRewardG` | 10 friends | USD100 AllHotelVoucher |

All vouchers have 365-day validity and USD120 minimum spend requirement.

**Important:** When fraud-user-trust blocks a reward claim, `ConfirmReward` / `ConfirmMilestoneRewards` logs may NOT appear in growth-friends at all. Instead, you'll only see `Not enough fraud data to confirm reward` — the claim is rejected before the reward confirmation logic runs. If you see no confirm logs for a user but see repeated `GetFriends` and `RewardPlan` calls, check `fraud-user-trust-server` logs for the block reason.

### 3. Check fraud policy evaluation

```
mcp__datadog__search_datadog_logs
  query: "service:fraud-user-trust-server <userId> ReferralsPolicy"
  from: "now-7d"
```

Look for `Encountered N non-successful rules for ReferralsPolicy` messages.

**Common blocking rules:**

| Rule | Meaning | Category |
|------|---------|----------|
| `PhoneNumberNotReused` | Phone number linked to multiple accounts | `RULE_CATEGORY_BLOCK` |
| `NoMultipleReferralDeviceReuse` | Device used for referrals across accounts | `RULE_CATEGORY_NOT_ENOUGH_DATA` |
| `LastFraudPreventionOutcome` (`Payment Outcome: Block`) | User has a prior fraud-related payment block | `RULE_CATEGORY_NOT_ENOUGH_DATA` |
| `LastFraudPreventionOutcome` (`Payment Outcome: AlwaysBlock`) | User is *permanently* blocked from payments — this is a hard, non-retriable block. Retrying will never succeed. | `RULE_CATEGORY_NOT_ENOUGH_DATA` |
| `HasLaunchToday` | Account launched very recently (age in minutes too low) | `RULE_CATEGORY_NOT_ENOUGH_DATA` |

Log format: `RuleEvaluation(RuleGroup, RuleName, count, score, RISK_DECISION, RULE_CATEGORY)`

- `RISK_DECISION_BLOCK` = hard block on reward claim
- `RULE_CATEGORY_BLOCK` = definitive fraud signal
- `RULE_CATEGORY_NOT_ENOUGH_DATA` = insufficient data to clear, defaults to block. **Caution:** despite the name, this category also covers permanent blocks like `AlwaysBlock` — do not assume retrying will help

### 4. Verify voucher creation in Scranton (if reward was issued)

If growth-friends logs show a milestone reward was granted (N > 0), verify that Scranton actually created the voucher. Use the `trace_id` from the growth-friends log entry:

```
mcp__datadog__get_datadog_trace
  trace_id: "<trace_id_from_growth_friends_log>"
  only_service_entry_spans: true
  include_path: ["service:scranton"]
```

Look for a `PUT /api/v1/create` span in the `scranton` service. A successful creation shows:
- Multiple `executeQuery` and `executeAction` spans (Spanner reads/writes)
- Mixpanel tracking calls to `casablanca` (`POST /api/v1/mixpanel/track/`)
- No error tags on any span

If the Scranton span is missing or has errors, the voucher was not created despite the reward being granted in growth-friends.

### 5. Check for multi-account signals

```
mcp__datadog__search_datadog_logs
  query: "service:feature-flags-evaluation <userId>"
  from: "now-7d"
```

Look for `Attributes sent by client differed from attributes currently in Spanner` with userId changes like `(oldUserId -> newUserId)`. This indicates the same session/device was previously linked to a different account — corroborates phone/device reuse fraud signals.

### 6. Check reCAPTCHA (rule out bot)

```
mcp__datadog__search_datadog_logs
  query: "service:recaptcha-server <userId> confirm_referral_reward"
  from: "now-7d"
```

Score of 1.0 = "Low Risk" (legitimate user, not a bot).

## Interpreting Results

### Milestone threshold not reached

If growth-friends logs show `gave referrer 0 milestone rewards (eligible for: List())` and BigQuery shows `reward_type = NULL`:
- The user is on a milestone-based reward structure (e.g. `MilestoneRewardD`)
- Rewards are only granted at specific friend count thresholds, not per referral
- The user needs more successful referrals to reach the next milestone
- This is working as designed — explain the milestone structure to the customer

### Friend count limit or existing user

If growth-friends logs show:
- `"they already have 2 friends"` → the user or referee has hit the friend limit for their structure
- `"they were already an existing user"` → the referred person was not a new Hopper user

These are valid rejections, not bugs.

### Referral code not used

If BigQuery shows `used_friend_referral_code = false` for recent friends:
- The referred users joined the app but did not use the referral code
- The friend link was still created (possibly via other attribution) but may affect reward eligibility

### Fraud policy block

If `ReferralsPolicy` has blocking rules, the claim is rejected by anti-fraud — this is not a bug.

- **`PhoneNumberNotReused` / `NoMultipleReferralDeviceReuse`**: Phone or device linked to another account. The other account ID may appear in feature-flags userId diffs.
- **`LastFraudPreventionOutcome` (`Block`)**: User has a prior payment fraud block on their account — the referral system won't grant rewards to accounts with fraud history.
- **`LastFraudPreventionOutcome` (`AlwaysBlock`)**: User is *permanently* blocked. This is a hard block with score 1.0 — retrying will never succeed. The user's account has been flagged for permanent payment fraud prevention. growth-friends logs will show `Not enough fraud data to confirm reward ... user should try again later` but the "try again" is misleading — this block is permanent.
- **`HasLaunchToday`**: Account is too new. The user may need to wait before claiming.

Note: `has_fraud_signal = true` in BigQuery (`internal__inviter_structure_history_with_invitee`) does not always mean the fraud team blocked the reward — it indicates a signal was present. Cross-reference with `fraud-user-trust-server` logs to confirm if a block actually occurred.

**Next steps:** Escalate to the fraud/trust team for manual review. If legitimate (recycled phone number, family members), they can override the policy.

### Voucher created but user can't see it

If the Scranton trace shows a successful `PUT /api/v1/create`:
- The voucher was created — check if it's visible in the user's wallet
- Some vouchers only appear during checkout (e.g. hotel vouchers with min spend requirements)
- Advise the customer to search for a qualifying product to see the voucher applied

### No fraud block but still failing

Check `trenton` logs for the referral endpoint (`/api/v1/social/referrals/info/<userId>`) — look for non-200 status codes or timeouts (499 with ~50s duration).

### Localization warning only

`Localization param is empty` is cosmetic — rewards still function but text isn't localized. Not a blocker.

## Escalation

If the issue requires manual intervention, escalate to the `growth-friends` service team:
- Owner: `org-vt-consumer`
- Slack: `#consumer-general`
