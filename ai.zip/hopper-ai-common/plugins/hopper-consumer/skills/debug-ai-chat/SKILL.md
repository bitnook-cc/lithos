---
name: debug-ai-chat
description: >-
  Use when debugging a bad consumer-ai travel agent conversation, investigating what
  went wrong with a chat, or someone pastes a conversation ID or ai.portal.hopper.com
  link. Covers the Hopper AI travel assistant (agent_id=travel) served by consumer-ai.
  Does NOT cover hts-assist, fintech-air, or other AI products.
---

# Debug Consumer-AI Chat

This skill debugs **consumer-ai travel agent** conversations — the Hopper AI travel
assistant that helps users search flights, plan trips, and manage bookings.

**Scope:** `service:consumer-ai`, `agent_id=travel`, scored in `fact_ai_conversation_scores`.
**Not in scope:** hts-assist (HTS support agent), fintech-air (fintech offers), or other AI products.

**Example:** a user reports a bad conversation →
`https://ai.portal.hopper.com/ai/chat/b3e1a4f2-7c89-4d12-ae56-1f2b3c4d5e6f/view`

When given a conversation ID, follow this workflow top-to-bottom.
Steps 1–3 have no dependencies — run them in parallel to save time.
Stop early if the root cause becomes clear.

## Step 0: Extract the conversation ID

The user may provide:
- A raw UUID: `b3e1a4f2-7c89-4d12-ae56-...`
- A portal link: `https://ai.portal.hopper.com/ai/chat/{id}/view`
- A BigQuery row reference

Extract the UUID. All queries below use it as `@cid`.

Portal link for any conversation: `https://ai.portal.hopper.com/ai/chat/{conversation_id}/view`

---

## Step 1: Get the score verdict

```sql
SELECT
  conversation_id,
  chat_date,
  quality_rating,
  primary_failure_mode,
  actionability,
  user_intent,
  abandonment_reason,
  failure_turn_index,
  total_turn_count,
  score_version,
  scoring_status,
  bench_capability,
  bench_difficulty,
  bench_scenario_type,
  bench_vertical,
  is_unsolvable,
  constraint_count,
  scored_at
FROM `h4r-common-bi-prd.ai__gld.fact_ai_conversation_scores`
WHERE conversation_id = @cid
ORDER BY scored_at DESC
LIMIT 1
```

Run with: `bq query --project_id=h4r-common-bi-stg --use_legacy_sql=false --parameter='cid:STRING:{ID}'`

Note: `--project_id=h4r-common-bi-stg` is the *billing* project (where compute runs), not the data
project. Most engineers have `bigquery.jobs.create` on stg but not prd. The query reads from
`h4r-common-bi-prd` tables via cross-project access, which is granted by default.

**Interpret the result:**

| Field | What it tells you |
|-------|-------------------|
| `quality_rating` | `bad` = something broke. `acceptable` = partial success. `good` = fine. |
| `primary_failure_mode` | The *what*: `technical_error`, `wrong_tool_selected`, `hallucinated_info`, `retrieval_failure`, `misunderstood_intent`, `poor_formatting`, `unsupported_capability` |
| `actionability` | The *where to fix*: `infra_fix` (backend), `tool_fix` (tool code), `prompt_fix` (LLM instructions), `knowledge_fix` (data gaps), `policy_fix` (business rules), `ui_fix` (frontend) |
| `abandonment_reason` | Why the user left: `technical_error`, `user_cancelled`, `confused_by_response`, `no_relevant_results`, etc. |
| `failure_turn_index` | Which turn broke (1-indexed, counting both `[USER]` and `[AGENT]` lines). Cross-reference with `total_turn_count` to understand how deep into the conversation the failure occurred, and with Step 3 timestamps to pinpoint the time window for Datadog searches. |
| `scoring_status` | If not empty string, the *scorer itself* failed (timeout/rate_limit/parse_failure). Re-score may be needed. |

**If no rows returned:** the conversation hasn't been scored yet. Check:
- Is `chat_date` within the last 4 days? (LOOKBACK_DAYS = 4)
- Is the conversation from the `travel` agent? (only `travel` agent is scored, config: `includedAgentIds: ["travel"]`)
- Is the scorer running? (see "Check if scorer is running" in Aggregate Playbooks below)

---

## Step 2: Check Datadog logs for that conversation

Search Datadog (via MCP or UI) for errors and warnings tied to this conversation.

**Primary search:**
```
service:consumer-ai env:production @conversationId:{ID} -"[notifications]"
```
Time range: bracket the `chat_date` from Step 1 (e.g., that day +/- 1 hour around when it happened).

The `-"[notifications]"` filter excludes noisy SSE notification reconnect logs (`SSE error, closing connection` / `Connecting to SSE` / `SSE connection opened`) that dominate results and obscure real errors.

**What to look for:**
- `status:error` → backend errors, tool failures, LLM errors
- `"Error detected and will be displayed to user"` → user-visible error was shown
- `"Flight agent run failed"` → flight sub-agent crashed
- `"Flight agent stopped by user"` → user hit stop (logged at `info` level, not an error)
- `"Streaming updates timed out"` → response stream died
- `"Tool execution failed"` → tool threw an error (after PR #1998 merged)
- `"Failed to parse UI message chunk"` → broken streaming response

**Flight agent sub-search:**
```
service:a2a-flight env:production @conversationId:{ID}
```

**Client-side errors (browser RUM):**
```
source:browser @conversationId:{ID}
```
Check these fields on client-side error logs:
- `@error.message` — e.g., `"Load failed"` (iOS Safari), `"Failed to fetch"` (Chrome/Android)
- `@http.useragent_details` — device, OS version, browser
- `@network.client.geoip` — carrier and location (helps identify mobile network issues)
- `@errorCategory` — `request_failed` = network failure vs other categories

**Tool failure metrics (after PR #1998):**
```
consumer_ai.tool.execution.error{conversationId:{ID}}
```

**LLM cost check (optional, for anomalies):**

```sql
SELECT
  workflow, component, base_model_id,
  SUM(input_tokens) AS input_tokens,
  SUM(output_tokens) AS output_tokens,
  ROUND(SUM(total_cost_usd), 4) AS cost_usd,
  COUNT(*) AS llm_calls
FROM `h4r-common-bi-prd.ai__gld.fact_ai_token_usage`
WHERE conversation_id = @cid AND environment = 'production'
GROUP BY 1, 2, 3 ORDER BY cost_usd DESC
```

Sum `llm_calls` across all rows — total > 20 suggests retry loops or excessive sub-agent
invocations. A single row won't exceed 20, but 15 + 3 + 3 + 3 = 24 across components is a red flag.
Very high `input_tokens` suggests context window bloat.

---

## Step 3: Check the raw transcript

The transcript is stored in Spanner `debug_logs`. Check the raw observability output in BigQuery.

**Metadata query** (timestamps and agent info):

```sql
SELECT conversation_id, agent_id, created_at, log_type
FROM `gcp-hopper-app-production.ai_observability__raw.raw_conversation_output`
WHERE conversation_id = @cid
ORDER BY created_at
```

This tells you:
- `agent_id` — which agent handled it (should be `travel` for scored convos)
- `created_at` — exact timestamps for each turn. Use these to correlate `failure_turn_index` from Step 1: count rows in order and match the Nth turn to its timestamp, then narrow your Datadog search to that time window.
- `log_type` — `request` (user turn) or `response` (agent turn)

**Body content query** (the actual diagnostic data — tool call inputs/outputs as JSON):

```sql
SELECT created_at, log_type, SUBSTR(body, 1, 2000) AS body_preview
FROM `gcp-hopper-app-production.ai_observability__raw.raw_conversation_output`
WHERE conversation_id = @cid
ORDER BY created_at
```

The `body` field contains full LLM API payloads including tool call arguments and results.
Truncate with `SUBSTR` to avoid BQ output limits. Increase to 5000+ if you need more context
on a specific turn. Look for:
- **Repeated tool calls** with identical inputs → wasteful retry loop
- `"flights":[]` in flightAgent output → empty inventory (see Flight Agent section below)
- Tool error objects embedded in the response → silent failures the AI SDK swallowed

Schema: `conversation_id STRING, user_id STRING, log_type STRING, body STRING, created_at TIMESTAMP, agent_id STRING`

**To read the actual transcript**, open the portal link:
`https://ai.portal.hopper.com/ai/chat/{conversation_id}/view`

**PII note:** BigQuery tables (`raw_conversation_output`, `conversation_scores`) are PII-scrubbed.
User messages may contain redacted placeholders (e.g., `[PERSON_NAME]`, `[EMAIL]`, `[PHONE]`) where
the scrubber replaced real data. If you need the unscrubbed text to understand context (e.g., the
scrubber mangled a city name or flight reference), read the raw transcript from Spanner `debug_logs`
via the portal link above or by querying Spanner directly — Spanner retains the original unscrubbed
messages.

---

## Step 4: Diagnose by failure mode

Based on Step 1's `primary_failure_mode` + `actionability`, follow the appropriate branch:

### `technical_error` + `infra_fix` (server-side)

Backend failure. Check Datadog (Step 2) for:
- Tool errors: `"Tool execution failed"` with tool name
- LLM API errors: 4xx/5xx from OpenAI or Vertex AI
- Timeout: `"Streaming updates timed out"`
- If Datadog shows nothing → likely a *silent tool failure* (AI SDK swallows errors). Check the transcript for tool calls that returned no useful data.
- Known silent-failure tools: `tripData`, `createTrip`, `linkConversationToTrip`

### `technical_error` + `infra_fix` (client-side)

If Datadog server logs show no errors but the scorer flagged `technical_error`, check client-side logs (`source:browser`). Common patterns:

- `errorMessage: "Load failed"` → iOS Safari `fetch()` network failure. Caused by cellular handoff, app backgrounding, or unstable connection. Very common (~83% of user-visible errors).
- `errorMessage: "Failed to fetch"` → Chrome/Android network failure. Same root causes.
- Check `@http.useragent_details` for device/OS/browser to confirm mobile.
- Check `@network.client.geoip` for carrier and location (e.g., satellite carrier = expected flakiness).
- Look for the recovery sequence: `error → submitted → streaming → ready`. If the client auto-retried and recovered, this is a transient network issue — no backend fix needed.
- If no recovery, the user saw an error screen. Check if the error message was helpful.

### `technical_error` + `tool_fix`

A specific tool's implementation is broken. Check which tool from:
1. Datadog: `"Tool execution failed" @toolName:{name}`
2. Transcript: look for `[TOOL toolName] error:` or `[TOOL toolName] failed:` lines

### `wrong_tool_selected` + `prompt_fix`

LLM chose the wrong tool. Read the transcript to see:
- What the user asked for
- Which tool the agent called instead
- What tool it *should* have called
- Check if the prompt instructions in `libs/core/agent/agents/travel/prompt.ts` guide this correctly

### `hallucinated_info` + `prompt_fix` or `knowledge_fix`

Agent stated something false. Read the transcript to identify the hallucination.
- If the agent made up flight prices/routes → `knowledge_fix` (tool data was missing)
- If the agent misinterpreted tool output → `prompt_fix`

### `retrieval_failure` + `tool_fix`

Tool code is broken or misformatting queries. Check:
1. Was the search query reasonable? (look at tool call inputs in `body`)
2. Did the tool return an error or malformed response?

### `retrieval_failure` + `knowledge_fix`

Agent's retrieval data is stale or incomplete. Check:
1. Is the data source missing coverage? (e.g., destination info, policy docs)
2. Did the tool return results but they were irrelevant to what the user asked?

### `retrieval_failure` + `infra_fix`

Tool executed correctly but the underlying data source has no coverage. Check:
1. Did the shopping API return `"flights":[]` (empty inventory) for the market/dates?
2. Is this a known thin market? (e.g., niche routes, far-out dates, connecting itineraries)
3. Did the agent try alternate parameters? (e.g., broader date range, nearby airports)
4. If consistently empty for a market that should have inventory, escalate as a data pipeline issue.

### `misunderstood_intent` + `prompt_fix`

Agent answered the wrong question. Read the transcript and check if:
- User query was ambiguous
- Agent prompt doesn't handle this intent pattern
- Language barrier or typo misled the agent

### `poor_formatting` + `ui_fix`

Correct information, confusing presentation. Open the portal link and compare the raw `body`
JSON (Step 3) against what the UI renders. Common causes: markdown rendering issues, widget
hydration failures, long unformatted lists, or flight options displayed without structure.

### `unsupported_capability`

The user asked for something outside the travel agent's scope (e.g., car rental booking,
insurance claims, non-travel questions). No code fix needed unless the capability *should*
be supported — in that case, file a product decision to expand scope.

### `user_cancelled` (abandonment_reason)

Not an error. User stopped the agent mid-response. Verify in Datadog:
- `"Flight agent stopped by user"` (info level) → confirms user-initiated
- No error logs → confirms no crash

### Retry loop detection

In the transcript body, look for repeated tool calls with the same `toolName` and identical
or near-identical input parameters. This indicates the agent is retrying a failed operation
without changing its approach — a wasteful loop that burns tokens and time. Common with
`shopMultipleFlights` when the agent retries the same date/route after getting empty results
instead of trying alternate parameters.

---

## Flight Agent Diagnostics

`flightAgent` is the most common tool in scored conversations. Key signals in its output:

- `"flights":[]` (empty array) = no inventory found for the requested market/dates. This is the
  single most common cause of `retrieval_failure`.
- `market_brief` field = the flight agent's own explanation of why results look the way they do.
  Read this first — it often contains the diagnosis.
- **Common empty-inventory causes:**
  - Destination not resolved to airport codes (e.g., user said "Japan" but agent searched `JPN` instead of `NRT`/`HND`/`KIX`)
  - Inventory not loaded for connecting routes or thin markets
  - Dates too far out (>330 days) or in the past
  - City-level vs airport-level code mismatch (search with `city/TYO` vs `airport/NRT`)
- If the agent got empty results and didn't retry with alternate parameters (broader dates,
  nearby airports, city-level codes), that's a `prompt_fix` — the SOP should guide fallback behavior.

---

## Aggregate Playbooks (for weekly/bulk analysis)

### Quality overview

```sql
WITH scored AS (
  SELECT s.*,
    ROW_NUMBER() OVER (PARTITION BY s.conversation_id ORDER BY s.scored_at DESC) AS rn
  FROM `h4r-common-bi-prd.ai__gld.fact_ai_conversation_scores` s
  WHERE s.scoring_status = ''
    AND s.chat_date BETWEEN DATE_SUB(CURRENT_DATE(), INTERVAL 7 DAY) AND CURRENT_DATE()
    AND NOT EXISTS (
      SELECT 1 FROM UNNEST(s.experiments) e
      WHERE e.experiment_name = 'HopperEmployees' AND e.variant = 'Available'
    )
),
deduped AS (SELECT * FROM scored WHERE rn = 1)
SELECT
  chat_date,
  COUNT(*) AS total,
  COUNTIF(quality_rating = 'bad') AS bad,
  ROUND(COUNTIF(quality_rating = 'bad') / COUNT(*) * 100, 1) AS bad_pct
FROM deduped
GROUP BY chat_date ORDER BY chat_date
```

Always: deduplicate on `conversation_id` (latest `scored_at`), filter `scoring_status = ''`, exclude HopperEmployees.

The following queries reuse the `deduped` CTE from above — replace the final `SELECT` in the Quality overview query with these, or prepend the full CTE header.

### Failure mode breakdown

```sql
-- Replace the final SELECT in the Quality overview query with:
SELECT primary_failure_mode, actionability, COUNT(*) AS cnt
FROM deduped
WHERE quality_rating = 'bad' AND primary_failure_mode != 'no_failure'
GROUP BY 1, 2 ORDER BY cnt DESC
```

### Get portal links for bad conversations

```sql
-- Replace the final SELECT in the Quality overview query with:
SELECT
  CONCAT('https://ai.portal.hopper.com/ai/chat/', conversation_id, '/view') AS link,
  primary_failure_mode, actionability, user_intent, chat_date
FROM deduped
WHERE quality_rating = 'bad'
ORDER BY chat_date DESC LIMIT 20
```

### Check if scorer is running

Search Datadog: `service:conversation-scorer env:production "Starting scoring run"` (last 2 days).
Key log fields: `candidates`, `includedByAgent`, `alreadyScored`, `todo`, `scored`, `succeeded`, `failed`.
CronJob schedule: `0 6 * * *` UTC.

---

## Architecture

```
User → consumer-ai (K8s) → LLM (OpenAI/Vertex)
                          → a2a-flight sub-agent
                          → tools (tripData, createTrip, editTripCanvas, etc.)
                          ↓
                    Spanner (debug_logs, conversations)
                          ↓
              conversation-scorer (K8s CronJob, 06:00 UTC daily)
                          ↓
              BigQuery (ai_scoring__raw.conversation_scores)
                          ↓
              SQLMesh (fact_ai_conversation_scores) — @daily FULL rebuild
```

**Repos:**
- `hopper-org/ai` — consumer-ai service, conversation-scorer, agent code, tools
- `hopper-org/sqlmesh-projects` — SQLMesh models (fact tables, ext tables, seeds)

**Key paths in `hopper-org/ai`:**
- `apps/conversation-scorer/` — scorer config, prompt, schema, orchestrator
- `libs/core/agent/agents/travel/` — main travel agent prompt and tools
- `libs/a2a/flight/` — flight sub-agent
- `libs/core/agent-trace/wrappers.ts` — tool tracing and observability
- `deployment/workloads/conversation-scorer/BUILD` — CronJob definition

## Gotchas

1. **Silent tool failures**: The AI SDK catches thrown tool errors and feeds them back to the model silently. No Datadog logs, no metrics (pre-PR #1998). Only way to detect: read the transcript or check scorer output for `technical_error`.
2. **BQ parameter types**: The `@google-cloud/bigquery` Node.js client silently drops string values declared as `TIMESTAMP` type. Always use `type: "STRING"`.
3. **User cancellations**: `abandonment_reason = 'user_cancelled'` (score_version >= 5). Older versions misclassify these as `technical_error/infra_fix`.
4. **Scorer not scoring**: If `fact_ai_conversation_scores` has no recent data, check: (a) CronJob has a `deployment_group` in `deployment/BUILD`, (b) BQ reader parameter types are `"STRING"` not `"TIMESTAMP"`, (c) `includedAgentIds` matches the agent.
5. **Client-side errors dominate**: ~83% of user-visible errors are client-side network failures (iOS Safari "Load failed"), not backend bugs. Always check `source:browser` logs before assuming a server issue.
6. **SSE notification noise**: Datadog results for a conversation will be flooded with SSE reconnect logs. Always add `-"[notifications]"` to your search filter.
