# hopper-flights

Skills for Hopper Flights engineers — booking flows, provider debugging, route discovery.

## Skills

| Skill | Purpose |
|---|---|
| `building-dashboard-jmes-queries` | Translate staging BQ machine session queries into Dashboard JMES for production |
| `find-bookable-flights` | Find bookable flights for testing and debugging |
| `flights-connectivity-autocover` | Autocover connectivity debugging and analysis |
| `flights-schedule-change` | Flights schedule change handling |
| `flights-travel-agency-repos` | Navigate Flights travel agency repositories |
| `read-provider-state-machine-sessions` | Read and debug provider state machine sessions |

## Install

```
/plugin marketplace add hopper-org/hopper-ai-common
/plugin install hopper-flights@hopper-ai-common
```
