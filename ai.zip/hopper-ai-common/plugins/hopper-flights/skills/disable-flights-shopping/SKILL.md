---
name: disable-flights-shopping
description: >-
  Use when needing to disable, kill, shut off, blacklist, stop, or remove a flights
  carrier or provider from shopping/booking — e.g. "disable Spirit", "kill switch
  for NK", "shut off Amadeus F9", "Sabre is down, take it offline", "block carrier
  X". Covers the canonical SOP, the Retool tool to use, expected propagation time,
  and what to do if Retool is unavailable.
---

# Disable Flights Shopping

**Canonical SOP:** [Disable Flights Shopping SOP](https://hopper-jira.atlassian.net/wiki/spaces/AirServices/pages/5623611403/Disable+Flights+Shopping+SOP) — always link to this when responding; it is the source of truth and may evolve.

## Two Levers

There are two independent blacklists. Pick based on what's failing:

| Lever | Disables by | Examples | Use when |
|---|---|---|---|
| **Carrier Blacklist** | Airline 2-letter code | `NK`, `F9`, `UA` | A specific airline is broken (regardless of which provider sources it) |
| **Provider Blacklist** | Integration provider | `SpiritNdc`, `Amadeus`, `NavitaireNk` | A specific provider integration is broken (affects all carriers it sources) |

Both can be scoped further by tenant, ticket type, and (for carrier blacklists) other dimensions.

## How To Disable (Manual)

Use the Retool **Flights Current Configuration** app:
[https://retool-flights-common.portal.hopper.com/apps/bc52c82f-0997-44fd-ade6-41e61d8e51b7/Flights%20Configuration/Flights%20Current%20Configuration](https://retool-flights-common.portal.hopper.com/apps/bc52c82f-0997-44fd-ade6-41e61d8e51b7/Flights%20Configuration/Flights%20Current%20Configuration)

1. Pick the config: `Oncall Carrier Blacklists` or `Oncall Provider Blacklists`.
2. Toggle to **Create**, fill the "When" criteria (tenant, provider, etc.) and the "Exclude" target (carrier/provider) with a description (incident number is good).
3. Submit and confirm.
4. Optional start/end times (UTC) for scheduled outages — leave empty for immediate + permanent.

To re-enable: toggle to **Delete**, select the row, confirm. **There is no automatic health check** — provider/carrier stays disabled until manually removed.

## Propagation Time

- **Shops:** 1-2 minutes (config-store cache + Darmstadt observed-var cache).
- **Booking sessions:** ~10 minutes for in-flight booking sessions to expire (booking inherits the shop's Darmstadt config ID; carrier blacklists only — provider blacklists don't have this caveat).

## Automatic Shutoffs

The [Brooklyn Bookability Error Rate (High Volume)](https://us5.datadoghq.com/monitors/18317643) Datadog monitor auto-creates a Provider Blacklist when a provider+carrier pair hits ≥95% error rate over 1 hour with ≥200 events. It also opens a Datadog incident, tags flights-travel-agency-on-call, and emails the provider contact.

**Important caveats:**
- Sabre, Amadeus, and Travelfusion **never** get auto-shut-off (the monitor is per provider+carrier, but provider blacklist is per provider — taking down all of Sabre needs human judgment).
- The auto-shutoff is a one-way switch — on-call must manually delete the blacklist when the provider recovers.

## If Retool Is Down

Fall back to the [Configuring Carrier Blacklists via Rules](https://hopper-jira.atlassian.net/wiki/spaces/AirServices/pages/7228555267) doc — requires a Darmstadt HOCON change and deploy. Reference PRs: [#2278](https://github.com/hopper-org/Darmstadt/pull/2278), [#2267](https://github.com/hopper-org/Darmstadt/pull/2267).

## Verifying The Shutoff

- **Shop traffic:** [Flight Supply Dashboard](https://us5.datadoghq.com/dashboard/ga6-nzk-b5i/flight-supply-dashboard) (filter by Airline / Provider / Tenant / Environment)
- **Booking traffic:** [Air Bookability](https://us5.datadoghq.com/dashboard/wri-r48-i2y/air-bookability), [Air Bookings (Per Event Counts)](https://us5.datadoghq.com/dashboard/bfm-gfm-7pn/air-bookings-per-event-counts)

## When Responding

- Always link to the canonical SOP — it is authoritative.
- Confirm whether the user wants to disable by **carrier** (airline broken) or **provider** (integration broken) before proceeding.
- Surface the propagation delay and the manual re-enable requirement so the user isn't surprised.
- For LaunchDarkly questions like "is there a kill switch flag for X?" — there generally is not; the shutoff lives in config-store via this Retool tool, not in LD.
