---
name: find-bookable-flights
description: >-
  Find flight routes known to book successfully for specific providers and carriers
  in staging/development. Queries BigQuery booking records to identify working
  routes. Use when user needs "bookable routes", "test flights", "find routes for
  provider", "which routes book for [carrier]", or "shop flights in staging".
---

# Find Bookable Flights

Find flight routes that are known to book successfully for a given provider and/or carrier in staging and development environments. This is useful when you need real route data for testing booking flows.

## Prerequisites

You need access to BigQuery and the `bq` CLI tool.

1. **Check `bq` is installed**: `which bq` — it ships with the Google Cloud SDK (`gcloud`)
2. **Authenticate if needed**: `gcloud auth application-default login`
3. **Ensure access to the staging dataset**: The queries use `h4r-common-bi-stg.brooklyn__slv.fact_flight_product`

## Finding Bookable Routes

Query BigQuery for recent PNRs (passenger name records) that booked successfully with a given provider or carrier. The `fact_flight_product` table in the staging dataset contains booking records with provider, route, and carrier information.

### Base Query

```sql
SELECT
  pnr.system_locator,
  fact.session_timestamp,
  pnr.provider,
  pnr.sub_provider
FROM `h4r-common-bi-stg.brooklyn__slv.fact_flight_product` fact,
UNNEST(pnr_facts) AS pnr
WHERE fact.session_timestamp >= TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 60 DAY)
  AND (LOWER(pnr.sub_provider) = 'amadeusndcx' OR LOWER(pnr.provider) = 'amadeusndcx')
LIMIT 10
```

### How to Adapt the Query

**Filter by provider or sub-provider:** Replace `'amadeusndcx'` with the target provider name (always lowercase):

```sql
AND (LOWER(pnr.sub_provider) = 'sabre' OR LOWER(pnr.provider) = 'sabre')
```

**Filter by carrier:**

```sql
SELECT
  pnr.system_locator,
  fact.session_timestamp,
  pnr.provider,
  pnr.sub_provider,
  seg.marketing_airline,
  seg.origin,
  seg.destination
FROM `h4r-common-bi-stg.brooklyn__slv.fact_flight_product` fact,
UNNEST(pnr_facts) AS pnr,
UNNEST(pnr.segments) AS seg
WHERE fact.session_timestamp >= TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 60 DAY)
  AND LOWER(seg.marketing_airline) = 'aa'
LIMIT 10
```

**Find distinct routes for a provider:**

```sql
SELECT DISTINCT
  seg.origin,
  seg.destination,
  seg.marketing_airline,
  pnr.provider,
  pnr.sub_provider
FROM `h4r-common-bi-stg.brooklyn__slv.fact_flight_product` fact,
UNNEST(pnr_facts) AS pnr,
UNNEST(pnr.segments) AS seg
WHERE fact.session_timestamp >= TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 60 DAY)
  AND (LOWER(pnr.sub_provider) = 'amadeusndcx' OR LOWER(pnr.provider) = 'amadeusndcx')
LIMIT 20
```

### Running the Query

```bash
bq query --use_legacy_sql=false '
SELECT
  pnr.system_locator,
  fact.session_timestamp,
  pnr.provider,
  pnr.sub_provider
FROM `h4r-common-bi-stg.brooklyn__slv.fact_flight_product` fact,
UNNEST(pnr_facts) AS pnr
WHERE fact.session_timestamp >= TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 60 DAY)
  AND (LOWER(pnr.sub_provider) = '\''amadeusndcx'\'' OR LOWER(pnr.provider) = '\''amadeusndcx'\'')
LIMIT 10
'
```

## Using the Results

1. **Pick a route** from the results
2. **Shop the route** in staging/development using the identified provider/carrier
3. **Use a future date** — the route worked recently, so it should be shoppable for upcoming dates
4. **Verify availability** — if one route doesn't return results, try another from the query output
