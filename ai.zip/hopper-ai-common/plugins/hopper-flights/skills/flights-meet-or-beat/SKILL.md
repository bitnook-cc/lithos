---
name: flights-meet-or-beat
description: >-
  Use when investigating Meet or Beat (MoB) data quality issues, debugging why
  MoB results differ from OTA competitors, tracing MoB data pipeline from
  Lexington through STFF to analysis tables, or comparing tenant vs competitor
  fares. Triggers: "meet or beat", "MoB", "hts_mob", "lowest fare comparison",
  "QL2", "STFF responses", "WS connecting flights missing", "artificial losses",
  "fare comparison mismatch".
---

# Flights Meet or Beat (MoB) Investigation

## Overview

Meet or Beat (MoB) compares Hopper/tenant flight fares against OTA competitors (Expedia, etc.) to measure price competitiveness. This skill covers how to investigate data quality issues in the MoB pipeline — particularly cases where fares appear missing, connecting flights are dropped, or results diverge from what OTAs show.

## Data Pipeline

```
Lexington (shop aggregator)
  │
  ├─→ PubSub: shop_results_v2
  │     └─→ Rotterdam (Daventry Spark: ShopsTripLevelDumpRunner)
  │           └─→ Parquet on GCS: gs://warehouse.hive.{env}.{domain}/shop_trip_fare_facts/
  │                 └─→ data-orchestration: flights_etl.stage_shop_trip_fare_facts (bronze)
  │                       └─→ sqlmesh: flights_shop__slv.wholeco_fact_shop_trip_fare (silver)
  │                             └─→ flights_shop__gld.wholeco_fact_shop_trip_fare (gold VIEW)
  │
  └─→ BigQuery: lexington_shop_data (separate path, powers Shop Viewer UI)

MoB Analysis Pipeline (built daily by jhita@hopper.com at ~11:30 UTC):
  requested_shops + gold STFF → hts_mob_stff_responses
  hts_mob_stff_responses + QL2 data → hts_mob_lowest_fare_comparison
```

## Key Tables

| Table | Project | Purpose |
|-------|---------|---------|
| `flights_meet_or_beat.requested_shops` | `gcp-hopper-app-production` | MoB shop requests (routes, dates, user IDs) |
| `flights_shop__slv.wholeco_fact_shop_trip_fare` | `h4r-common-bi-prd` | Silver STFF — all shop trip fare facts |
| `flights_shop__gld.wholeco_fact_shop_trip_fare` | `h4r-common-bi-prd` | Gold STFF — VIEW over `flights_shop__gld_physical`, no filtering |
| `jhita.hts_mob_stff_responses` | `gcp-hopper-ds-research` | MoB STFF responses joined with requested_shops |
| `jhita.hts_mob_lowest_fare_comparison` | `gcp-hopper-ds-research` | Final comparison: tenant vs competitor fares |
| `jhita.hts_mob_ql2_processed_data` | `gcp-hopper-ds-research` | QL2 competitor (OTA) shop data |
| `jhita.hts_mob_country_tier_snapshot` | `gcp-hopper-ds-research` | Country tier mapping for route classification |

Always run queries with `--project_id=gcp-hopper-ds-research` as the billing project.

## MoB User IDs

The MoB system uses dedicated user IDs for shopping. To find the current one:

```sql
SELECT DISTINCT userId, tenant, COUNT(*) as shop_count
FROM `gcp-hopper-app-production.flights_meet_or_beat.requested_shops`
WHERE DATE(shopStartedAt) >= CURRENT_DATE() - 7
GROUP BY userId, tenant
ORDER BY shop_count DESC
```

Known RBC MoB user: `44bea8dd-ce10-4e57-9961-596b6b4487c9`

## Investigation Workflow

### Step 1: Verify the shop exists in requested_shops

```sql
SELECT shopId, userId, origin, destination,
  DATE(shopScheduledAt) as scheduled_date,
  DATE(shopStartedAt) as started_date,
  reference, tenant
FROM `gcp-hopper-app-production.flights_meet_or_beat.requested_shops`
WHERE userId = '{MOB_USER_ID}'
  AND origin = '{ORIGIN}'
  AND destination = '{DESTINATION}'
  AND DATE(shopScheduledAt) >= CURRENT_DATE() - 14
ORDER BY shopStartedAt DESC
```

MoB shops specific departure dates on specific days — not every date is shopped. If a departure date isn't found, it was never requested.

### Step 2: Check STFF data for the shop

Query the silver table to see what Lexington returned:

```sql
SELECT
  received_date_utc,
  trip_outgoing_stops,
  COUNT(*) as trip_count,
  MIN(fare_pricing_subtotal) as cheapest_fare
FROM `h4r-common-bi-prd.flights_shop__slv.wholeco_fact_shop_trip_fare`
WHERE shop_id = '{SHOP_ID}'
GROUP BY received_date_utc, trip_outgoing_stops
ORDER BY received_date_utc, trip_outgoing_stops
```

Key columns in silver STFF:
- `trigger_user_id` — the user who triggered the shop
- `trigger_name` — `in_app_shop` for MoB shops (NOT `price_validation`)
- `trip_outgoing_stops` — 0 = direct, >0 = connecting
- `received_date_utc` — date STFF data was received (critical for join timing)

### Step 3: Compare silver STFF vs hts_mob_stff_responses

```sql
-- Silver side
SELECT received_date_utc, COUNT(*) as silver_count,
  COUNT(CASE WHEN trip_outgoing_stops > 0 THEN 1 END) as connecting
FROM `h4r-common-bi-prd.flights_shop__slv.wholeco_fact_shop_trip_fare`
WHERE trigger_user_id = '{MOB_USER_ID}'
  AND received_date_utc BETWEEN '{START}' AND '{END}'
GROUP BY received_date_utc ORDER BY received_date_utc;

-- MoB side
SELECT shop_date, COUNT(*) as mob_count,
  COUNT(CASE WHEN departure_stops > 0 THEN 1 END) as connecting
FROM `gcp-hopper-ds-research.jhita.hts_mob_stff_responses`
WHERE user_id = '{MOB_USER_ID}'
  AND shop_date BETWEEN '{START}' AND '{END}'
GROUP BY shop_date ORDER BY shop_date;
```

Connecting trip counts should match exactly. Small total differences (~10-20 per day) are expected — these are LEFT JOIN rows from `requested_shops` with no STFF match.

### Step 4: Inspect specific fares

```sql
SELECT
  departure_flights, departure_carriers, departure_stops,
  base, taxes, total_amount, total_amount_usd,
  fare_source, is_multiticket, multiticket_type
FROM `gcp-hopper-ds-research.jhita.hts_mob_stff_responses`
WHERE user_id = '{MOB_USER_ID}'
  AND origin = '{ORIGIN}' AND destination = '{DESTINATION}'
  AND shop_date = '{SHOP_DATE}' AND departure_date = '{DEP_DATE}'
ORDER BY total_amount_usd ASC
LIMIT 20
```

- `base` and `total_amount` are in local currency (e.g., CAD for Canadian routes)
- `total_amount_usd` is the USD-converted total — this is what the ranking uses
- `base_usd` has a known bug (always equals 1.0) — do not use it

### Step 5: Trace build query lineage

If data is missing, trace which query built the table:

```sql
SELECT query, creation_time, user_email
FROM `gcp-hopper-ds-research.region-us.INFORMATION_SCHEMA.JOBS`
WHERE destination_table.table_id = '{TABLE_NAME}'
  AND statement_type IN ('INSERT', 'CREATE_TABLE_AS_SELECT', 'MERGE')
  AND state = 'DONE'
ORDER BY creation_time DESC
LIMIT 2
```

## hts_mob_stff_responses Build Query — Key Filters

The daily build joins `requested_shops` with gold STFF:

```sql
FROM `gcp-hopper-app-production.flights_meet_or_beat.requested_shops` rs
LEFT JOIN `h4r-common-bi-prd.flights_shop__gld.wholeco_fact_shop_trip_fare` stff
  ON rs.shopId = stff.shop_id
  AND stff.received_date_utc = CURRENT_DATE() - 1
WHERE DATE(rs.shopStartedAt) = CURRENT_DATE() - 1
  AND DATE(shopScheduledAt) >= CURRENT_DATE() - 14
GROUP BY ALL
```

Critical filters:
- `received_date_utc = CURRENT_DATE() - 1` — only joins STFF data received *yesterday*
- `shopStartedAt = CURRENT_DATE() - 1` — only processes shops started *yesterday*
- Runs at ~11:30 UTC daily — if STFF data lands late, it gets missed

## hts_mob_lowest_fare_comparison — Ranking Logic

The comparison query selects the cheapest fare per shop:

```sql
ROW_NUMBER() OVER (
  PARTITION BY shop_id
  ORDER BY total_amount_usd, duration, departure_local_time
) AS tenant_fare_rank
...
QUALIFY tenant_fare_rank = 1
```

- Ranks by `total_amount_usd` (cheapest wins), then `duration`, then departure time
- No filter on `departure_stops` — connecting flights CAN win if cheapest
- Excludes carriers F8 (Flair) and YB only
- `reference` must match `%wholeco%`, `%weekly%`, or `%adhoc%`
- `tenant` must match the target (e.g., `rbc`)

The QL2 competitor data is ranked similarly per `report_shop_id` and `ota`.

Final result classification:
- *Price Meet*: `|perc_price_diff| <= 1%`
- *Price Beat*: tenant cheaper by >1%
- *Price Lose*: tenant more expensive by >1%
- *Availability Beat*: tenant has fare, competitor doesn't
- *Availability Lose*: competitor has fare, tenant doesn't

## Common Issues

### "Connecting flights missing from MoB"

Usually NOT a pipeline issue. Check:
1. Was the departure date actually shopped? MoB samples specific dates, not all.
2. Are connecting flights in `hts_mob_stff_responses`? They usually are.
3. Is the Looker Studio dashboard filtering to direct-only? The underlying data includes connecting flights, but dashboard filters may exclude them.
4. The Shop Viewer (Lexington BigQuery path) uses a *different data source* than STFF — results may differ.

### "MoB cheapest price doesn't match OTA"

- `total_amount_usd` is the comparison metric, not `base` or `total_amount`
- Prices in `total_amount` are in local currency (CAD for Canadian routes)
- QL2 and MoB may shop at different times — fare availability changes
- Check `shop_time_diff` in `hts_mob_lowest_fare_comparison` for timing gaps

### "base_usd is wrong"

Known bug. The build query computes `COALESCE(stff.fare_usd_exchange_rate / fare_usd_exchange_rate, 0)` — divides exchange rate by itself, always yields 1.0. Use `total_amount_usd` instead.

### Date boundary issues

If shops run near midnight UTC, `received_date_utc` might land on day N while `shopStartedAt` is day N-1 (or vice versa). The `CURRENT_DATE() - 1` filter on both sides can cause misalignment.

## Related Tables

| Table | Purpose |
|-------|---------|
| `jhita.hts_mob_itineraries_comparison` | Itinerary-level comparison (carrier, flights, stops) |
| `jhita.hts_mob_ql2_processed_data` | Processed QL2 competitor data |
| `jhita.hts_mob_ota_mapping` | OTA name mapping |
| `jhita.manual_mob_reporting` | Manual reporting aggregation |
| `jhita.mob_shop_routes_t1_tiered_*` | Route selection/generation tables |

## Key Repos

| Repo | Role |
|------|------|
| `hopper-org/flights-meet-or-beat` | MoB service — schedules shops, writes to `requested_shops` |
| `hopper-org/Lexington` | Shop aggregator, publishes to PubSub and BigQuery |
| `hopper-org/Rotterdam` | Runs `ShopsTripLevelDumpRunner` (Daventry Spark), outputs STFF parquet |
| `hopper-org/data-orchestration` | Loads parquet into `stage_shop_trip_fare_facts` |
| `hopper-org/sqlmesh-projects` | Creates silver/gold STFF views from stage tables |

## Further Reading

See [Resources](references/resources.md) for Confluence docs, key file paths in each repo, QL2 references, and BigQuery project mappings.
