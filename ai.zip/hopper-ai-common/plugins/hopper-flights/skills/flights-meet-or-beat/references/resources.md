# Flights Meet or Beat — Resources

Links to Confluence docs, GitHub repos, and dashboards relevant to MoB investigations.

## Confluence — Flights MoB

| Document | Space | Description |
|----------|-------|-------------|
| [Flights Meet or Beat (MoB)](https://hopper-jira.atlassian.net/wiki/spaces/AirServices/pages/6070075607/Flights+Meet+or+Beat+MoB) | Flights Travel Agency | Primary MoB documentation — Looker Studio view, data sources, methodology |
| [COT Migration - flights-meet-or-beat](https://hopper-jira.atlassian.net/wiki/spaces/ENG/pages/7714406420/COT+Migration+-+flights-meet-or-beat) | Engineering | Service ownership, approval chain, migration details |
| [flights-meet-or-beat XGCP Security Approval](https://hopper-jira.atlassian.net/wiki/spaces/ENG/pages/7224328201/flights-meet-or-beat+XGCP+Security+Approval) | Engineering | XGCP security approval for cross-project BigQuery and PubSub access |
| [Meet or Beat Overview](https://hopper-jira.atlassian.net/wiki/spaces/~882519001/pages/6685360277/Meet+or+Beat+Overview) | David Vaynshteyn | High-level MoB overview including Sabre and NDC reports |
| [Meet or Beat Shopping User IDs](https://hopper-jira.atlassian.net/wiki/spaces/TT1/pages/6419120222/Meet+or+Beat+Shopping+User+IDs) | Travel Tech | Reference list of all MoB shopping user IDs per tenant and region |

## Confluence — QL2 (Competitor Data)

| Document | Space | Description |
|----------|-------|-------------|
| [QL2 Quick Tutorial](https://hopper-jira.atlassian.net/wiki/spaces/VI/pages/6747160726/QL2+Quick+Tutorial) | Virtual Interlining | How QL2 works — scraping platform for competitor OTA pricing |
| [QL2 Shop Configuration](https://hopper-jira.atlassian.net/wiki/spaces/AirServices/pages/6075711678/QL2+Shop+Configuration) | Flights Travel Agency | How to configure QL2 shops, OTA codes, POS settings |
| [QL2 data quality analysis](https://hopper-jira.atlassian.net/wiki/spaces/EME/pages/5813993766/QL2+data+quality+analysis) | Europe Market Expansion | Known QL2 data quality issues and patterns |
| [Kiwi QL2 Data Quality Investigation](https://hopper-jira.atlassian.net/wiki/spaces/VI/pages/7204339768/Kiwi+QL2+Data+Quality+Investigation) | Virtual Interlining | QL2 vs manual search accuracy analysis |
| [Ingesting QL2 Data for Hopper Analysis](https://hopper-jira.atlassian.net/wiki/spaces/AirServices/pages/5725257775/Ingesting+QL2+Data+for+Hopper+Analysis) | Flights Travel Agency | QL2 SFTP ingestion pipeline into BigQuery |
| [Daily Meet or Beat Reporting (via QL2)](https://hopper-jira.atlassian.net/wiki/spaces/AirServices/pages/5725192236/Daily+Meet+or+Beat+Reporting+via+QL2) | Flights Travel Agency | Original MoB reporting design using QL2 |
| [RFC: Migrate QL2 data ingestion](https://hopper-jira.atlassian.net/wiki/spaces/AirServices/pages/6880067696/RFC+Migrate+QL2+data+ingestion) | Flights Travel Agency | Migration plan for QL2 data ingestion to golden path |

## Confluence — STFF & Shopping Pipeline

| Document | Space | Description |
|----------|-------|-------------|
| [STFF Silver Tables for flights-bi-sqlmesh](https://hopper-jira.atlassian.net/wiki/spaces/AirServices/pages/6975389832/STFF+Silver+Tables+for+flights-bi-sqlmesh) | Flights Travel Agency | Silver table design in sqlmesh, column mappings from bronze |
| [Flights Shopping Service (Lexington) Overview](https://hopper-jira.atlassian.net/wiki/spaces/AirServices/pages/5597495460/Flights+Shopping+Service+aka+Lexington+Overview) | Flights Travel Agency | How Lexington aggregates shops across providers |
| [Lexington Shop Viewer](https://hopper-jira.atlassian.net/wiki/spaces/AirServices/pages/6171853950/Lexington+Shop+Viewer) | Flights Travel Agency | Shop Viewer tool — reads from BigQuery `lexington_shop_data` (separate data path from STFF) |
| [Lexington Shop Viewer Tech Spec](https://hopper-jira.atlassian.net/wiki/spaces/AirServices/pages/6199607482/Lexington+Shop+Viewer+Tech+Spec) | Flights Travel Agency | Technical spec for Shop Viewer BigQuery integration |
| [Daventry - Technical Documentation](https://hopper-jira.atlassian.net/wiki/spaces/AirServices/pages/5267292280/Daventry+-+Technical+Documentation) | Flights Travel Agency | Daventry Spark jobs that process shop events into STFF parquet |
| [Switch to Productionized Meet or Beat Data](https://hopper-jira.atlassian.net/wiki/spaces/TT1/pages/6617497613/Release+Note+Switch+to+Productionized+Meet+or+Beat+Data) | Travel Tech | Release note for MoB data migration into sqlmesh + Looker |

## GitHub Repositories

| Repo | Description |
|------|-------------|
| [hopper-org/flights-meet-or-beat](https://github.com/hopper-org/flights-meet-or-beat) | MoB service — schedules and runs test shops, writes to `requested_shops` |
| [hopper-org/Lexington](https://github.com/hopper-org/Lexington) | Flight shop aggregator — publishes to PubSub `shop_results_v2` and BigTable |
| [hopper-org/Rotterdam](https://github.com/hopper-org/Rotterdam) | ETL DAGs — runs `ShopsTripLevelDumpRunner` (Daventry Spark) to produce STFF parquet |
| [hopper-org/data-orchestration](https://github.com/hopper-org/data-orchestration) | Loads STFF parquet into BigQuery `flights_etl.stage_shop_trip_fare_facts` |
| [hopper-org/sqlmesh-projects](https://github.com/hopper-org/sqlmesh-projects) | Creates silver/gold STFF views from stage tables (`flights_shop__slv`, `flights_shop__gld`) |

### Key Files in Each Repo

*Lexington:*
- `server/src/main/scala/com/hopper/lexington/ShopResultPublisher.scala` — publishes shop results to PubSub
- `shop-data-server/src/main/scala/com/hopper/lexington/ShopDataController.scala` — Shop Viewer API endpoints
- `core/src/main/resources/base.conf` — PubSub topic, BigTable, BigQuery config

*Rotterdam:*
- `dags/hopper_app/flights_internal_shops.py` — DAG for `ShopsTripLevelDumpRunner`

*data-orchestration:*
- `dags/flights_etl/shop_trip_fare_facts_daily.py` — loads STFF parquet into BigQuery

*sqlmesh-projects:*
- `projects/flights_bi_sqlmesh/models/slv/wholeco_fact_shop_trip_fare.sql` — silver view definition
- `deployment/configs/production.env` — maps `@bi_project` to `h4r-common-bi-prd`

## BigQuery Projects

| Environment | App Project | ETL/BQ Project | BI Project |
|-------------|-------------|----------------|------------|
| Production | `gcp-hopper-app-production` | `gcp-hopper-etldata-production` | `h4r-common-bi-prd` |
| Development | `gcp-hopper-app-development` | `gcp-hopper-etldata-development` | — |
| Research | `gcp-hopper-ds-research` (billing project for queries, also hosts `jhita.*` analysis tables) | — | — |

## Datadog Dashboards

Search for dashboards related to:
- `flights-meet-or-beat` — service health and shop execution metrics
- `lexington` — shopping pipeline latency and provider response metrics
- `daventry` — STFF processing and parquet generation

## Looker Studio

The primary MoB analysis dashboard is a Looker Studio view built on top of `gcp-hopper-ds-research.jhita.hts_mob_lowest_fare_comparison`. Access is managed by the data science team (jhita@hopper.com).
