# Architecture & Data Models

## System Architecture

```
                    +------------------+
                    |   GDS Queues     |
                    | (Sabre, Amadeus) |
                    +--------+---------+
                             |
                    +--------v---------+     +-------------------+
                    |    Brooklyn      |     |  NDC Providers    |
                    |(LocatorQueue     |     | (OrderChangeNotif |
                    | Services)        |     |  webhooks)        |
                    +--------+---------+     +--------+----------+
                             |                        |
                    +--------v---------+     +--------v----------+
                    |  Schedule Change |     |  Webhook Server   |
                    |   Machine        |<----+                   |
                    |  (executor)      |     +-------------------+
                    +--------+---------+
                             |
              +--------------+--------------+
              |              |              |
     +--------v------+ +----v-----+ +------v------+
     | Minor: Auto-  | | Major:   | | Discard:    |
     | accept + MOD  | | User     | | Notify +    |
     | email         | | Outreach | | Cancel      |
     +-------+-------+ +----+-----+ +-------------+
             |              |
             |     +--------v--------+
             |     | UserOutreach    |
             |     | Machine         |
             |     +--------+--------+
             |              |
             |  +-----------+-----------+
             |  |                       |
             |  +--------v------+ +----v-------+
             |  | User Accepts  | | User Denies|
             |  +--------+------+ +----+-------+
             |           |             |
     +-------v-----------v--+    +-----v----------+
     | Reissue tickets      |    | Route to CS    |
     | (even exchange       |    | (Kustomer)     |
     |  with waiver code)   |    +----------------+
     +-----------+----------+
                 |
     +-----------v----------+
     | PTM (Brooklyn)       |
     | Update itinerary     |
     | Send MOD email       |
     +----------------------+
```

## State Machines in Detail

### ScheduleChangeMachine

The main orchestrator. Source: `machine/src/main/scala/.../executor/schedulechange/ScheduleChangeMachine.scala`

**Sub-machines (composed):**

1. **ScheduleChangeCouponsMachine** — Retrieves ticket/coupon data from providers.

2. **EvaluationMachine** — Runs classification rules. See `EvaluationMachine.scala` for the current step list. Key evaluation areas:
   - Segment differences (departure/arrival times, flight numbers, carriers)
   - Connection validity (MCT/VCT checks)
   - Cancellations (HX segments)
   - Airport changes
   - Reprotection availability
   - Per-airline thresholds

3. **ScheduleChangeCreateOrUpdateMachine** — Persists SKCH to Cloud Spanner. Handles deduplication.

4. **AcceptScheduleChangeMachine** — Auto-accepts minor changes via provider API.

**Special case routing** happens before evaluation — see ScheduleChangeMachine for the current set of special cases (unusable coupons, all-cancelled segments, ticketless carriers, manual PNRs, multi-provider bookings, IRROP, fare optimization, etc.).

### ScheduleChangeActionMachine

Processes user accept/deny decisions. Source: `machine/src/main/scala/.../executor/schedulechange/ScheduleChangeActionMachine.scala`

**Accept flow:**
1. Validate PNR status
2. Retrieve current itinerary
3. Check ticket status (coupons must be OPEN)
4. Execute acceptance via provider API
5. Look up waiver code
6. Reissue tickets with waiver code (even exchange)
7. Verify all tickets successfully reissued
8. Send to PTM for MOD email

**Deny flow:**
1. Validate PNR
2. Route to CS agent via Kustomer

### UserOutreachMachine

Notification lifecycle. Source: `machine/src/main/scala/.../executor/useroutreach/UserOutreachMachine.scala`

Handles notification lifecycle for major schedule changes — initial notification, follow-ups, and auto-accept at deadline.

**Time-to-departure affects notification behavior:**
- **Close to departure:** Email refers user to airline, no accept/deny
- **Moderate time:** Accept/deny available, deny = refer to airline
- **Far from departure:** Accept/deny available, deny = pick time preferences, CS finds alternatives

See UserOutreachMachine for current time thresholds.

## Service Integration

### flights-servicing-eligibility (FSE)

Primary gating service for exchange and cancellation eligibility. Key SKCH integration:

- **Active schedule change (`UserAction.Waiting`)** → `INELIGIBLE_PENDING_SCHEDULE_CHANGE`
- Exchange blocked until user accepts or denies
- Cancellation eligibility delegates to provider services
- FSE also checks void windows via Darmstadt

### flights-exchange

Checks `ScheduleChangeApi.findScheduleChange()` before allowing exchange:
- ANY non-accepted schedule change → FAIL with `InexchangeableTicketScheduleChangePending`
- `UserAction.Accept` allows; `UserAction.Waiting` blocks

### flights-cancellation

Cancellations may follow schedule changes:
- User denies major SKCH and wants refund → cancellation flow
- Major SKCH during fare optimization → cancel booking

### Brooklyn

Houses LocatorQueueServices (GDS queue polling) and PostTicketingMachine (PTM):
- **LocatorQueueServices:** Polls PCCs for SKCH/PTM pickups
- **PTM:** Processes completed booking changes — sends emails, push notifications, updates stored reservations

## Data Models

### ScheduleChangeDifference

```
ScheduleChangeDifference
├── NoDifference          — old and new itinerary identical
├── ItineraryDelta        — contains SegmentDifferences
│   └── SegmentDifference
│       ├── departureTimeDelta
│       ├── arrivalTimeDelta
│       ├── flightNumberChange
│       ├── carrierChange
│       ├── airportChange (origin/destination)
│       └── equipmentChange
└── Problematic           — cannot process (unknown airports, segment mismatch,
                            overlapping segments, unexpected status)
```

### UserAction States

| State | Meaning | Blocks exchange? |
|-------|---------|-----------------|
| `Waiting` | SKCH pending user response | Yes |
| `Accept` | User accepted new itinerary | No |
| `Deny` | User denied new itinerary | No |

### Reprotection

**Reprotection** = airline-provided prospective itinerary with new flight segments.

Validation criteria:
- All impacted segments must have equivalents with TK or SC status
- One segment can become two (or vice versa) for the same leg
- Affected segments must have coupon status OPEN
- Prospective itinerary must be "continuous" (no ARNK gaps)

## gRPC APIs

### FlightsScheduleChangeServer

```protobuf
service FlightsScheduleChangeService {
  rpc OrderChangeNotif(OrderChangeNotifRequest) returns (OrderChangeNotifResponse);
  rpc FrequentFlyerNumberOrderChangeNotif(...)
      returns (FrequentFlyerNumberOrderChangeNotifResponse);
}
```

### ScheduleChangeApi (called by other services)

Used by flights-exchange and flights-servicing-eligibility to check SKCH status:
- `findScheduleChange(itineraryId)` → returns `Option[ScheduleChange]` with `userAction` state

## Key Source File Locations

| Purpose | Path |
|---------|------|
| Main gRPC server | `server/src/main/scala/.../FlightsScheduleChangeServer.scala` |
| Webhook server | `webhook-server/src/main/scala/.../WebhookServer.scala` |
| SKCH Machine | `machine/src/main/scala/.../schedulechange/ScheduleChangeMachine.scala` |
| Action Machine | `machine/src/main/scala/.../schedulechange/ScheduleChangeActionMachine.scala` |
| User Outreach | `machine/src/main/scala/.../useroutreach/UserOutreachMachine.scala` |
| Evaluation | `machine/src/main/scala/.../schedulechange/EvaluationMachine.scala` |
| Feature flags | `core/src/main/scala/com/hopper/core/FeatureFlagService.scala` |
| Core config | `core/src/main/scala/com/hopper/core/config/CoreConfig.scala` |
| Spanner store | `server/src/main/scala/.../store/db/ScheduleChangeStore.scala` |
| Tenant configs | `core/src/main/resources/tenants/{tenant-id}/{env}.conf` |

## Configuration

### Environment Configs

```
core/src/main/resources/
├── development.conf, staging.conf, production.conf
└── tenants/
    └── {tenant-id}/{development,staging,production}.conf
```

### Orange (State Machine) Configuration

- Spanner-backed session persistence
- BigQuery export via spanner-extract pipelines
- Dashboard: `dashboard-nopii.portal.hopper.com`
