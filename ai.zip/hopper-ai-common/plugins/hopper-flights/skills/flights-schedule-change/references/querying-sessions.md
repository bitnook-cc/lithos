# Querying Schedule Change Sessions in BigQuery

## BigQuery Table

Session history for the schedule change machine is stored in:

```
gcp-hopper-etldata-production.orange_air_schedule_change_air_schedule_change_private.session_history_history
```

For staging/development, replace `production` with `staging` or `development` in the GCP project name.

## Key Columns

| Column | Type | Description |
|--------|------|-------------|
| `session_id` | BYTES | Session UUID (needs decoding) |
| `state_id` | STRING | Step code (e.g., `ix`, `mrn`, `tpi`, `cnde`, `done!`) |
| `state_output` | BYTES | Step output JSON (needs `safe_convert_bytes_to_string()`) |
| `__timestamp` | TIMESTAMP | When the state was recorded |

- Use `safe_convert_bytes_to_string(state_output)` to convert output bytes to JSON text.
- Use `json_value()` or `json_query()` to extract fields from the resulting JSON.

## UUID Decoding Helper

`session_id` is stored as BYTES. Use this temp function to decode it to a readable UUID string:

```sql
CREATE TEMP FUNCTION DECODE_UUID(x BYTES)
RETURNS STRING
AS (
  CONCAT(
    SUBSTR(TO_HEX(x), 0, 8), '-',
    SUBSTR(TO_HEX(x), 9, 4), '-',
    SUBSTR(TO_HEX(x), 13, 4), '-',
    SUBSTR(TO_HEX(x), 17, 4), '-',
    SUBSTR(TO_HEX(x), 21)
  )
);
```

Include this at the top of any query that selects `session_id`.

## Common Step IDs

| Step ID | Name | Description |
|---------|------|-------------|
| `ix` | Start context | Contains request, provider, locator |
| `mrn` | Maybe rewrite NDCx | NDCx rewrite detection and handling |
| `tpi` | API prospective itinerary | Fetches prospective itinerary from provider |
| `cnde` | Check NDCx evaluation | NDCx-specific evaluation logic |
| `cndm` | Check NDCx minor SKCH experiment | NDCx minor schedule change experiment |
| `ds` | Determine severity | Severity classification |
| `done!` | Final state | Contains Result (Ok/Fail) and errors |

## Example Queries

### Find NDCx rewrite sessions

```sql
SELECT
  DECODE_UUID(session_id) as session_id,
  state_id,
  safe_convert_bytes_to_string(state_output) as output
FROM `gcp-hopper-etldata-production.orange_air_schedule_change_air_schedule_change_private.session_history_history`
WHERE
  DATE(__timestamp) = '2026-03-31'
  AND state_id = 'mrn'
  AND CONTAINS_SUBSTR(
    safe_convert_bytes_to_string(state_output),
    '"isNdcxRewrite":true'
  )
```

### Find Amadeus-sourced sessions

```sql
SELECT
  DECODE_UUID(session_id) as session_id,
  state_id,
  json_value(safe_convert_bytes_to_string(state_output), '$.value.request.from.provider.QueuesAndRemarksApiProvider') as provider
FROM `gcp-hopper-etldata-production.orange_air_schedule_change_air_schedule_change_private.session_history_history`
WHERE
  DATE(__timestamp) = '2026-03-31'
  AND state_id = 'ix'
  AND json_value(safe_convert_bytes_to_string(state_output), '$.value.request.from.provider.QueuesAndRemarksApiProvider') = 'Amadeus'
```

### Find sessions by end state/result

```sql
SELECT
  DECODE_UUID(session_id) as session_id,
  json_value(safe_convert_bytes_to_string(state_output), '$.Result') as result
FROM `gcp-hopper-etldata-production.orange_air_schedule_change_air_schedule_change_private.session_history_history`
WHERE
  DATE(__timestamp) BETWEEN '2026-03-30' AND '2026-03-31'
  AND state_id = 'done!'
```

### Join multiple steps using INTERSECT DISTINCT

Find sessions that started from Amadeus and ended in failure:

```sql
SELECT session_id
FROM `gcp-hopper-etldata-production.orange_air_schedule_change_air_schedule_change_private.session_history_history`
WHERE
  DATE(__timestamp) BETWEEN '2026-03-30' AND '2026-03-31'
  AND state_id = 'ix'
  AND json_value(safe_convert_bytes_to_string(state_output), '$.value.request.from.provider.QueuesAndRemarksApiProvider') = 'Amadeus'

INTERSECT DISTINCT

SELECT session_id
FROM `gcp-hopper-etldata-production.orange_air_schedule_change_air_schedule_change_private.session_history_history`
WHERE
  DATE(__timestamp) BETWEEN '2026-03-30' AND '2026-03-31'
  AND state_id = 'done!'
  AND json_value(safe_convert_bytes_to_string(state_output), '$.Result') = '"Fail"'
```

## Dashboard

Sessions can also be browsed in the Dashboard UI at `dashboard-nopii.portal.hopper.com` under the Schedule Change section. The Dashboard supports JMES-path style queries for filtering session data.

## Confluence

For more details, see: [Analyze state machine sessions](https://hopper-jira.atlassian.net/wiki/spaces/AirServices/pages/6478364689/Analyze+state+machine+sessions)
