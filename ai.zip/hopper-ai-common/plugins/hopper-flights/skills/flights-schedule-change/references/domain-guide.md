# Domain & Provider Guide

## Schedule Changes vs. Exchanges

Schedule changes are always **involuntary** — initiated by the airline. Customer-initiated modifications are called **exchanges** and are a completely separate flow.

### Schedule Changes (Involuntary, Airline-Initiated)

- Airline changes flight times, numbers, equipment, routing, or cancels flights
- Detected via GDS queue monitoring or NDC OrderChangeNotification webhooks
- User gets accept/deny options with a configurable deadline
- Ticket reissuance is an **even exchange** — no change fees, uses airline waiver code
- DOT rules require refunding associated products for involuntary cancellations

### Exchanges (Voluntary, Customer-Initiated)

- Customer requests date/route/time changes
- May incur change fees and fare differences
- Processed through `flights-exchange` service
- Exchange eligibility determined by `flights-servicing-eligibility`

### Edge Case: Exchange Appearing as SKCH

When a passenger contacts the airline directly and makes an exchange, this can appear in GDS queues looking like a schedule change. The system detects this by comparing segments to coupons — if they match, no action needed.

## Severity Rules

Classification is handled by the **EvaluationMachine** — see `EvaluationMachine.scala` for the current rule set and thresholds. The rules evaluate:

- **Time changes** — departure/arrival deltas against configurable thresholds
- **Connection validity** — MCT/VCT checks for misconnections
- **Cancellations** — HX segments
- **Routing changes** — nonstop to connecting, airport changes
- **Reprotection** — whether airline provided a valid alternative itinerary

Per-airline overrides may apply — check the EvaluationMachine code for current thresholds.

**Key principle:** Stored severity Major is never downgraded.

### Segment Statuses

| Status | Meaning |
|--------|---------|
| HK | Confirmed (normal) |
| TK | Schedule change pending acknowledgment |
| SC | Schedule change applied |
| HX | Cancelled by airline |

## Reprotection

**Reprotection** = airline provides a prospective itinerary with new flight segments to replace changed ones.

**Validation criteria:**
- All impacted segments must have equivalents with TK or SC status
- One segment can become two (or vice versa) for the same leg
- Affected segments must have coupon status OPEN
- Prospective itinerary must be "continuous" (no gaps/ARNK issues)

## Eligibility Interaction

### flights-servicing-eligibility (FSE)

The primary gating service for exchange and cancellation. **Critical SKCH interaction:**

- **Active schedule change (`UserAction.Waiting`)** → `INELIGIBLE_PENDING_SCHEDULE_CHANGE`
- Exchange blocked until user accepts or denies
- Cancellation eligibility delegates to provider services (Southlake, Madrid, etc.)

### flights-exchange

Checks `ScheduleChangeApi.findScheduleChange()` before allowing exchange:
- ANY non-accepted schedule change → FAIL with `InexchangeableTicketScheduleChangePending`
- `UserAction.Accept` allows; `UserAction.Waiting` blocks

### flights-cancellation

Triggered post-SKCH in several scenarios:
- User denies major SKCH and wants refund → cancel flow
- Major SKCH during fare optimization → booking cancelled

## Provider-Specific Handling

### Sabre (GDS)

- **Detection:** Brooklyn polls GDS queues per PCC
- **Operations:** Queue/remark operations, VCT command for MCT validation, ETR commands for reissuance
- **Waiver code** placed in endorsement field, waiver box, OSI, tour code

### Amadeus (GDS)

- **Detection:** Brooklyn polls GDS queues
- **Reissue:** ATC reissue for involuntary exchanges, requires Amadeus certification

### FarelogixNDC

- **Detection:** OCN webhooks received by webhook server
- **Notes:** Waiver code may not be required (populated in OrderReshop response)

### AmadeusNdcx

- Partial automation, OCN-based for some carriers
- Carrier-specific exchange flows vary — check code for current behavior

### Travelfusion

- Limited automation — check London service for current API support

### Multi-Provider (Hacker Fares, Virtual Interlining)

- Each slice may have a different provider
- Provider determination must check per-locator, not top-level booking plan
- Conflicts between slices need special evaluation

## Waiver Codes

All GDS schedule change reissuances need a waiver code for the even exchange. The waiver code is placed in endorsement field, waiver box, OSI, and tour code.

Waiver codes are managed via the `waiverCodeConfiguration` module and a Retool app. Check the module for current configuration details.

**Common failure modes:**
- Expired waiver codes → reissue failure
- Missing waiver code for airline → manual reissue needed
- Wrong waiver code format → GDS rejection

## Fare Optimization Integration

When a booking is in **pre-ticketing fare optimization** and a SKCH occurs:

| SKCH Severity | Action |
|--------------|--------|
| Minor | Accept schedule change, continue optimization |
| Major | Cancel booking |

## DOT Compliance

All major schedule changes follow DOT rules:
- User must be notified with accept/decline options
- Configurable deadline for user response
- Auto-accept if no response
- Involuntary cancellations require refunding associated products

## Notification Channels

| Channel | Use Case |
|---------|----------|
| Push notification | Initial/follow-up for major SKCH |
| Email (MOD) | Itinerary modification confirmations via PTM |
| Email (SKCH-specific) | Accept/deny CTA emails via UserOutreach |
| Kustomer conversation | Agent escalation for failures |
