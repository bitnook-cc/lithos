# Kustomer Messages

## Overview

When schedule change automation fails or requires manual intervention, the system creates a **Kustomer conversation** to alert CS (Customer Support) agents. Each conversation contains a title and body describing the issue, booking details, and action required.

**Reference:** [Copy spreadsheet](https://docs.google.com/spreadsheets/d/15dFPJuI3cUN6iyndaJvygCROMZfz_BcY0DF3rs72l3g/edit?gid=0#gid=0) — source of truth for message copy, Guru link requirements, and funnel types

## End-to-End Flow

```
State machine step fails or detects manual-review condition
  → ExternalNotification triggered
    → ErrorHandlingSteps checks feature flags (useInternalFlowOnly)
      → KustomerClient.createKustomerConversation()
        → Reads template file, replaces {{variables}}
          → Appends CX Dashboard link (if user ID known)
            → Determines funnel type (GDS/NDC × urgent/standard)
              → Calls Kremlin (gRPC) to create agent notification
                → CS agent sees conversation in Kustomer
```

Not all `ExternalNotification` types create Kustomer conversations — some only send emails or queue remarks. Check `ExternalNotification.scala` for the full mapping.

The `user_denied_skch` template is a special case: it is triggered from `ScheduleChangeService` when a user denies a major schedule change, not from `ExternalNotification`.

## Template System

### Format

Templates are plain text files. The first line is the title (prefixed with `title=`), the rest is the message body (supports Markdown).

```
title=Schedule change accept error for {{pnr}} - review required

Error description and agent instructions here.

PNR: {{pnr}}
Provider: {{provider}}
Tenant: {{tenant}}
```

### Variable Replacement

`KustomerClient.replace()` performs standard variable substitution on both title and body:

| Variable | Description | Default if missing |
|----------|-------------|--------------------|
| `{{pnr}}` | PNR locator (e.g., `M-ABC123`) | — |
| `{{booking_locator}}` | Booking-level locator (e.g., `H-*` for multi-provider) | — |
| `{{provider}}` | Provider name from locator (Amadeus, Sabre, etc.) | — |
| `{{tenant}}` | Tenant ID (hopper-app, capone, etc.) | — |
| `{{issuing_carrier_codes}}` | Comma-separated airline codes | `n/a` |
| `{{first_departure_timestamp}}` | First segment departure time | `n/a` |
| `{{guru_link}}` | Guru knowledge base card URL (from HOCON config) | — |

Templates can also use custom placeholders via `additionalReplacements: Map[String, String]`. For example, `user_denied_skch.txt` uses `{{remarks}}` to inject GDS denial remarks.

### CX Dashboard Link

When the user ID is known and an itinerary ID is available, a dashboard link is automatically appended to the message body:

```
Dashboard Link: https://cx-dashboard.portal.hopper.com/tenant/{tenant}/user/{userId}/flight/{itineraryId}
```

## Funnel Routing

Kustomer conversations are routed to agent queues (funnels) based on provider type and urgency:

| Funnel | Provider | Urgency |
|--------|----------|---------|
| `gds_task_skch` | GDS (Sabre, Travelport) | > 14 days to departure |
| `gds_task_skch_urgent` | GDS | ≤ 14 days or forceUrgent |
| `ndc_task_skch` | NDC (FarelogixNdc, Facade) | > 14 days to departure |
| `ndc_task_skch_urgent` | NDC | ≤ 14 days or forceUrgent |

Some notification types force the urgent funnel regardless of departure date (e.g., `AcceptSkchError`, `AnomalyError`, `LocatorLookupError`). See `ExternalNotification.scala` for which types set `forceUrgentFunnel = true`.

## Guru Links

Some templates include a `{{guru_link}}` placeholder that resolves to a Guru knowledge base card URL, giving CS agents direct access to the relevant SOP. The URL is configured in HOCON (`skchGuruCardLink` in `base.conf`) and can be overridden per environment since different realms may use different Guru cards. To add a Guru link to a template, append `Please see GURU CARD: {{guru_link}}` — no code changes needed.
