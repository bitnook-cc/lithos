# Operations Guide

## Monitoring

### Dashboards

- **Dashboard (no PII):** `dashboard-nopii.portal.hopper.com` — view SKCH sessions, locator queues, secure logs
- **Datadog:** `us5.datadoghq.com` — service metrics, traces, logs
- **Amplitude:** SKCH-related event tracking and user flows

### What to Monitor

| Check | What to look for |
|-------|-----------------|
| PNRs sent to Kustomer | Volume spikes, new error patterns |
| Reissues (major + minor) | Successful count via dashboard-nopii |
| Reissue failures | Any failures requiring manual intervention |
| Split/manual PNRs | Locator lookup failures |
| IRROP cases | Flights within 72hrs needing urgent handling |
| Exchange-as-SKCH detection | Passenger exchanges appearing as SKCHs |
| Partial reissue failures | Multi-ticket PNRs where only some tickets reissued |

### Key Slack Channels

| Channel | Purpose |
|---------|---------|
| `#flights-travel-agency` | General discussion, incidents |
| `#flights-travel-agency-servicing-alerts` | Automated SKCH reissue/major alerts with ops review |
| `#flights-travel-agency-product-ops` | Product/ops SKCH rules and policies |

## Common Failure Patterns

### GDS Reissue Failures

| Error pattern | Likely cause | Approach |
|---------------|-------------|----------|
| Session not initialized | Sabre session issue | Retry with fresh session |
| Segment select error | Ticket exchange segment mapping | Check segment mapping logic |
| Simultaneous PNR modification | Two processes modifying PNR at once | Retry; common with some airlines |
| Printer not assigned | Sabre printer config, or DTY lost after PCC emulation | Check PCC printer config in Darmstadt; verify ContextChange includes ChangeDuty after ChangeAAA emulation |

### Multi-Provider Edge Cases

Multi-provider bookings (hacker fares, virtual interlining) are a recurring source of issues. Common problems:
- Provider determination using top-level booking plan instead of per-locator
- Conflicts between slices requiring special evaluation
- NDC bookings misrouted as GDS

### Queue Loops

A PNR can get stuck in an automation cycle if SKCH machine operations (like adding remarks) cause the PNR to re-enter a monitored queue. Symptoms: single PNR generating many session requests. Resolution typically involves fixing the root cause (queue config, remark behavior) and letting exponential backoff drain the queue.

## Debugging Playbook

### Investigating a Schedule Change Issue

1. **Find the PNR** — Search `dashboard-nopii.portal.hopper.com` for the PNR/locator
2. **Check session state** — Find the SKCH machine session, inspect step results
3. **Check severity** — Look at EvaluationMachine output for classification result
4. **Check provider** — Verify correct provider was detected (especially for multi-provider)
5. **Check tenant config** — Verify tenant-specific settings in `core/src/main/resources/tenants/`
6. **Check feature flags** — Verify relevant flags are enabled for the tenant
7. **Check eligibility** — Look at FSE reports for the locator
8. **Check Kustomer** — See if a conversation was created for agent review

### Datadog Queries

```
service:flights-schedule-change @pnr:<PNR_VALUE>
service:flights-schedule-change-webhook-server @error
service:flights-servicing-eligibility @locator:<LOCATOR>
```

### Testing Schedule Changes

1. Create test booking in staging
2. Simulate schedule change via GDS (Sabre: queue placement; NDC: test OCN webhook)
3. Monitor SKCH machine session in dashboard
4. Verify severity classification
5. Verify user notification (if major)
6. Verify ticket reissuance (if applicable)
7. Verify eligibility blocking while waiting
