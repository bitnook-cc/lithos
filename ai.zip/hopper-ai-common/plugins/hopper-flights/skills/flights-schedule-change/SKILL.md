---
name: flights-schedule-change
description: >-
  Flights schedule change (SKCH) engineering at Hopper. Use when working on schedule
  change detection, severity evaluation, ticket reissuance, user notifications,
  exchange/cancellation eligibility, or any post-booking involuntary change handling
  across the flights-schedule-change service and related repos. Also triggers when
  SKCH-related Jira tickets mention Kustomer messages, Guru links, or CS agent
  notifications in the schedule change context.
---

# Flights Schedule Change Skill

## What Is a Schedule Change?

A **schedule change (SKCH)** is an itinerary modification initiated by an airline — flight time changes, cancellations, equipment swaps, carrier changes, or routing changes. Schedule changes are always **involuntary** (airline-initiated). Customer-initiated modifications are called **exchanges**, not schedule changes.

| | Schedule Change (SKCH) | Exchange |
|---|---|---|
| **Initiated by** | Airline (involuntary) | Customer (voluntary) |
| **Service** | `flights-schedule-change` | `flights-exchange` |
| **Ticket exchange type** | Even exchange (no fees, waiver code) | May incur change fees + fare difference |
| **User action** | Accept/deny new itinerary | Choose new flights |

**Edge case:** A passenger may contact the airline directly and make an exchange, which then appears in GDS queues looking like a schedule change. The system detects this by comparing segments to coupons — if they match, no action is taken.

## Service Ecosystem

Schedule changes span multiple services. The primary service is `flights-schedule-change`, but understanding the broader ecosystem is essential:

| Service | Role in SKCH |
|---------|-------------|
| **flights-schedule-change** | Core SKCH detection, evaluation, acceptance, reissuance |
| **flights-servicing-eligibility** | Gates exchange/cancel — blocks when SKCH pending |
| **flights-exchange** | Executes voluntary exchanges; checks for pending SKCH first |
| **flights-cancellation** | Cancellation when SKCH makes trip unacceptable |
| **Brooklyn** | GDS queue polling (LocatorQueueServices), PostTicketingMachine (PTM) |
| **Darmstadt** | PCC config, queue configs |
| **Southlake / Madrid** | Sabre / Amadeus GDS integration |
| **flights-provider-facade** | NDC provider abstraction |
| **flights-itineraries** | Itinerary retrieval |
| **Mumbai** | Customer messaging (SMS/push/email) |

## Module Structure (flights-schedule-change)

```
flights-schedule-change/
├── core/          # Shared config, LaunchDarkly flags, clients
├── server/        # gRPC API server, Spanner persistence
├── server-proto/  # Protobuf definitions
├── machine/       # State machines (executors + schedulers)
├── webhook-server/# HTTP server for NDC OrderChangeNotifications
└── waiverCodeConfiguration/  # Waiver code management
```

## State Machines

The service uses Hopper's [state machine framework](../state-machines/SKILL.md) with three primary machines:

### ScheduleChangeMachine (main orchestrator)
Detects and processes schedule changes. Contains composed sub-machines:
- **ScheduleChangeCouponsMachine** — retrieves tickets/coupons from providers
- **EvaluationMachine** — severity classification (see `EvaluationMachine.scala` for current rules)
- **ScheduleChangeCreateOrUpdateMachine** — persists SKCH to DB
- **AcceptScheduleChangeMachine** — auto-accepts minor changes via provider API

### ScheduleChangeActionMachine
Processes user accept/deny actions on major schedule changes. Validates PNR, retrieves itinerary, executes action (reissue tickets on accept, route to CS on deny).

### UserOutreachMachine
Manages customer notifications for major changes. Sends initial notification, follow-ups at configurable intervals. Auto-accepts if user doesn't respond within deadline (DOT compliance).

**Source:** `machine/src/main/scala/com/hopper/flights_schedule_change/executor/`

## Severity Classification

| Severity | Handling |
|----------|----------|
| **Minor** | Auto-accepted, ticket reissued if needed |
| **Major** | User notified with accept/deny window |

Classification is handled by the **EvaluationMachine**. See `EvaluationMachine.scala` for the current rule set. Key principles:
- Stored severity Major is never downgraded
- Per-airline overrides may apply (check the code for current thresholds)
- Rules evaluate segment differences: time deltas, flight number changes, carrier changes, airport changes, connection validity, cancellations, reprotection availability

## End-to-End Processing Flow

1. **Detection** — Brooklyn monitors GDS queues / NDC webhook receives OrderChangeNotification
2. **Retrieval** — Fetch current vs. prospective itinerary from provider
3. **Special case routing** (before severity evaluation) — various edge cases are routed differently (unusable coupons, all-cancelled segments, ticketless carriers, manually created PNRs, multi-provider bookings, IRROP, fare optimization). See `ScheduleChangeMachine.scala` for current routing logic.
4. **Evaluation** — EvaluationMachine runs classification
5. **Routing by severity**:
   - Minor → auto-accept → reissue if needed → PTM → MOD email
   - Major → UserOutreachMachine → user accept/deny → ScheduleChangeActionMachine
6. **Reissuance** — Even exchange with airline waiver codes (no fees)
7. **Post-action** — PTM updates itinerary, sends confirmation emails

### Eligibility Blocking

When a SKCH is pending (`UserAction.Waiting`), `flights-servicing-eligibility` blocks all exchanges with `INELIGIBLE_PENDING_SCHEDULE_CHANGE`. Exchanges are only unblocked after the user accepts or denies the schedule change.

## Waiver Code & OSI Configuration

When a schedule change is accepted and tickets are reissued, the system sends **OSI messages** and applies **waiver codes, endorsements, and tour codes** to the PNR.

- **Global OSI**: Fixed messages hardcoded in `ScheduleChangeMachineModels.WaiverCodeOutcome.globalOsiMessages`, sent on every reissue regardless of carrier.
- **Carrier-specific config**: Per-airline OSI, endorsement, tour code, and waiver code managed via **Retool UI** and stored in Hopper's **config-store**. Read by the `waiverCodeConfiguration` module at runtime. Config can apply to all providers or be scoped to specific providers (Sabre, Amadeus, etc.).

### How Config Is Applied

- **OSI messages** (global + carrier-specific): `flights-schedule-change` merges them and sends via a separate state machine step to the provider's `/osiMessages` endpoint (Southlake for Sabre, Madrid for Amadeus). Enabled per-provider via a flag in `AcceptSteps.sendOsiMessage()`.
- **Endorsement, tour code, waiver code**: passed from `flights-schedule-change` to the provider inside the `involuntaryReissue` request (`GdsTicketingInfo` fields), applied by Southlake/Madrid during the reissue session.

## Build & Test

```bash
# All tests
sbt '+Test / test; +IntegrationTest / test'

# Module-specific tests
sbt 'flights-schedule-change-core/test'
sbt 'flights-schedule-change-machine/test'
sbt 'flights-schedule-change-server/test'

# Format code
sbt scalafmtAll
```

Also use the `scala` and `state-machines` skills when working in this repo.

## Feature Flags

Feature flags in this service are transient — they gate rollouts of new behavior and are removed once confirmed stable. Check `core/src/main/scala/com/hopper/core/FeatureFlagService.scala` for the current set of flags and their usage. Use the `launchdarkly-flag-*` skills for flag operations.

## Database

**Cloud Spanner** (hillvalley instance):
- Table: `schedule_changes` (id, tenant, user_id, schedule_change JSON, timestamps)
- Soft deletes via `deleted_at`

## Testing Patterns

- **Specs2** test framework with `*Spec.scala` naming
- **SpannerFixtures** for DB integration tests
- Mock providers for GDS integrations
- **InMemoryRunner** for state machine unit tests
- **MachineTester** base class for machine tests

## Tenant Configuration

Per-tenant configs in `core/src/main/resources/tenants/{tenant-id}/{env}.conf`. Each contains queue configuration, PCC overrides, NDC settings, and provider-specific config. Check the `tenants/` directory for the current list.

## Terminology

| Term | Meaning |
|------|---------|
| SKCH | Schedule Change |
| PNR | Passenger Name Record (booking) |
| GDS | Global Distribution System (Sabre, Amadeus) |
| NDC | New Distribution Capability |
| OCN | Order Change Notification (NDC) |
| HK/TK/SC/HX | Segment statuses: confirmed / change pending / change applied / cancelled |
| ETR | Electronic Ticket Record |
| FTC | Future Travel Credit |
| IRROP | Irregular Operations (within 72hrs of departure) |
| PTM | Post-Ticketing Machine (in Brooklyn) |
| Even exchange | Ticket reissue with no fees (uses waiver code) |
| Reprotection | Airline-provided prospective itinerary for changed flights |
| FSE | flights-servicing-eligibility |

## Additional References

- [Architecture & Data Models](references/architecture.md) — state machines, data models, service integration, APIs
- [Operations Guide](references/operations.md) — monitoring, debugging playbook, common failure patterns
- [Domain & Provider Guide](references/domain-guide.md) — business rules, provider-specific handling, eligibility
- [Querying Sessions](references/querying-sessions.md) — BigQuery queries for schedule change state machine session data
- [Kustomer Messages](references/kustomer-messages.md) — CS agent notification templates, variable replacement, funnel routing, Guru links
