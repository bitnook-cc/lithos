---
name: building-dashboard-jmes-queries
description: >-
  Use when querying state machine sessions in production but BigQuery is blocked
  by PII restrictions, or when translating a staging BigQuery exploration into a
  Dashboard JMESPath query for production. Covers facade, Southlake, Madrid, London.
  Triggers: "query production sessions", "JMES query", "Dashboard JMES",
  "translate BQ to JMES", "production BQ access denied", "no BQ permission on
  production state machine tables".
---

# Building Dashboard JMES Queries

## Why and when

Production state machine session tables contain PII. AI tooling cannot query them via `bq` (Access Denied). The Dashboard exposes the same data through a JMESPath interface that filters server-side — use `dashboard-nopii.portal.hopper.com`, where PII is redacted but search runs against full data.

This skill does ONE thing: translates a working staging BQ query into a Dashboard JMES query + URL params. Workflow:

1. Develop the query in staging BQ (use `read-provider-state-machine-sessions`)
2. Verify JSON paths against real staging outputs (see "Critical" below)
3. Translate to JMES + URL params using the table below
4. Run on `dashboard-nopii.portal.hopper.com`

JMES is opaque — you cannot iterate on field paths interactively. Get the SQL working in staging first.

## Quick reference: BQ → Dashboard

| BigQuery filter | Dashboard equivalent |
|---|---|
| `state_id = 'foo'` (any session containing this step) | `state=foo` URL param |
| `state_id = 'foo' AND success = FALSE` (failure-only) | `state=foo` + JMES `foo.Result == 'Fail'` |
| `state_id IN ('a','b')` (must contain BOTH) | `state=a&state=b` (Orange enforces `COUNT(DISTINCT state_id) = N`) |
| `LIKE '%X%'` against `state_output` for state `s` | `s.value.path.to.field == 'X'` |
| Time window | `from=YYYY-MM-DDTHH:MM-0500&to=...` |
| Result projection | Trailing JMES expression (e.g. `&& [occ, ocf]`) |

`queryFields=s1&queryFields=s2&...` is **required for every state your JMES references**. Orange concatenates only those state outputs into the JSON the JMESPath runs against — references to a state not in `queryFields` always evaluate to null.

## State output shape

Same in BQ and Dashboard: `{"Result": "Ok"|"Fail", "value": {...} | "errors": [...]}`. So `step.Result == 'Fail'`, `step.errors[0].error.code`, `step.value.foo` all work.

## Critical: verify JSON path nesting before publishing

The single biggest failure mode is assuming a field is at `value.X` when it is actually `value.Y.X`. Substring presence in `state_output` does NOT prove direct-child nesting.

Before publishing a JMES path, **either**:

1. Open a known matching session in the Dashboard and read the raw JSON of the relevant step, **or**
2. Sample the bytes preceding the field in staging BQ and count closing braces (`},"X":` = direct sibling, `}},"X":` = one level shallower). The reference file has the exact SQL.

For the facade BookingMachine `prq` step specifically:
- `prq.value.bookingPlan.api.{QueuelessApiProvider, supplier, pcc}` — provider info is nested under `bookingPlan`
- `prq.value.trip.{source, validatingCarrierCode, slices}` — trip data is direct under `value`

Older Confluence examples (`plan.value.api.QueuelessApiProvider`) used a flatter `plan` step. Do not transplant paths between step IDs without re-verifying.

## Canonical sources

- [Confluence: Dashboard queries](https://hopper-jira.atlassian.net/wiki/spaces/AIRDOCS/pages/5232558369/Dashboard+queries) — Hopper-flavored Dashboard search docs, URL examples
- [`MachineBackingStoreBQ.scala`](https://github.com/hopper-org/Orange/blob/master/orange-zest/src/main/scala/com/hopper/orange/bigquery/MachineBackingStoreBQ.scala) in `hopper-org/Orange` — the source of truth for how URL params + JMES compile to BigQuery. Read the `search()` method when behavior is unclear
- [JMESPath specification](https://jmespath.org/specification.html) — language grammar and truthiness rules

## See also

- [references/jmes-and-dashboard-reference.md](references/jmes-and-dashboard-reference.md) — Hopper operational notes: URL param table, step-by-step build, worked LATAM example, common mistakes
- `hopper-flights:read-provider-state-machine-sessions` — staging BQ exploration. Use BEFORE this skill
- `hopper-developer:state-machine-debugging` — generic CLI (`state-machine.py`) for any client machine. Complementary, not a replacement
