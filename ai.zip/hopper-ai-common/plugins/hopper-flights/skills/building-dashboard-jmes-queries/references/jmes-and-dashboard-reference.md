# JMES + Dashboard URL Reference

## Canonical sources

For language and translation behavior, go to the source — do not work from this file's interpretation:

- [JMESPath specification](https://jmespath.org/specification.html) — JMES grammar, operators, truthiness rules
- [Confluence: Dashboard queries](https://hopper-jira.atlassian.net/wiki/spaces/AIRDOCS/pages/5232558369/Dashboard+queries) — Hopper-flavored Dashboard search docs and worked URL examples
- [`MachineBackingStoreBQ.scala`](https://github.com/hopper-org/Orange/blob/master/orange-zest/src/main/scala/com/hopper/orange/bigquery/MachineBackingStoreBQ.scala) (`hopper-org/Orange`) — the source of truth for how URL params + JMES compile to BigQuery. Read the `search()` method when behavior is unclear.

The rest of this file is Hopper-specific operational notes and a worked example.

## Dashboard hosts

| Host | Use |
|---|---|
| `dashboard.portal.hopper.com` | Full PII, requires elevated access |
| `dashboard-nopii.portal.hopper.com` | Default for AI/automation; results redacted but search runs against full data |

## Machine paths

For facade machine paths (`/#/facadeBookings`, `/#/facadeCancelBooking`, etc.) see `read-provider-state-machine-sessions`. Generic pattern: `https://<host>/#/<sessionType>`. The `sessionType` is the Trenton session type, not the BQ client_id — see `CLIENT_TRENTON` in `state-machine.py` from `hopper-developer:state-machine-debugging`.

## URL parameters

| Param | Meaning | Cardinality |
|---|---|---|
| `state` | Session must contain this state. Multiple → must contain all (Orange enforces `COUNT(DISTINCT state_id) = N`) | repeating |
| `excludeStates` | Session must NOT contain this state | repeating |
| `from`, `to` | Time window. ISO format with offset, e.g. `2026-05-07T00:00-0500` | single |
| `limit`, `offset` | Pagination. Keep limit small (≤25) for query-string searches | single |
| `queryFields` | States whose `state_output` JSON gets concatenated into the JMES context. **Required for every state your JMES references** | repeating |
| `queryString` | URL-encoded JMES expression. Filters rows server-side. Trailing expression is the projection ("Query Output") | single |

Read `MachineBackingStoreBQ.search()` for the exact SQL each param compiles to.

## Building a query: step-by-step

1. **Run the BQ query in staging** (use `read-provider-state-machine-sessions`). Capture matching session IDs and the literal JSON bytes around each filter point
2. **Identify which states each filter touches.** Every state referenced in JMES must be listed in `queryFields`
3. **Verify nesting depth for each path** (see "Critical: verify JSON path nesting" in SKILL.md). Do not skip
4. **Convert filters one by one.** `LIKE '%X%'` → `field == 'X'` or `contains(field, 'X')`. `success = FALSE` → `step.Result == 'Fail'` (and add `state=step` to require presence)
5. **Add a projection.** Trailing `&& [step1, step2]` or `&& {label: path}` returns data per matching session
6. **URL-encode and assemble.** Spaces → `%20`, `==` → `%3D%3D`, `&&` → `%26%26`, `[` → `%5B`, `,` → `%2C`, `]` → `%5D`. Single quotes stay literal (mirror Confluence examples)

## Worked example: facade BookingMachine — LATAM rollback failures

Goal: find production sessions where Order Change (`occ`) AND Order Rollback (`ocf`) both failed for LATAM bookings routed through `FacadeQueueless` / `LatamNdc`.

### Equivalent staging BQ

```sql
WITH
  matching_context AS (
    SELECT DISTINCT session_id
    FROM `gcp-hopper-etldata-staging.orange_shared_flights_facade_booking_private.session_history_history`
    WHERE ts > TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 7 DAY)
      AND CAST(state_output AS STRING) LIKE '%FacadeQueueless%'
      AND CAST(state_output AS STRING) LIKE '%LatamNdc%'
      AND CAST(state_output AS STRING) LIKE '%"validatingCarrierCode":"LA"%'
  ),
  occ_failures AS (
    SELECT session_id FROM `<same table>`
    WHERE ts > TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 7 DAY)
      AND state_id = 'occ' AND success = FALSE
  ),
  ocf_failures AS (
    SELECT session_id FROM `<same table>`
    WHERE ts > TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 7 DAY)
      AND state_id = 'ocf' AND success = FALSE
  )
SELECT session_id FROM matching_context
INNER JOIN occ_failures USING (session_id)
INNER JOIN ocf_failures USING (session_id)
```

### Path verification (against staging real data)

| Path I assumed | Path that actually works | Why |
|---|---|---|
| `prq.value.api.QueuelessApiProvider` | `prq.value.bookingPlan.api.QueuelessApiProvider` | `api` is nested under `bookingPlan`, not a direct child of `value`. Old `plan` step was flatter — don't transplant paths between step IDs |
| `prq.value.api.supplier` | `prq.value.bookingPlan.api.supplier` | same |
| `prq.value.trip.validatingCarrierCode` | (correct as-is) | `trip` IS a direct child of `value` |
| `prq.value.trip.validatingCarrier` | `prq.value.trip.validatingCarrierCode` | The field name is `validatingCarrierCode`, not `validatingCarrier`. Sample real data, don't guess |

### Final JMES

```
prq.value.bookingPlan.api.QueuelessApiProvider == 'FacadeQueueless'
&& prq.value.bookingPlan.api.supplier == 'LatamNdc'
&& prq.value.trip.validatingCarrierCode == 'LA'
&& occ.Result == 'Fail'
&& ocf.Result == 'Fail'
&& [occ, ocf]
```

### Final Dashboard URL

```
https://dashboard-nopii.portal.hopper.com/#/facadeBookings
  ?state=ocf&state=occ&state=prq
  &from=2026-05-07T00:00-0500&to=2026-05-14T23:59-0500
  &limit=10&offset=0
  &queryFields=prq&queryFields=occ&queryFields=ocf
  &queryString=<URL-encoded JMES from above>
```

(Newlines added for readability — the real URL is single-line.)

## Common mistakes

| Mistake | Symptom | Fix |
|---|---|---|
| State referenced in JMES but missing from `queryFields` | Always 0 results | Add it to `queryFields` |
| Path assumed flat without verification | 0 results despite known matches | Open a known session in Dashboard and read raw JSON, or sample bytes preceding the field name in BQ |
| `state=foo&state=bar` when only `foo` is required | 0 results when `bar` is rare/optional | Drop the `state=bar` and let JMES filter on `bar.Result == 'Fail'` instead |
| Wide time window + complex JMES | Slow / timeouts | Confluence warns query-string runs against every row. Start small, widen on demand |
| Using `dashboard.portal.hopper.com` without access | Auth failure | Use `dashboard-nopii.portal.hopper.com` |
| URL-encoding single quotes | Confluence examples leave `'` literal | Mirror existing examples — don't encode |

## Performance notes

- Dashboard query-string evaluation runs against every row in the time window. Start with the smallest window that covers the question
- Adding `state=foo` is cheap (filters before JMES). Adding more JMES filters is cheap relative to widening the time range
- Use `excludeStates=done!` to skip successfully-completed sessions when looking for failures
