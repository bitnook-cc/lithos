---
name: read-provider-state-machine-sessions
description: >-
  Investigate provider state machine sessions for booking, cancel, exchange,
  schedule change, seats, and fare optimization. Covers flights-provider-facade
  (NDC), Southlake (Sabre GDS), Madrid (Amadeus GDS), and London (Travelfusion).
  Use when debugging booking failures, querying BigQuery for session history,
  browsing Dashboard for step output, or tracing provider machine flows. Triggers:
  "booking session", "provider session", "state machine session", "BigQuery booking".
---

# Read Provider State Machine Sessions

## Services Overview

| Service | Provider Type | Examples |
|---------|--------------|----------|
| flights-provider-facade | NDC | Kiwi, Duffel, AirGateway |
| Southlake | GDS (Sabre) | Sabre BFM |
| Madrid | GDS (Amadeus) | Amadeus Shop |
| London | LCC | Travelfusion |

Each service runs state machines for booking flows. Every machine execution is a **session** with ordered **steps**, each producing a state output (JSON).

## Two Ways to Read Sessions

### 1. Dashboard (Web UI)

URL pattern: `https://dashboard-{env}.portal.hopper.com/{path}`

| Machine | Dashboard Path |
|---------|---------------|
| BookingMachine | `/#/facadeBookings` |
| CancelMachine | `/#/facadeCancelBooking` |
| ExchangeShoppingMachine | `/#/facadeExchangeShopping` |
| ExchangeBookingMachine | `/#/facadeExchangeBooking` |
| ScheduleChangeMachine | `/#/flightsNdcScheduleChange` |
| SeatsBookingMachine | `/#/facadeSeatsBooking` |
| FareOptimizationVoidMachine | `/#/flightsFacadeFareOptimizationVoid` |

Replace `{env}` with `development`, `staging`, or `production`.

**Using the Dashboard:**
1. Open the machine's Dashboard URL
2. Filter by state (e.g., `done!`, `brq`, `or`) or search by session ID
3. Click a session to view **State History** (step list) and **JSON** (step output)

### 2. BigQuery

Query the `session_history_history` table for any machine. Key columns:

| Column | Type | Description |
|--------|------|-------------|
| `session_id` | STRING | Machine session ID |
| `state_id` | STRING | Step abbreviation (e.g., `brq`, `done!`) |
| `state_output` | BYTES | JSON output (cast to STRING to read) |
| `success` | BOOL | Whether the step succeeded |
| `ts` | TIMESTAMP | When the step executed |

See [references/provider-machines.md](references/provider-machines.md) for full table paths per environment and service.

## Common BigQuery Queries

### Find all steps for a session
```sql
SELECT session_id, state_id, success,
       CAST(state_output AS STRING) AS output, ts
FROM `{table_path}`
WHERE session_id = '{session_id}'
ORDER BY ts
```

### Find the failing step in a session
```sql
SELECT session_id, state_id,
       CAST(state_output AS STRING) AS output, ts
FROM `{table_path}`
WHERE session_id = '{session_id}' AND success = FALSE
ORDER BY ts
```

### Find failed bookings by provider (last 24h)
```sql
SELECT session_id, state_id,
       CAST(state_output AS STRING) AS output, ts
FROM `{table_path}`
WHERE state_id = 'done!'
  AND success = FALSE
  AND ts > TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 24 HOUR)
  AND CAST(state_output AS STRING) LIKE '%{provider}%'
ORDER BY ts DESC
LIMIT 100
```

### Find successful bookings by provider (last 24h)
```sql
SELECT session_id, state_id,
       CAST(state_output AS STRING) AS output, ts
FROM `{table_path}`
WHERE state_id = 'done!'
  AND success = TRUE
  AND ts > TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 24 HOUR)
  AND CAST(state_output AS STRING) LIKE '%{provider}%'
ORDER BY ts DESC
LIMIT 100
```

### Find price increase failures
```sql
SELECT session_id, state_id,
       CAST(state_output AS STRING) AS output, ts
FROM `{table_path}`
WHERE state_id = 'vpi'
  AND success = FALSE
  AND ts > TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 24 HOUR)
ORDER BY ts DESC
```

### Find stuck ticketing sessions
```sql
SELECT session_id, state_id,
       CAST(state_output AS STRING) AS output, ts
FROM `{table_path}`
WHERE state_id IN ('or', 'trq')
  AND ts < TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 2 HOUR)
  AND session_id NOT IN (
    SELECT session_id FROM `{table_path}`
    WHERE state_id = 'done!'
  )
ORDER BY ts DESC
```

## State Output JSON Structure

All step outputs follow this pattern:

```json
// Success
{"Result": "Ok", "value": { ... }}

// Failure
{"Result": "Fail", "errors": [ ... ]}
```

## Debugging Checklist

1. **Get session ID** -- from logs, Dashboard, or BigQuery
2. **Check `done!` state** -- did the session complete? Was it successful?
3. **Find the failing step** -- query for `success = FALSE`
4. **Read the step output** -- cast `state_output` to STRING, check `errors` array
5. **Identify the phase** -- which phase failed? (Price/Book/Ticket/LongPoll for BookingMachine)
6. **Check retry behavior** -- did the machine retry? Look for repeated step IDs
7. **Cross-reference Datadog** -- use session ID to find related logs and traces

## Key Error Patterns

| Pattern | Meaning |
|---------|---------|
| `brq` state = `CancelCommand` | Booking timed out or was cancelled |
| `vpi` failed | Price increased beyond threshold |
| `occ` failed | Payment/order confirmation failed |
| `or` = `Unconfirmed` | Ticketing failed, PNR unconfirmed |
| `casr` failed `BagsNotConfirmed` | Ancillary bag confirmation failed |
| `ocf` or `ocal` present | Rollback/cancellation was triggered |
| `teqi`, `apl`, `stk` present | Session entered error queue processing |

## References

- [Provider machines, BigQuery tables, and provider-specific queries](references/provider-machines.md)
- [All machine step references](references/booking-machine-steps.md)
