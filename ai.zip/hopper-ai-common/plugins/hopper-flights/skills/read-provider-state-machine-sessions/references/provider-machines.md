# Provider Machines Reference

## BigQuery Table Paths

### Facade (NDC) -- Development

| Machine | Table Path |
|---------|-----------|
| BookingMachine | `gcp-hopper-etldata-development.orange_shared_flights_facade_booking_private.session_history_history` |
| CancelMachine | `gcp-hopper-etldata-development.orange_shared_flights_facade_cancel_private.session_history_history` |
| ExchangeShoppingMachine | `gcp-hopper-etldata-development.orange_shared_flights_facade_exch_shp_private.session_history_history` |
| ExchangeBookingMachine | `gcp-hopper-etldata-development.orange_shared_flights_facade_exchange_book_private.session_history_history` |
| ScheduleChangeMachine | `gcp-hopper-etldata-development.orange_shared_flights_facade_skch_private.session_history_history` |
| SeatsBookingMachine | `gcp-hopper-etldata-development.orange_shared_facade_seats_book_private.session_history_history` |
| FareOptimizationVoidMachine | `gcp-hopper-etldata-development.orange_shared_flights_facade_fo_void_private.session_history_history` |

For staging/production, replace `development` with `staging` or `production` in the GCP project name.

### Southlake (Sabre GDS) -- Staging

| Machine | Table Path |
|---------|-----------|
| BookingMachine | `gcp-hopper-etldata-staging.orange_shared_southlake_booking_private.session_history_history` |

### Madrid (Amadeus GDS) -- Staging

| Machine | Table Path |
|---------|-----------|
| BookingMachine | `gcp-hopper-etldata-staging.orange_shared_madrid_booking_private.session_history_history` |

### London (Travelfusion) -- Staging

| Machine | Table Path |
|---------|-----------|
| BookingMachine | `gcp-hopper-etldata-staging.orange_shared_london_booking_private.session_history_history` |

## Dashboard URLs

Base URL: `https://dashboard-{env}.portal.hopper.com`

| Machine | Path |
|---------|------|
| BookingMachine | `/#/facadeBookings` |
| CancelMachine | `/#/facadeCancelBooking` |
| ExchangeShoppingMachine | `/#/facadeExchangeShopping` |
| ExchangeBookingMachine | `/#/facadeExchangeBooking` |
| ScheduleChangeMachine | `/#/flightsNdcScheduleChange` |
| SeatsBookingMachine | `/#/facadeSeatsBooking` |
| FareOptimizationVoidMachine | `/#/flightsFacadeFareOptimizationVoid` |

## Provider-Specific Details

### Sabre (Southlake)

- **Provider field**: `"Sabre"`
- **Credential**: `pcc` (Pseudo City Code)
- **API provider type**: `QueuesAndRemarksApiProvider`
- **Trip source**: `SabreBFM`
- **Notable**: Uses structured booking remarks

### Amadeus (Madrid)

- **Provider field**: `"Amadeus"`
- **Credential**: `pcc` (Pseudo City Code)
- **API provider type**: `QueuesAndRemarksApiProvider`
- **Trip source**: `AmadeusShop`

### Travelfusion (London)

- **Provider field**: `"Travelfusion"`
- **Credential**: `supplier` (not pcc)
- **API provider type**: `QueuelessApiProvider`
- **Trip source**: `TravelfusionShop`
- **Notable**: `VoidAvailabilityRule = NotAvailable`; `FareBrand` is critical for pricing

## Provider-Specific BigQuery Queries

### Find sessions by provider (Facade)

```sql
SELECT session_id, state_id, success,
       CAST(state_output AS STRING) AS output, ts
FROM `gcp-hopper-etldata-{env}.orange_shared_flights_facade_booking_private.session_history_history`
WHERE state_id = 'done!'
  AND CAST(state_output AS STRING) LIKE '%"Sabre"%'
  AND ts > TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 24 HOUR)
ORDER BY ts DESC
```

Replace `"Sabre"` with `"Amadeus"` or `"Travelfusion"` as needed.

### Find Sabre sessions in Southlake directly

```sql
SELECT session_id, state_id, success,
       CAST(state_output AS STRING) AS output, ts
FROM `gcp-hopper-etldata-staging.orange_shared_southlake_booking_private.session_history_history`
WHERE state_id = 'done!'
  AND ts > TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 24 HOUR)
ORDER BY ts DESC
```

### Find Travelfusion fare brand issues

```sql
SELECT session_id, state_id,
       CAST(state_output AS STRING) AS output, ts
FROM `gcp-hopper-etldata-{env}.orange_shared_flights_facade_booking_private.session_history_history`
WHERE state_id IN ('prq', 'psts')
  AND success = FALSE
  AND CAST(state_output AS STRING) LIKE '%Travelfusion%'
  AND CAST(state_output AS STRING) LIKE '%FareBrand%'
  AND ts > TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 24 HOUR)
ORDER BY ts DESC
```

## Service Endpoints

| Service | Description |
|---------|-------------|
| flights-provider-facade | NDC provider orchestration (Kiwi, Duffel, AirGateway) |
| Southlake | Sabre GDS booking service |
| Madrid | Amadeus GDS booking service |
| London | Travelfusion LCC booking service |
