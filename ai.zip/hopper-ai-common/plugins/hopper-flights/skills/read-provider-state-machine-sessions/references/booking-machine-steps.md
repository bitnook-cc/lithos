# Machine Step References

## BookingMachine

### Phase 1: Price

| Step | Description |
|------|-------------|
| `prq` | Price request |
| `psts` | Price status |
| `cfid` | Confirm flight ID |
| `cie` | Check itinerary eligibility |
| `ex` | Exchange check |
| `ipro` | Identify provider |
| `pbbi` | Pre-book baggage info |
| `sbpd` | Set booking provider data |
| `pbsd` | Pre-book seat data |
| `sprr` | Set price result reference |
| `tp` | Transform price |
| `tpe` | Transform price enrichment |
| `isce` | Is schedule change eligible |

### Phase 2: Book

| Step | Description |
|------|-------------|
| `brq` | Book request |
| `bsts` | Book status |
| `guss` | Get user session state |
| `grr` | Get reservation reference |
| `pbbiebas` | Pre-book baggage info enriched before ancillary selection |
| `oc` | Order create |
| `ar` | Add remarks |
| `tuf` | Transform user fare |
| `turn` | Transform user reference number |
| `vpi` | Validate price increase |
| `wnv` | Wait for name validation |
| `vas` | Validate ancillary selection |
| `vafs` | Validate ancillary fulfillment status |
| `casr` | Confirm ancillary selection result |
| `occ` | Order confirmation / payment |
| `ocf` | Order confirmation failure (rollback) |
| `tb` | Transform booking |
| `tbe` | Transform booking enrichment |

### Phase 3: Ticket

| Step | Description |
|------|-------------|
| `trq` | Ticket request |
| `tsts` | Ticket status |
| `or` | Order retrieve (check ticketing) |
| `cbtsr` | Check booking ticket status result |
| `tt` | Transform ticket |
| `tte` | Transform ticket enrichment |

### Phase 4: Long Poll

| Step | Description |
|------|-------------|
| `lprq` | Long poll request |
| `lpor` | Long poll order retrieve |
| `ptrq` | Post-ticket request |
| `ptp` | Post-ticket processing |
| `ocal` | Order cancel (rollback on failure) |
| `tlpe` | Transform long poll enrichment |

### Error Queue Steps

| Step | Description |
|------|-------------|
| `teqi` | Ticket error queue init |
| `apl` | Add to processing list |
| `stk` | Stuck ticket handling |

### Sync/End Steps

| Step | Description |
|------|-------------|
| `prqs` | Price request sync |
| `prss` | Price response sync |
| `brqs` | Book request sync |
| `brss` | Book response sync |
| `trqs` | Ticket request sync |
| `trss` | Ticket response sync |
| `lprqs` | Long poll request sync |
| `lprss` | Long poll response sync |
| `done!` | Session complete |

## CancelMachine

| Step | Description |
|------|-------------|
| `cqrqs` | Cancel queue request |
| `gti` | Get ticket info |
| `cfid` | Confirm flight ID |
| `ipro` | Identify provider |
| `ceufn` | Check eligibility for cancellation |
| `cqrsq` | Cancel queue response |
| `goi` | Get order info |
| `fcqs` | Fulfillment cancel queue start |
| `iorc` | Issue order refund/cancel |
| `ec` | Execute cancel |
| `cos` | Cancel order status |
| `frp` | Fulfillment refund processing |
| `frsq` | Fulfillment response |

Long poll steps follow the same pattern as BookingMachine.

## ExchangeShoppingMachine

| Step | Description |
|------|-------------|
| `esrqs` | Exchange shopping request sync |
| `esrq` | Exchange shopping request |
| `ti` | Trip info |
| `tent` | Trip entitlement |
| `cfid` | Confirm flight ID |
| `ipro` | Identify provider |
| `ro` | Retrieve order |
| `pes` | Provider exchange shop |
| `esrsq` | Exchange shopping response sync |

## ExchangeBookingMachine

| Step | Description |
|------|-------------|
| `epqrs` | Exchange price quote request sync |
| `epqr` | Exchange price quote request |
| `ecid` | Exchange confirmation ID |
| `cfid` | Confirm flight ID |
| `ipro` | Identify provider |
| `owner` | Identify owner |
| `gti` | Get ticket info |
| `ro` | Retrieve order |
| `rf` | Retrieve fare |
| `oqri` | Order quote request info |
| `epqrsq` | Exchange price quote response sync |
| `efcs` | Exchange fulfillment confirm start |
| `efc` | Exchange fulfillment confirm |
| `aeo` | Apply exchange to order |
| `iorc` | Issue order refund/cancel |
| `ex` | Execute exchange |
| `es` | Exchange status |
| `efr` | Exchange fulfillment response |

## ScheduleChangeMachine

| Step | Description |
|------|-------------|
| `scrs` | Schedule change request sync |
| `scr` | Schedule change request |
| `cfid` | Confirm flight ID |
| `ipro` | Identify provider |
| `gti` | Get ticket info |
| `ro` | Retrieve order |
| `ascs` | Apply schedule change solution |
| `scrsq` | Schedule change response sync |

Inner machine steps vary by `ScheduleChangeType`.

## SeatsBookingMachine

### Setup Phase

| Step | Description |
|------|-------------|
| `cfid` | Confirm flight ID |
| `ipro` | Identify provider |
| `gti` | Get ticket info |
| `ro` | Retrieve order |
| `gpaaom` | Get passenger and ancillary order map |
| `ipf` | Initialize provider flow |

### Fulfillment Phase

| Step | Description |
|------|-------------|
| `fabs` | Fulfillment ancillary booking start |
| `gsofp` | Get seat offers from provider |
| `ex` | Execute seat booking |
| `cspci` | Confirm seat provider confirmation ID |
| `wnsp` | Wait for new seat price |
| `sfp` | Seat fulfillment processing |

### Provider-Specific Variants

Different providers use different fulfillment flows:
- **Basic** -- simple seat assignment
- **WithOfferPrice** -- requires offer price step
- **WithOrderQuote** -- requires order quote step
- **WithPaymentValidation** -- requires payment validation
- **WithSeatValidation** -- validates seat availability
- **WithSeatStatusValidation** -- validates seat assignment status

### Post-Fulfillment Phase

| Step | Description |
|------|-------------|
| `mbp` | Map booking passengers |
| `vbs` | Validate booked seats |
| `vsoin` | Validate seat order item number |
| `rfo` | Reconcile fulfillment order |
| `bsfr` | Booking seats fulfillment response |

## FareOptimizationVoidMachine

### Phase 1: Reshop

| Step | Description |
|------|-------------|
| `pfovrqs` | Fare opt void reshop request sync |
| `fti` | Fetch ticket info |
| `cfid` | Confirm flight ID |
| `ipro` | Identify provider |
| `ro` | Retrieve order |
| `vc` | Void check |
| `vp` | Void pricing |
| `vcs` | Void comparison |
| `voi` | Void order info |
| `rf` | Retrieve fare |
| `pfovrsq` | Fare opt void reshop response sync |

### Phase 2: Void + Reissue

| Step | Description |
|------|-------------|
| `pfovriqs` | Fare opt void reissue request sync |
| `co` | Cancel order |
| `afo` | Apply fare optimization |
| `afoa` | Apply fare optimization ancillaries |
| `rfa` | Retrieve fare after |
| `ce` | Confirm exchange |
| `owv` | Order wait void |
| `owc` | Order wait cancel |
| `owcf` | Order wait cancel failure |
| `pfovrisq` | Fare opt void reissue response sync |

## Error Patterns by Machine

| Machine | Common Failure Steps | Meaning |
|---------|---------------------|---------|
| BookingMachine | `vpi` | Price increase beyond threshold |
| BookingMachine | `occ` | Payment/order confirmation failure |
| BookingMachine | `or` (Unconfirmed) | Ticketing failed |
| BookingMachine | `casr` (BagsNotConfirmed) | Bag ancillary not confirmed |
| CancelMachine | `iorc` | Refund/cancel execution failed |
| ExchangeBookingMachine | `efc` | Exchange confirmation failed |
| SeatsBookingMachine | `ex` | Seat booking execution failed |
| FareOptimizationVoidMachine | `co` | Cancel order failed during void |
