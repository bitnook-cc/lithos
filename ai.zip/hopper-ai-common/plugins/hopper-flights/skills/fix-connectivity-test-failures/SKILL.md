---
name: fix-connectivity-test-failures
description: >-
  Diagnose and fix failed scenario test runs from flights-nonprod-traffic-generator.
  Fetches recent failures via gRPC, investigates root causes using Datadog logs,
  and opens PRs to fix issues in the responsible repos.
  Use when user explicitly asks to "run fix-connectivity-test-failures".
  Do NOT trigger for general debugging requests like "fix tests" or "diagnose failures".
---

# Fix Connectivity Test Failures

Fetch the latest failed scenario test runs from `flights-nonprod-traffic-generator`, diagnose each failure using Datadog logs, identify the responsible repo, fix the issue, and open a PR.

## Prerequisites

1. Verify `grpcurl` is installed: `which grpcurl`
2. Verify `gh` CLI is authenticated: `gh auth status`
3. Network access to `flights-nonprod-traffic-gen-unit-7170.ea.app-staging.h4r.io` is required (this host is publicly accessible behind IAP — no VPN or `hopctl proxy` needed)

## Step 1: Clone & Fetch Failures

Clone the traffic generator repo to get proto definitions:

```bash
gh repo clone hopper-org/flights-nonprod-traffic-generator
```

Fetch recent failed test runs via gRPC:

```bash
grpcurl -plaintext \
  -import-path flights-nonprod-traffic-generator/proto \
  -proto com/hopper/flights/provider/traffic/v1/test_run_service.proto \
  -d '{"page_size": 10, "filters": [{"field": "result", "value": "FAIL"}], "sort": {"field": "created_at", "descending": true}}' \
  flights-nonprod-traffic-gen-unit-7170.ea.app-staging.h4r.io \
  com.hopper.flights.provider.traffic.v1.TestRunService/ListTestRuns
```

### Processing the response

Response fields (camelCase per protobuf JSON):

| Field | Description |
|-------|-------------|
| `runId` | Unique test run identifier |
| `provider` | Provider name (e.g., "Travelfusion") |
| `carrier` | Airline carrier code |
| `tenant` | Tenant identifier |
| `scenarioType` | Type of scenario (e.g., "booking") |
| `result` | "PASS" or "FAIL" |
| `datadogLink` | URL to Datadog logs for the provider service |
| `sessionLink` | Dashboard/session link (may be empty) |
| `createdAt` | ISO timestamp |
| `errorMessage` | Error message from the failed phase |
| `failedPhase` | Which phase failed (e.g., "shopping", "booking", "pricing") |
| `errorResponseBody` | Raw response body from the provider service on failure |
| `traceId` | Datadog trace ID for correlating spans |
| `diagnosticsJson` | JSON with DD log links for each provider service involved |

Additional filters available: `{"field": "failed_phase", "value": "<phase>"}` to narrow by failure phase (e.g., "shopping", "booking").

**Filter to last 4 hours:** Discard any result where `createdAt` is older than 4 hours from the current time. Keep the first 2 failures.

**If zero failures in the 4-hour window:** Report "No recent failures found in the last 4 hours" and stop.

## Step 2: Diagnose the Failure

For each failed test run, start with the structured error context from the API response, then dig deeper with Datadog if needed.

### Use the enriched error fields first

The API response includes structured error context that often gives you enough to diagnose without querying Datadog:

1. **`errorMessage`** — The error thrown during the failed phase
2. **`failedPhase`** — Which phase failed (shopping, booking, pricing, etc.)
3. **`errorResponseBody`** — The raw response from the provider service that caused the failure
4. **`traceId`** — Datadog trace ID for span-level debugging
5. **`diagnosticsJson`** — JSON containing DD log links for multiple provider services involved in the scenario. Parse this to get targeted log URLs for each service.

### Dig deeper with Datadog

If the error fields don't provide enough context, query Datadog for the full log trail.

**Using the diagnostics links:** Parse `diagnosticsJson` for pre-built log links to the provider services involved. These are the most targeted starting points.

**Using the datadogLink:** The `datadogLink` field contains a URL like:

```
https://us5.datadoghq.com/logs?query=service%3Alondon+%40sessionToken%3A1cb91e9e-6690-42cc-9b0d-08f7ba7cbc2c&from_ts=1773766071913&to_ts=1773766087405&live=false
```

Extract from the URL query parameters:
- **Log filter query**: URL-decode the `query` param (e.g., `service:london @sessionToken:1cb91e9e-...`)
- **Time range**: `from_ts` and `to_ts` are epoch milliseconds

**Using the traceId:** If a `traceId` is present, use it to pull the full distributed trace:

```
mcp__datadog__get_datadog_trace
  trace_id: "<traceId>"
```

**Querying logs via MCP:** Activate the Datadog MCP tools first:

```
ToolSearch(query: "datadog", max_results: 20)
```

Then search logs:

```
mcp__datadog__search_datadog_logs
  filter: "<URL-decoded query>"
  from: "<from_ts divided by 1000>"
  to: "<to_ts divided by 1000>"
```

If epoch seconds are not accepted by the MCP tool, fall back to `from: "now-1h"` and rely on the session token filter to narrow results.

If the Datadog link's query does not include an `env:` tag, append `env:development` or `env:staging` since this targets nonprod traffic.

If the initial query returns limited results, broaden the search:
- Remove the `service:` prefix to search across all services
- Use filter: `@sessionToken:<token>` alone

### Determine root cause

From the error fields and/or logs, identify:
1. **Which service produced the error** — from `diagnosticsJson` service links, or the `service` tag on error-level logs (e.g., `london`, `flights-provider-facade`)
2. **The error message / stack trace** — from `errorMessage` and `errorResponseBody`, or `status:error` logs
3. **Which phase failed** — from `failedPhase` (shopping, booking, pricing, cancel, exchange, schedule change)
4. **Root cause category**:
   - Mapping error (request/response transformation)
   - Config issue (missing or incorrect configuration)
   - Provider response handling bug
   - Test harness issue (scenario definition or traffic generator logic)

### Mapping service to repo

Use the `service` tag from the error logs to find the responsible repo:

1. Search GitHub:
   ```bash
   gh search repos --owner hopper-org "<service-name>" --limit 5
   ```

2. Search flights team repos:
   ```bash
   gh search repos --owner hopper-org --topic flights-travel-agency --limit 100
   ```

3. Service names in Datadog typically match repo names (e.g., `london` -> repo `london`).

4. If error logs come from `flights-nonprod-traffic-generator` itself, the fix is in the already-cloned repo.

## Step 3: Fix and Open PRs

For each diagnosed failure:

### Clone and branch

1. Clone the responsible repo:
   ```bash
   gh repo clone hopper-org/<repo-name>
   ```

2. Detect the default branch:
   ```bash
   gh repo view hopper-org/<repo-name> --json defaultBranchRef --jq '.defaultBranchRef.name'
   ```

3. Create a fix branch:
   ```bash
   cd <repo-name>
   git checkout -b fix/tg-<scenarioType>-<provider>-<carrier>-<first 8 chars of runId>
   ```

### Fix the issue

Using the diagnosis from Step 2, locate the relevant code and make the fix. Read the repo's `CLAUDE.md` and `AGENTS.md` if present for project-specific conventions.

### Commit and open PR

1. Commit the fix:
   ```bash
   git add <changed-files>
   git commit -m "fix: <description of fix>"
   ```

2. Push and open a PR:
   ```bash
   git push -u origin HEAD
   gh pr create --title "fix: <summary>" --body "$(cat <<'EOF'
   ## Summary

   **Failed scenario:** <scenarioType> for <provider>/<carrier> (tenant: <tenant>)
   **Datadog logs:** <datadogLink>

   ### Root cause
   <root cause analysis from Step 2>

   ### Changes
   <description of what was changed and why>
   EOF
   )"
   ```

### Repeat for second failure

If the second failure is in a different repo, clone it and repeat. If it's the same repo with the same root cause, include the fix in a single PR and note that it addresses both failures.

## Edge Cases

- **Same repo, same root cause:** One PR fixes both; note this in the PR body.
- **Config change needed:** If the fix is in `Darmstadt` or `flight-config`, clone that repo and PR the config change.
- **Ambiguous root cause:** Report the diagnosis and ask for guidance rather than guessing.

## Expected Output

Report on completion:
- Number of failures found in the last 4 hours
- For each failure: scenario details, root cause summary, and PR link
- Example: "2 failures found. PR #1: [fix booking mapping for Travelfusion/CM](link). PR #2: [fix config for Travelfusion/AV](link)."

## Related Skills

- [datadog-ops](hopper-developer:datadog-ops) — Datadog log querying patterns and MCP tool usage
- [read-provider-state-machine-sessions](hopper-flights:read-provider-state-machine-sessions) — debugging booking failures
- [flights-travel-agency-repos](hopper-flights:flights-travel-agency-repos) — discovering flights team repos
