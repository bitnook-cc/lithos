# flights-exchange ExchangeBookingMachine Steps

The outer orchestrator machine that coordinates the entire exchange regardless of provider.

## All Steps

| Step ID | Name | Type | Purpose |
|---------|------|------|---------|
| ru | Retrieve User | reliable | Get user from auth service |
| re | Retrieve Experiments | reliable | Load experiment flags |
| ciff | Check Internal Feature Flags | backed | Get LaunchDarkly flags |
| ri | Retrieve Itinerary | reliable | Fetch booking itinerary |
| lks | Link Session | backed | Link session for tracking |
| rt | Retrieve Trip | reliable | Get trip details from AirExchangeShopping Bigtable cache |
| ci | Darmstadt Configuration Id | reliable | Load provider config |
| ftc | Fetch Travel Credit | reliable | Check travel credit availability |
| mrops | Maybe Retrieve Order Product Summaries | reliable | Get order product data |
| gfe | Get Fulfillment Entity for VCC | reliable | Get VCC fulfillment entity |
| fsc | Fetch Schedule Changes | reliable | Check for schedule changes |
| cfpsc | Check For Pending Schedule Change | backed | Block if pending |
| cnbsp | Check Not BSP | backed | Verify not BSP settlement |
| ciew | Check Inside Exchange Window | backed | Validate exchange window |
| ssf | Select Shopped Fare | backed | Select best fare from reshop |
| ced | Compute Exchange Diff | backed | Calculate fare difference |
| gti | Generate Trace ID | backed | Generate conversation trace |
| bpqrq | Build Provider Price Quote Request | backed | Build provider-specific price quote request |
| | **--> Delegate to provider machine for price quote -->** | | |
| bpqrs | Build Price Quote Response | backed | Format price quote for client |
| pqc | Price Quote Check | backed | Validate price quote |
| | **<-- Client polls price quote, then sends finalize -->** | | |
| _(payment)_ | Payment preparation | mixed | Setup VCC/card/cash payment |
| ap | Authorize Payment | reliable | Pre-authorize payment |
| gvcc | Get Virtual Credit Card | reliable | Generate VCC via Portland if needed |
| | **--> Delegate to provider machine for finalize -->** | | |
| rff | Remove from Fare Optimization | reliable | Remove from FO if applicable |
| ptc | Post Ticketing Request | backed | Build PTM request |
| pptr | Publish Post Ticketing Request | reliable | Send to Brooklyn via `locator-requests` Pub/Sub |
| wesr | Write Exchange Successful Remarks | reliable | Add remarks to booking |
| bfr | Build Finalize Response | backed | Build final response |
| tb/tt | Track Book/Ticketed | backed | Track metrics |

## Error Codes

| Error | Description |
|-------|-------------|
| `UserNotFound` | User lookup failed |
| `ItineraryNotFound` | Booking not found |
| `LocatorNotFound` | PNR not found |
| `TripNotFound` | Trip lookup failed |
| `QuotedPriceExceedsShoppedPriceThreshold` | Price changed significantly since shopping |
| `ProviderPriceQuoteFailed` | Provider returned error during quote |
| `FinalizeFailed` | Booking finalization failed |
| `PaymentAuthorizationFailed` | Payment pre-auth failed |
| `PaymentServiceError` | Payment service error |
| `DepartureIsLessThan4HoursFromNow` | Too close to departure |
| `ProviderAutomationUnsupported` | Provider doesn't support automated exchange |

## Failure Modes

- **Pre-check rejection** -- Exchange rejected at pre-check stage for reasons like unsupported provider, departure within 24 hours, pending schedule change, basic economy fare, or ticketless carrier. No provider calls made.

- **GDS eligibility timeout** -- When flights-servicing-eligibility contacts Southlake or Madrid for provider-level eligibility, a poll timeout (40 seconds) may occur. Returns ineligible with reason "exceeded machine timeout."

- **Exchange shopping provider failure** -- AirExchangeShopping fans out to providers in parallel. If one fails, partial results may be returned. If all fail, error response with no fare options.

- **Price quote state machine failure** -- The flights-exchange machine has a 20-minute global timeout and 90-second provider polling timeout. If any step fails, `PollExchangePriceQuote` returns error. Session cannot be retried; user must start new price quote. For NDC providers, may fall back to "AutomationUnsupported" result, triggering a Kustomer support message.

- **Payment failure during finalization** -- If payment authorization fails (insufficient funds, card declined, VCC issue), finalization halts. Original booking remains unchanged.

- **Provider finalization failure** -- After payment succeeds but provider fails to complete exchange (network error, PNR locked, GDS outage), the system is in partially-completed state. 300-second polling timeout for exchange ticketing. May need manual reconciliation.

- **Post-ticketing event delivery failure** -- If `locator-requests` Pub/Sub message is lost or Brooklyn is down, downstream processing is delayed but the exchange itself has completed.
