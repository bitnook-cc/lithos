# GDS Provider Exchange Details

Detailed machine steps and API mappings for Southlake (Sabre GDS) and Madrid (Amadeus GDS) exchange flows.

## Southlake (Sabre GDS)

Southlake has three exchange state machines that handle Sabre GDS integration.

### EligibilityMachine

| Step | Type | Description |
|------|------|-------------|
| getConfigId | backed | Fetch Darmstadt config |
| openEligibilitySession | reliable | Open Sabre session |
| openSabrePnr | reliable | Read PNR (catches PurgedPNR errors) |
| queueHistory | reliable | Get queue status (manual exchange, COVID cancellation queues) |
| getTicketStatus | reliable | Read ticket details with coupons |
| getUpdatedCouponStatus | reliable | Refresh coupon status |
| splitDetailsByPax | mapped | Group tickets by passenger |
| checkTickets | backed | Validate single ticket, all coupons open |
| getStructureFareRules | reliable | Fetch fare rules from Sabre |
| checkStructureFareRules | backed | Validate exchangeability |
| closeEligibilitySession | reliable | Close Sabre session |

**Key validations:**
- Rejects split PNRs
- Rejects ticketless carriers
- All ticket coupons must be open
- Checks manual exchange and COVID cancellation queue history

### ShoppingMachine

| Step | Type | Description |
|------|------|-------------|
| openShoppingSession | reliable | Open Sabre session |
| openSabrePnr | reliable | Read existing PNR |
| getOpenTicketNumbers | mapped | Get current ticket numbers |
| getUpdatedShoppingRequest | mapped | Patch cabin codes from itinerary |
| sabreExchangeShop | reliable | Call `ExchangeShoppingRQ` SOAP endpoint |
| closeShoppingSession | reliable | Close session |

**Sabre API:** `ExchangeShoppingRQ` SOAP -- searches for alternative flights with exchange pricing.

### ExchangeBookingMachine (~30 steps)

**Price Quote Phase:**
1. `generateTraceId` -- Create conversation ID
2. `openSession` -- Open Sabre session
3. `sabreChangeContext` -- Set PCC
4. `sabreQueueHistory` -- Check queues (manual exchange, COVID cancellation)
5. `sabreReadItinerary` -- Read original booking
6. `sabreReadTickets` -- Get ticket info
7. `getUpdatedCouponStatus` -- Refresh coupons
8. `sabreProviderProfile` -- Get profile info
9. `sabreCancel` -- Cancel original segments from PNR
10. `sabreBookPrice` -- Price new segments
11. `sabreMiscSegmentSell` -- Add misc segments
12. `sabreAutomatedExchange` -- `AutomatedExchangesLLSRQ` SOAP (get exchange pricing)
13. `generatePriceQuote` -- Create quote response

**Finalize Phase:**
14. `sabrePreauthorizeIfUserCard` -- Auth payment if needed
15. `sabreAutomatedExchangeCommit` -- `AutomatedExchangesLLSRQ` SOAP (confirm exchange)
16. `shouldSabreAutomatedExchangeCommitEnd` -- Check if end transaction needed
17. `sabreAutomatedExchangeCommitEndTransaction` -- End transaction
18. `ignoreTransactionAndReadItinerary` -- Finalize PNR
19. `priceRecords` -- Build ticketing inputs
20. `sabreEnhancedTicket` -- Issue tickets (per-passenger via `ExchangeTicketMachine`)
21. `checkTicketFailure` -- Validate all tickets issued
22. `pollForPartialTickets` -- Poll if partial tickets
23. `getFinalFormOfPayment` -- Get payment method used
24. `exchangeSuccessful` -- Mark complete

**Sabre APIs used:**
- `ExchangeShoppingRQ` -- exchange shopping
- `AutomatedExchangesLLSRQ` -- exchange pricing inquiry and commit
- `TKT_ExchangeRQ` -- low-level exchange ticketing
- `PNR_Retrieve`, `PNR_Cancel`, `Air_SellFromRecommendation` -- PNR operations
- `Ticket_IssueeDocumentRequest` -- enhanced ticketing

**Error handling:** Detects "INVALID AS BOOKED - LOWER FARE APPLIES" and "LOWER FARE FOUND - QUIT TO REBOOK" from AutomatedExchange, raising `RebookExchangeError`.

---

## Madrid (Amadeus GDS)

Madrid has three exchange state machines for Amadeus GDS integration.

### EligibilityMachine -- v7

| Step | Type | Description |
|------|------|-------------|
| generateTraceId | backed | Create trace |
| getPNR | reliable (10s, 2 retries) | Get PNR from ticket if not provided |
| pnrRetrieve | reliable (10s, 2 retries) | Retrieve PNR |
| queueHistory | reliable (20s, 2 retries) | Check queue history |
| sendQueue (ExchangeBookError) | reliable (20s, 1 retry) | Send to exchange error queue if needed |
| sendQueue (CancelV2Instant) | reliable (20s, 2 retries) | Send to cancel queue if needed |
| checkEligibilityExtended | reliable (10s, 2 retries) | Check via extended API (fallback to standard) |
| getStructureFareRules | rescue (reliable, 10s, 2 retries) | Fetch fare rules (rescue for recycled PNRs) |
| rescueRecycledPNR | backed rescue | Handle recycled PNR case |

### ExchangeShoppingMachine -- v2

| Step | Type | Description |
|------|------|-------------|
| generateTraceId | backed | Create trace |
| pnrRetrieve | reliable (10s, 3 retries) | Get ticket information |
| extendedAmadeusExchangeShop | reliable (40s, 3 retries) | Primary: extended variant with ticket/passenger data |
| amadeusExchangeShop | reliable (40s, 3 retries) | Fallback via rescue: standard variant |
| clampPricing | mapped | Ensure non-negative amounts |

**Amadeus API:** `Ticket_ATCShopperMasterPricerTravelBoardSearch` (FMPTBQ variant for exchanges). Madrid tries the extended variant first, falling back to standard if it fails.

### ExchangeBookingMachine -- v17

**Price Quote Phase:**
1. `generateConversationId` -- Create trace
2. `ensurePnrUnlocked` -- Rollback PNR if needed
3. `pnrRetrieve` -- Get current booking state (`PNR_Retrieve` / PNRRET)
4. `cancelSegments` -- Remove old flight segments (`PNR_Cancel` / PNRXCL)
5. `sellFromRecommendation` -- Add new flight segments (`Air_SellFromRecommendation` / ITAREQ)
6. `repricePNRWithBookingClass` -- Get pricing (`Fare_PricePNRWithBookingClass` / TPCBRQ)
7. `amadeusTravellerToPassengerMapping` -- Map travellers to passengers

**Finalize Phase:**
8. `reissueConfirmedPricing` -- `Ticket_ReissueConfirmedPricing`
9. `getTicketsInfo` -- Get ticket details (with fallback rescue)
10. `paymentMethod` -- Determine payment method
11. `preauthNecessary` -- Check if preauth needed
12. `maybePreauth` -- Conditional preauth flow (8 sub-steps if needed)
13. `preSavePNRRedisplay` -- Redisplay PNR before save
14. `savePNR` -- Save PNR (with retry for simultaneous changes)
15. `pollForAirlineLocator` -- Wait for airline to confirm reservation (5 retries)
16. `issueAllTickets` -- Dynamic fold machine (`IssueTicketMachine`) over passengers
17. `exchangeSuccessful` -- Mark complete
18. `successSignOut` / `failureSignOut` -- Close Amadeus session (`Security_SignOut` / VLSSOQ)

**Amadeus APIs used:**
- `Ticket_ATCShopperMasterPricerTravelBoardSearch` -- exchange shopping
- `PNR_Retrieve` (PNRRET) -- get PNR state
- `PNR_Cancel` (PNRXCL) -- cancel segments
- `Air_SellFromRecommendation` (ITAREQ) -- add new segments
- `Fare_PricePNRWithBookingClass` (TPCBRQ) -- reprice
- `Ticket_ReissueConfirmedPricing` -- reissue old tickets
- `FOP_CreateFormOfPayment` (TFOPCQ) -- handle payment
- `Ticket_IssueeDocumentRequest` -- issue new tickets
- `Security_SignOut` (VLSSOQ) -- close session

**Unique Madrid aspects:**
- Extended exchange APIs (`shopExtended`, `checkExtended`) for richer eligibility checking with passenger/ticket data
- Nested dynamic machines (`IssueTicketMachine` fold over passengers)
- Pessimistic preauthorization logic (checks if needed based on payment method)
- Airline locator polling (waits for airline to confirm reservation)

---

## GDS vs Facade: Key Differences

| Aspect | GDS (Southlake/Madrid) | Facade (NDC) |
|--------|----------------------|--------------|
| **Session model** | Stateful GDS session maintained throughout | Stateless API calls |
| **Shopping API** | Sabre: `ExchangeShoppingRQ`; Amadeus: `FMPTBQ` | OrderReshop with ExchangeIndicator=ON |
| **Booking approach** | Cancel segments + sell new + reprice in PNR | Accept offer + OrderChange |
| **Ticketing** | Per-passenger ticket issuance (dynamic machine) | Single OrderChange with payment |
| **Payment** | FOP created in GDS session | Payment passed in OrderChange request |
| **Queue checks** | Built-in queue history validation | Not applicable (queueless) |
| **Error recovery** | Session rollback (ignore transaction) | Retry or abort |
| **Eligibility** | Dedicated EligibilityMachine with fare rules check | Via flights-servicing-eligibility |
