# Exchange File Locations

Key file paths across all exchange-related repositories.

## AirExchangeEligibility
- **Service:** `air-exchange-eligibility-server/src/main/scala/com/hopper/air_exchange_eligibility/DefaultAirExchangeEligibilityService.scala`
- **Proto:** `air-exchange-eligibility-proto/src/main/protobuf/hopper/air_exchange_eligibility/v1/service.proto`
- **Models:** `air-exchange-eligibility-proto/src/main/protobuf/hopper/air_exchange_eligibility/v1/model.proto`

## flights-servicing-eligibility
- **Service:** `flights-servicing-eligibility-server/src/main/scala/com/hopper/flights_servicing_eligibility/DefaultFlightsServicingEligibilityService.scala`
- **Exchange Logic:** `flights-servicing-eligibility-server/src/main/scala/com/hopper/flights_servicing_eligibility/ExchangeEligibilityService.scala`
- **Feature Flags:** `flights-servicing-eligibility-server/src/main/scala/com/hopper/flights_servicing_eligibility/FeatureFlagService.scala`

## AirExchangeShopping
- **Service:** `air-exchange-shopping-server/src/main/scala/com/hopper/air_exchange_shopping/DefaultAirExchangeShoppingService.scala`
- **Proto:** `air-exchange-shopping-proto/src/main/protobuf/hopper/air_exchange_shopping/v1/service.proto`

## flights-exchange
- **Machine:** `flights-exchange-machine/src/main/scala/com/hopper/flights_exchange/machine/ExchangeBookingMachine.scala`
- **Machine Steps:** `flights-exchange-machine/src/main/scala/com/hopper/flights_exchange/machine/ExchangeBookingMachineSteps.scala`
- **Service:** `flights-exchange-server/src/main/scala/com/hopper/flights_exchange/DefaultFlightsExchangeService.scala`
- **Proto:** `flights-exchange-proto/src/main/protobuf/hopper/flights_exchange/v1/service.proto`
- **Feature Flags:** `flights-exchange-machine/src/main/scala/com/hopper/flights_exchange/machine/FeatureFlagService.scala`

## flights-provider-facade (Exchange)
- **Shopping Machine:** `machine/src/main/scala/com/hopper/facade/machine/executor/exchange/ExchangeShoppingMachine.scala`
- **Shopping Steps:** `machine/src/main/scala/com/hopper/facade/machine/executor/exchange/ExchangeShoppingMachineSteps.scala`
- **Shopping Models:** `machine/src/main/scala/com/hopper/facade/machine/api/exchange/ExchangeShoppingMachineModels.scala`
- **Booking Machine:** `machine/src/main/scala/com/hopper/facade/machine/executor/exchange/ExchangeBookingMachine.scala`
- **Booking Steps:** `machine/src/main/scala/com/hopper/facade/machine/executor/exchange/ExchangeBookingMachineSteps.scala`
- **Exchange Helper:** `core/src/main/scala/com/hopper/facade/core/util/ExchangeHelper.scala`
- **Proto (OrderReshop):** `proto/src/main/protobuf/hopper/facade/proto/v1/order_reshop_request_models.proto`
- **Proto (OrderChange):** `proto/src/main/protobuf/hopper/facade/proto/v1/change_request_models.proto`
- **Proto (ExchangeShop):** `proto/src/main/protobuf/hopper/facade/proto/v1/exchange_shop_request_models.proto`
- **State Machine Docs:** `docs/STATE_MACHINES.md`

## flights-provider-integration-amadeus-ndcx
- **OrderChange:** `service/src/main/scala/com/hopper/amadeusndcx/service/OrderChangeService.scala`
- **OrderReshop:** `service/src/main/scala/com/hopper/amadeusndcx/service/OrderReshopService.scala`
- **ExchangeShop:** `service/src/main/scala/com/hopper/amadeusndcx/service/ExchangeShopService.scala`
- **Request Mappers:** `core/src/main/scala/com/hopper/amadeusndcx/core/mappers/ExchangeShopRequestMapper.scala`
- **OrderChange Mapper:** `core/src/main/scala/com/hopper/amadeusndcx/core/mappers/OrderChangeRequestMapper.scala`
- **XML Models:** `core/src/main/scala/com/hopper/amadeusndcx/core/models/requests/orderExchangeReshop/`
- **Test XML:** `core/src/test/resources/airlineAC/exchangeShop/`

## flights-provider-integration-ndc
- **OrderChange:** `service/src/main/scala/com/hopper/ndc/service/OrderChangeService.scala`
- **NDC Versions:** `core/src/main/scala/com/hopper/ndc/v172/`, `v181/`, `v192/`, `v213/`

## Southlake (Sabre GDS)
- **EligibilityMachine:** `southlake-machine/src/main/scala/com/hopper/southlake/exchange/EligibilityMachine.scala`
- **EligibilityMachineSteps:** `southlake-machine/src/main/scala/com/hopper/southlake/exchange/EligibilityMachineSteps.scala`
- **ShoppingMachine:** `southlake-machine/src/main/scala/com/hopper/southlake/exchange/ShoppingMachine.scala`
- **ShoppingMachineSteps:** `southlake-machine/src/main/scala/com/hopper/southlake/exchange/ShoppingMachineSteps.scala`
- **ExchangeBookingMachine:** `southlake-machine/src/main/scala/com/hopper/southlake/exchange/ExchangeBookingMachine.scala`
- **ExchangeBookingMachineSteps:** `southlake-machine/src/main/scala/com/hopper/southlake/exchange/ExchangeBookingMachineSteps.scala`
- **EligibilityService:** `southlake-server/src/main/scala/com/hopper/southlake/exchange/ExchangeEligibilityService.scala`
- **ExchangeShoppingApi:** `southlake-server/src/main/scala/com/hopper/southlake/exchange/ExchangeShoppingApi.scala`
- **ExchangeShoppingRQ:** `southlake-server/src/main/scala/com/hopper/southlake/exchange/ExchangeShoppingRQ.scala`
- **AutomatedExchange:** `southlake-server/src/main/scala/com/hopper/southlake/sabre/AutomatedExchange.scala`
- **AutomatedExchangeCommit:** `southlake-server/src/main/scala/com/hopper/southlake/sabre/AutomatedExchangeCommit.scala`
- **TktExchange:** `southlake-server/src/main/scala/com/hopper/southlake/sabre/TktExchange.scala`
- **Scheduler:** `southlake-machine/src/main/scala/com/hopper/southlake/SouthlakeMachineSchedulerServer.scala`

## Madrid (Amadeus GDS)
- **EligibilityMachine:** `machine/src/main/scala/com/hopper/madrid/exchange/EligibilityMachine.scala`
- **EligibilityMachineSteps:** `machine/src/main/scala/com/hopper/madrid/exchange/EligibilityMachineSteps.scala`
- **ExchangeShoppingMachine:** `machine/src/main/scala/com/hopper/madrid/exchange/ExchangeShoppingMachine.scala`
- **ExchangeShoppingMachineSteps:** `machine/src/main/scala/com/hopper/madrid/exchange/ExchangeShoppingMachineSteps.scala`
- **ExchangeBookingMachine:** `machine/src/main/scala/com/hopper/madrid/exchange/ExchangeBookingMachine.scala`
- **ExchangeBookingMachineSteps:** `machine/src/main/scala/com/hopper/madrid/exchange/ExchangeBookingMachineSteps.scala`
- **ExchangeBookingMachineApi:** `machine/src/main/scala/com/hopper/madrid/exchange/ExchangeBookingMachineApi.scala`
- **EligibilityService:** `server/src/main/scala/com/hopper/madrid/exchange/ExchangeEligibilityService.scala`
- **ExchangeShoppingApi:** `server/src/main/scala/com/hopper/madrid/shop/exchange/ExchangeShoppingApi.scala`
- **ExchangeApi:** `server/src/main/scala/com/hopper/madrid/exchange/ExchangeApi.scala`
- **Scheduler:** `machine/src/main/scala/com/hopper/madrid/MadridMachineSchedulerServer.scala`

## support-remoteui
- **Exchange Flow:** `support-air/src/main/scala/com/hopper/support/remoteui/air/support/exchange/state/ExchangeTripFlow.scala`
- **Screens:** `support-air/src/main/scala/com/hopper/support/remoteui/air/support/exchange/screens/`
- **Link Builder:** `support-air/src/main/scala/com/hopper/support/remoteui/air/support/exchange/ExchangeTripLinkBuilder.scala`
- **Proto:** `support-air-proto/src/main/protobuf/hopper/support/remoteui/air/v1/model.proto`

## Newark
- **Cart Exchange Controller:** `newark-mobile-api/src/main/scala/com/hopper/newark/mobileapi/v3/exchange/CartExchangeController.scala`
- **Cart Exchange Client:** `newark-mobile-api/src/main/scala/com/hopper/newark/mobileapi/v3/exchange/FlightsCartExchangeClient.scala`
- **Cart Exchange Interface:** `newark-mobile-api/src/main/scala/com/hopper/newark/mobileapi/v3/exchange/CartExchangeInterface.scala`
- **Exchange Shop Controller:** `newark-mobile-api/src/main/scala/com/hopper/newark/mobileapi/v2/exchange/ExchangeShopController.scala`
- **Exchange Shop Service:** `newark-mobile-api/src/main/scala/com/hopper/newark/mobileapi/v2/exchange/ExchangeShopService.scala`
- **Server Registration:** `newark-mobile-api/src/main/scala/com/hopper/newark/mobileapi/NewarkMobileApiServer.scala`
