# Facade Provider Exchange Details

Detailed machine steps and API mappings for the flights-provider-facade exchange flow and its downstream NDC provider integrations (amadeus-ndcx, ndc).

## ExchangeShoppingMachine (flights-provider-facade)

For queueless NDC providers (amadeus-ndcx, sabre-ndc-b6, etc.):

| Step | Type | Description |
|------|------|-------------|
| Shopping Request | sync | Receive external shopping request |
| Generate Trace ID | backed | Create trace for observability |
| Extract PNR | backed | Get locator from request |
| Extract PCC | backed | Get PCC from request |
| Extract Shop Query | backed | Parse shopping parameters |
| Extract Shop Provider | backed | Determine provider type |
| Get Tenant | backed | Resolve tenant |
| Get Config ID | backed | Load config version |
| Get Integration Provider | backed | Map to specific NDC integration |
| Compute Trips to Shop | mapped | Filter requested slices for CHANGE/ADD actions |
| Retrieve Order | reliable (45s, 3 retries) | Fetch existing booking via OrderRetrieve |
| Compute Trips to Cancel | mapped | Match KEEP slices against order, identify cancellable items |
| Provider Exchange Shop | reliable (45s, 3 retries) | Call OrderReshop with `ExchangeIndicator=ON` |
| Shopping Response | sync | Return results |

**Key data models:**
```scala
case class OrderId(value: String)
case class SegmentInfo(origin: String, destination: String, segmentId: String)
case class OrderItem(orderItemId: String, serviceIds: Map[String, String])
case class ExchangeShopInformation(orderId: OrderId, sliceInfo: Seq[Seq[SegmentInfo]], orderItems: Seq[OrderItem])
```

## ExchangeBookingMachine (flights-provider-facade)

Handles direct provider communication for NDC exchange booking:

| Step ID | Name | Type | Purpose |
|---------|------|------|---------|
| cfid | Set Config ID | backed | Load config store version |
| ipro | Integration Provider | backed | Determine provider integration |
| owner | Get Owner Code | backed | Extract airline owner code |
| gti | Generate Trace ID | backed | Generate conversation trace |
| **Price Quote Phase** | | | |
| ro | Retrieve Order | reliable | Fetch booking via OrderRetrieve |
| rf | Reshop Flights | reliable | Call OrderReshop (ExchangeIndicator=ON) |
| oqri | Order Quote or Fallback | reliable | OrderQuote (Sabre B6 only) or fallback reshop |
| _(map)_ | Price Quote Response | mapped | Extract and format price quote |
| **Finalize Phase** | | | |
| aeo | Accept Exchange Offer | reliable | OrderChange: AcceptOfferRequest |
| iorc | Invalidate Reshop Cache | reliable | Clear cached reshop data |
| ex | Exchange Book | reliable | OrderChange: AddPaymentInstrumentRequest |
| es | Exchange Successful | backed | Mark exchange complete |

## Provider API Mappings

### Shopping (OrderReshop)

| Facade Concept | Amadeus NDCX | Sabre NDC B6 |
|----------------|-------------|--------------|
| OrderReShop | `OrderReshopRQ` XML via `ExchangeShopRequestMapper` | `OrderReshopRQ` XML (NDC v2.1.3) |
| ExchangeIndicator=ON | Sets exchange context in request | Sets exchange context in request |
| Owner code | Extracted from first 2 chars of orderId (e.g., "AC") | From order metadata |

### Booking (OrderChange)

| Facade Step | Amadeus NDCX Mapping | Sabre NDC B6 Mapping |
|-------------|---------------------|---------------------|
| Accept Exchange Offer (`AcceptOfferRequest`) | `ExchangeAcceptOrderReshopRQ` (AmadeusAction.OrderReshop) | `OrderChangeRQ` (NDC v2.1.3) |
| Exchange Book (`AddPaymentInstrumentRequest`) | `OrderChangeRQ` with payment (AmadeusAction.OrderChange) | `OrderChangeRQ` with payment |

**Key difference:** For Amadeus NDCX, the accept step maps to an `OrderReshop` action (not OrderChange), while the finalize step maps to `OrderChange`. For Sabre NDC B6, both use `OrderChange` but with different request content. Sabre B6 also requires an additional `OrderQuote` step before finalization.

### OrderReShop Proto Model

```protobuf
OrderReShopRequest {
  trace_id: string
  order_id: string                  // e.g., "AC0ABCD1234"
  trips_to_cancel: TripToCancel[]   // segments to remove
  trips_to_add: TripToAdd[]         // new flights to price
  indicator: ExchangeIndicator      // ON for exchange
  context: ReshopContext            // EXCHANGE for exchange flows
  owner: string                     // airline code owner
}
```

### OrderChange Proto Model

```protobuf
OrderChangeRequest {
  trace_id: string
  order_id: string
  request: oneof {
    AcceptOfferRequest              // accept offer with passengers/contact
    AddPaymentInstrumentRequest     // add payment method
    ConfirmScheduleChangeRequest    // (not used in exchange)
    OsiMessageRequest               // add OSI message
    SeatFulfillmentRequest          // fulfill seats
  }
}
```

## Amadeus NDCX Integration Details

**Request mapping (`ExchangeShopRequestMapper`):**
- Converts facade `ExchangeShopRequest` into `ExchangeOrderReshopRQ` XML
- `fallbackOwner` extracted from first 2 characters of orderId
- Sends to Amadeus via `AmadeusClient` with `AmadeusAction.OrderReshop`

**Response mapping (`ExchangeShopResponseMapper`):**
- Parses `ExchangeOrderReshopRS` XML
- Extracts prices and new order data

**OrderChange mapping (`OrderChangeRequestMapper`):**
- AcceptOffer step: Maps to `ExchangeAcceptOrderReshopRQ` with `AmadeusAction.OrderReshop`
- Payment step: Maps to `OrderChangeRQ` with payment details, `AmadeusAction.OrderChange`
- Handles card, cash, and VCC payment types

## NDC Integration Details (Sabre B6, Farelogix, etc.)

**Multiple NDC versions supported:**
- v1.7.2 (Farelogix)
- v1.8.1 (Navitaire)
- v1.9.2 (LATAM)
- v2.1.3 (Alaska, Sabre Mosaic/B6)

**OrderChange specifics:**
- Supports both regular payment (`AddPaymentInstrumentRequest`) and seat fulfillment
- LATAM-specific workarounds: calls OrderRetrieve post-OrderChange to fetch seat info if missing
- Payment token handling for VCC/card payments
- More complex payment instrument handling than Amadeus NDCX

## FacadeSupplier Enum

When `provider = FACADE`, the `FacadeSupplier` specifies the NDC integration:
- `FRONTIER_NDC`
- `AZUL`
- `AIR_ASIA`
- `LATAM_NDC`
- `BREEZE_NDC`
- `SPIRIT_NDC`
- `AMADEUS_NDCX`
- `ALASKA_NDC`
- `SABRE_NDC_VA`
- `SABRE_NDC_B6`
- `NAVITAIRE_PD`
- `NAVITAIRE_Y4`
