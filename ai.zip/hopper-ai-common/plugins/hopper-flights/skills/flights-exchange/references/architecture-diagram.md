# Exchange Architecture Diagram

Full service interaction diagram across all four phases of the exchange flow.

```mermaid
sequenceDiagram
    participant App as Consumer (Newark / B2B)
    participant FSE as flights-servicing-eligibility
    participant AEE as AirExchangeEligibility
    participant Itin as flights-itineraries
    participant AES as AirExchangeShopping
    participant FPF as flights-provider-facade
    participant FX as flights-exchange
    participant GDS as GDS Provider (Southlake / Madrid)
    participant Pay as Payment (Zurich / Portland)
    participant BK as Brooklyn

    rect rgb(240, 248, 255)
    Note over App, FPF: Phase 1 -- Eligibility Check
    App->>FSE: gRPC: GetReport(userId, itineraryId)
    FSE->>Itin: gRPC: get itinerary details
    Itin-->>FSE: itinerary data
    Note right of FSE: Evaluates pre-check rules internally
    par Provider-level eligibility fan-out
        FSE->>GDS: HTTP: exchange eligibility (Sabre/Amadeus)
        FSE->>FPF: HTTP: POST /api/v1/exchangeEligibility (NDC)
    end
    GDS-->>FSE: eligibility + penalty details
    FPF-->>FSE: NDC eligibility result
    FSE-->>App: combined eligibility report
    end

    rect rgb(245, 255, 245)
    Note over App, FPF: Phase 2 -- Exchange Shopping
    App->>AES: gRPC: ExchangeShop(itinerary, slices, dates)
    AES->>Itin: gRPC: GetReservationFromItinerary
    Itin-->>AES: reservation details
    par Fan-out to providers
        AES->>GDS: HTTP: exchange shopping (Sabre via Southlake, Amadeus via Madrid)
        AES->>FPF: HTTP: exchange shopping (NDC via ExchangeShoppingMachine)
    end
    GDS-->>AES: exchange fare options
    FPF-->>AES: NDC exchange fare options
    Note right of AES: Enriches fares via flights-fare-mapping, caches in Bigtable
    AES-->>App: exchange trip results with fares
    end

    rect rgb(255, 248, 240)
    Note over App, Pay: Phase 3a -- Price Quote
    App->>FX: gRPC: ScheduleExchangePriceQuote(sessionId, tripId, fareId)
    FX-->>App: accepted (async)
    FX->>AES: gRPC: TripResult(tripId) -- retrieve cached fare
    AES-->>FX: fare option details
    FX->>GDS: HTTP: request price quote from provider
    GDS-->>FX: price quote (residual value, new total)
    App->>FX: gRPC: PollExchangePriceQuote(sessionId)
    FX-->>App: price quote result
    end

    rect rgb(255, 240, 245)
    Note over App, BK: Phase 3b -- Finalization
    App->>FX: gRPC: ScheduleExchangeFinalize(sessionId, confirm/abort)
    FX-->>App: accepted (async)
    FX->>Pay: HTTP: process payment (charge difference / issue credit)
    Pay-->>FX: payment result
    FX->>GDS: HTTP: finalize exchange booking
    GDS-->>FX: new ticket issued
    FX->>Itin: gRPC: update reservation
    Itin-->>FX: confirmed
    App->>FX: gRPC: PollExchangeFinalize(sessionId)
    FX-->>App: finalization result (success / error)
    FX-)BK: Pub/Sub: locator-requests (post-ticketing)
    end
```
