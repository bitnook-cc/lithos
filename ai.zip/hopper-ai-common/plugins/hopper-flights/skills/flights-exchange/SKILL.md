---
name: flights-exchange
description: >-
  Flights exchange engineering at Hopper. Use when working on voluntary exchange
  eligibility, shopping, booking, or post-ticketing across the exchange service
  ecosystem including flights-exchange, AirExchangeShopping, AirExchangeEligibility,
  flights-servicing-eligibility, flights-provider-facade, support-remoteui, Newark,
  Brooklyn, and provider integrations (amadeus-ndcx, ndc, Southlake, Madrid).
---

# Flights Exchange Skill

## What Is an Exchange?

An **exchange** is a voluntary, customer-initiated itinerary modification -- the passenger wants to change their flights to different ones. Exchanges may incur change fees and fare differences. The primary service is `flights-exchange`, with eligibility gated by `AirExchangeEligibility` and `flights-servicing-eligibility`.

**Important:** No HTS (Hopper Technology Solutions) tenants currently support automated exchanges. RBC will be the first HTS tenant to support them.

## Service Ecosystem

Exchanges span many services. The architecture splits into two provider paths: **Facade (queueless NDC providers)** and **GDS (Southlake for Sabre, Madrid for Amadeus)**.

| Service | Role in Exchange |
|---------|-----------------|
| **support-remoteui** | Mobile app-facing support screen, entry point for exchange flow |
| **Newark** | Mobile API gateway, orchestrates exchange shop/book calls from the app |
| **AirExchangeEligibility** | Fast pre-check eligibility (no provider calls), called by support-remoteui |
| **flights-servicing-eligibility** | Full eligibility with provider API calls + penalties |
| **AirExchangeShopping** | Exchange shopping gRPC service, routes to provider and polls for results |
| **flights-exchange** | Core exchange booking orchestrator (state machine) |
| **flights-provider-facade** | Provider abstraction for NDC: ExchangeShoppingMachine + ExchangeBookingMachine |
| **flights-provider-integration-amadeus-ndcx** | Amadeus NDC provider integration (OrderReshop, OrderChange) |
| **flights-provider-integration-ndc** | Generic NDC providers (Sabre NDC B6, Farelogix, LATAM, etc.) |
| **Southlake** | Sabre GDS integration: 3 exchange machines (Eligibility, Shopping, Booking) |
| **Madrid** | Amadeus GDS integration: 3 exchange machines (Eligibility, Shopping, Booking) |
| **London** | Travelfusion -- **no exchange support** (`isExchangeable = false` hardcoded) |
| **Brooklyn** | Post-ticketing machine (PTM), consumes `locator-requests` Pub/Sub after exchange finalization |
| **Darmstadt** | PCC config, queue configs, send queue purposes |

## End-to-End Architecture

The exchange flow has three major phases: **Eligibility**, **Shopping**, and **Booking**.

```
                          EXCHANGE FLOW OVERVIEW

  +------------------+     +------------------+     +------------------+
  |   1. ELIGIBILITY |---->|   2. SHOPPING    |---->|   3. BOOKING     |
  |                  |     |                  |     |                  |
  | Can the customer |     | What flights are |     | Book the new     |
  | change flights?  |     | available?       |     | flights, pay,    |
  |                  |     |                  |     | and reticket     |
  +------------------+     +------------------+     +------------------+
```

### Full Service Flow Diagram

See [Architecture Diagram](references/architecture-diagram.md) for the full mermaid sequence diagram showing all service interactions across all four phases.

### Provider Path Split

```
AirExchangeShopping
    |
    +-- provider = SABRE ---------> Southlake (Sabre GDS machines)
    |                                 EligibilityMachine
    |                                 ShoppingMachine
    |                                 ExchangeBookingMachine
    |
    +-- provider = AMADEUS -------> Madrid (Amadeus GDS machines)
    |                                 EligibilityMachine
    |                                 ExchangeShoppingMachine
    |                                 ExchangeBookingMachine
    |
    +-- provider = FACADE --------> flights-provider-facade (NDC)
    |   or FARELOGIX_NDC              ExchangeShoppingMachine
    |   (queueless NDC)               ExchangeBookingMachine
    |                                   |
    |   Both route to the              +-- amadeus-ndcx (Air Canada, etc.)
    |   same facade client.            +-- ndc (Sabre NDC B6, Farelogix, etc.)
    |   FACADE uses a FacadeSupplier
    |   sub-enum to specify the
    |   specific NDC integration.
```

---

## Phase 1: Exchange Eligibility

Eligibility determines whether a booking can be exchanged **before** showing any shopping options. There are two levels of checking.

### Pre-Check (Fast Path -- No Provider Calls)

Performed by **AirExchangeEligibility** service. Called directly by support-remoteui's `ExchangeTripFlow` via `getPreCheckExchangeEligibility()`. This is a fast, local check that filters out obviously ineligible bookings without making expensive provider API calls.

**Checks performed in order:**

| Check | Result if Failed | Details |
|-------|-----------------|---------|
| Provider supported? | `INELIGIBLE_PROVIDER` | Travelfusion, GDX, Facade+F9 not supported |
| First flight departed? | `INELIGIBLE_AIRLINE_CONTROL_PARTIAL` | `departureTime.isBeforeNow` |
| Departs within 24h? | `INELIGIBLE_AIRLINE_CONTROL24_HOURS` | `departureTime.minusHours(24).isBeforeNow && departureTime.isAfterNow` |
| Pending schedule change? | `INELIGIBLE_PENDING_SCHEDULE_CHANGE` | `scheduleChange.userAction == UserAction.Waiting` |
| Basic economy fare? | `INELIGIBLE_BASIC_ECONOMY` | `brandType == BasicEconomy` or `shelfBrandName.contains("Basic")` |
| Ticketless carrier? (Amadeus only) | `INELIGIBLE_TICKETLESS` | Hard-coded: F9, NK, SY |
| All pass | `ELIGIBLE` | Proceed to shopping or full check |

**Decision tree:**

```
Exchange Pre-Check
|
+-- Provider supported?
|   +-- NO (Travelfusion, GDX, Facade+F9) --> INELIGIBLE_PROVIDER
|   +-- YES --> continue
|
+-- First flight departed?
|   +-- YES --> INELIGIBLE_AIRLINE_CONTROL_PARTIAL
|   +-- NO --> continue
|
+-- Departs within 24 hours?
|   +-- YES --> INELIGIBLE_AIRLINE_CONTROL24_HOURS
|   +-- NO --> continue
|
+-- Pending schedule change?
|   +-- YES (UserAction.Waiting) --> INELIGIBLE_PENDING_SCHEDULE_CHANGE
|   +-- NO --> continue
|
+-- Basic economy fare?
|   +-- YES --> INELIGIBLE_BASIC_ECONOMY
|   +-- NO --> continue
|
+-- Ticketless carrier? (Amadeus only: F9, NK, SY)
|   +-- YES --> INELIGIBLE_TICKETLESS
|   +-- NO --> ELIGIBLE
```

### Full Eligibility Check (With Provider Calls)

Performed by **flights-servicing-eligibility** service. Called by Newark's `ExchangeShopService.exchangeEligibility()` endpoint (`/fareRules`). After passing pre-checks, the service routes to the appropriate provider:

| Provider | Routing Logic |
|----------|--------------|
| **Sabre (GDS)** | Pre-check + Southlake EligibilityMachine for penalties |
| **Amadeus (GDS)** | Pre-check + Madrid EligibilityMachine for penalties |
| **FarelogixNdc** | Requires `FarelogixNdcExchangeShop` experiment = "Available" |
| **FacadeQueueless + SabreNdcB6** | Direct provider API call |
| **FacadeQueueless + AmadeusNdcx** | Carrier whitelist (AC only) + `AmadeusNdcxExchangeShopAC` flag |
| **Multi-provider bookings** | Always `Ineligible("MultiProvider")` |

**Returns:** `Eligible` (with penalty: NoPenalty / PenaltyPerPassenger / UnknownPenalty) or `Ineligible` (with reason)

### GDS Eligibility Machines

Both Southlake and Madrid have dedicated **EligibilityMachine** state machines that perform provider-level eligibility checks:

**Southlake EligibilityMachine (Sabre):**
1. Open Sabre session
2. Read PNR (catches purged PNRs)
3. Check queue history (manual exchange queue, COVID cancellation queue)
4. Get ticket status with coupon validation (all coupons must be open)
5. Check for split PNR, ticketless carriers
6. Fetch structure fare rules from Sabre
7. Validate fare rules allow exchanges
8. Return Eligible (with penalty) or Ineligible

**Madrid EligibilityMachine (Amadeus) -- v7:**
1. Generate trace ID
2. Get PNR from ticket (if not provided)
3. Check queue history (manual exchange, cancel queues)
4. PNR retrieve
5. Check eligibility via extended API (fallback to standard)
6. Get structure fare rules (rescue step for recycled PNRs)
7. Return eligibility result

### Support-RemoteUI Eligibility Screens

When `ExchangeTripFlow` in support-remoteui (the mobile app-facing support screen) receives an ineligibility result, it routes to the appropriate screen:

| Eligibility Status | Screen | User Action |
|---|---|---|
| `ELIGIBLE` | None (proceeds to exchange) | Route to `ItineraryAction(Change)` |
| `INELIGIBLE_PROVIDER` | `ExchangeIneligibleProviderScreen` | Contact airline |
| `INELIGIBLE_PENDING_SCHEDULE_CHANGE` | `ScheduleChangePrompt` | Acknowledge schedule change first |
| `INELIGIBLE_BASIC_ECONOMY` | `ExchangeIneligibleBasicEconomyScreen` | Contact airline |
| `INELIGIBLE_TICKETLESS` | `ExchangeIneligibleTicketlessScreen` | Contact airline |
| `INELIGIBLE_AIRLINE_CONTROL_PARTIAL` | `ExchangeIneligibleAirlineControlScreen` | Contact airline |
| `INELIGIBLE_AIRLINE_CONTROL24_HOURS` | `ExchangeIneligibleAirlineControlScreen` | Contact airline |

---

## Phase 2: Exchange Shopping

Exchange shopping finds available alternative flights and their pricing. The flow routes to different provider backends depending on the booking's provider.

### Flow Overview

```
Newark ExchangeShopController (POST /exchangeShop)
    |
    v
Newark ExchangeShopService
    | Validates: itinerary exists, has validating carrier,
    | has ticket numbers, passengers valid, not multi-ticket,
    | not departed, provider supported
    |
    v
AirExchangeShopping.exchangeShop() (gRPC)
    | Creates session, converts to common model
    | Polls with 1s frequency, 10min timeout
    | Enriches results via flights-fare-mapping
    | Caches trip results in Bigtable
    |
    +-- SABRE -------> Southlake ShoppingMachine
    +-- AMADEUS -----> Madrid ExchangeShoppingMachine
    +-- FACADE ------> Facade ExchangeShoppingMachine
    +-- FARELOGIX ---> Facade ExchangeShoppingMachine
```

### Provider Routing (AirExchangeShopping)

```scala
provider match {
  case AMADEUS             => madrid client (Amadeus GDS)
  case FARELOGIX_NDC       => facade client
  case FACADE              => facade client
  case SABRE | UNSPECIFIED => sabre client (Southlake -- default)
}
```

**Note:** Both `FARELOGIX_NDC` and `FACADE` route to the same facade client. `FACADE` additionally uses a `FacadeSupplier` sub-enum to specify the specific NDC integration (e.g., `AMADEUS_NDCX`, `SABRE_NDC_B6`, `FRONTIER_NDC`).

### Exchange Actions (RequestedSlice)

A `RequestedSlice` represents a slice from the user's existing itinerary and the action to perform on it:

| Action | Meaning |
|--------|---------|
| `CHANGE` | Replace this slice with new flights |
| `KEEP` | Retain this slice unchanged |
| `FLOWN` | Already flown, ignore |
| `ADD` | Add new trip |
| `REMOVE` | Remove trip |

### Provider Shopping Details

- **Facade (NDC):** ExchangeShoppingMachine retrieves the existing order via OrderRetrieve, computes trips to shop (CHANGE/ADD) and trips to cancel (KEEP), then calls OrderReshop with `ExchangeIndicator=ON`. See [Facade Provider Details](references/facade-providers.md).
- **Southlake (Sabre):** ShoppingMachine opens a Sabre session, reads the PNR, and calls `ExchangeShoppingRQ` SOAP. See [GDS Provider Details](references/gds-providers.md).
- **Madrid (Amadeus):** ExchangeShoppingMachine (v2) calls `Ticket_ATCShopperMasterPricerTravelBoardSearch` (extended variant first, standard fallback). See [GDS Provider Details](references/gds-providers.md).

---

## Phase 3: Exchange Booking

Exchange booking is the most complex phase. The architecture depends on whether the provider is Facade (NDC) or GDS:

- **All providers:** `flights-exchange` ExchangeBookingMachine is the outer orchestrator
- **Facade (NDC):** Delegates to `flights-provider-facade` ExchangeBookingMachine
- **Sabre GDS:** Delegates to `Southlake` ExchangeBookingMachine
- **Amadeus GDS:** Delegates to `Madrid` ExchangeBookingMachine

All paths use a **two-phase approach**: Price Quote first, then Finalize (Book & Ticket or Abort).

### Newark API Endpoints (Cart Flow)

Exchanges are represented as product modifications through the Commerce Cart service:

```
POST /cart/flightsExchange/quote   (Schedule/Poll) --> Commerce Cart service
POST /cart/flightsExchange/fulfill (Schedule/Poll) --> Commerce Cart service
```

**Quote flow:**
1. **Schedule:** Look up order by reservationId via `CartLookupService`, then call `OrderCommandService.initiateModificationQuote()` with `FlightModificationRequested` (reason: `UserExchanged`)
2. **Poll:** Poll via `QuoteQueryService.pollQuote()`, get breakdown via `QuoteQueryService.quoteBreakdown()`, unpack `FlightsExchangePriceQuote` pricing details. Returns `AppItineraryPricing`

**Fulfillment flow:**
1. **Schedule:** Get quoted breakdown, extract payment method from original order (prefers last payment method, credit card only -- rejects APM/alternative payment methods). Create purchase payment via `CartPaymentService`, add payment instances to quote, initiate fulfillment via `QuoteCommandService.initiateFulfillment()`
2. **Poll:** Poll via `QuoteQueryService.pollFulfillment()`, retrieve order state via `CartSummaryService.cartState()`, construct `ShareableItinerary` with full app model

> **V2 flow (legacy):** Newark also has older V2 endpoints (`POST /exchangeBook/price` and `/exchangeBook/finalize`) that call `flights-exchange.scheduleExchangePriceQuote()` and `scheduleExchangeFinalize()` directly, bypassing the Commerce Cart service. See `ExchangeBookController` and `FlightsExchangeBackedExchangeBookService` in `newark-mobile-api/src/main/scala/com/hopper/newark/mobileapi/v2/exchange/`.

### flights-exchange ExchangeBookingMachine (Outer Orchestrator)

This machine coordinates the entire exchange regardless of provider. It retrieves user/itinerary/trip data, validates eligibility (pending schedule changes, BSP, exchange window), selects the shopped fare, computes the exchange diff, then delegates to the provider machine for price quoting and finalization. After finalization, it handles payment, publishes post-ticketing requests to Brooklyn, writes remarks, and tracks metrics.

For the full step-by-step breakdown, see [flights-exchange Machine Details](references/flights-exchange-machine.md).

### Provider Booking Details

- **Facade (NDC):** ExchangeBookingMachine retrieves order, reshops flights, then accepts offer via OrderChange (`AcceptOfferRequest`) and books via OrderChange (`AddPaymentInstrumentRequest`). Key difference: for Amadeus NDCX the accept step maps to `OrderReshop` action, while for Sabre NDC B6 both steps use `OrderChange`. Sabre B6 also requires an additional `OrderQuote` step. See [Facade Provider Details](references/facade-providers.md).
- **Southlake (Sabre):** ~30-step stateful Sabre session: cancel segments, sell new, reprice, then `AutomatedExchangesLLSRQ` for pricing/commit, per-passenger ticketing via `ExchangeTicketMachine`. See [GDS Provider Details](references/gds-providers.md).
- **Madrid (Amadeus):** v17 machine with stateful Amadeus session: cancel segments, sell from recommendation, reprice, reissue confirmed pricing, per-passenger ticketing via `IssueTicketMachine` fold. See [GDS Provider Details](references/gds-providers.md).

### GDS vs Facade: Key Differences

| Aspect | GDS (Southlake/Madrid) | Facade (NDC) |
|--------|----------------------|--------------|
| **Session model** | Stateful GDS session maintained throughout | Stateless API calls |
| **Shopping API** | Sabre: `ExchangeShoppingRQ`; Amadeus: `FMPTBQ` | OrderReshop with ExchangeIndicator=ON |
| **Booking approach** | Cancel segments + sell new + reprice in PNR | Accept offer + OrderChange |
| **Ticketing** | Per-passenger ticket issuance (dynamic machine) | Single OrderChange with payment |
| **Payment** | FOP created in GDS session | Payment passed in OrderChange request |
| **Queue checks** | Built-in queue history validation | Not applicable (queueless) |
| **Error recovery** | Session rollback (ignore transaction) | Retry or abort |

For full machine step details, see [GDS Provider Details](references/gds-providers.md) and [Facade Provider Details](references/facade-providers.md).

### Brooklyn Post-Ticketing Integration

After exchange finalization, `flights-exchange` publishes a post-ticketing request to Brooklyn:

1. `flights-exchange` builds a `PostTicketingRequest` with the exchange result
2. Publishes to `locator-requests` Pub/Sub topic
3. Brooklyn's `locator_queues` worker consumes the event
4. Brooklyn PTM processes: updates itinerary, handles locator queue, sends confirmation
5. Exchange remarks are written with `ModifyReasonType.Voluntary`

---

## Async Schedule/Poll Pattern

All exchange operations use an asynchronous **schedule/poll** pattern because provider calls are long-running:

```
Client                    Service                   State Machine
  |                         |                           |
  |-- Schedule(request) --> |                           |
  |                         |-- Start session --------> |
  |<-- 200 OK (token) ----- |                           |
  |                         |                           |
  |-- Poll(token) --------> |                           |
  |                         |-- Check status ---------->|
  |<-- Pending ------------ |                           |
  |                         |                           |
  |-- Poll(token) --------> |                           |
  |                         |-- Check status ---------->|
  |<-- Result ------------- |<-- Complete --------------|
```

This pattern appears at every layer:
- Newark <-> flights-exchange (price quote + finalize)
- AirExchangeShopping <-> provider (Southlake / Madrid / facade)
- flights-exchange <-> provider machine (price quote + finalize via `RemoteExchangeBookMachineApi`)

Typical polling latency: 6-15 seconds for shopping, 20-minute global timeout for booking with 90-second provider polling timeout.

---

## Payment & Settlement

Exchange booking supports three payment methods:

| Method | Description |
|--------|------------|
| **Cash (Direct)** | |
| **User Card** | Customer's saved credit card is charged for the fare difference |
| **VCC (Virtual Credit Card)** | Generated virtual card |

**Payment flow in flights-exchange:**
1. Determine settlement method from cart/booking context
2. If VCC needed: call Portland API to generate virtual card
3. Pre-authorize payment amount
4. Pass payment details to provider machine
5. On failure: rollback authorization

**GDS-specific:** Sabre uses `AutomatedExchangeCommit` with optional authorization code; Madrid uses `FOP_CreateFormOfPayment` (TFOPCQ) with conditional preauth flow.

---

## Feature Flags

### Exchange Eligibility Flags

| Flag | Service | Purpose |
|------|---------|---------|
| `AmadeusNdcxExchangeShopAC` | flights-servicing-eligibility | Enables exchange for AmadeusNdcx (AC carrier only) |
| `FarelogixNdcExchangeShop` | flights-servicing-eligibility | Enables exchange for FarelogixNdc provider |
| `BasicEconomyExchIneligibility` | support-remoteui | Enable basic economy ineligibility check |

### Exchange Booking Flags

| Flag | Service | Purpose |
|------|---------|---------|
| `InternalFlightsExchangeForcePriceQuoteAutomation` | flights-exchange | Force automation even if unsupported |
| `InternalFlightsExchangeKustomerTest` | flights-exchange | Test Kustomer integration (Control, BookingError, PaymentError, PostCommitError) |
| `FlightsExchangePostCommitErrorFulfillmentSuccess` | flights-exchange | Handle post-commit errors gracefully |
| `KustomerMessageServiceExchange` | flights-exchange | Enable Kustomer message service for exchanges |

### Exchange Shopping Flags

| Flag | Service | Purpose |
|------|---------|---------|
| `FarelogixNdcExchangeShop` | Newark | Control FarelogixNDC provider availability in shopping |
| `FlightExchangeAutomationCartForApp.AllowCartAutomatedExchanges` | Newark | Gate automated exchanges (Cart flow, rolled out 100%) |
| `ShopWhitelistAmadeusNdcx` | flights-provider-facade | Whitelist Amadeus NDCX for shopping |

---

## Failure Modes & Error Codes

See [flights-exchange Machine Details](references/flights-exchange-machine.md) for the full list of error codes and failure modes.

---

## Key File Locations

See [File Locations Reference](references/file-locations.md) for the complete list of key files across all exchange repos.

---

## Entry Points (gRPC & HTTP)

| Protocol | Endpoint / RPC | Description |
|----------|---------------|-------------|
| gRPC | `FlightsServicingEligibilityService.GetReport` | Combined eligibility report including exchange; first call in user journey |
| gRPC | `AirExchangeEligibilityService.GetPreCheckExchangeEligibility` | Fast pre-check; called by support-remoteui |
| gRPC | `AirExchangeEligibilityService.GetExchangeEligibility` | Full provider-level eligibility; currently dormant (zero production traffic) |
| gRPC | `AirExchangeShoppingService.ExchangeShop` | Initiate exchange fare search across providers |
| gRPC | `AirExchangeShoppingService.TripResult` | Retrieve stored trip from Bigtable cache; used by flights-exchange during price quoting |
| gRPC | `FlightsExchangeService.ScheduleExchangePriceQuote` | Initiate async price quote |
| gRPC | `FlightsExchangeService.PollExchangePriceQuote` | Poll price quote session |
| gRPC | `FlightsExchangeService.ScheduleExchangeFinalize` | Initiate async finalization (confirm or abort) |
| gRPC | `FlightsExchangeService.PollExchangeFinalize` | Poll finalization session |
| HTTP | `POST /api/v1/exchangeEligibility` (facade) | NDC provider exchange eligibility, called by flights-servicing-eligibility |

---

## Terminology

| Term | Meaning |
|------|---------|
| PNR | Passenger Name Record (booking) |
| GDS | Global Distribution System (Sabre, Amadeus) |
| NDC | New Distribution Capability (airline direct connect) |
| PCC | Pseudo City Code (agent/office identifier) |
| VCC | Virtual Credit Card |
| PTM | Post-Ticketing Machine (Brooklyn) |
| FTC | Future Travel Credit |
| BSP | Billing and Settlement Plan |
| FOP | Form of Payment |
| FSE | flights-servicing-eligibility |
| FO | Fare Optimization |
| HTS | Hopper Technology Solutions (B2B tenants) |
| Queueless | Providers using NDC APIs directly (no GDS queue polling) |
| OrderReshop | NDC API to get new pricing for changed flights |
| OrderChange | NDC API to finalize exchange (accept offer + payment) |
| OrderRetrieve | NDC API to fetch existing booking details |
| OrderQuote | NDC API to get final quote before booking (Sabre B6 only) |

For GDS-specific API command codes (AutomatedExchangesLLSRQ, FMPTBQ, PNRRET, etc.), see [GDS Provider Details](references/gds-providers.md).
