---
name: flights-connectivity-autocover
description: >-
  Generate high-quality unit tests for a Flights Connectivity Scala/SBT
  repository and open a PR. Scoped exclusively to Flights Connectivity repos.
  Use when user explicitly asks to "run flights-connectivity-autocover".
  Do NOT trigger for general test requests like "add tests" or "improve coverage".
  Also triggered by scheduled runs against the Flights Connectivity repo list.
  Requires: gh CLI, sbt, Java 17+, hopper-developer plugin (for datadog-ops skill).
---

# Flights Connectivity Autocover

Generate high-quality unit tests for a Flights Connectivity Scala/SBT
repository, validated with Stryker4s mutation testing, and open a PR with the
results.

**Scope:** This skill operates exclusively on Flights Connectivity repos. See
the [flights-travel-agency-repos skill](hopper-flights:flights-travel-agency-repos)
for the full list.

**Invocation (ad hoc):** Ask Claude to "run flights-connectivity-autocover" in any Flights
Connectivity repo.

**Invocation (scheduled):** `claude -p "$(cat path/to/SKILL.md)" --skip-frontmatter`

**Prerequisites:**
- gh CLI authenticated with repo write access
- hopper-developer plugin installed (provides datadog-ops skill for production data)
- sbt available on PATH, Java 17+

**Expected outputs:**
- SUCCESS: A PR containing **new or improved test files** (`.scala` files under `src/test/`) with label `flights-connectivity-autocover` on branch `flights-connectivity-autocover/<module-name>`
- SUCCESS (bugfix): Zero or more separate PRs containing **actual code fixes** (not documents) for production bugs found during analysis
- SKIP: Outputs `SKIP: <repo> — open flights-connectivity-autocover PR already exists (#<number>)` and moves to next repo
- SKIP (all): Outputs `SKIP: All repos scheduled for today have open flights-connectivity-autocover PRs` and exits
- ERROR: Structured error message if PR creation fails

**The PR MUST contain test code.** Do not create PRs that only contain
analysis documents, findings, recommendations, or markdown files. If you
encounter obstacles (private methods, complex mocking, large files), solve
them — do not document them as "challenges" and stop.

---

## Phase 0: Select Repo & Gate Check

Determine today's day of the week and select the repos assigned to that day.
For each repo, check whether it already has an open PR with the
`flights-connectivity-autocover` label. Select the first repo that does not.

**Daily repo schedule:**

| Day       | Repos                                                                  |
|-----------|------------------------------------------------------------------------|
| Monday    | flights-provider-integration-consolid, flights-provider-facade         |
| Tuesday   | Madrid, flights-provider-integration-letsfly                           |
| Wednesday | London, flights-provider-integration-azul                              |
| Thursday  | Southlake, flights-provider-integration-ndc                            |
| Friday    | flights-provider-integration-fr24, flights-provider-integration-amadeux-ndcx |

Only process the repos assigned to today. If today is a weekend, skip the run
entirely and output: `SKIP: No repos scheduled on weekends`.

**For each repo scheduled today, run:**

```bash
gh pr list --repo hopper-org/<repo> --label flights-connectivity-autocover --state open --json number,title
```

- If open PRs exist, log: `SKIP: <repo> — open flights-connectivity-autocover PR already exists (#<number>)` and continue to the next repo.
- If no open PRs, select this repo and proceed to Phase 1.
- If all of today's repos have open PRs, output: `SKIP: All repos scheduled for today have open flights-connectivity-autocover PRs` and stop.

**Clone the selected repo:**

```bash
gh repo clone hopper-org/<repo> -- --depth=50
cd <repo>
```

## Phase 1: Research & Prioritization

### 1a. Install Stryker4s

- Add to project/plugins.sbt:
    `addSbtPlugin("io.stryker-mutator" % "sbt-stryker4s" % "0.14.3")`
- Add to build.sbt (top-level):
    `ThisBuild / strykerIsSupported := true`
- Verify the plugin loaded for the target subproject: `sbt "project <module>" compile`
  If the project is multi-module, confirm stryker is available in the subproject
  you plan to test (not just root).

### 1b. Detect Test Framework

- Scan existing test files (`src/test/scala/**/*Spec.scala`, `*Test.scala`)
- If majority use org.specs2 → write Specs2 tests
- If majority use org.scalatest → write ScalaTest tests
- Match the dominant style, imports, and assertion patterns you observe

### 1c. Identify High-Value Targets

Use the [datadog-ops skill](hopper-developer:datadog-ops) to query Datadog.
Invoke it to search logs, query metrics, and check APM spans for this service.
Specifically, gather:
- Top 20 endpoints/code paths by request volume (last 7 days)
- Top error classes and exception types (last 7 days)
- Any recent error spikes or anomalies

Map Datadog findings back to source files in the repo.

### 1d. Assess Current Coverage

Run `sbt coverage test coverageReport`, or if scoverage is not configured,
analyze existing test files to identify which source files have no corresponding
tests.

### 1e. Prioritize Files

Rank source files by: (production importance from Datadog) × (lack of coverage).
Select the top 3-5 files regardless of complexity. If a file requires mocking
external dependencies, mock them. Do not skip files because they are hard to test.

**Do skip** files that are purely static data with no behavioral logic (e.g.,
constant maps, enum definitions, config objects). These cannot produce
meaningful behavioral tests — testing them just mirrors the source data.

### 1f. Fix Production Bugs (MANDATORY)

You MUST investigate and fix production bugs before writing tests. Do not skip
this step. Do not defer fixes to the team. Do not create "findings" or
"recommendations" documents instead of actual code fixes.

Use the [datadog-ops skill](hopper-developer:datadog-ops) to review error logs
for the selected files. For each bug you find (e.g., incorrect error handling,
off-by-one errors, race conditions, missing null checks):

1. Do NOT write tests that protect the buggy behavior
2. Investigate the root cause by reading the source code, understanding the
   expected behavior, and tracing the error path
3. Write the actual fix. If a method is `private[this]` and untestable, change
   its visibility or refactor to make the fix testable — this is a bug fix PR,
   not just a test PR
4. Create a **separate branch and PR** for each bug fix:
   - Branch: `flights-connectivity-autocover/bugfix/<short-description>`
   - Title: `fix: <description of the bug>`
   - Label: `flights-connectivity-autocover`
   - Body: include Datadog evidence (error logs, traces) and explanation of the fix
5. Collect the URLs of all bug fix PRs to include in the main coverage PR

If you find zero production bugs after thorough investigation, state that
explicitly and proceed to Phase 2. But production errors in Datadog almost
always indicate real bugs — do not rationalize them away.

## Phase 2: Write Tests

The goal is **behavioral guardrail tests** — tests that will catch real bugs
when an agent or developer modifies the codebase. Every test should protect
against a plausible mistake someone could make while changing this code.

### 2a. What NOT to Test

Do not write tests that merely transcribe source data back into assertions.
These are brittle (break whenever values are added) and catch nothing a
compiler wouldn't. Specific anti-patterns to avoid:

- **Exhaustive enum/set membership**: Do not individually assert that each
  member of a set or sealed trait hierarchy exists. Instead, test the
  *behavior* that depends on those members (e.g., "retriable errors are
  retried", not "retriableErrors contains X").
- **Static map mirroring**: Do not re-assert every key-value pair in a
  lookup table. Instead, test the function that *uses* the map — e.g., verify
  that `composeFareBrand("UA", brand)` returns the right brand type for a
  representative sample, and test what happens for unknown keys.
- **Constructor smoke tests**: Do not test that case classes can be
  instantiated or that fields hold the values passed to them.
- **Type-checking assertions**: Do not assert `x must beAnInstanceOf[Y]`
  when the compiler already guarantees it.

### 2b. What TO Test

Focus on logic that, if broken, would cause a production incident:

- **Branching logic and conditionals**: if/match arms, especially error
  handling paths and fallback behavior
- **Data transformations**: parsing, serialization, mapping between domain
  types — test with realistic inputs from Datadog traffic
- **Edge cases from production errors**: use Datadog error patterns to
  construct test inputs that exercise known failure modes
- **Invariants the code relies on**: e.g., "retriable and unretriable sets
  are disjoint" — this is a behavioral property, not a membership list
- **Integration boundaries**: verify that mocked dependencies are called
  with the right arguments and that their responses are handled correctly

### 2c. Write the Tests

For each selected file, in priority order:

1. Read the source file thoroughly
2. Read any existing test file for that source
3. Write new tests or extend existing tests that:
   - Test behavioral code paths (informed by Datadog traffic data)
   - Cover edge cases and error conditions observed in production
   - Use the repo's existing test framework and conventions
   - Use representative samples, not exhaustive enumeration
   - Mock external dependencies and verify interaction patterns
4. Run the tests to verify they pass: `sbt "testOnly *YourNewSpec"`

**Overcoming obstacles — do not give up:**

- **Private methods**: Widen visibility (e.g., `private[this]` →
  `private[packagename]`) so tests can reach the method. This is an
  acceptable trade-off for testability.
- **Complex mocking**: Study how existing tests in the repo set up mocks.
  Copy their patterns. If no patterns exist, create minimal trait-based
  mocks. Do the work — do not skip the file.
- **Large files**: Test the most critical methods, not the entire file.
  Stryker can be scoped to specific mutant ranges if needed.
- **Unfamiliar domain**: Read the source code, read Datadog logs for
  real request/response examples, and use those as test fixtures.

You MUST produce at least one new test file or extend an existing one.
A run that produces zero test code is a failure.

## Phase 3: Validate & Ship

### 3a. Stryker Validation

Create `stryker4s.conf` scoped to your tested source files. Use `**` glob prefix
for file names (module-relative paths do not work):

```hocon
stryker4s {
  mutate = ["**/File1.scala", "**/File2.scala"]
  concurrency = 4
  reporters = ["console"]
}
```

Run: `sbt "project <module>" stryker`

Time budget: 10 minutes. If Stryker exceeds this, reduce scope.

**Known limitations of Stryker4s 0.14.3:**
- Some Scala patterns (sealed traits, case classes, implicit classes) produce
  0 mutants. If a file generates no mutations, skip Stryker validation for it.
- StringLiteral mutations (error messages → "") often dominate surviving mutants
  but are low-value. If most survivors are string literals in error messages,
  consider adding `excluded-mutations = ["StringLiteral"]` to the config and
  re-running to get a more meaningful score.

### 3b. Kill Surviving Mutants

For each file with mutation score < 65%:
- Review the surviving mutants
- Add or improve test assertions to kill them
- Re-run Stryker scoped to just that file
- Iterate up to 3 times per file
- If a file stays below 40% after 3 iterations, drop the test file — it's not
  adding enough value. Note the file in the PR as "attempted but insufficient
  mutation coverage"

### 3c. Clean Up

- Remove the stryker4s line from project/plugins.sbt
- Remove strykerIsSupported from build.sbt
- Remove stryker4s.conf
- Do NOT include stryker setup in the PR
- Do NOT include analysis documents, findings files, or markdown files
  (e.g., `AUTOCOVER_FINDINGS.md`) in the PR — only test code and any
  necessary source changes (visibility widening, etc.)

### 3d. Full Test Run

Run: `sbt "Test / test"`
- All tests (existing + new) must pass
- Total test runtime must be under 5 minutes
- If new tests are slow, optimize or remove the slowest ones

### 3e. Open PR

Create a branch named `flights-connectivity-autocover/<module-name>` (e.g., `flights-connectivity-autocover/southlake-server`).

Format code: `sbt scalafmtAll`

Create PR with:
- Title: `chore: improve unit test coverage for <primary module>`
- Label: `flights-connectivity-autocover`
- Body should include:

```markdown
## Summary
- Which files were tested and why (Datadog importance + coverage gap)
- Mutation scores achieved per file

## Bug Fix PRs
- Links to any separate bug fix PRs created during this run
- For each: brief description of the bug and Datadog evidence

## Stryker Results
- Per-file mutation scores (before and after)
- Any surviving mutants that could not be killed and why

## Test Quality Notes
- Test framework used and why
- Any notable mocking strategies for complex dependencies
```
