---
name: flights-travel-agency-repos
description: >-
  Discover Flights Travel Agency repositories in the hopper-org GitHub organization.
  Use when user asks to "find flights repos", "list travel agency repos",
  "which repos does flights team own", or needs to discover services and libraries
  maintained by the Flights Travel Agency team.
---

# Flights Travel Agency Repos

List all Flights Travel Agency repositories:

```bash
gh search repos --owner hopper-org --topic flights-travel-agency --limit 100
```

## Flights Connectivity Repos

A subset of Travel Agency repos owned by the Flights Connectivity team:

- Southlake
- flights-provider-facade
- London
- Madrid
- flights-provider-integration-ndc
- flights-provider-integration-amadeux-ndcx
- flights-provider-integration-letsfly
- flights-provider-integration-fr24
- flights-provider-integration-consolid
- flights-provider-integration-azul
