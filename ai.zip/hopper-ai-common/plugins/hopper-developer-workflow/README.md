# hopper-developer-workflow

An opinionated plugin for the standard Hopper development workflow.

## Install

```
/plugin marketplace add hopper-org/hopper-ai-common
/plugin install hopper-developer-workflow@hopper-ai-common
```

## Skills

| Skill | Description |
|-------|-------------|
| `pull-requests` | Pre-PR checklist — run tests, format code, commit, and create the PR |
