---
name: pull-requests
description: >-
  Use when preparing code for a pull request or writing PR descriptions. Triggers:
  "create a PR", "open a PR", "submit for review", "ready for review", "ship it",
  "merge this", "push my changes", "write a PR description", "PR template", or asks
  about the pre-PR checklist, dev workflow, or how to submit code at Hopper.
---

# Pull Requests

## Overview

This is a skill for the standard Hopper development workflow. It defines the steps engineers should follow before and after creating a pull request. Always run through these steps in order.

**Critical:** When operating autonomously (e.g., via Slack), you MUST monitor CI checks after creating the PR and fix any failures immediately. This is not optional.

## Branch Naming Convention

When creating a new branch, prefix its name with the user's GitHub username (stripping the _hopper suffix) followed by `/`.

**Format:** `{github_username_no_hopper_suffix}/{branch-name}`

**Examples:**
- `flastname/add-payment-retry`
- `sotherlastname/fix-null-pointer-in-search`
- `tuser/update-dependencies`

**Why:** Prevents branch name collisions when multiple people or Hopper AI sessions work on similar changes.

**How to determine the username:**
- Run `gh api user --jq '.login' | sed 's/_hopper$//'`

## Pre-PR Checklist

### 1. Rebase onto Latest Main Branch

Before doing anything else, rebase your branch onto the latest commit from the hopper-org repo's main branch. The main branch is usually `master` or `main`.

First, you will need to find the name of the remote pointing to the `hopper-org` repo. Then, fetch the latest from the main branch and rebase. Resolve any conflicts that arise during the rebase.

```bash
git remote -v              # find the remote for hopper-org
git fetch hopper           # replace "hopper" with the correct remote name
git rebase hopper/master   # or hopper/main
```

This ensures your PR is not out-of-date and avoids merge conflicts later. Do this before running tests, formatting, or pushing code.

### 2. Add Tests (non-trivial changes only)

| Change type | Add tests? |
|---|---|
| Config, docs, copy updates | No |
| Simple refactors (no behavior change) | No |
| New features or new behavior | Yes |
| Bug fixes with edge cases | Yes |
| Changes to core logic | Yes |

For non-trivial changes — new features, bug fixes with edge cases, or changes to core logic — add unit tests to cover the changes. Skip this step for trivial changes like config tweaks, copy updates, or simple refactors.

Focus on tests that:
- Cover the primary behavior being added or changed
- Validate edge cases that caused the bug being fixed
- Protect against regressions in critical paths

Do not add low-value tests just for coverage. A few well-targeted tests are better than many superficial ones.

### 3. Run Formatter

Run the project's code formatter to ensure consistent style before creating a PR.

| Build system | Format command |
|---|---|
| sbt (Scala) | `sbt --client scalafmtAll` |
| npm / yarn / pnpm / bun | Check `package.json` scripts for `format` or `lint:fix` |
| buf (protobuf) | `buf format -w` |

For other build systems, check the repo's `README.md` or Github Actions workflows (`.github/workflows`) for the correct formatting command.

After formatting, stage any formatting changes and include them in your commit.

### 4. Run Tests

Run the project's test suite and ensure all tests pass before creating a PR.

| Build system | Test command |
|---|---|
| sbt (Scala) | `sbt --client test` |
| npm / yarn / pnpm / bun | Check `package.json` scripts for `test` |

For other build systems, check the repo's `README.md` or GitHub Actions workflows (`.github/workflows`) for the correct test command.

If tests fail, fix the failures and try again. Repeat this **up to 3 times**.

If you still cannot get the tests passing after 3 attempts, ask the user for guidance on what to do next. The user may want to go ahead and create the PR, or may offer help in fixing the test failures.

### 4. Check PR Template for Additional Instructions

Look for `.github/PULL_REQUEST_TEMPLATE.md` or `.github/pull_request_template.md` in the repo. If a template exists, read it to understand:

- What sections are required (e.g., "What", "Test plan", "Checklist")
- What checkboxes need to be filled (e.g., "[ ] New feature", "[ ] Bug fix")
- Any repo-specific requirements (e.g., ticket references, migration steps)

If no template exists, skip this step.

### 5. Commit with Conventional Commits

All commits must follow [Conventional Commits](https://www.conventionalcommits.org/). We most commonly use the following prefixes:

- `feat:` — New feature (significant change)
- `fix:` — Bug fix or minor change
- `chore:` — No deployment needed (docs, config, tooling)

See [release-me skill](hopper-developer:release-me) for all available prefixes, and how they map to version bumps.

### 6. Create the PR and Share the Link

Once tests pass and code is formatted, create the pull request.

**PR title** must follow [Conventional Commits](https://www.conventionalcommits.org/) (enforced by CI). See the [release-me skill](hopper-developer:release-me) for details on how commit prefixes map to version bumps.

**PR description:**

If a template exists (from step 4), use it:
- Fill out all required sections
- Pre-check boxes that correspond to what's done in the PR (e.g., `[x] Bug fix`)
- Leave unchecked boxes blank if they don't apply

If no template exists, use this minimal structure:

```markdown
## Jira Ticket
https://hopper-jira.atlassian.net/browse/XXX-0000

## What
[Problem/motivation and solution if not obvious from diff]
```

When writing your description:

- **Summary/What** — State the problem/motivation. Explain the solution only if it's not obvious from the diff (complex logic, domain knowledge, non-obvious tradeoffs). Keep it concise (1-3 sentences). Focus on *why*, not *what* — the diff shows what changed.
- **Test plan** — Describe scenarios to verify, not how to test. Do NOT mention formatters/linters (expected for all PRs).
- **Ticket reference** — Link to the relevant Jira ticket or GitHub issue, if applicable.
- **Template checkboxes** — Pre-check boxes that apply (e.g., `[x] Bug fix`), leave others unchecked.

**IMPORTANT: Send the PR link to the user immediately after creation.** Do not wait for CI checks to finish before sharing the link — the user needs it right away to review the diff while CI runs in parallel. Share the link first, then proceed to monitor CI.

### 7. Monitor CI After Opening (REQUIRED)

**IMPORTANT:** You MUST monitor CI checks after creating a PR. This is non-negotiable when operating autonomously (e.g., via Slack) — users expect CI to pass without manual follow-up. Do not wait for the user to report failures; watch CI proactively and fix issues as they surface.

**Immediately after creating the PR, watch CI status:**

```bash
gh pr checks --watch
```

If `--watch` is not available (non-interactive environments, background tasks), poll manually every 10-30 seconds until all checks complete:

```bash
gh pr checks
```

**Continue watching until:**
- All required checks pass, OR
- You've attempted to fix failures 3 times, OR
- The user asks you to stop

**When checks fail:**
1. Identify the failing check from the output
2. Read the CI log to understand the failure: `gh run view <run-id> --log-failed`
3. Fix the issue — common failures:
   - **Lint/formatting** — run the formatter (step 3) and push
   - **Test failures** — read the failure output, fix the test or code, push
   - **Build/compilation errors** — fix imports, type mismatches, missing dependencies
   - **Dependabot / compliance checks** — check if dependency overrides are needed
4. Push the fix and continue watching. Repeat up to 3 times.
5. If still failing after 3 attempts, notify the user with:
   - The failing check name
   - Relevant excerpts from the CI log
   - What you tried to fix it
   - Ask for guidance on next steps

**Example autonomous flow:**
```bash
# 1. Create PR
gh pr create --title "..." --body "..."

# 2. IMMEDIATELY share the PR link with the user (don't wait for CI)
# e.g., send a message with the PR URL so they can start reviewing

# 3. Start watching CI
gh pr checks --watch

# 4. If lint fails:
gh run view <run-id> --log-failed   # read the failure
npm run lint -- --fix               # fix it
git add . && git commit && git push # push fix
gh pr checks --watch                # resume watching
```

### 8. Addressing Automated Review Bot Comments

Automated bots may add review comments to PRs flagging potential issues (e.g., security vulnerabilities, code quality problems). When asked to address these issues:

1. Fetch the PR's unresolved review threads using the GraphQL API (the REST API does not expose resolved state)
2. **Only act on unresolved comments** — resolved comments indicate issues that have already been fixed. A review service resolves comments as fixes are pushed, so treating resolved comments as outstanding will lead to unnecessary or duplicate work.
3. For each unresolved comment, read the comment body to understand the issue, then fix it in code

```bash
gh api graphql -f query='
  query($owner: String!, $repo: String!, $pr: Int!) {
    repository(owner: $owner, name: $repo) {
      pullRequest(number: $pr) {
        reviewThreads(first: 100) {
          nodes {
            isResolved
            comments(first: 10) {
              nodes {
                body
                author { login }
                path
                line
              }
            }
          }
        }
      }
    }
  }
' -f owner='{owner}' -f repo='{repo}' -F pr={pr_number} | \
  jq '.data.repository.pullRequest.reviewThreads.nodes[] | select(.isResolved == false)'
```

**Key rule:** If a comment thread is marked as resolved, skip it entirely. Do not re-fix or re-evaluate resolved issues.

### 9. Updating an Existing PR

When pushing additional changes to an existing PR, review the PR title and description. If the new changes significantly change what the PR is doing — e.g., adding a new feature on top of a refactor, or changing the approach — update the title and description to accurately reflect the current state of the PR.

No update is needed for minor follow-ups like fixing typos, addressing review feedback, or small tweaks that don't change the PR's purpose.

## Common Mistakes

- **Not sharing the PR link immediately** — always send the PR URL to the user right after creation, before monitoring CI. Don't make them wait for CI to finish before they can see the PR.
- **Not watching CI after creating PR** — the #2 mistake. You MUST monitor CI checks immediately after opening a PR and fix failures proactively. Don't wait for the user to report them.
- **Skipping the formatter** — leads to CI failures on style checks. Always format before pushing.
- **Adding boilerplate tests** — tests that don't cover real behavior add noise. Focus on high-value assertions.
- **Creating a PR with failing tests** — if tests won't pass after 3 attempts, ask the user instead of pushing broken code.
- **Skipping pre-commit hooks** — never use `--no-verify`. Let hooks run and fix any issues they surface.
- **Verbose PR descriptions** — repeating what's in the diff wastes reviewers' time. Focus on why, not what.
- **Ignoring PR templates** — always check for and use the repo's template if one exists.
- **Mentioning formatters/linters in test plans** — these are expected for all PRs and shouldn't be called out.
- **Acting on resolved review bot comments** — resolved comments have already been addressed. Only fix unresolved comments to avoid duplicate or unnecessary work.

## Important Notes

- Always check the repo's `CLAUDE.md` or `AGENTS.md` for repo-specific build/test/format commands that override the defaults above.
- If you're unsure about the correct commands for a repo, check the `README.md` or CI workflow files (`.github/workflows/`) for guidance.
