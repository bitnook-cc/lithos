---
name: payouts-tenant-onboarding
description: >
  Onboard a new tenant payout method in the customer-payouts service.
  Covers tenant config changes, Spreedly secret provisioning via external secrets,
  BUILD version bumps, and justfile updates for local development.
  Triggers: "customer-payouts onboarding", "add payout method", "configure overRefund",
  "configure pushToCard", "add tenant to customer-payouts", "payout tenant config",
  "Spreedly secrets", "onboard payout", "customer payouts config".
---

# Customer Payouts Tenant Onboarding

## Overview

The `customer-payouts` service handles refunds/payouts for fintech ancillary products (CFAR/DAFAR). Each airline tenant needs configuration for which payout methods it supports (PushToCard, OverRefund, Wise, NoOp, etc.) and the corresponding secrets.

**Repository**: `hopper-org/customer-payouts`
**Operations doc**: https://hopper-jira.atlassian.net/wiki/spaces/PAYMENTS/pages/7909048322/Customer+payouts+Operations

## When to Use This Skill

Invoke this skill when:
- Adding a new tenant to customer-payouts
- Adding a new payout method (overRefund, pushToCard, Wise, etc.) to an existing tenant
- Provisioning Spreedly secrets for a tenant
- Updating secret versions for customer-payouts

## Key Concepts

### Tenant Config Model

Each tenant has a `TenantPayoutConfig` with `PayoutProviderConfigs`:
- `"NoOp"` — passthrough, no actual payout processing (used for CFAR ViaPartner payouts)
- `"Provided"` — real provider configs with weighted routing

`Provided` configs can include multiple payout methods:
- `pushToCard` — push money to customer's credit card (via Nuvei, Ecommpay, Stripe)
- `pushToCardFallback` — fallback providers for PTC
- `bankTransfer` — bank transfer via Wise
- `overRefund` — refund more than charged (via Adyen/Spreedly or Zurich)

### Routing: hc-airlines Chooses the Payout Method

The upstream service `hc-airlines` determines the payout method type sent to customer-payouts:
- CFAR sends `NoOpPayoutMethod` (ViaPartner)
- DAFAR sends `Overrefund.SpreedlyOverrefund`

This means `NoOp` and real providers (e.g., `SpreedlyOverrefund`) can coexist in the same `overRefund` array — they go through separate adapter pools and don't compete with each other.

### Spreedly Secret Sources

First, **ask the user whether the Spreedly environment for this tenant has already been created.**

**If yes** — fetch and read the `hopper-cloud-airlines` BUILD file yourself:
```bash
gh api repos/hopper-org/hopper-cloud-airlines/contents/deployment/workloads/unit/BUILD \
  --jq '.content' | base64 -d
```

Look through the `hc-airlines-payment-conf` and `hc-airlines-payout-conf` `known_keys` blocks for keys that match the tenant. Key naming is not always obvious (e.g. `payout-azal-username` for Azerbaijan Airlines, `payout-gother-username` for GoTher). If you find candidate keys but are unsure which belongs to this tenant, present the options to the user and ask them to confirm.

- If keys are **found** — use the shared secret approach (see Step 5a).
- If keys are **not found** — tell the user explicitly: _"I searched hopper-cloud-airlines BUILD and couldn't find Spreedly keys for this tenant in either `hc-airlines-payment-conf` or `hc-airlines-payout-conf`. Before proceeding with dedicated secrets, please confirm: do you have access to the Spreedly environment key and access secret for this tenant?"_ Only continue to create dedicated GCP secrets (see Step 5a) once the user confirms they have the values.

**If no** — the Spreedly environment doesn't exist yet. Tell the user this is a **blocker**: the Spreedly environment must be created before onboarding can proceed. Ask them to create the environment and come back, or direct them to the [#payments-fraud-team](https://hopchat.slack.com/archives/C07AZ0LJ9FG) Slack channel for clarification.

**Shared secret approach** (keys exist in `hc-airlines-payment-conf` or `hc-airlines-payout-conf`):

| Secret | Key Pattern | Used For |
|--------|-------------|----------|
| `hc-airlines-payment-conf` | `payment-{airline}-username`, `payment-{airline}-password` | Airlines that use Spreedly for payment processing (Frontier, Spirit, Air Canada, Flair) |
| `hc-airlines-payout-conf` | `payout-{airline}-username`, `payout-{airline}-password` | Airlines that use Spreedly for payout processing (AirAsia, Flyadeal, Jazeera, AZAL, OmanAir, GoTher) |

**Dedicated secret approach** (no keys in shared secrets, or user prefers isolation):

Create individual GCP secrets `customer-payouts-{airline}-spreedly-environment-key` and `customer-payouts-{airline}-spreedly-access-secret` via Olympus (see Step 6).

**Non-prod environments** share the same test Spreedly environment (`HTS - Airlines - Test Environment`).

**Production** has per-airline Spreedly environments.

## Step-by-Step Onboarding Process

### Step 1: Identify Requirements

Ask the user:
1. Which tenant (airline)? Get the tenant ID (e.g., `fa-spirit`) and display name (e.g., `"Spirit Airlines"`). For the `amplitudeId`, try to derive it before asking the user:
   - Check `hopper-cloud-airlines` partners config: `gh api repos/hopper-org/hopper-cloud-airlines/contents/hc-airlines/src/main/resources/partners.conf --jq '.content' | base64 -d | grep -A5 '{tenant-id}'` and look for an `id` field that looks like a UUID
   - If not found, do a GitHub code search across hopper-org repos for the tenant ID
   - Only ask the user if you cannot find it
2. Which payout method(s)? Select all that apply: overRefund, pushToCard, bankTransfer, NoOp. A tenant can have multiple methods configured simultaneously.
3. Which environment(s)? (staging, production, development)
4. Does the tenant already have a config, or is this a new tenant?
5. Depending on payout method, collect the following additional data:
   - **OverRefund**: Which Adyen merchant account code? (e.g., `Distributed_fintech_US`). Do **not** assume a default — always confirm with the user.
   - **PushToCard**: What is the default transaction descriptor? This appears on the customer's card statement. Examples from existing tenants: `"HTS*AirAsia Move"`, `"HTS*Jazeera Airways"`. Ask the user to confirm the value.
   - **Wise (bankTransfer)**: What is the transaction descriptor for Wise transfers? Examples from existing tenants: `"HTSAirAsiaMove"`, `"WizzAirDisruptionAssistance"` (no spaces, no asterisk). Ask the user to confirm the value.
   - **NoOp**: No additional data required.

### Step 2: Find Reference Configs

Clone the repo and examine existing tenant configs for the same payout method:

```bash
git clone https://github.com/hopper-org/customer-payouts.git
```

Key config files:
- `server/src/main/resources/base.conf` — **source of truth** for all tenant configs; changes here apply to all environments
- `deployment/configs/app-production-common.conf` — production-only overrides (must always be updated if it contains a `tenantPayoutConfigs` list, which it always does)

Reference patterns by payout method:

**SpreedlyOverrefund only** (e.g., fa-frontier):
```hocon
payoutProviderConfigs: {
  PayoutProviderConfigs: "Provided"
  overRefund: [
    {
      PayoutProviderConfig: "SpreedlyOverrefund"
      weight: 1.0
      merchantAccountCodes: ["Distributed_fintech_US"]
    }
  ]
}
```

**SpreedlyOverrefund + NoOp** (when CFAR NoOp must coexist with DAFAR overrefund, e.g., fa-spirit, hopper-app):
```hocon
payoutProviderConfigs: {
  PayoutProviderConfigs: "Provided"
  overRefund: [
    {
      PayoutProviderConfig: "SpreedlyOverrefund"
      weight: 1.0
      merchantAccountCodes: ["Distributed_fintech_US"]
    },
    {
      PayoutProviderConfig: "NoOp"
      weight: 1.0
    }
  ]
}
```

**PushToCard with providers** (e.g., fa-air-asia):
```hocon
payoutProviderConfigs: {
  PayoutProviderConfigs: "Provided"
  pushToCard: [
    {
      PayoutProviderConfig: "NuveiPushToCard"
      receiverToken: ""
      receiverToken: ${?AIRLINE_NUVEI_RECEIVER_TOKEN}
      weight: 1.0
    },
    {
      PayoutProviderConfig: "EcommpayPushToCard"
      receiverToken: ""
      receiverToken: ${?AIRLINE_ECOMMPAY_RECEIVER_TOKEN}
      weight: 1.0
    }
  ]
}
```

### Step 3: Check for Existing Payouts

Before modifying a tenant config, verify if the tenant already has payouts flowing through customer-payouts:

```sql
SELECT
  fa_product,
  provider,
  COUNT(*) as count
FROM `gcp-hopper-etldata-production.customer_payouts.payout`
WHERE tenant_id = '{tenant_id}'
  AND created_at >= TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 90 DAY)
GROUP BY fa_product, provider
```

If the tenant has existing CFAR NoOp payouts, you MUST preserve the NoOp provider in the config.

### Step 4: Update Tenant Config

Always edit both:
- `server/src/main/resources/base.conf` — default for all environments including staging
- `deployment/configs/app-production-common.conf` — must also be updated; add or update the tenant entry there too

For Spreedly-based methods (overRefund, pushToCard), the tenant block needs:
```hocon
{
  id: "{tenant-id}",
  amplitudeId: "{amplitude-id}"
  name: "{Tenant Name}",
  spreedlyEnvironmentKey: ""
  spreedlyEnvironmentKey: ${?TENANT_SPREEDLY_ENVIRONMENT_KEY}
  spreedlyAccessSecret: ""
  spreedlyAccessSecret: ${?TENANT_SPREEDLY_ACCESS_SECRET}
  payoutProviderConfigs: {
    // ... provider configs
  }
},
```

The double-declaration pattern (empty string then env var override) is required so config spec tests pass when the env var is not set.

### Step 5: Provision Secrets

Depending on whether the Spreedly credentials use the **shared** or **dedicated** secret approach (determined in the Spreedly Secret Sources step above):

#### 5a. `deployment/workloads/unit/external_secret.bzl`

**Shared secret approach** — add to `DATA_FROM_ENV_VARS` and `build_data_from_secrets`:
```python
# DATA_FROM_ENV_VARS
("{secret-key}-username", "{TENANT}_SPREEDLY_ENVIRONMENT_KEY"),
("{secret-key}-password", "{TENANT}_SPREEDLY_ACCESS_SECRET"),
```
Also add `"{secret-key}-username"` and `"{secret-key}-password"` to the appropriate `known_keys` list in `build_data_from_secrets` (`hc-airlines-payment-conf` or `hc-airlines-payout-conf`).

**Dedicated secret approach** — add to `SECRETS_PER_REALM["common"]` instead:
```python
("{airline}-spreedly-environment-key", "customer-payouts-{airline}-spreedly-environment-key", "1", "1", "1", "{TENANT}_SPREEDLY_ENVIRONMENT_KEY"),
("{airline}-spreedly-access-secret",   "customer-payouts-{airline}-spreedly-access-secret",   "1", "1", "1", "{TENANT}_SPREEDLY_ACCESS_SECRET"),
```

#### 5b. `deployment/workloads/unit/BUILD`

Only needed for the **shared secret approach** — bump the appropriate version in `data_from_overrides` for each target environment:
- `airlines_payment_version` — if using `hc-airlines-payment-conf`
- `airlines_payout_version` — if using `hc-airlines-payout-conf`

To find the correct version, check the `hopper-cloud-airlines` repo:
```bash
grep -A1 "hc-airlines-{payment|payout}-conf" hopper-cloud-airlines/deployment/workloads/unit/BUILD
```

The version in customer-payouts should match or exceed the version in hc-airlines for that environment.

#### 5c. `justfile`

Add a credentials loading section for local development:

**Shared secret approach:**
```
# Spreedly creds - {Airline}
echo "Loading {Airline} credentials..." >&2
echo "export {TENANT}_SPREEDLY_ENVIRONMENT_KEY=$(gcloud secrets versions access latest --secret="hc-airlines-{payment|payout}-conf" --project="gcp-hopper-app-development" 2>&1 | jq -r '."{secret-key}-username"')"
echo "export {TENANT}_SPREEDLY_ACCESS_SECRET=$(gcloud secrets versions access latest --secret="hc-airlines-{payment|payout}-conf" --project="gcp-hopper-app-development" 2>&1 | jq -r '."{secret-key}-password"')"
echo "✅ {Airline} credentials loaded" >&2
```

**Dedicated secret approach:**
```
# Spreedly creds - {Airline}
echo "Loading {Airline} credentials..." >&2
echo "export {TENANT}_SPREEDLY_ENVIRONMENT_KEY=$(gcloud secrets versions access latest --secret="customer-payouts-{airline}-spreedly-environment-key" --project="gcp-hopper-app-development")"
echo "export {TENANT}_SPREEDLY_ACCESS_SECRET=$(gcloud secrets versions access latest --secret="customer-payouts-{airline}-spreedly-access-secret" --project="gcp-hopper-app-development")"
echo "✅ {Airline} credentials loaded" >&2
```

### Step 6: PushToCard-Only — Create Receiver Tokens and Olympus Secrets

For PushToCard, receiver tokens and Spreedly secrets must be created in GCP via **two separate Olympus PRs** — one for non-prod (dev + staging) and one for production.

Add to `SECRETS_PER_REALM["common"]` in `external_secret.bzl`:
```python
("{airline}-ecommpay-receiver", "customer-payouts-{airline}-ecommpay-receiver", "1", "1", "1", "{TENANT}_ECOMMPAY_RECEIVER_TOKEN"),
("{airline}-nuvei-receiver",    "customer-payouts-{airline}-nuvei-receiver",    "1", "1", "1", "{TENANT}_NUVEI_RECEIVER_TOKEN"),
("{airline}-stripe-receiver",   "customer-payouts-{airline}-stripe-receiver",   "1", "1", "1", "{TENANT}_STRIPE_RECEIVER_TOKEN"),
```

Also add the corresponding justfile entries:
```
echo "export {TENANT}_NUVEI_RECEIVER_TOKEN=$(gcloud secrets versions access latest --secret="customer-payouts-{airline}-nuvei-receiver" --project="gcp-hopper-app-development")"
echo "export {TENANT}_ECOMMPAY_RECEIVER_TOKEN=$(gcloud secrets versions access latest --secret="customer-payouts-{airline}-ecommpay-receiver" --project="gcp-hopper-app-development")"
echo "export {TENANT}_STRIPE_RECEIVER_TOKEN=$(gcloud secrets versions access latest --secret="customer-payouts-{airline}-stripe-receiver" --project="gcp-hopper-app-development")"
```

**Olympus PRs** — add the following secrets to `apps/customer-payouts/hopper-app/{env}/apps-customer-payouts.tf` in each environment:
```hcl
"customer-payouts-{airline}-nuvei-receiver" : {
  accessors      = local.default_accessors
  version_adders = local.default_version_adders
}
"customer-payouts-{airline}-ecommpay-receiver" : {
  accessors      = local.default_accessors
  version_adders = local.default_version_adders
}
"customer-payouts-{airline}-stripe-receiver" : {
  accessors      = local.default_accessors
  version_adders = local.default_version_adders
}
```
If using the dedicated Spreedly secret approach, also add `customer-payouts-{airline}-spreedly-environment-key` and `customer-payouts-{airline}-spreedly-access-secret` to each environment's TF file.

Receiver tokens are created via the Spreedly API and set manually in GCP Secret Manager after Olympus PRs are applied:

**Ecommpay receiver:**
```bash
curl -X POST \
     -u "{environment_key}:{access_secret}" \
     --data '{"receiver":{"receiver_type":"ecommpay"}}' \
     https://core.spreedly.com/v1/receivers.json
```

**Nuvei receiver:**
```bash
curl -X POST \
     -u "{environment_key}:{access_secret}" \
     --data '{"receiver":{"receiver_type":"safe_charge"}}' \
     https://core.spreedly.com/v1/receivers.json
```

### Step 7: Create PRs

**Olympus** (if secrets need to be created): create two PRs — non-prod (dev + staging) first, then prod. Merge order matters: non-prod → populate secrets → prod → populate secrets → customer-payouts.

**customer-payouts PR** should include:
- Tenant config changes (`base.conf`, `app-production-common.conf`)
- `external_secret.bzl` changes
- `BUILD` version bumps (shared secret approach only)
- `justfile` updates

## Prerequisite: Secret Keys Must Exist in hopper-cloud-airlines

Before adding any secret key to `customer-payouts`, you **must** verify that the key already exists in the `hopper-cloud-airlines` repo's external secret configuration:

```
https://github.com/hopper-org/hopper-cloud-airlines/blob/master/deployment/workloads/unit/BUILD
```

Specifically, the key (e.g., `payment-hopper-username`) must appear in the `known_keys` list of the corresponding `data_from` block (e.g., `hc-airlines-payment-conf`) in that BUILD file. If the key does not exist there, the external secret sync will fail at deploy time because GCP Secret Manager won't have a matching entry.

If the key is missing from `hopper-cloud-airlines`, coordinate with the FA team or Payments team to add it there first — do **not** add it to `customer-payouts` until it exists upstream.

For non-prod, all airlines share the same test Spreedly environment, so the credential values are the same — only the key names are new.

## Common Patterns and Gotchas

1. **NoOp + real provider coexistence**: When a tenant has CFAR (NoOp) and DAFAR (real provider), both go in the `overRefund` array. They don't conflict because `hc-airlines` sends different payout method types, which route to separate adapter pools.

2. **Config-only changes**: Adding a payout method typically requires NO code changes — only config and secret provisioning. The routing is handled by `hc-airlines` upstream.

3. **Double-declaration pattern**: Always use the empty-string-then-env-var pattern for secrets in HOCON config:
   ```hocon
   spreedlyEnvironmentKey: ""
   spreedlyEnvironmentKey: ${?ENV_VAR}
   ```

4. **Merchant account codes**: For SpreedlyOverrefund, `merchantAccountCodes` must match the Adyen merchant account. Common value: `["Distributed_fintech_US"]`.

5. **Version alignment**: The `airlines_payment_version` / `airlines_payout_version` in customer-payouts BUILD should match the version in `hopper-cloud-airlines` BUILD for the target environment.

## File Reference

| File | Purpose |
|------|---------|
| `server/src/main/resources/base.conf` | Default tenant payout configs (all environments) |
| `deployment/configs/app-production-common.conf` | Production tenant payout configs |
| `deployment/workloads/unit/external_secret.bzl` | Secret key mappings and known_keys |
| `deployment/workloads/unit/BUILD` | Secret version numbers per environment |
| `justfile` | Local dev credential loading |
| `server/src/main/scala/.../config/TenantPayoutConfig.scala` | Tenant config data model |
| `server/src/main/scala/.../config/ConfigReader.scala` | Config parsing and adapter construction |
