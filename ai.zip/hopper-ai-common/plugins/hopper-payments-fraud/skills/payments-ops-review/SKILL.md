---
name: payments-ops-review
description: Use when generating the weekly payments fraud operational report — summarizing Datadog alerts, PagerDuty incidents, and engineer investigations from the past on-call shift — and creating a new subpage under the Technical ops review Confluence table of contents.
---

# Payments Ops Review

## Overview

Reads one week of alert activity across three Slack channels, enriches notable alerts with historical frequency and Datadog context, synthesizes a structured report table, and creates a new Confluence subpage under the ops review table of contents. Run at the start of each Tuesday shift.

For noisy or repeatedly auto-resolving alerts, surface the pattern in the report (how often it fired, whether it was ever actioned) and leave the action item blank for the team to decide during the review meeting. Claude can observe patterns but cannot determine whether a monitor should be removed — that judgment belongs to the team.

---

## Key References

| Resource | Value |
|---|---|
| Slack channel — infra alerts | `#devops-alerts-payments-fraud` — ID `C0ADG2HPCNM` |
| Slack channel — ETL/pipeline alerts | `#fraud-etl-alerts` — ID `C02TULA4GF2` |
| Slack channel — SQLMesh/Tobiko alerts | `#fraud-sqlmesh-alerts` — ID `C09VB8Z1VM3` |
| Datadog bot user ID | `U01NE8M479U` |
| PagerDuty bot user ID | `U5XEZJL57` |
| SQLMesh alert bot name | `Fraud Jobs Reporting` |
| Confluence parent page ID (TOC) | `7048593834` |
| Confluence cloud ID | `hopper-jira.atlassian.net` |
| Datadog dashboard | `https://us5.datadoghq.com/dashboard/8u8-8t7-iwr` |

---

## Date Range

The shift starts every **Tuesday**. The report covers the previous Tuesday 00:00 IST → this Tuesday 00:00 IST.

Compute `oldest` Unix timestamp for the Slack query:
```python
import datetime
today = datetime.date.today()
days_since_tuesday = (today.weekday() - 1) % 7  # Tuesday = weekday 1
last_tuesday = today - datetime.timedelta(days=days_since_tuesday)
# IST = UTC+5:30, so midnight IST = UTC 18:30 the previous day
oldest_unix = int(datetime.datetime(last_tuesday.year, last_tuesday.month, last_tuesday.day,
                                    tzinfo=datetime.timezone.utc).timestamp()) - 19800
```

---

## Process

### Step 1 — Read all three Slack channels

Read all three channels in parallel for the reporting period using `response_format: detailed` — this is required to capture the `message_ts` field needed to construct accurate Slack thread links:

```
slack_read_channel(channel_id="C0ADG2HPCNM", oldest=<last_tuesday_unix>, limit=100, response_format="detailed")
slack_read_channel(channel_id="C02TULA4GF2", oldest=<last_tuesday_unix>, limit=100, response_format="detailed")
slack_read_channel(channel_id="C09VB8Z1VM3", oldest=<last_tuesday_unix>, limit=100, response_format="detailed")
```

Slack thread URL format: `https://hopchat.slack.com/archives/{channel_id}/p{message_ts_without_decimal}`
e.g. `message_ts: 1774682346.523199` → `https://hopchat.slack.com/archives/C0ADG2HPCNM/p1774682346523199`

**Channel characteristics:**

**`#devops-alerts-payments-fraud`** — Datadog + PagerDuty alerts for live payment services.
- Datadog alert bodies are always empty — read thread replies for content.
- Read threads for: every PagerDuty message, every Datadog message with ≥1 reply, any `hopper-ai` summary thread.

**`#fraud-etl-alerts`** — Rotterdam (Airflow) DAG and task failures, paged via PagerDuty.
- Messages have full content (task name, DAG name, failure type).
- Alert types: `Task Failed`, `Task SLA Missed`. PD service: `Data Pipeline Fraud & Chargebacks`.
- Common tasks: `etl-chargebacks-daily`, `etl-chargebacks-ledger`, `assert_chargeback_facts_not_delayed`.
- Read threads for every PD message to find resolution and owner.

**`#fraud-sqlmesh-alerts`** — Tobiko Cloud / SQLMesh model run results.
- Bot: `Fraud Jobs Reporting`. Messages have full content (status, failed model, error).
- Status levels: `:rotating_light: failure` (model run failed) and `:information_source: info` (audit threshold exceeded).
- `failure` status = always include in report. `info` status = include only if recurring or unresolved.
- Common errors: Google Sheets service overloaded, BigQuery resource exceeded, model timeouts.

For each message across all channels, note:
- Sender / bot, alert type, thread reply count, reactions (`:eyes:` = acknowledged)

### Step 2 — Classify each alert using SRE taxonomy

Apply this classification to every distinct alert (group repeated fires of the same monitor):

| Class | Definition | Criteria |
|---|---|---|
| **Page** | Urgent, user-impacting, required human response | PagerDuty escalation occurred |
| **Investigate** | Actionable but not urgent enough to page | Engineer replied in thread, no PD |
| **Flapping** | Monitor threshold too sensitive; auto-resolved repeatedly | ≥3 fires in the week, all auto-resolved, no thread replies |
| **External cause** | Alert triggered by a known third-party event (maintenance, outage) | Root cause identified in thread as provider-side |
| **Noise** | Not actionable, auto-resolved, no engineer attention | 1-2 fires, no thread, no PD |
| **New regression** | First-time error pattern; code change likely responsible | Error tracking issue ID in alert, or "new error detected" monitor |

**Alerts classified as Noise or Flapping should still appear in the report.** For these, the Context column should describe the pattern objectively (e.g. "Fired 9 times this week, all auto-resolved within minutes, no engineer replies") and the Action item column should be left blank or marked "Discuss in review" — the team will decide what to do with it.

### Step 3 — Search historical frequency for each notable alert

For every alert, first strip the variable parts of the alert name to get a stable search stem — then search the past 90 days using that stem:

```
slack_search_public_and_private(
  query="<alert stem> in:#devops-alerts-payments-fraud after:<date-90-days-ago>"
)
```

**How to stem the alert name** — remove these variable parts before searching:
- Environment/realm path: `common/production/`, `common/staging/`, `capone/production/`
- Timestamps: `(2026-03-28T00:00:00+00:00)`, `(last_24h)`
- Run IDs or UUIDs
- Specific pod or host names

Examples:
| Full alert name | Search stem |
|---|---|
| `createCard: Error rate is high in common/production/portland-server` | `createCard: Error rate is high` |
| `Cronjob crash detected in common/production/chargeback-blocking-job` | `Cronjob crash detected` |
| `Rotterdam: Task Failed in gcp-hopper etl-chargebacks-daily (2026-03-28T00:00:00+00:00): assert_chargeback_facts_not_delayed` | `etl-chargebacks-daily assert_chargeback_facts_not_delayed` |
| `fraud-prevention: hopper-app ground rejection rate alert (last_24h)` | `ground rejection rate alert` |
| `fintech_ancillaries__manual_reviews__cfar_contract_connections` | `cfar_contract_connections` |

If that returns results, extract:
- How many times it fired in the past 90 days
- Whether any thread discussed a resolution (root cause, Jira ticket, PR)
- Rough trend (getting better, worse, or stable)

If the 90-day search returns **no results**, do a second search with no date filter to find the oldest thread where this alert was discussed:

```
slack_search_public_and_private(
  query="<monitor name> in:#devops-alerts-payments-fraud"
)
```

Look for the earliest thread with engineer replies and note when it was and what was discussed. This tells the team whether this is a long-dormant issue that has resurfaced.

If no history exists at all, note it as a first occurrence.

Include findings in the Context column: e.g. *"Fired 4 times in past 90 days; last discussed [date] — [brief resolution or link]."* or *"No recent history; oldest thread from [date] discussed [summary]."*

### Step 4 — Query Datadog for deeper context

For **Page** and **New regression** alerts, use Datadog tools to get:
- Exact error messages and stack traces (`search_datadog_logs`)
- Monitor trigger/recovery timeline (`search_datadog_monitors`)
- Error tracking issue details (`get_datadog_error_tracking_issue` if issue ID is available)
- Upstream service dependencies causing the alert (`search_datadog_service_dependencies`)

For **Flapping** alerts, check the monitor's current threshold configuration to suggest a concrete fix.

### Step 5 — Synthesize report rows

**Cross-channel correlation first:** Before writing rows, identify topics that span multiple channels — e.g. a SQLMesh model failure in `#fraud-sqlmesh-alerts` that was also investigated in a `#devops-alerts-payments-fraud` thread. These should be a single row, not two separate rows. Link to whichever thread has the richest discussion.

The report has **two separate tables**:

**Table 1 — Service alerts** (from `#devops-alerts-payments-fraud`): live payment service incidents — Datadog monitors, PagerDuty pages, engineer investigations.

**Table 2 — Data pipeline alerts** (from `#fraud-etl-alerts` and `#fraud-sqlmesh-alerts`): ETL DAG failures, SQLMesh model failures, audit failures. Group all fires of the same DAG or model family into one row (e.g. all `etl-chargebacks-daily` failures → one row, regardless of which sub-task failed each day).

Each row covers one **distinct topic** (not one alert fire).

| Column | Content |
|---|---|
| **Topics** | Short title linked to the most relevant Slack thread (use `message_ts` for accurate URL): `[Title](slack-thread-url)` |
| **Context / Brief description** | What happened, SRE class, historical frequency (from Step 3), root cause if known, resolution. Include PD incident number if paged. |
| **Action item** | Jira ticket, PR link, or blank if the team needs to discuss |

Include the SRE class in the Context description, e.g. *"[Flapping — 9 fires this week, all auto-resolved]"* or *"[Page — PD incident Q2B9XZBYH8WJEI]"*.

### Step 6 — Create a Confluence subpage and update the table of contents

Each week's report is a *new subpage* under the parent TOC page (`7048593834`). This keeps the parent page lightweight and each report self-contained.

#### 6a — Create the subpage

Use `createConfluencePage` with the parent page as the parent:

```
createConfluencePage(
  cloudId="hopper-jira.atlassian.net",
  spaceId="5223055600",
  title="Technical ops review — YYYY-MM-DD",
  parentPageId="7048593834",
  contentFormat="markdown",
  content=<report markdown below>
)
```

The subpage title must follow the format `Technical ops review — YYYY-MM-DD` using this Tuesday's date. The space key is `PAYMENTS` (numeric ID `5223055600`).

The subpage content:

```markdown
[Datadog dashboard](https://us5.datadoghq.com/dashboard/8u8-8t7-iwr)

## Action items

Items identified during the review meeting. Check off completed items, add new ones as needed.

- [ ] _Add action items during the review…_

## Service alerts (#devops-alerts-payments-fraud)

| **Topics** | **Context / Brief description** | **Action item** |
| --- | --- | --- |
| [Alert name](slack-thread-url) | [SRE class] What happened. Fired N times in past 90 days; last resolved via [link]. | |

## Data pipeline alerts (#fraud-etl-alerts / #fraud-sqlmesh-alerts)

| **Topics** | **Context / Brief description** | **Action item** |
| --- | --- | --- |
| [DAG / model name](slack-thread-url) | [SRE class] Fires this week (e.g. daily for 6 days). Sub-tasks affected. Historical frequency. Root cause if known. | |
```

When generating the Action items section, pre-populate it with one checkbox per row from both tables that has a non-empty Action item column. Use this format:

```markdown
- [ ] **[Topic short title]** — action item text
```

Then append 3 blank checkbox lines at the end for items added during the live review:

```markdown
- [ ] 
- [ ] 
- [ ] 
```

This gives the team a ready-made checklist they can tick off and extend during the meeting.

#### 6b — Update the parent TOC page

Read the parent page to get its current version and content:
```
getConfluencePage(cloudId="hopper-jira.atlassian.net", pageId="7048593834", contentFormat="markdown")
```

Prepend a new row to the table of contents linking to the newly created subpage. The TOC is a simple list with the most recent report at the top:

```markdown
- [Technical ops review — YYYY-MM-DD](<subpage URL>)
```

Increment the page version by 1 when calling `updateConfluencePage`.

---

## Alert Classification

Use these labels in the Context column to describe what kind of alert this was. They're observational, not prescriptive — the team decides what to do about them during the review.

| Class | Observable signal |
|---|---|
| **Page** | PagerDuty escalation occurred |
| **Investigate** | Engineer replied in thread, no PD escalation |
| **Flapping** | Same monitor fired ≥3× this week, all auto-resolved, no thread replies |
| **External cause** | Root cause discussed in thread as provider-side (Conferma, Spreedly, BQ, etc.) |
| **Noise** | 1-2 fires, auto-resolved, no thread, no PD |
| **New regression** | "New error detected" monitor, or first appearance of an error tracking issue ID |

---

## Pattern Recognition Hints

Observable patterns that help classify alerts and write useful Context descriptions:

| What you see | Class | What to note in Context |
|---|---|---|
| Same monitor fires ≥3×, all auto-resolved, no replies | Flapping | Fire count, auto-resolve time, no engineer action taken |
| Fires align with a known provider maintenance window | External cause | Provider name, whether the team was pre-notified |
| "New error detected" monitor or new error tracking issue ID | New regression | Issue ID, first seen date, affected service/endpoint |
| Cronjob crash alert | Investigate/Page | OOM vs bad health endpoint vs upstream failure; match against recent deploys |
| ETL `assert_*_not_delayed` sensor | Investigate | Whether upstream table was actually delayed or sensor timed out prematurely |
| ETL `Task SLA Missed` or `Task Failed` | Page | DAG name, task name, how many consecutive failures |
| SQLMesh `:rotating_light: failure` | Investigate/Page | Failed model name, error message (BQ quota, Sheets overload, timeout) |
| SQLMesh `:information_source: info` | Investigate (if recurring) | Audit measure name, threshold exceeded, frequency this week |
| Google Sheets overload error in SQLMesh | External cause | Spreadsheet ID, how often this model depends on Sheets |
| Rejection rate alert, no PD | Noise (likely) | Note whether it belongs in `#fraud-ops` instead |
| Pod crashloopbackoff | Investigate/Page | Whether same pod recurs or one-off; match against deploy timeline |

---

## Example Output Row

```markdown
| [Portland createCard errors](https://hopchat.slack.com/archives/C0ADG2HPCNM/p1774682345049939) | [Page — PD Q2B9XZBYH8WJEI, cause:external-provider] `createCard: Error rate is high in common/production/portland-server`. Fired once 2026-03-28, acked by Ajinkya, auto-resolved in ~30 min. Root cause: Conferma scheduled maintenance. Historically: fired 5 times in past 90 days, 4 of which were also Conferma-related. | Use Datadog Downtime during next Conferma maintenance window. Consider proactively disabling the Conferma card pool. |
```

---

## Common Mistakes

- **Reading Datadog alert bodies from Slack** — they're always empty. Read thread replies.
- **One row per alert fire** — group by monitor/topic, not by fire count.
- **Skipping historical frequency search** — always search Slack for past 90 days before classifying.
- **Forgetting to increment Confluence parent page version** — the `updateConfluencePage` call will 409.
- **Forgetting to update the parent TOC** — after creating the subpage, always add the link to the parent page.
- **Omitting Noise/Flapping alerts entirely** — include them with the observable pattern (fire count, auto-resolve time) and leave the action item for the team to fill in.
- **Not checking for existing resolution** — if a past Slack thread resolved the issue, link to it.
- **Assuming root cause from history** — historical context (e.g. "this monitor often fires due to Conferma") must never override what the engineer actually said in the thread. Always read the thread first; use history only to enrich, not to substitute.
