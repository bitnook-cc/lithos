---
name: olympus
description: >-
  Use when making infrastructure changes in Olympus (Hopper's GCP IaC repo),
  adding cloud resources for a service, creating new app structures, or
  troubleshooting Atlantis plans and OPA policy violations.
---

# Olympus — GCP Infrastructure as Code

## Overview

Olympus is Hopper's central Terraform repository for managing GCP infrastructure. Teams self-service their infrastructure through the `apps/` directory, while platform-owned resources live in `projects/` and `organizations/`.

All changes go through Atlantis CI on GitHub PRs.

## Directory Structure

```
Olympus/
  apps/                          # Self-service application infrastructure
    {service}/{realm}/{env}/     # e.g., apps/air-exchange-shopping/hopper-app/production/
      apps-{service}.tf          # Resource definitions (team-owned)
      data.tf                    # Remote state references (team-owned)
      outputs.tf                 # Exported values (team-owned)
      versions.tf                # Provider versions (platform-owned, do not edit)
      acl.rego                   # Policy exceptions (platform-owned)
      HOPPEROWNERS               # Team ownership
  projects/                      # Platform-managed foundation (requires platform approval)
    gcp-hopper-app-{env}/        # Shared GCP projects
  organizations/                 # GCP org-level resources (requires platform approval)
  policy/                        # OPA/Rego governance policies
    gcp-self-service/            # Self-service policies (module versions, ACLs)
```

**Realms:** `hopper-app`, `capone`, `partner`, `gdata`
**Environments:** `development`, `staging`, `production`

## Self-Service Workflow

### Step 1: Create App Structure

Use the GitHub Action workflow to bootstrap a new app:

1. Go to [Actions > Generate App](https://github.com/hopper-org/Olympus/actions/workflows/generate-app.yml)
2. Provide: `app_name`, `realm`, `owning_teams` (e.g., `@hopper-org/platform-core`), `self_service: yes`
3. This creates the directory structure with templates for all environments

### Step 2: Generate Service Accounts

Use the [Generate SA](https://github.com/hopper-org/Olympus/actions/workflows/generate-sa.yml) workflow:
- Creates **two PRs**: one for non-production (dev + staging), one for production
- Uses the `gke-service-sa` module with Workload Identity binding

### Step 3: Add Infrastructure Resources

Edit your `apps-{service}.tf` file using approved modules from [`hopper-org/terraform-modules`](https://github.com/hopper-org/terraform-modules).

**Prefer modules over bare `resource` blocks.** Hopper-vetted modules bake in our conventions (naming, IAM bindings, labels, monitoring, deletion protection) and pass OPA policy checks that bare resources often fail. Before writing a `resource "google_..." "..."` block, check `hopper-org/terraform-modules` for an existing module that wraps it. If nothing fits, consider modifying or adding a module when the resource would be reusable elsewhere; for genuine one-offs, an OPA policy exception (via `acl.rego`) is better than a bare resource.

**Module pinning convention:**
```terraform
source = "git::git@github.com:hopper-org/terraform-modules.git//modules/{module-name}?ref={module-name}-v{X.Y.Z}"
```

Always pin to specific versions. Never use `?ref=master`.

**Common modules:**

| Resource | Module |
|----------|--------|
| Spanner DB | `spanner-db-autoscaling` |
| Bigtable | `bigtable-db` |
| Pub/Sub | `pubsub` |
| Secrets | `secret` |
| Cloud Storage | `storage-bucket` |
| Cloud SQL | `cloudsql-postgresdb` |
| Cloud Redis | `cloud-redis` |
| BigQuery | `bigquery-dataset` |

**Remote state references** (in `data.tf`):
```terraform
data "terraform_remote_state" "project" {
  backend = "gcs"
  config = {
    bucket      = "nonprod-mgmt-infra-hopper-com"
    prefix      = "gcp-hopper-app-development"
    credentials = "credentials.json"
  }
}
```

### Step 4: Create PR

- **Dev + staging** can go in the same PR
- **Production MUST be a separate PR**
- Always apply dev/staging first, then production
- Use conventional commit messages: `feat: add Spanner database for my-service`

### Step 5: Atlantis Plan & Apply

Atlantis auto-plans when the PR is created. See the [atlantis skill](hopper-developer:atlantis) for the full workflow.

Key rules for Olympus:
- If using `atlantis apply -d {directory}` for partial applies, label the PR with `do-not-unlock`
- If apply fails, label with `do-not-unlock` and fix immediately

## Approval Requirements

| Scope | Who approves |
|-------|-------------|
| `apps/` (self-service) | HOPPEROWNERS team member |
| `apps/` production deletion | Platform team required |
| `apps/` with ACL changes | Platform team required |
| `projects/` | Platform team required |
| `organizations/` | Platform team required |

## OPA Policy Violations

Olympus enforces policies via OPA/Rego. See [Policy Violations](references/policy-violations.md) for common violations and fixes.

**Testing policies locally:**
```bash
make policy-test
```

## App Modules Pattern

For complex apps with shared config across environments, use a module:

```
apps/{service}/
  modules/app/          # Module definition (main.tf, variables.tf, outputs.tf)
  hopper-app/
    development/        # Uses relative path: ../../modules/app
    staging/            # Uses pinned git ref
    production/         # Uses pinned git ref
```

Development uses `source = "../../modules/app"`, staging/production use pinned git refs.

## File Ownership

**Team can edit** (no platform approval):
- `apps-{service}.tf`, `data.tf`, `outputs.tf`, `secrets.tf`, `HOPPEROWNERS`

**Platform-owned** (always requires approval):
- `versions.tf`, `acl.rego`

## References

- [Policy Violations](references/policy-violations.md) — Common OPA violations and how to fix them
- [Module Versions](references/module-versions.md) — Requesting and using approved module versions
