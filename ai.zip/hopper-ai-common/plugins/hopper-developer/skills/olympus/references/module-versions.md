# Module Versions

## Pinning Convention

All Terraform modules must be pinned to approved versions:

```terraform
source = "git::git@github.com:hopper-org/terraform-modules.git//modules/{module-name}?ref={module-name}-v{X.Y.Z}"
```

Never use `?ref=master` or leave the ref unpinned.

## Finding Approved Versions

Approved versions are defined in `policy/gcp-self-service/module-policy.rego`. Check this file for the current list of approved versions for each module.

## Requesting a New Version

If the version you need isn't in the approved list:

1. Test with the new version in development/staging
2. Contact `#dev-platform-infra` on Slack with:
   - Module name and version
   - Why you need this version (changelog link if available)
   - Evidence that dev/staging tests passed
3. Platform team will add the version to `module-policy.rego`
4. Re-plan your PR once approved

## Common Modules and Their Purposes

| Module | Purpose |
|--------|---------|
| `gke-service-sa` | GCP service account with Workload Identity for K8s |
| `spanner-db-autoscaling` | Cloud Spanner with auto-scaling |
| `bigtable-db` | Cloud Bigtable instance and tables |
| `pubsub` | Pub/Sub topics and subscriptions |
| `secret` | Secret Manager secrets |
| `storage-bucket` | Cloud Storage buckets |
| `cloudsql-postgresdb` | Cloud SQL PostgreSQL databases |
| `cloud-redis` | Cloud Memorystore (Redis) |
| `bigquery-dataset` | BigQuery datasets, tables, views |
| `pubsub-lite` | Pub/Sub Lite topics and subscriptions |

## Service Account Pattern

```terraform
module "my-service" {
  source = "git::git@github.com:hopper-org/terraform-modules.git//modules/gke-service-sa?ref=gke-service-sa-v2.1.0"

  project_id    = data.terraform_remote_state.project.outputs.project_id
  k8s_namespace = "my-service"
  workload_identity_mapping = {
    "master" : ["master", "hopper"]
  }
}
```

Creates a GCP service account bound to Kubernetes service accounts via Workload Identity.
