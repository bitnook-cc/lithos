# OPA Policy Violations

Common policy violations in Olympus and how to resolve them.

## Module Not Approved / Wrong Version

```
policy_only_approved_modules violated: Module version not in approved list
Module: gke-service-sa
Version: v1.0.0
Approved versions: v2.0.0, v2.1.0, v2.2.0
```

**Fix:** Update the module source to an approved version:
```terraform
source = "git::git@github.com:hopper-org/terraform-modules.git//modules/gke-service-sa?ref=gke-service-sa-v2.2.0"
```

**If the version you need isn't approved:** Contact `#dev-platform-infra` with the module name, version, and why you need it. Include test results from dev/staging.

## Special IAM Users

```
policy_no_special_iam_users violated: Special IAM users require ACL
```

Triggered when using `allUsers` or `allAuthenticatedUsers` in IAM bindings.

**Fix:** Add an ACL entry to `acl.rego` in your project directory:
```rego
package main

iam_special_users_acl = {
    "module.my_bucket.google_storage_bucket_iam_binding.viewers[0]": {"allUsers"}
}
```

This requires platform team approval.

## Root Resources

```
policy_no_root_resources violated: Direct Google resources require ACL
```

Triggered when using raw `google_*` resources instead of approved modules.

**Fix:** Add a root resource ACL to `acl.rego`:
```rego
package main

root_resources_acl = {
    "google_bigquery_dataset.my_dataset",
    "google_storage_bucket.my_bucket",
}
```

This requires platform team approval. Prefer using approved modules when possible.

## Production Publisher Groups

```
policy_only_serviceaccounts_allowed_publishers_production violated
```

Triggered when a non-service-account principal publishes to a production Pub/Sub topic.

**Fix:** Add a module ACL to `acl.rego`:
```rego
package main

modules_acls = {
    "module.my_module.data.null_data_source.policy_violated[0]": {
        "acl": "[\"group:mygroup@hopper.com\"]",
        "name": "policy_violated_only_serviceaccounts_allowed_publishers_production"
    }
}
```

This requires platform team approval.

## Testing Policies Locally

```bash
# Run all policy tests
make policy-test

# Run specific suite
conftest verify -p policy/gcp-self-service/ -p policy/gcp-self-service-tests/ -d policy/gcp-self-service-tests/
```

Requires conftest v0.38.0.
