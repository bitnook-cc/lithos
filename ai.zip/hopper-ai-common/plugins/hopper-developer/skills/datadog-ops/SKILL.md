---
name: datadog-ops
description: >-
  Use when investigating production issues, debugging service behavior,
  searching logs, querying metrics, checking monitors/SLOs, discovering
  service dependencies via APM spans, or understanding how telemetry
  flows for a Hopper service in Datadog.
---

# Datadog Operations — Investigating & Debugging

## Overview

Hopper uses Datadog for monitoring and observability across all services. This skill covers how to find and interpret Datadog data during investigations, incidents, or debugging sessions.

## Accessing Datadog (IMPORTANT — read before querying)

Try these methods in order. Use whichever is available in your environment:

1. **MCP tools** — Datadog MCP tools (`mcp__datadog__*`) may be available as
   deferred tools. Run `ToolSearch(query: "datadog", max_results: 20)` to
   discover and activate them. If results come back, use the MCP tools for all
   queries described in this skill.

2. **Datadog CLI** — If MCP tools are not available, check for the `dog` CLI:
   `which dog`. If present, use it for metric queries (`dog metric query ...`),
   monitor lookups (`dog monitor search ...`), and event streams.

3. **Datadog API via curl** — If neither MCP nor CLI is available, check for a
   `DD_API_KEY` and `DD_APP_KEY` environment variable. If set, query the
   Datadog API directly (e.g., `curl -H "DD-API-KEY: $DD_API_KEY" ...`).
   See https://docs.datadoghq.com/api/ for endpoints.

**Do not conclude that Datadog is inaccessible without trying all three
methods.** The most common failure mode is skipping step 1 — MCP tools exist
but are deferred and won't appear until you search for them.

## Finding a Service in Datadog

### APM Service Page

The primary entry point for any service:

```
https://app.datadoghq.com/apm/service/{service-name}
```

Service names match the `telemetry_name` from the deploy plan (e.g., `bifrost`, `houston`, `hamburg-provider-dhisco`).

### Backstage Annotations

Services register their DD links in `.backstage/component/*.yml`:

```yaml
annotations:
  datadoghq.com/site: datadoghq.com
  datadoghq.com/dashboard-url: https://app.datadoghq.com/apm/service/{service-name}
```

### Using DD MCP Tools

Search for services, hosts, dashboards, and monitors:

```
mcp__datadog__search_datadog_services     — find services by name
mcp__datadog__search_datadog_dashboards   — find dashboards
mcp__datadog__search_datadog_monitors     — find monitors for a service
mcp__datadog__search_datadog_hosts        — find hosts running a service
```

## Data Retention

Understanding retention windows is critical — querying outside these windows returns zero results, which can be mistaken for "no data exists."

| Data Type | Hot / Standard Retention | Extended Retention |
|-----------|------------------------|--------------------|
| Logs | ~15 days | Flex storage (`storage_tier: "flex_and_indexes"`) retains logs longer but with slower query performance and limited availability. Not all log indexes are configured for Flex. |
| APM Spans (indexed) | ~15 days | — |
| APM Spans (real-time) | 15 minutes | — |
| Metrics | 15 months | — |

**Practical implications:**
- When investigating issues older than ~2 weeks, logs and indexed spans may no longer be available. Fall back to metrics (which have 15-month retention) or check if Flex storage has the data.
- When searching Flex storage, use `storage_tier: "flex_and_indexes"` in `mcp__datadog__search_datadog_logs`. Queries may be slower and some log indexes may not have Flex enabled.
- If a log search returns zero results for a time range older than 15 days, it likely means the data has aged out of retention — not that the events never occurred.
- For historical analysis beyond log retention, use metrics (e.g., `trace.*.hits` with error tags) or BigQuery audit tables if available.

## Querying Logs

### Log Search via MCP

```
mcp__datadog__search_datadog_logs
  filter: "service:bifrost env:production status:error"
  from: "now-1h"
  to: "now"
```

### Log Analysis with SQL

```
mcp__datadog__analyze_datadog_logs
  filter: "service:bifrost env:production"
  sql_query: "SELECT status, count(*) FROM logs GROUP BY status ORDER BY count(*) DESC"
```

### Common Log Filters

| Filter | Purpose |
|--------|---------|
| `service:{name}` | Logs from a specific service |
| `env:production` | Production environment only |
| `status:error` | Error-level logs |
| `status:(critical OR alert OR emergency)` | Severe issues |
| `@http.status_code:[500 TO 599]` | HTTP 5xx errors |
| `source:{name}` | Logs by source (may differ from service) |
| `host:{hostname}` | Logs from a specific host |

Use `(source:foo OR service:foo)` when unsure whether something is a source or service.

### Log Pipeline

Logs flow through this pipeline before reaching Datadog:

1. **Application** writes structured JSON logs (logback with `SimpleJsonEncoder`)
2. **GKE** collects container stdout/stderr into **GCP Cloud Logging**
3. **GCP Pub/Sub** subscription `export-logs-to-datadog` receives log entries
4. **platform-log-streamer** processes logs:
   - Stage 1: PII scrubbing (field-name-based redaction of emails, phones, addresses, etc.)
   - Stage 2: PII detection (heuristic-based, marks remaining PII as `<PII_DETECTED: type>`)
5. **Datadog Log Intake** (`gcp-intake.logs.us5.datadoghq.com`) receives cleaned logs

If you see `<REDACTED_PII: JSON>` or `<PII_DETECTED: email>` in logs, this is the scrubber working as intended.

## Querying Metrics

### Metric Query via MCP

```
mcp__datadog__get_datadog_metric
  queries: ["avg:trace.finagle.http.server.request.duration{service:bifrost,env:production}"]
  from: "now-1h"
```

### Common Hopper Metrics

**HTTP trace metrics** (from DD APM):
- `trace.finagle.http.server.request.hits` — request count
- `trace.finagle.http.server.request.errors` — error count
- `trace.finagle.http.server.request.duration` — latency

**gRPC trace metrics:**
- `trace.grpc.server.request.hits`
- `trace.grpc.server.request.errors`
- `trace.grpc.server.request.duration`

**JVM metrics** (from DD Java agent):
- `jvm.heap_memory` / `jvm.non_heap_memory`
- `jvm.gc.major_collection_count` / `jvm.gc.minor_collection_count`
- `jvm.thread_count`

**Container/K8s metrics:**
- `kubernetes.cpu.usage.total`
- `kubernetes.memory.usage`
- `kubernetes.pods.running`

### Metric Context

Use `get_datadog_metric_context` to discover available tags and dimensions for a metric before querying:

```
mcp__datadog__get_datadog_metric_context
  metric_name: "trace.finagle.http.server.request.hits"
  scope_tags: ["service:bifrost", "env:production"]
  include_tag_values: true
```

## Understanding Tags

### Unified Service Tagging (UST)

Every Hopper service automatically gets these tags via deployment mixins:

| Tag | Source |
|-----|--------|
| `service` / `DD_SERVICE` | `telemetry_name` from deploy plan |
| `env` / `DD_ENV` | Environment (development/staging/production) |
| `version` / `DD_VERSION` | Application version |

These are set as pod labels (`tags.datadoghq.com/*`) and injected as env vars via Kubernetes downward API.

### Additional Tags

| Tag | Purpose |
|-----|---------|
| `bu:{business_unit}` | Business unit (air, platform, hotels, etc.) |
| `realm:{realm}` | Deployment realm (common, capone, partner) |
| `app-tenant` | Extracted from `x-hopper-tenant-id` header |
| `managed:terraform` | Resource managed by Arecibo IaC |

## Trace Correlation

### Logs to Traces

Logs include MDC fields for trace correlation:
- `xRequestId` — request correlation ID
- `spanId` — Datadog span ID

Datadog automatically correlates logs and traces when `DD_SERVICE`, `DD_ENV`, and trace IDs are present.

### Trace Propagation

Services propagate trace context via headers using both Datadog and B3 formats:
- `DD_TRACE_PROPAGATION_STYLE_EXTRACT = "datadog,b3multi"`
- `DD_TRACE_PROPAGATION_STYLE_INJECT = "datadog,b3multi"`

### Envoy Proxy Spans (Istio Service Mesh)

Hopper uses Istio within GKE, which injects a sidecar Envoy proxy container into every pod. All inter-service traffic flows through these proxies, which add their own spans to traces.

When service A calls service B, the trace shows four hops:

```
A (app) → A' (envoy egress) → B' (envoy ingress) → B (app)
```

The envoy spans appear as separate services in APM. **When identifying upstream/downstream dependencies, always look through the proxy spans to the actual application service.** The upstream of B is A, not B's envoy sidecar or A's envoy sidecar.

#### Querying Envoy Sidecar Spans

Envoy sidecar spans are available in the **15-minute real-time window** (they are not indexed for long-term retention). They are service-independent — they work for any pod in the mesh regardless of application-level APM instrumentation.

Filter envoy sidecar spans with `@component:proxy`. The service name follows the pattern `<workload>.<namespace>` (e.g., `unit.lexington`, `unit.southlake`).

**Key attributes on envoy sidecar spans:**

| Attribute | Description | Example |
|-----------|-------------|---------|
| `istio.namespace` | Namespace of the pod running this sidecar | `lexington` |
| `istio.canonical_service` | Workload name of the pod | `unit` |
| `service` | Caller's service identity | `unit.lexington` |
| `upstream_cluster.name` | Target service and port | `outbound\|7070\|\|unit.southlake.svc.cluster.local;` |
| `http.host` | Target host header | `unit.southlake.svc.cluster.local` |
| `http.url` | Full URL with path | `http://unit.southlake.svc.cluster.local:7070/api/v1/query` |
| `http.request.headers.user-agent` | Caller identity (app name + version) | `lexington-production/0.175.0` |
| `node_id` | Full sidecar identity | `sidecar~<pod-ip>~<pod>.<ns>~<ns>.svc.cluster.local` |

**Outbound vs inbound spans:**
- `upstream_cluster.name` starting with `outbound|` → the sidecar is sending traffic to another service
- `upstream_cluster.name` starting with `inbound|` → the sidecar is receiving traffic for its own pod

#### Querying Ingress Gateway Spans

The Istio ingress gateway (`service:istio-ingressgateway.istio-system`) handles traffic entering the cluster from external sources. These spans are available in both real-time and indexed windows.

**Key attributes:**

| Attribute | Description | Example |
|-----------|-------------|---------|
| `upstream_cluster.name` | Target service | `outbound\|7070\|\|unit.tysons.svc.cluster.local;` |
| `http.host` | External hostname | `travel.capitalone.com` |
| `http.useragent_details.*` | Browser/device/OS details | `Chrome Mobile WebView`, `iPhone` |
| `peer.address` | Load balancer IP | `35.191.90.72` |

## Discovering Service Dependencies

### Finding Upstream Consumers (who calls a service)

Use these approaches in order of preference:

#### 1. Envoy sidecar spans (15-minute real-time, service-independent)

Find all services calling a target by querying for outbound envoy spans targeting its mesh URL:

```
mcp__datadog__search_datadog_spans
  query: "@component:proxy env:production @upstream_cluster.name:*<namespace>*"
  from: "now-15m"
```

Extract unique `istio.namespace` values from the results — each is a distinct caller namespace. The `service` field (e.g., `unit.lexington`) provides the caller's workload identity.

To see inbound spans on the target's own sidecar:
```
  query: "@component:proxy env:production @istio.namespace:<namespace> @upstream_cluster.name:inbound*"
  from: "now-15m"
```

These show `http.request.headers.user-agent` identifying the caller (e.g., `lexington-production/0.175.0`).

#### 2. Application server spans (15-minute + 2-week indexed)

Application spans have longer retention and richer metadata but require the service to have Datadog APM instrumentation (all Scala services using `helpers-stable` have this).

```
mcp__datadog__search_datadog_spans
  query: "service:<telemetry_name> env:production @span.kind:server"
  from: "now-15m"    # or "now-2w" for indexed spans
```

Extract the caller identity from `peer.service` (format: `unit.<workload-name>`, e.g., `unit.flights-provider-facade`). Note: `peer.hostname` on server spans is always `127.0.0.6` (the envoy sidecar loopback) and does not identify the caller.

The **2-week indexed window** captures infrequent callers that may not appear in a 15-minute snapshot. Look for consumers that appear early in the window but have zero traffic recently — these may be stale.

#### 3. Service dependency API

```
mcp__datadog__search_datadog_service_dependencies
  service: "<telemetry_name>"
  direction: "upstream"
```

Note: this API may return limited results. Prefer span queries for comprehensive discovery.

### Finding Downstream Dependencies (what a service calls)

#### Internal mesh dependencies

**Via envoy sidecar spans** (15-minute real-time):
```
mcp__datadog__search_datadog_spans
  query: "@component:proxy env:production @istio.namespace:<namespace> @upstream_cluster.name:outbound*"
  from: "now-15m"
```

Extract targets from `upstream_cluster.name` (format: `outbound|<port>||<workload>.<namespace>.svc.cluster.local;`).

**Via application client spans** (15-minute + 2-week indexed):
```
mcp__datadog__search_datadog_spans
  query: "service:<telemetry_name> env:production @span.kind:client"
  from: "now-15m"
```

Key attributes for identifying targets:
- **HTTP dependencies**: `clnt/namer.name` → mesh URL (e.g., `unit.swansea.svc.cluster.local:7070`)
- **gRPC dependencies**: `grpc.authority` → mesh URL (e.g., `unit.flights-config.svc.cluster.local:7170`)

#### External dependencies

External outbound calls (e.g., to third-party APIs like Sabre) are **only visible in application client spans**, not envoy sidecar spans, because they exit the mesh.

```
mcp__datadog__search_datadog_spans
  query: "service:<telemetry_name> env:production @span.kind:client"
  from: "now-15m"
```

Identify external calls by:
- `peer.hostname` with a non-cluster hostname (e.g., `webservices.platform.sabre.com`)
- `finagle.service_name` with the client label (e.g., `sabre-soap`)
- `http.host` with an external domain
- `clnt/namer.name` pointing to a non-`.svc.cluster.local` address

### Identifying Public Consumers

For services exposed via `inet_ingress()` or Kong API Gateway:

- **RUM-traced requests**: spans with the tag `ingestion_reason:rum` indicate end-user traffic (webapp or mobile app)
- **Ingress gateway spans**: query `service:istio-ingressgateway.istio-system` to see external traffic entering the cluster, including `http.host` (the public hostname) and `http.useragent_details` (browser/device info)
- **Kong routes**: check Olympus (`Olympus/apps/<service-name>/hopper-app/*/kong.tf`) for route definitions including public hostnames (e.g., `*.htsapis.com` for partner APIs)

## Monitors & SLOs

### Finding Monitors

```
mcp__datadog__search_datadog_monitors
  query: "service:bifrost"
```

### Monitor Source of Truth

Monitors are managed as Terraform in the **Arecibo** repo (`applications/{service}/monitors.tf`). See the [datadog-config](hopper-developer:datadog-config) skill for details on creating or modifying monitors.

### SLO Patterns

SLOs are typically defined as:
- **Metric-based**: numerator (successful requests) / denominator (total requests)
- **Monitor-based**: uptime of a specific monitor

Query SLOs with `mcp__datadog__search_datadog_monitors` or check `applications/{service}/slos.tf` in Arecibo.

## Investigating Incidents

### Quick Investigation Checklist

1. **Identify the service** — check APM service page for error rate/latency spikes
2. **Search error logs** — `service:{name} env:production status:error` in last hour
3. **Check monitors** — search for firing monitors on the service
4. **Query key metrics** — latency p99, error rate, request volume
5. **Check traces** — use `mcp__datadog__get_datadog_trace` for specific trace IDs
6. **Check dependencies** — `mcp__datadog__search_datadog_service_dependencies` for upstream/downstream issues
7. **Check recent deploys** — correlate with recent `-rendered` tags

### Creating Investigation Notebooks

Use `mcp__datadog__create_datadog_notebook` to capture findings with logs, metrics, and markdown analysis.

## References

- [Datadog Config Skill](hopper-developer:datadog-config) — Setting up monitors, SLOs, and instrumentation
