# Package Patterns

Common release-me package configurations for different project types.

## Standard Bazel Service (Most Common)

Two packages — service code and deployment manifests versioned independently:

```json
{
  "packages": {
    "service": {
      "paths": ["."],
      "initial-version": "0.1.0",
      "exclude-paths": ["deployment", ".backstage"]
    },
    "deployment": {
      "paths": ["deployment", ".backstage", "MODULE.bazel"],
      "initial-version": "0.1.0"
    }
  }
}
```

**Why two packages?**
- Deployment config changes (scaling, env vars) don't need a new service artifact
- Service code changes don't need a deployment release unless manifests also changed
- Reduces unnecessary builds and deploys

## Library

Single package tracking the whole repo:

```json
{
  "packages": {
    "lib": {
      "paths": ["."],
      "initial-version": "0.1.0"
    }
  }
}
```

## Multi-Language Project

Separate packages for different language ecosystems:

```json
{
  "packages": {
    "spark": {
      "paths": ["build.sbt", "project", "hopper-tools-spark"],
      "initial-version": "0.1.0"
    },
    "python": {
      "paths": ["pyproject.toml", "requirements*.txt", "python-tools"],
      "initial-version": "0.1.0"
    }
  }
}
```

## Monorepo with Multiple Services

```json
{
  "packages": {
    "service-a": {
      "paths": ["services/a"],
      "initial-version": "0.1.0"
    },
    "service-b": {
      "paths": ["services/b"],
      "initial-version": "0.1.0"
    },
    "deployment": {
      "paths": ["deployment"],
      "initial-version": "0.1.0"
    }
  }
}
```

## Path Syntax

Paths use git pathspec format:
- `"."` — everything in the repo
- `"deployment"` — the deployment/ directory and all contents
- `"*.sbt"` — all .sbt files in root
- `"project"` — the project/ directory

`exclude-paths` takes precedence over `paths` at the package level.

## Per-Package Commit Mapping Override

Rarely used, but a package can override the global mapping:

```json
{
  "packages": {
    "service": {
      "paths": ["."],
      "initial-version": "0.1.0",
      "conventional-commit-mapping": {
        "feat": { "version": "PATCH" }
      }
    }
  }
}
```

When specified, this **completely replaces** the global mapping for that package.
