# GitHub Actions Integration

release-me integrates with GitHub Actions through reusable actions in `hopper-org/.github`.

## PR Title Validation

Runs on every PR to enforce conventional commit format:

```yaml
name: PR Title Check
on:
  pull_request:
    types: [opened, edited, synchronize, reopened]

permissions:
  contents: read
  id-token: write
  pull-requests: read

jobs:
  check-pr-title:
    runs-on: gh-runner-small
    if: github.repository_owner == 'hopper-org'
    steps:
      - uses: actions/checkout@v4
      - uses: hopper-org/.github/actions/release-me/0.2.x/check-pr-title@main
        with:
          token: ${{ github.token }}
```

Reads `release-me-config.json` to determine allowed commit types.

## Detect Package Changes

Determines which packages have changed files and need testing:

```yaml
jobs:
  detect:
    runs-on: gh-runner-medium
    outputs:
      changes: ${{ steps.run.outputs.changes }}
    steps:
      - uses: actions/checkout@v4
        with:
          fetch-depth: 0
      - id: run
        uses: hopper-org/.github/actions/release-me/0.2.x/package-changes/squash-and-merge@main
        with:
          ref: ${{ github.event.pull_request.head.sha }}
```

Output JSON structure:
```json
{
  "service": { "test-candidate": true },
  "deployment": { "test-candidate": false }
}
```

Use in downstream jobs:
```yaml
jobs:
  test-service:
    needs: detect
    if: fromJson(needs.detect.outputs.changes).service.test-candidate
    steps:
      - run: sbt test
```

## Query Bump (PR Preview)

Shows what version bumps would happen if the PR merged:

```yaml
- uses: hopper-org/.github/actions/release-me/0.2.x/query-bump@main
  with:
    base-ref: ${{ github.event.pull_request.base.sha }}
    ref: ${{ github.event.pull_request.head.sha }}
    hopper-cd-automation-key: ${{ secrets.HOPPER_CD_AUTOMATION_KEY }}
```

## Release (On Merge to Master)

The main release workflow — bumps versions, creates tags, triggers downstream:

```yaml
name: Release
on:
  push:
    branches: [master]
  workflow_dispatch: {}

permissions:
  contents: write
  id-token: write

jobs:
  release-me:
    runs-on: gh-runner-small
    if: github.repository_owner == 'hopper-org'
    outputs:
      release: ${{ steps.release.outputs.release }}
    steps:
      - uses: actions/checkout@v4
        with:
          fetch-depth: 0
      - name: release-me release
        id: release
        uses: hopper-org/.github/actions/release-me/0.2.x/release@main
        with:
          ref: ${{ github.ref }}
          hopper-cd-automation-key: ${{ secrets.HOPPER_CD_AUTOMATION_KEY }}

  publish-artifacts:
    needs: release-me
    if: >-
      github.repository_owner == 'hopper-org' &&
      fromJSON(needs.release-me.outputs.release).packages.service.is-release
    # ... build and publish steps

  harness-delivery:
    needs: [release-me, publish-artifacts]
    if: >-
      github.repository_owner == 'hopper-org' &&
      (
        fromJSON(needs.release-me.outputs.release).packages.service.is-release ||
        fromJSON(needs.release-me.outputs.release).packages.deployment.is-release
      ) &&
      !cancelled() &&
      !contains(needs.*.result, 'failure')
    # ... Harness CD trigger steps
```

## Release Output Structure

```json
{
  "packages": {
    "service": {
      "version": "1.43.0",
      "commit": "abc123",
      "tag": "service-v1.43.0",
      "is-release": true
    },
    "deployment": {
      "version": "0.25.0",
      "commit": "abc123",
      "tag": "deployment-v0.25.0",
      "is-release": false
    }
  }
}
```

`is-release` is `true` only when the commit type maps to a non-NONE version bump for that package.

## Important Notes

- **Explicit permissions override defaults.** When you set a `permissions:` block on a workflow, GitHub removes all default permissions — including `contents: read`. You must explicitly list every permission the workflow needs (e.g., `contents: read` for `actions/checkout`, `pull-requests: read` for PR title checks).
- **fetch-depth: 0** is required — release-me needs full git history
- **hopper-cd-automation-key** secret is required for tagging (GitHub App credentials)
- Release jobs should only run in `hopper-org` (not on personal forks): check `github.repository_owner == 'hopper-org'`
- Harness delivery should wait for publish but still run if only deployment changed (`!cancelled()` + `!contains(needs.*.result, 'failure')`)
