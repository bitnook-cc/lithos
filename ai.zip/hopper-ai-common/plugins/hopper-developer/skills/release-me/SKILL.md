---
name: release-me
description: >-
  Use when configuring release-me for a new service, troubleshooting version
  bumps, understanding how conventional commits map to releases, or setting up
  the release GitHub Actions workflow.
---

# release-me — Semantic Versioning & Release Automation

## Overview

release-me is Hopper's tool for automatic semantic versioning based on conventional commits. It tracks independently-versioned packages within a repo, creates git tags on merge to master, and triggers downstream CI/CD (Harness) pipelines.

## How It Works

1. PR title follows [Conventional Commits](https://www.conventionalcommits.org/) (enforced by CI)
2. On merge to master, release-me computes the version from the full git history and conventional commits since `root-sha`
3. It creates a **detached commit** (not on the main branch) with the updated manifest and per-package git tags (e.g., `service-v1.2.3/release`)
4. Downstream jobs (artifact publish, Harness delivery) trigger based on which packages released

## Configuration Files

### release-me-config.json

```json
{
  "root-sha": "<full-40-char-commit-sha>",
  "packages": {
    "service": {
      "paths": ["."],
      "initial-version": "0.0.0",
      "exclude-paths": ["deployment"]
    },
    "deployment": {
      "paths": ["deployment", "MODULE.bazel", ".backstage"],
      "initial-version": "0.0.0"
    }
  },
  "conventional-commit-mapping": {
    "feat": { "version": "MINOR" },
    "fix": { "version": "PATCH" },
    "perf": { "version": "PATCH" },
    "refactor": { "version": "PATCH" },
    "test": { "version": "PATCH" },
    "build": { "version": "PATCH" },
    "ci": { "version": "PATCH" },
    "deps": { "version": "PATCH" },
    "revert": { "version": "PATCH" },
    "docs": { "version": "NONE" },
    "chore": { "version": "NONE" },
    "style": { "version": "NONE" }
  }
}
```

### .release-me-manifest.json

Placeholder file required by release-me. On the main branch, this file always contains `0.0.0` (or `0.0.0-SNAPSHOT` for service packages). The actual versions are computed from git history — not read from this file. The manifest is only updated in the detached release commits (visible in `-rendered` tags), never on the main branch.

```json
{
  "service": "0.0.0-SNAPSHOT",
  "deployment": "0.0.0"
}
```

## Setting Up a New Service

### Step 1: Initialize Config

Set `root-sha` to the **full SHA** of the merge base with master:

```bash
root_sha=$(git merge-base upstream/master HEAD)
```

Always use the full 40-character SHA, not an abbreviated hash.

### Step 2: Choose Package Structure

See [Package Patterns](references/package-patterns.md) for common configurations.

**Standard service** (most common — two packages):
- `service`: tracks application code, excludes deployment manifests
- `deployment`: tracks Bazel deployment config and Backstage metadata

**Library** (single package):
- `lib`: tracks everything in the repo

### Step 3: Set Up GitHub Actions

Three workflows are needed. See [GitHub Actions](references/github-actions.md) for templates.

1. **PR validation** — checks PR title matches conventional commits
2. **Tests** — detects which packages changed, runs tests conditionally
3. **Release** — bumps versions, creates tags, triggers artifact publish and Harness delivery

### Step 4: Create Initial Manifest

```json
{
  "service": "0.0.0-SNAPSHOT",
  "deployment": "0.0.0"
}
```

Service packages use `0.0.0-SNAPSHOT`, deployment packages use `0.0.0`. These are placeholders — the actual versions are computed by release-me from git history using the `initial-version` in the config.

## Conventional Commit Mapping

| Commit type | Version bump | Example |
|------------|-------------|---------|
| `feat` | MINOR (1.0.0 -> 1.1.0) | `feat: add payment retry logic` |
| `fix` | PATCH (1.0.0 -> 1.0.1) | `fix: handle null response from provider` |
| `perf`, `refactor`, `test`, `build`, `ci`, `deps`, `revert` | PATCH | `refactor: extract validation logic` |
| `docs`, `chore`, `style` | NONE (no release) | `docs: update README` |

**Version bump levels:**
- `MAJOR` — breaking changes (X.0.0), rarely used
- `MINOR` — new features (0.X.0), resets patch to 0
- `PATCH` — fixes and improvements (0.0.X)
- `NONE` — no version change, no release triggered

## Multi-Package Behavior

When a commit lands on master:
- release-me checks which `paths` were affected
- Only packages with changed paths get a version bump
- Each package can release independently
- The `is-release` flag in the output indicates which packages released

**Example:** A commit touching only `deployment/` bumps the `deployment` package but not `service`.

## Finding the Version of a Commit

Since the manifest on the main branch always contains `0.0.0`, you need to use git tags to find the actual version.

### From per-package release tags

Each package release creates a tag: `{package}-v{version}/release` (e.g., `service-v1.38.1/release`).

```
mcp__github__list_tags
  owner: "hopper-org"
  repo: "{repo}"
  perPage: 10
```

Filter for tags ending in `/release` to find per-package versions.

### From GitHub Actions output

The release workflow outputs JSON with version info per package. In downstream jobs, access it via:

```yaml
version: ${{ fromJSON(needs.release-me.outputs.release).packages.service.version }}
is-release: ${{ fromJSON(needs.release-me.outputs.release).packages.service.is-release }}
tag: ${{ fromJSON(needs.release-me.outputs.release).packages.service.tag }}
```

**Note:** Services deployed via Harness also have `-rendered` tags (e.g., `v1.38.1_v1.18.4-rendered`) created by `hopper-org/.github/actions/cd-release`. See the deployment skill for details.

## Troubleshooting

| Problem | Cause | Fix |
|---------|-------|-----|
| No release created on merge | Commit type maps to `NONE` | Use `feat:` or `fix:` prefix |
| Wrong package released | Paths overlap or exclude-paths missing | Check `paths` and `exclude-paths` in config |
| Version not bumping | `root-sha` set incorrectly | Reset with `git merge-base upstream/master HEAD` |
| PR title check failing | Title doesn't match conventional commits | Format: `type: description` or `type(scope): description` |

## References

- [Package Patterns](references/package-patterns.md) — Common package configurations for different project types
- [GitHub Actions](references/github-actions.md) — Workflow templates for PR validation, testing, and release
