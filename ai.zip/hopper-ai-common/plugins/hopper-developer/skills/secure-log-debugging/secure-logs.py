# /// script
# requires-python = ">=3.11"
# dependencies = ["google-cloud-bigquery", "protobuf"]
# ///
"""CLI for debugging secure-logs (external API call records).

Usage: uv run secure-logs.py <command> [options]

Secure-logs stores HTTP request/response pairs for calls to external/third-party
services.  Data is gzip-compressed protobuf (HttpRequest/HttpResponse).

Use the state-machine-debugging skill's state-machine.py to get conversation_ids
from sessions, then use this tool to inspect the actual HTTP calls.

Proto source:
  https://github.com/hopper-org/secure-logs/blob/master/proto/src/main/protobuf/hopper/securelogs/v1/secure_logs_service.proto

BQ table: gcp-hopper-etldata-{env}.secure_logs_private.statements
Partitioned on timestamp (MONTH), clustered by (conversation_id, timestamp, statement_id).
Columns:
  statement_id        STRING    UUID (UUIDv7, embeds timestamp)
  conversation_id     STRING    UUID linking to Orange sessions
  timestamp           TIMESTAMP time of the statement
  expires_at          DATE      retention expiry
  tenant              STRING    tenancy (nullable)
  user_id             STRING    user UUID (nullable)
  statement_request   BYTES     gzip(proto HttpRequest{url, method, headers, body})
  statement_response  BYTES     gzip(proto HttpResponse{success{status, headers, body}
                                  | failure{response, message, stacktrace}})
  producer            STRING    Hopper service that made the call (nullable)
  third_party_service STRING    external service name (nullable)
  action              STRING    action annotation (nullable)
  labels              RECORD[]  key-value labels (repeated)
"""

from __future__ import annotations

import argparse
import gzip
import json
import re
import sys
from datetime import datetime
from typing import Any

from google.cloud import bigquery
from google.protobuf import descriptor_pb2, descriptor_pool, message_factory


# ─── Protobuf dynamic message definitions ───────────────────────────
# Defines HttpRequest/HttpResponse using protobuf's descriptor API so we
# can decode the gzip-compressed proto bytes from BQ without compiled
# proto files.  See proto source link above for the original definitions.

_LABEL = descriptor_pb2.FieldDescriptorProto
_pool = descriptor_pool.DescriptorPool()


def _add_map_field(
    msg: descriptor_pb2.DescriptorProto,
    name: str,
    number: int,
    entry_name: str,
    pkg: str,
    parent: str,
) -> None:
    """Add a map<string, string> field to a message descriptor."""
    entry = msg.nested_type.add(name=entry_name)
    entry.field.add(
        name="key", number=1,
        type=_LABEL.TYPE_STRING, label=_LABEL.LABEL_OPTIONAL,
    )
    entry.field.add(
        name="value", number=2,
        type=_LABEL.TYPE_STRING, label=_LABEL.LABEL_OPTIONAL,
    )
    entry.options.CopyFrom(descriptor_pb2.MessageOptions(map_entry=True))
    msg.field.add(
        name=name, number=number,
        type=_LABEL.TYPE_MESSAGE, label=_LABEL.LABEL_REPEATED,
        type_name=f".{pkg}.{parent}.{entry_name}",
    )


def _build_descriptors() -> tuple[type, type]:
    """Build HttpRequest and HttpResponse message classes dynamically."""
    fdp = descriptor_pb2.FileDescriptorProto(
        name="securelogs.proto", package="securelogs", syntax="proto3",
    )

    # HttpRequest { string url=1; string method=2; map<string,string> headers=3; bytes body=4; }
    req = fdp.message_type.add(name="HttpRequest")
    req.field.add(name="url", number=1, type=_LABEL.TYPE_STRING, label=_LABEL.LABEL_OPTIONAL)
    req.field.add(name="method", number=2, type=_LABEL.TYPE_STRING, label=_LABEL.LABEL_OPTIONAL)
    _add_map_field(req, "headers", 3, "HeadersEntry", "securelogs", "HttpRequest")
    req.field.add(name="body", number=4, type=_LABEL.TYPE_BYTES, label=_LABEL.LABEL_OPTIONAL)

    # HttpResponse.Response { int32 status=1; map<string,string> headers=2; bytes body=3; }
    resp_msg = fdp.message_type.add(name="HttpResponse")
    response = resp_msg.nested_type.add(name="Response")
    response.field.add(name="status", number=1, type=_LABEL.TYPE_INT32, label=_LABEL.LABEL_OPTIONAL)
    _add_map_field(response, "headers", 2, "HeadersEntry", "securelogs", "HttpResponse.Response")
    response.field.add(name="body", number=3, type=_LABEL.TYPE_BYTES, label=_LABEL.LABEL_OPTIONAL)

    # HttpResponse.Failure { Response response=1; string message=2; string stacktrace=3; }
    failure = resp_msg.nested_type.add(name="Failure")
    failure.field.add(
        name="response", number=1,
        type=_LABEL.TYPE_MESSAGE, label=_LABEL.LABEL_OPTIONAL,
        type_name=".securelogs.HttpResponse.Response",
    )
    failure.field.add(name="message", number=2, type=_LABEL.TYPE_STRING, label=_LABEL.LABEL_OPTIONAL)
    failure.field.add(name="stacktrace", number=3, type=_LABEL.TYPE_STRING, label=_LABEL.LABEL_OPTIONAL)

    # oneof result { Response success=1; Failure failure=2; }
    resp_msg.oneof_decl.add(name="result")
    resp_msg.field.add(
        name="success", number=1,
        type=_LABEL.TYPE_MESSAGE, label=_LABEL.LABEL_OPTIONAL,
        type_name=".securelogs.HttpResponse.Response",
        oneof_index=0,
    )
    resp_msg.field.add(
        name="failure", number=2,
        type=_LABEL.TYPE_MESSAGE, label=_LABEL.LABEL_OPTIONAL,
        type_name=".securelogs.HttpResponse.Failure",
        oneof_index=0,
    )

    _pool.Add(fdp)
    req_cls = message_factory.GetMessageClass(_pool.FindMessageTypeByName("securelogs.HttpRequest"))
    resp_cls = message_factory.GetMessageClass(_pool.FindMessageTypeByName("securelogs.HttpResponse"))
    return req_cls, resp_cls


HttpRequest, HttpResponse = _build_descriptors()


def _format_body(body: bytes, max_len: int = 2000) -> str:
    """Decode body bytes to text, pretty-print JSON if possible."""
    if not body:
        return "<empty>"
    try:
        text = body.decode("utf-8")
    except UnicodeDecodeError:
        return f"<binary {len(body)} bytes>"
    try:
        obj = json.loads(text)
        text = json.dumps(obj, indent=2)
    except (json.JSONDecodeError, ValueError):
        pass
    if len(text) > max_len:
        return text[:max_len] + f"\n... truncated ({len(body)} bytes total)"
    return text


def decode_request(data: bytes) -> dict[str, Any]:
    """Decode gzip+proto HttpRequest."""
    msg = HttpRequest()
    msg.ParseFromString(gzip.decompress(data))
    return {
        "url": msg.url,
        "method": msg.method,
        "headers": dict(msg.headers),
        "body": msg.body,
    }


def decode_response(data: bytes) -> dict[str, Any]:
    """Decode gzip+proto HttpResponse."""
    msg = HttpResponse()
    msg.ParseFromString(gzip.decompress(data))
    which = msg.WhichOneof("result")
    if which == "success":
        return {
            "type": "success",
            "status": msg.success.status,
            "headers": dict(msg.success.headers),
            "body": msg.success.body,
        }
    if which == "failure":
        result: dict[str, Any] = {"type": "failure"}
        if msg.failure.HasField("response"):
            result["status"] = msg.failure.response.status
            result["headers"] = dict(msg.failure.response.headers)
            result["body"] = msg.failure.response.body
        result["message"] = msg.failure.message
        result["stacktrace"] = msg.failure.stacktrace
        return result
    return {"type": "unknown"}


def _print_decoded(req: dict, resp: dict, body_max: int = 2000) -> None:
    """Pretty-print decoded request and response."""
    print(f"  {req['method']} {req['url']}")
    if req["headers"]:
        for k, v in req["headers"].items():
            if k.lower() in ("content-type", "accept"):
                print(f"    {k}: {v}")
    if req["body"]:
        print(f"  Request body:")
        print(f"    {_format_body(req['body'], body_max)}")

    status = resp.get("status", "?")
    rtype = resp.get("type", "?")
    print(f"  Response: {status} ({rtype})")
    if resp.get("message"):
        print(f"  Error: {resp['message']}")
    if resp.get("body"):
        print(f"  Response body:")
        print(f"    {_format_body(resp['body'], body_max)}")
    if resp.get("stacktrace"):
        print(f"  Stacktrace: {resp['stacktrace'][:500]}")


# ─── BQ helpers ──────────────────────────────────────────────────────


def _table(env: str) -> str:
    return f"gcp-hopper-etldata-{env}.secure_logs_private.statements"


def _parse_ts_range(ts: str) -> tuple[str, str]:
    """Parse truncated ISO 8601 into (start, end) SQL timestamp strings.

    Supports: 2023-01-03, 2023-01-03T22, 2023-01-03T22:30, 2023-01-03T22:30:45
    """
    from datetime import timedelta

    patterns = [
        (r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}$", "%Y-%m-%dT%H:%M:%S", timedelta(seconds=1)),
        (r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$", "%Y-%m-%dT%H:%M", timedelta(minutes=1)),
        (r"^\d{4}-\d{2}-\d{2}T\d{2}$", "%Y-%m-%dT%H", timedelta(hours=1)),
        (r"^\d{4}-\d{2}-\d{2}$", "%Y-%m-%d", timedelta(days=1)),
    ]
    for regex, fmt, delta in patterns:
        if re.match(regex, ts):
            dt = datetime.strptime(ts, fmt)
            end = dt + delta
            return dt.strftime("%Y-%m-%d %H:%M:%S"), end.strftime("%Y-%m-%d %H:%M:%S")
    print(f"Unsupported timestamp format: {ts}", file=sys.stderr)
    sys.exit(1)


def _ts_range_filter(ts: str) -> str:
    """BQ filter for secure_logs using a truncated ISO 8601 timestamp."""
    start, end = _parse_ts_range(ts)
    return f'timestamp >= "{start}" AND timestamp < "{end}"'


def _time_filter(hours: int) -> str:
    interval = f"TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL {hours} HOUR)"
    return f"timestamp > {interval}"


def _run_query(sql: str) -> list[dict[str, Any]]:
    client = bigquery.Client()
    return [dict(row) for row in client.query(sql).result()]


def _fmt_ts(ts: Any) -> str:
    if isinstance(ts, datetime):
        return ts.strftime("%Y-%m-%d %H:%M:%S")
    return str(ts)


# ─── Commands ────────────────────────────────────────────────────────


def cmd_list(args: argparse.Namespace) -> None:
    """List statements for a conversation ID."""
    ts_filter = f"AND {_ts_range_filter(args.timestamp)}" if args.timestamp else ""
    sql = f"""
        SELECT statement_id, timestamp, third_party_service, action, producer
        FROM `{_table(args.env)}`
        WHERE conversation_id = "{args.conversation_id}" {ts_filter}
        ORDER BY timestamp LIMIT {args.limit}
    """
    for row in _run_query(sql):
        svc = row.get("third_party_service") or "?"
        action = row.get("action") or "?"
        producer = row.get("producer") or "?"
        print(
            f"{_fmt_ts(row['timestamp'])}  {svc:25s}  {action:30s}  "
            f"producer={producer}  id={row['statement_id']}"
        )


def cmd_get(args: argparse.Namespace) -> None:
    """Get a specific statement with decoded request/response."""
    ts_filter = f"AND {_ts_range_filter(args.timestamp)}" if args.timestamp else ""
    sql = f"""
        SELECT statement_id, conversation_id, timestamp,
               third_party_service, action, producer, user_id,
               statement_request, statement_response, labels
        FROM `{_table(args.env)}`
        WHERE conversation_id = "{args.conversation_id}"
          AND statement_id = "{args.statement_id}" {ts_filter}
        LIMIT 1
    """
    rows = _run_query(sql)
    if not rows:
        print("Statement not found.", file=sys.stderr)
        sys.exit(1)
    row = rows[0]
    print(f"statement_id:  {row['statement_id']}")
    print(f"conversation:  {row['conversation_id']}")
    print(f"timestamp:     {_fmt_ts(row['timestamp'])}")
    print(f"producer:      {row.get('producer') or '?'}")
    print(f"service:       {row.get('third_party_service') or '?'}")
    print(f"action:        {row.get('action') or '?'}")
    print(f"user_id:       {row.get('user_id') or '?'}")
    if row.get("labels"):
        labels = {l["key"]: l["value"] for l in row["labels"]}
        print(f"labels:        {labels}")
    print()
    try:
        req = decode_request(row["statement_request"])
        resp = decode_response(row["statement_response"])
        _print_decoded(req, resp, body_max=args.body_max)
    except Exception as e:
        print(f"Failed to decode request/response: {e}", file=sys.stderr)


def cmd_get_body(args: argparse.Namespace) -> None:
    """Print raw request or response body for a statement. Pipe-friendly."""
    ts_filter = f"AND {_ts_range_filter(args.timestamp)}" if args.timestamp else ""
    sql = f"""
        SELECT statement_request, statement_response
        FROM `{_table(args.env)}`
        WHERE conversation_id = "{args.conversation_id}"
          AND statement_id = "{args.statement_id}" {ts_filter}
        LIMIT 1
    """
    rows = _run_query(sql)
    if not rows:
        print("Statement not found.", file=sys.stderr)
        sys.exit(1)
    row = rows[0]
    try:
        if args.side == "request":
            msg = decode_request(row["statement_request"])
        else:
            msg = decode_response(row["statement_response"])
        body = msg.get("body", b"")
        if isinstance(body, bytes):
            sys.stdout.buffer.write(body)
        else:
            print(body)
    except Exception as e:
        print(f"Failed to decode: {e}", file=sys.stderr)
        sys.exit(1)


def cmd_list_service(args: argparse.Namespace) -> None:
    """Find statements by third-party service."""
    sql = f"""
        SELECT statement_id, conversation_id, timestamp, action, producer
        FROM `{_table(args.env)}`
        WHERE third_party_service = "{args.service}"
          AND {_time_filter(args.hours)}
        ORDER BY timestamp DESC LIMIT {args.limit}
    """
    for row in _run_query(sql):
        action = row.get("action") or "?"
        producer = row.get("producer") or "?"
        print(
            f"{_fmt_ts(row['timestamp'])}  {action:30s}  producer={producer}  "
            f"conv={row['conversation_id']}  id={row['statement_id']}"
        )


def cmd_list_producer(args: argparse.Namespace) -> None:
    """Find statements by producer service."""
    sql = f"""
        SELECT statement_id, conversation_id, timestamp,
               third_party_service, action
        FROM `{_table(args.env)}`
        WHERE producer = "{args.producer}"
          AND {_time_filter(args.hours)}
        ORDER BY timestamp DESC LIMIT {args.limit}
    """
    for row in _run_query(sql):
        svc = row.get("third_party_service") or "?"
        action = row.get("action") or "?"
        print(
            f"{_fmt_ts(row['timestamp'])}  {svc:25s}  {action:30s}  "
            f"conv={row['conversation_id']}  id={row['statement_id']}"
        )


def cmd_list_services(args: argparse.Namespace) -> None:
    """List distinct third-party services seen recently."""
    sql = f"""
        SELECT third_party_service, COUNT(*) AS cnt,
               ARRAY_AGG(DISTINCT action LIMIT 10) AS actions,
               ARRAY_AGG(DISTINCT producer LIMIT 5) AS producers
        FROM `{_table(args.env)}`
        WHERE {_time_filter(args.hours)}
          AND third_party_service IS NOT NULL
        GROUP BY third_party_service
        ORDER BY cnt DESC LIMIT 100
    """
    for row in _run_query(sql):
        actions = ", ".join(row.get("actions") or [])
        producers = ", ".join(row.get("producers") or [])
        print(f"{row['third_party_service']:30s}  count={row['cnt']:>6d}  producers=[{producers}]")
        if actions:
            print(f"  actions: {actions}")


# ─── CLI ─────────────────────────────────────────────────────────────


def main() -> None:
    parser = argparse.ArgumentParser(description="Debug secure-logs (external API calls)")
    parser.add_argument("--env", default="staging", help="Environment (default: staging)")
    sub = parser.add_subparsers(dest="command", required=True)

    _TS_HELP = "Truncated ISO 8601 timestamp to narrow BQ scan (e.g. 2023-01-03, 2023-01-03T22)"

    # list
    p = sub.add_parser("list", help="List statements for a conversation ID")
    p.add_argument("conversation_id", help="Conversation UUID")
    p.add_argument("--limit", type=int, default=50)
    p.add_argument("--timestamp", help=_TS_HELP)

    # get
    p = sub.add_parser("get", help="Get statement with decoded request/response")
    p.add_argument("conversation_id", help="Conversation UUID")
    p.add_argument("statement_id", help="Statement UUID")
    p.add_argument("--body-max", type=int, default=2000, help="Max body chars to display")
    p.add_argument("--timestamp", help=_TS_HELP)

    # get-body
    p = sub.add_parser("get-body", help="Print raw request or response body (pipe-friendly)")
    p.add_argument("conversation_id", help="Conversation UUID")
    p.add_argument("statement_id", help="Statement UUID")
    p.add_argument("side", choices=["request", "response"], help="Which body to print")
    p.add_argument("--timestamp", help=_TS_HELP)

    # search-service
    p = sub.add_parser("search-service", help="Find statements by third-party service")
    p.add_argument("service", help="Third-party service name (e.g. AlaskaNdc, Dida)")
    p.add_argument("--hours", type=int, default=24)
    p.add_argument("--limit", type=int, default=50)

    # search-producer
    p = sub.add_parser("search-producer", help="Find statements by producer")
    p.add_argument("producer", help="Producer service name (e.g. Hamburg)")
    p.add_argument("--hours", type=int, default=24)
    p.add_argument("--limit", type=int, default=50)

    # list-services
    p = sub.add_parser("list-services", help="List third-party services seen recently")
    p.add_argument("--hours", type=int, default=24)

    args = parser.parse_args()
    commands = {
        "list": cmd_list,
        "get": cmd_get,
        "get-body": cmd_get_body,
        "search-service": cmd_list_service,
        "search-producer": cmd_list_producer,
        "list-services": cmd_list_services,
    }
    commands[args.command](args)


if __name__ == "__main__":
    main()


# ─── Tests ───────────────────────────────────────────────────────────
# Run with: uv run --with-requirements secure-logs.py --with pytest -- pytest secure-logs.py -v


def test_parse_ts_range_day():
    start, end = _parse_ts_range("2023-01-03")
    assert start == "2023-01-03 00:00:00"
    assert end == "2023-01-04 00:00:00"


def test_parse_ts_range_hour():
    start, end = _parse_ts_range("2023-01-03T22")
    assert start == "2023-01-03 22:00:00"
    assert end == "2023-01-03 23:00:00"


def test_parse_ts_range_minute():
    start, end = _parse_ts_range("2023-01-03T22:30")
    assert start == "2023-01-03 22:30:00"
    assert end == "2023-01-03 22:31:00"


def test_parse_ts_range_second():
    start, end = _parse_ts_range("2023-01-03T22:30:45")
    assert start == "2023-01-03 22:30:45"
    assert end == "2023-01-03 22:30:46"


def test_ts_range_filter():
    f = _ts_range_filter("2023-06-15T14")
    assert 'timestamp >= "2023-06-15 14:00:00"' in f
    assert 'timestamp < "2023-06-15 15:00:00"' in f


def test_time_filter():
    f = _time_filter(24)
    assert "timestamp >" in f
    assert "INTERVAL 24 HOUR" in f


def test_decode_request_roundtrip():
    """Build a proto HttpRequest, gzip it, and decode it back."""
    msg = HttpRequest()
    msg.url = "https://example.com/api"
    msg.method = "POST"
    msg.headers["Content-Type"] = "application/json"
    msg.body = b'{"key": "value"}'
    compressed = gzip.compress(msg.SerializeToString())

    result = decode_request(compressed)
    assert result["url"] == "https://example.com/api"
    assert result["method"] == "POST"
    assert result["headers"]["Content-Type"] == "application/json"
    assert result["body"] == b'{"key": "value"}'


def test_decode_response_success_roundtrip():
    """Build a success HttpResponse, gzip it, and decode it back."""
    msg = HttpResponse()
    msg.success.status = 200
    msg.success.headers["Content-Type"] = "text/xml"
    msg.success.body = b"<ok/>"
    compressed = gzip.compress(msg.SerializeToString())

    result = decode_response(compressed)
    assert result["type"] == "success"
    assert result["status"] == 200
    assert result["headers"]["Content-Type"] == "text/xml"
    assert result["body"] == b"<ok/>"


def test_decode_response_failure_roundtrip():
    """Build a failure HttpResponse, gzip it, and decode it back."""
    msg = HttpResponse()
    msg.failure.response.status = 500
    msg.failure.response.body = b"Internal Server Error"
    msg.failure.message = "connection refused"
    msg.failure.stacktrace = "at com.example.Service"
    compressed = gzip.compress(msg.SerializeToString())

    result = decode_response(compressed)
    assert result["type"] == "failure"
    assert result["status"] == 500
    assert result["body"] == b"Internal Server Error"
    assert result["message"] == "connection refused"
    assert result["stacktrace"] == "at com.example.Service"


def test_format_body_json():
    body = b'{"key":"value"}'
    result = _format_body(body)
    assert '"key": "value"' in result  # pretty-printed


def test_format_body_truncation():
    body = b"x" * 3000
    result = _format_body(body, max_len=100)
    assert "truncated" in result


def test_format_body_binary():
    body = bytes(range(256))
    result = _format_body(body)
    assert "binary" in result


def test_format_body_empty():
    assert _format_body(b"") == "<empty>"
