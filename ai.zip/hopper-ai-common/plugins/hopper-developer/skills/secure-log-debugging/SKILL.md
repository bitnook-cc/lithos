---
name: secure-log-debugging
description: >-
  Use when investigating external/third-party API calls, debugging HTTP request/response
  payloads to providers, or tracing secure-logs entries by conversation ID, service, or producer.
  Triggers: "secure-logs", "secure logs", "third-party call", "external API call",
  "provider request", "provider response", "statement request", "statement response".
---

# Debug Secure-Logs (External API Calls)

## Overview

Secure-logs stores HTTP request/response pairs for all calls to external/third-party services (airlines, hotels, payment providers, etc.). Each entry is a **statement** linked to a state machine session via a **conversation_id**.

Typical flow: use the [state-machine-debugging skill](hopper-developer:state-machine-debugging) to find a `conversation_id` from a session, then use this skill to inspect the actual HTTP calls.

## CLI Tool

The `secure-logs.py` script in this skill directory provides all common queries. Run with `uv run <path-to-this-skill-dir>/secure-logs.py`.

All commands accept `--env` (default: `staging`). Production BQ access requires additional permissions that most developers don't have.

### List third-party services
```bash
uv run secure-logs.py list-services --hours 24
```
```
Hotelbeds                       count= 30376  producers=[Hamburg, hts-fintech-proxy]
  actions: Hotelbeds-Shop, Hotelbeds-Content, Availability, Hotelbeds-Availability
Amadeus                         count= 15215  producers=[Barajas, Madrid]
  actions: Location, PNR_AddMultiElements, Fare_InformativeBestPricingWithoutPNR, ...
Sabre                           count=  3766  producers=[Southlake]
```

### List statements for a conversation ID

**Large output warning**: A single conversation can have 50+ statements (e.g., hotel availability fans out to many providers). Use `--limit` to cap results.

```bash
uv run secure-logs.py list "CONVERSATION_UUID"
```
```
2026-03-20 17:05:20  webbeds                    webbeds-availability            producer=Hamburg  id=019d0c35-6be1-...
2026-03-20 17:05:20  Amadeus-GDS                Amadeus-GDS-Availability        producer=Hamburg  id=019d0c35-6c63-...
2026-03-20 17:05:21  ean                        ean-propertiesAvailability      producer=Hamburg  id=019d0c35-6c73-...
```

### Get a specific statement (decoded HTTP request/response)

**Large output warning**: Request/response bodies can be very large (XML/JSON payloads). Default truncation is 2000 chars. Use `--body-max` to control.

```bash
uv run secure-logs.py get "CONVERSATION_UUID" "STATEMENT_UUID"
uv run secure-logs.py get "CONVERSATION_UUID" "STATEMENT_UUID" --body-max 5000
```
```
statement_id:  019d0c35-6c63-7126-ba4f-bc061311a7ce
conversation:  9228104d-918b-479f-9d1f-73437494c9fa
timestamp:     2026-03-20 17:05:20
producer:      Hamburg
service:       Amadeus-GDS
action:        Amadeus-GDS-Availability

  POST https://noded2.test.webservices.amadeus.com:443/1ASIWHOUHPE
    content-type: text/xml
  Request body:
    <soapenv:Envelope xmlns:typ="http://xml.amadeus.com/2010/06/Types_v1" ...
  Response: 200 (success)
  Response body:
    <?xml version="1.0" encoding="UTF-8"?><soap:Envelope ...
```

### Get raw request or response body (pipe-friendly)
```bash
uv run secure-logs.py get-body "CONVERSATION_UUID" "STATEMENT_UUID" request
uv run secure-logs.py get-body "CONVERSATION_UUID" "STATEMENT_UUID" response
# Pipe to jq or xmllint:
uv run secure-logs.py get-body "CONV_UUID" "STMT_UUID" response 2>/dev/null | jq .
uv run secure-logs.py get-body "CONV_UUID" "STMT_UUID" response 2>/dev/null | xmllint --format -
```

### Search by third-party service
```bash
uv run secure-logs.py search-service AlaskaNdc --hours 24 --limit 20
```

### Search by producer (Hopper service)
```bash
uv run secure-logs.py search-producer Hamburg --hours 24 --limit 20
```

## Dashboard (Browser)

`https://dashboard-{env}.portal.hopper.com/#/securelog/{conversation_id}`
`https://dashboard-{env}.portal.hopper.com/#/securelog/{conversation_id}/{statement_id}?timestamp={iso_timestamp}`

## Key Concepts

- **statement**: One HTTP request/response pair to an external service
- **conversation_id**: UUID linking statements to state machine sessions
- **statement_request/response**: Gzip-compressed protobuf (`HttpRequest`/`HttpResponse`), decoded automatically by the CLI
- **producer**: The Hopper service that made the call (e.g., `Hamburg`, `Madrid`, `Southlake`)
- **third_party_service**: The external provider (e.g., `Amadeus`, `Sabre`, `AlaskaNdc`, `Hotelbeds`)
- **action**: What the call does (e.g., `AirShopping`, `OrderCreate`, `Availability`)

## Custom Queries

Read `secure-logs.py` to understand the query patterns and protobuf decoding, then write custom scripts as needed. Key details:

- **Table**: `gcp-hopper-etldata-{env}.secure_logs_private.statements`
- **Partition**: `timestamp` (MONTH) — always filter on `timestamp >` for performance
- **Clustering**: `conversation_id, timestamp, statement_id`
- **Proto source**: `hopper-org/secure-logs` repo, `proto/src/main/protobuf/hopper/securelogs/v1/secure_logs_service.proto`

## Debugging Checklist

1. **Get conversation_id** — from a session via `state-machine.py get-session-steps` (see [state-machine-debugging](hopper-developer:state-machine-debugging))
2. **List statements** — `list` shows all external calls in the session
3. **Inspect a call** — `get` decodes the full HTTP request and response
4. **Check response status** — look for non-2xx status codes or failure type
5. **Read error details** — failures include error message and stacktrace
