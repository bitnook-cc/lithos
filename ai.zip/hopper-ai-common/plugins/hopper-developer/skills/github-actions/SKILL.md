---
name: github-actions
description: >-
  Use when creating or modifying GitHub Actions workflows in a Hopper repo,
  setting up CI/CD pipelines, configuring runners, or troubleshooting
  workflow failures.
---

# GitHub Actions at Hopper

## Overview

Hopper uses GitHub Actions for CI/CD with custom self-hosted runners and shared reusable workflows/actions from [`hopper-org/.github`](https://github.com/hopper-org/.github).

## Custom Runners

**Never use `ubuntu-latest` or any GitHub-hosted runner.** Always use Hopper's self-hosted runners:

| Runner | Use case |
|--------|----------|
| `gh-runner-small` | Lightweight tasks: release-me, compliance checks, PR title validation |
| `gh-runner-medium` | Standard builds, artifact publishing |
| `gh-runner-arm-medium` | ARM-based Scala/Bazel builds |
| `gh-runner-arm-large` | Resource-intensive tests with coverage |
| `gh-runner-large` | Heavy builds, integration tests |

Choose the smallest runner that fits the workload.

## Required Patterns

### Permissions

**Every workflow MUST declare a `permissions` block.** When you specify any permission, all unspecified permissions are set to `none`. Only grant what the workflow actually needs.

Common permissions at Hopper:

```yaml
permissions:
  contents: read       # Needed for actions/checkout and reading repo contents
  id-token: write      # Needed for OIDC (mainly GCP auth via workload identity at Hopper)
  contents: write      # For tagging, pushing (implies read)
  pull-requests: read  # For reading PR metadata
  pull-requests: write # For PR comments (dyff, coverage)
  checks: write        # For status checks
```

All available permissions:

```yaml
permissions:
  actions: read|write|none
  artifact-metadata: read|write|none
  attestations: read|write|none
  checks: read|write|none
  contents: read|write|none
  deployments: read|write|none
  id-token: write|none
  issues: read|write|none
  models: read|none
  discussions: read|write|none
  packages: read|write|none
  pages: read|write|none
  pull-requests: read|write|none
  security-events: read|write|none
  statuses: read|write|none
```

### Fork Guard

All jobs must skip execution on personal forks:

```yaml
if: github.repository_owner == 'hopper-org'
```

## Shared Workflows & Actions

Reusable workflows and actions live in [`hopper-org/.github`](https://github.com/hopper-org/.github). Reference them as:

```yaml
# Reusable workflows
uses: hopper-org/.github/.github/workflows/{workflow}.yml@main

# Actions
uses: hopper-org/.github/actions/{action}@main
```

When unsure what's available, browse the repo directly.
