---
name: atlantis
description: "Use when working with Terraform infrastructure-as-code repos at Hopper (Olympus, Arecibo, github-config), when checking PR plans, applying changes, or troubleshooting Atlantis CI."
---

# Atlantis CI

## Overview

Hopper uses **Atlantis CI** to automate Terraform plan/apply workflows via GitHub pull requests. All infrastructure changes must go through Atlantis — never run `terraform apply` locally.

Key repos using Atlantis: `Olympus` (GCP infra), `Arecibo` (Datadog config), `github-config` (GitHub repo management).

## Workflow

```dot
digraph atlantis {
    "Create PR" -> "Atlantis auto-plans";
    "Atlantis auto-plans" -> "Review plan in PR comments";
    "Review plan in PR comments" -> "Plan looks good?" [shape=diamond];
    "Plan looks good?" -> "Comment: atlantis apply" [label="yes"];
    "Plan looks good?" -> "Fix code + push" [label="no"];
    "Fix code + push" -> "Atlantis auto-plans";
    "Comment: atlantis apply" -> "Apply succeeded?" [shape=diamond];
    "Apply succeeded?" -> "Merge PR" [label="yes"];
    "Apply succeeded?" -> "Comment: atlantis plan" [label="no — must re-plan first"];
    "Comment: atlantis plan" -> "Review plan in PR comments";
}
```

## Commands

Comment these on the PR:

| Command | Purpose |
|---|---|
| `atlantis plan` | Re-run plan for all affected projects |
| `atlantis apply` | Apply all planned projects |
| `atlantis unlock` | Discard plans and release locks |

> **Do NOT use `-d` or `-p` flags** with `atlantis plan` or `atlantis apply`. Targeted commands (e.g., `atlantis plan -d projects/gcp-hopper-app-staging`) release locks on projects not included in the command. If your PR affects multiple projects, a targeted plan/apply on one project will release the lock on the others, which can cause applied changes to be reverted. Always use `atlantis plan` and `atlantis apply` without flags to operate on all affected projects together.

## Reading the Plan

The relevant plan is the Atlantis comment posted **after** the latest commit or the latest `atlantis plan` comment, whichever is more recent. Earlier Atlantis comments are stale.

### Finding Atlantis Comments

Use the GitHub MCP tool to list PR comments and filter for Atlantis:

```
mcp__github__pull_request_read
  method: "get_comments"
  owner: "hopper-org"
  repo: "{repo}"
  pullNumber: {pr_number}
```

Then filter for comments where the author login contains "atlantis" and the body contains "Ran Plan". The **last** such comment is the current plan.

### If No Plan Comment Exists Yet

Atlantis hasn't finished. Check the PR check runs:

```
mcp__github__pull_request_read
  method: "get_check_runs"
  owner: "hopper-org"
  repo: "{repo}"
  pullNumber: {pr_number}
```

If `atlantisci_hopper/plan` is **pending**, the plan is still running. Wait and check again.

## Plan Review Checklist

Before applying, verify:

- **Resource counts** — check "Plan: X to add, Y to change, Z to destroy"
- **No unexpected destroys** — look for `-` (destroy) lines in the diff
- **No unexpected replacements** — `-/+` means destroy-and-recreate
- **Correct values** — descriptions, names, permissions match intent
- **Policy checks passed** — look for the policy check comment after the plan

## Applying

Comment `atlantis apply` on the PR. After applying:

- **Success**: Merge the PR
- **Failure**: Must re-plan first (`atlantis plan`), then review the new plan, then apply again. Never re-apply a stale plan.

## Commenting on a PR

Use the GitHub MCP tool to comment on a PR (e.g., to trigger plan or apply):

```
mcp__github__add_issue_comment
  owner: "hopper-org"
  repo: "{repo}"
  issue_number: {pr_number}
  body: "atlantis apply"
```

## Safety

- **Always review the plan** before applying — especially resource deletions
- **Test in dev/staging first** when possible (Olympus has per-environment directories)
- **After a failed apply**, always re-plan before retrying
- **Never run `terraform apply` locally** — all changes go through Atlantis
- **Production destroys** require explicit confirmation and careful review
- **Partially applied PRs** — if `atlantis apply` succeeds for some projects but fails for others, immediately add the `do-not-unlock` label to the PR to prevent others from unlocking it. Then either revert the change or fix the failing projects and re-plan/re-apply. Unlocking a partially applied PR can cause the successfully applied changes to be reverted

## Common Issues

| Issue | Solution |
|---|---|
| Plan is stale after new commits | Atlantis auto-re-plans on push, or comment `atlantis plan` |
| Apply fails with transient error | Re-plan (`atlantis plan`), verify plan, then re-apply |
| Lock held by another PR | Comment `atlantis unlock` on the blocking PR, or wait for it to merge |
| Policy violation | Read the error — it shows the exact ACL or module version needed |
| Plan shows unexpected changes | Check for state drift or changes made outside Terraform |
