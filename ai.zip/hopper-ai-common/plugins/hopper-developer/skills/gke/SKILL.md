---
name: gke
description: >-
  Use when investigating pods, deployments, or services running in GKE clusters
  at Hopper, when checking pod status, logs, events, or crash reasons, when
  needing to inspect Kubernetes resources for a Hopper service, or when looking
  up cluster names or namespaces for a Hopper service.
---

# GKE — Cluster Access & Kubernetes Operations

## Overview

Hopper services run on GKE clusters in GCP. This skill covers how to find and inspect workloads and debug pod issues.

**Use the Datadog MCP server** for all Kubernetes inspection. The `kubernetes` toolset is enabled on the Datadog MCP server and works across all environments including production. Neither `kubectl` nor the GKE MCP server can reach production clusters.

## Clusters

### Main Clusters (common realm)

| Environment | Project | Cluster | Location |
|-------------|---------|---------|----------|
| Development | `gcp-hopper-app-development` | `core-cluster` | `us-central1` |
| Staging | `gcp-hopper-app-staging` | `core-cluster` | `us-central1` |
| Production | `gcp-hopper-app-production` | `core-cluster` | `us-central1` |

### CI/CD Clusters

| Project | Cluster | Location |
|---------|---------|----------|
| `gcp-hopper-cicd` | `main-cluster` | `us-central1` |
| `gcp-hopper-cicd` | `main-cluster-2` | `us-east4` |

Partner and GData realms have their own clusters in their respective GCP projects.

Most services deploy to `core-cluster` in `us-central1`. The deploy target is configured in `deployment/vars.bzl`:

```starlark
default_sites = [
    SITES.env["development"].realm["common"].cluster["core-cluster"],
    SITES.env["staging"].realm["common"].cluster["core-cluster"],
    SITES.env["production"].realm["common"].cluster["core-cluster"],
]
```

### What Runs in Each Cluster

Every cluster has these infrastructure components (managed by the LongBeach repo):

| Component | What it does |
|-----------|-------------|
| **Istio** | Service mesh — mTLS, traffic routing, Envoy sidecars. Use `istioctl` to investigate mesh issues. |
| **Datadog agent** | DaemonSet on every node — collects APM traces, metrics, logs |
| **Calico** | Network policy enforcement |
| **cert-manager** | Automated TLS certificates |

## Finding Your Service

A service's namespace and workload names come from `deployment/vars.bzl`:

```starlark
DEPLOY_PLAN = plan.make(
    kube_namespace = "my-service",     # ← K8s namespace
    ...
    unit = plan.application(
        kube_name = "unit",             # ← Deployment name
        telemetry_name = "my-service",  # ← Datadog service name
        ...
    ),
)
```

## Inspecting Kubernetes Resources via Datadog MCP

Before using the Kubernetes tools, load the Datadog skill for tool schemas, parameter details, and query patterns:

```
load_datadog_skill
  skill_name: "datadog/kubernetes"
```

When querying, use the service's `kube_namespace` and `kube_name` from `deployment/vars.bzl` to identify resources, and `core-cluster` as the cluster name for most services.

## Debugging Workflows

### Check Pod Status

Use the Datadog MCP Kubernetes tools to search for pods matching your service, then describe any unhealthy ones.

### Get Crash Details

Retrieve the pod manifest and check `status.containerStatuses[].lastState.terminated`:

| Exit Code | Reason | What to do |
|-----------|--------|------------|
| 137 | `OOMKilled` | Container exceeded memory limit — bump `memory` in workload BUILD file |
| 1 | `Error` | Application error — check Datadog logs |
| 143 | — | SIGTERM (graceful shutdown, usually normal) |

### CrashLoopBackOff Checklist

1. **Search pods** → find the crashing pod
2. **Get manifest** → check `lastState.terminated.reason`
3. **OOMKilled?** → No error logs will exist (kernel kills the process). Bump memory in `mixins.runtime.jvm.container_resources()` or `mixins.core.container_resources()`.
4. **Error (exit 1)?** → Search Datadog logs: `service:{telemetry-name} env:{environment} status:error`
5. **Describe the pod** → probe failures suggest the app starts but doesn't become healthy in time

### Get Logs

For application log search, use **Datadog** — see [datadog-ops](hopper-developer:datadog-ops). App logs flow to Datadog, not GCP Cloud Logging.

## Pod Labels & Environment Variables

### Standard Labels

| Label | Source |
|-------|--------|
| `app.kubernetes.io/name` | `kube_name` from deploy plan |
| `app.kubernetes.io/part-of` | `kube_namespace` |
| `app.kubernetes.io/instance` | Usually `default` |
| `env` | Environment |
| `realm` | Realm |
| `tags.datadoghq.com/service` | `telemetry_name` |
| `tags.datadoghq.com/version` | App version |

### Environment Variables (Downward API)

| Env Var | Value |
|---------|-------|
| `H4R_ENV` | Environment (development/staging/production) |
| `H4R_REALM` | Realm |
| `H4R_CLUSTER_NAME` | Cluster name |
| `H4R_CLUSTER_PROJECT` | GCP project |
| `H4R_CLUSTER_REGION` | Region |
| `H4R_APP_TELEMETRY_NAME` | Datadog service name |
| `H4R_APP_VERSION` | Application version |
| `DD_SERVICE` | Same as telemetry name |
| `DD_ENV` | Same as environment |

## Alternatives (dev/staging only)

`kubectl` and the GKE MCP server (`mcp__gcp-gke__kube_get`) **do not work for production clusters**. They can only reach development and staging. If you need them for those environments:

- **kubectl:** Requires `gcloud container clusters get-credentials` with `--dns-endpoint` (clusters are not internet-exposed; without it you'll get `dial tcp 172.16.x.x:443: i/o timeout`).
- **GKE MCP:** Requires the GCP GKE MCP server installed locally (see [gcp](hopper-developer:gcp)).

For production, always use Datadog MCP.

## Cross-References

- [gcp](hopper-developer:gcp) — GCP project names and organization
- [deployment](hopper-developer:deployment) — How workloads are defined (BUILD files, vars.bzl, mixins)
- [datadog-ops](hopper-developer:datadog-ops) — Searching logs, metrics, and traces
- [olympus](hopper-developer:olympus) — GCP infrastructure as code
