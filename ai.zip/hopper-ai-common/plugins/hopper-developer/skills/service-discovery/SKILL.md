---
name: service-discovery
description: >-
  Use when needing to find Hopper services, libraries, or repositories — such as
  discovering which service owns a capability, finding API endpoints to call,
  understanding service dependencies, locating internal libraries and tools,
  looking up service ownership or tier, finding team Slack channels,
  or understanding how services collaborate within a business flow.
---

# Service, Library & Repository Discovery

## Overview

The [`hopper-org/service-directory`](https://github.com/hopper-org/service-directory) repository is the canonical source for discovering Hopper-internal services, libraries, and repositories. It contains structured, machine-readable metadata about what exists in the hopper-org GitHub organization.

Coverage is growing — not every service or library has an entry yet. If you can't find what you're looking for, fall back to GitHub org search or ask the user.

**Important:** The service-directory covers Hopper-internal tools only. Always consider whether a third-party library or service might be more appropriate for the task at hand.

## hopper-sd CLI

Install once with `uv tool install hopper-sd`, then use `hopper-sd` directly. To update: `uv tool upgrade hopper-sd`.

If `hopper-sd` is not found, install it before proceeding:

```bash
uv tool install hopper-sd
```

### Search

```bash
hopper-sd repo search "domain:air flight shopping"
hopper-sd repo search "type:service consumer:brooklyn"
hopper-sd repo search "email notifications"
hopper-sd repo search "interface:grpc visibility:public"
```

**Filters** (combinable, AND-ed):

| Filter | Matches |
|--------|---------|
| `domain:air` | exact domain |
| `type:service` | exact repo_type (service, library, bff, etc.) |
| `repo:Lexington` | substring match on repo name |
| `ns:lexington` | exact GKE namespace |
| `consumer:brooklyn` | services consumed by brooklyn |
| `depends-on:southlake` | services that depend on southlake |
| `interface:grpc` | services with gRPC interfaces |
| `visibility:public` | services with public APIs |

Free text (anything not a `field:value` pair) is BM25-ranked against descriptions and README content. Results are boosted by relevancy score.

Options: `--limit N` (default 10), `--refresh` (force re-download index).

The search index is cached locally at `~/.cache/service-directory/` and auto-refreshed from GitHub/GCS.

### Explore a service

```bash
hopper-sd repo show Lexington          # full README + metadata
hopper-sd repo workloads Lexington     # workloads with interfaces + mesh URLs
hopper-sd repo consumers Lexington     # who calls this service
hopper-sd repo dependencies Lexington  # what it depends on
hopper-sd repo list domains            # list all domains with counts
hopper-sd repo list types              # list all repo types with counts
```

### Repository metadata (from Backstage)

```bash
hopper-sd repo owner Lexington         # owning vertical/team
hopper-sd repo tier Lexington          # service tier
hopper-sd repo slack Lexington         # Slack channels (with vertical fallback)
```

These pull from Backstage and support `--json` for machine-readable output.

### Vertical (team) metadata

```bash
hopper-sd vertical slack org-vt-core_platform   # Slack channels for a vertical
```

## When to Use This

- **"Which service handles X?"** — `hopper-sd repo search "X"`
- **"How do I call service Y?"** — `hopper-sd repo show Y` for full details, or `repo workloads Y` for mesh URLs
- **"What are the dependencies of Z?"** — `hopper-sd repo dependencies Z`
- **"Is there an internal library for W?"** — `hopper-sd repo search "type:library W"`
- **"What services are in the flights domain?"** — `hopper-sd repo search "domain:air"`
- **"Where is the Terraform for X?"** — `hopper-sd repo search "type:infrastructure X"`
- **"Who owns service X?"** — `hopper-sd repo owner X`
- **"What tier is service X?"** — `hopper-sd repo tier X`
- **"What's the Slack channel for service X?"** — `hopper-sd repo slack X`
- **"How does flight shopping work end-to-end?"** — Check `summary/subsystems/air/` for cross-service flow docs

## How to Navigate

1. **Search** — `hopper-sd repo search "your query"` to find the right services or docs
2. **Show** — `hopper-sd repo show <name>` for full README and metadata
3. **Drill down** — `repo workloads`, `consumers`, or `dependencies` for specific details
4. **Ownership** — `repo owner`, `repo tier`, or `repo slack` for team and operational metadata
5. **Check APIs** — `repositories/<name>/api/` in the service-directory repo for OpenAPI specs or protobuf files

## What's in the Directory

```
service-directory/
├── repositories/           # One directory per repo
│   └── <name>/
│       ├── service.yaml    # Structured manifest (workloads, APIs, mesh URLs,
│       │                   #   visibility, consumers, dependencies, pub/sub)
│       ├── README.md       # Human-readable description with usage flows and examples
│       ├── .discovery.md   # Agent notes for faster re-analysis
│       ├── .metadata.yaml  # Generation provenance (SHAs, workflow URL, timestamp)
│       └── api/
│           ├── *.openapi.yaml   # OpenAPI specs for HTTP APIs
│           └── proto/           # Protobuf definitions for gRPC APIs
├── summary/                # Generated cross-repo summaries
│   ├── INDEX.md            # Top-level routing: domains + platform capabilities
│   ├── platform/           # Platform-wide catalogs
│   │   ├── services.md     # Shared platform services by capability
│   │   ├── infrastructure.md # IaC, CI/CD, developer tooling repos
│   │   └── libraries-*.md  # Shared libraries by language (scala, typescript, proto, etc.)
│   └── subsystems/         # Per-domain documentation
│       └── <domain>/
│           ├── overview.md # Domain overview: services, libraries, flows, cross-domain deps
│           └── <flow>.md   # Flow document with Mermaid sequence diagram
```

## Reporting Inaccuracies

If you find an inaccuracy while using the service directory — wrong API spec, missing endpoint, incorrect dependency, broken flow diagram — **report it** by opening a feedback issue:

1. Go to `hopper-org/service-directory` and open a new issue using the **Service Directory Feedback** template
2. Set the **Target** to the affected path (e.g., `repositories/Lexington` or `summary/subsystems/air/flight-shopping`)
3. Select the **Category** and describe the issue with evidence

The generating agent will read your feedback on the next run and fix the entry. This is the primary mechanism for improving service directory quality — don't silently work around inaccuracies, report them.
