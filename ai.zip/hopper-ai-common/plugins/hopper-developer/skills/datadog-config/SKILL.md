---
name: datadog-config
description: >-
  Use when creating or modifying Datadog monitors, SLOs, or dashboards in
  Arecibo, configuring DD instrumentation in deployment BUILD files, setting up
  metric allowlists, or adding DD integration to a Hopper service.
---

# Datadog Configuration — Monitors, SLOs & Instrumentation

## Overview

Hopper uses a mix of infrastructure-as-code (Terraform in Arecibo) and platform deployment mixins to configure Datadog. This skill covers how to set up and modify DD monitoring and instrumentation for a service.

## Arecibo — Monitors & SLOs as Code

All Datadog monitors, SLOs, and integrations are managed as Terraform in the [Arecibo](https://github.com/hopper-org/Arecibo) repo.

### Directory Structure

```
Arecibo/
  platform/
    datadog/                    # Platform-wide DD config (provider, PagerDuty, Slack)
      main.tf                   # Datadog provider (v3.36.1), GCS backend
      monitors.tf               # Log quota alerts, agent health, infrastructure
      pagerduty.tf              # PagerDuty integration (~80 services)
      slack.tf                  # Slack channel integrations (~90 channels)
      http-server-span-metrics.tf  # Span metric generation for HTTP services
      grpc-server-span-metrics.tf  # Span metric generation for gRPC services
    config/
      log-indexes.tf            # Log index configuration
      log-archives.tf           # Log archive to GCS
      trace-retention-filters.tf
  security/
    datadog/                    # Security-specific monitors (PII detection)
  applications/
    {service}/                  # Per-service monitoring
      main.tf                   # Provider reference
      monitors.tf               # Service monitors
      slos.tf                   # Service-level objectives
      local-variables.tf        # Notifications, thresholds, realms
      HOPPEROWNERS              # Team ownership
```

### Working with Arecibo

Arecibo uses Atlantis CI for Terraform plans/applies. See the [atlantis skill](hopper-developer:atlantis) for the PR workflow.

## Shared Terraform Modules

Monitors are built using shared modules from `hopper-org/terraform-modules`:

| Module | Purpose | Example ref |
|--------|---------|-------------|
| `http-monitors` | HTTP trace-based monitoring (latency, error rate) | `http-monitors-v4.2.2` |
| `jvm-monitors` | JVM heap, GC, thread monitoring | `jvm-monitors-v3.3.0` |
| `grpc-monitors` | gRPC service monitoring | `grpc-monitors-v3.x` |
| `kubernetes/pod` | Pod health, restarts, resource usage | `kubernetes/pod-v4.2.0` |
| `psql-monitors` | PostgreSQL database monitoring | `psql-monitors-v2.x` |
| `notification-users` | Slack + PagerDuty notification endpoints | `notification-users-v9.68.0` |

### Using HTTP Monitors Module

```terraform
module "http_monitors" {
  source = "git::git@github.com:hopper-org/terraform-modules.git//modules/http-monitors?ref=http-monitors-v4.2.2"

  service = local.service
  bu      = "platform"
  realm   = "common"

  warning_receivers  = [local.platform_slack]
  critical_receivers = [local.platform_pagerduty]

  error_rate_monitor_overrides = {
    # Per-endpoint threshold tuning
  }
  latency_monitor = {
    # Latency thresholds with grace periods
  }
}
```

### Using JVM Monitors Module

```terraform
module "jvm_monitors" {
  source = "git::git@github.com:hopper-org/terraform-modules.git//modules/jvm-monitors?ref=jvm-monitors-v3.3.0"

  service       = "bifrost"
  warning_notify = [local.platform_slack]
  alert_notify   = [local.platform_pagerduty]
}
```

### Notification Setup

```terraform
module "notification_users" {
  source = "git::git@github.com:hopper-org/terraform-modules.git//modules/notification-users?ref=notification-users-v9.68.0"
}

locals {
  platform_slack     = module.notification_users.slack_devops_alerts_platform
  platform_pagerduty = module.notification_users.pagerduty_platform
}
```

## Creating Monitors

### Module-Based (Preferred)

Use shared modules for standard monitoring patterns. This ensures consistency and automatic updates.

### Raw `datadog_monitor` Resource

For custom monitors not covered by modules:

```terraform
resource "datadog_monitor" "my_service_latency_high" {
  name = "My Service P90 Latency is High"
  type = "metric alert"

  query = "avg(last_60m):p90:trace.finagle.http.server.request.duration{service:my-service,env:production} > 0.8"

  monitor_thresholds {
    critical = 0.8
    warning  = 0.6
  }

  message = <<-EOT
    {{#is_alert}}${join(", ", local.critical_receivers)}{{/is_alert}}
    {{#is_warning}}${join(", ", local.warning_receivers)}{{/is_warning}}
    {{#is_recovery}}${join(", ", local.warning_receivers)}{{/is_recovery}}
  EOT

  tags = ["env:production", "service:my-service", "bu:platform", "managed:terraform"]
}
```

**Standard tags:** Always include `env:production`, `service:{name}`, `bu:{business_unit}`, `managed:terraform`.

**Notification pattern:** Two tiers — warning goes to Slack, critical goes to PagerDuty.

## Creating SLOs

### Metric-Based SLO

```terraform
resource "datadog_service_level_objective" "my_service_uptime" {
  name = "My Service API Uptime"
  type = "metric"

  query {
    numerator   = "sum:trace.finagle.http.server.request.hits{service:my-service,env:production}.as_count() - sum:trace.finagle.http.server.request.errors{service:my-service,env:production}.as_count()"
    denominator = "sum:trace.finagle.http.server.request.hits{service:my-service,env:production}.as_count()"
  }

  thresholds {
    timeframe = "7d"
    target    = 99.0
  }
  thresholds {
    timeframe = "30d"
    target    = 99.0
  }

  tags = ["env:production", "service:my-service", "bu:platform", "managed:terraform"]
}
```

### Monitor-Based SLO

```terraform
resource "datadog_service_level_objective" "my_service_synthetic" {
  name        = "My Service Synthetic Uptime"
  type        = "monitor"
  monitor_ids = [datadog_monitor.my_synthetic_test.id]

  thresholds {
    timeframe = "7d"
    target    = 99.9
  }

  tags = ["target:synthetic", "bu:platform"]
}
```

## Deployment Instrumentation

### Automatic via Predefs

Most instrumentation is automatic when using `mixins.predef.helpers_hopper_server()`:

```starlark
mixins.predef.helpers_hopper_server(
    datadog = True,           # Injects DD Java agent (default: True)
    opentelemetry = True,     # Enables OTel metrics export (default: True)
    # ...
)
```

This automatically:
- Injects the DD Java agent at `/app/javaagents/com.datadoghq-dd-java-agent.jar`
- Enables DD profiling (`DD_PROFILING_ENABLED=true`)
- Sets Unified Service Tagging (service/env/version) via pod labels
- Configures trace propagation (Datadog + B3 formats)
- Sets up OTel metrics export via OTLP/gRPC to the DD agent

### Telemetry Mixin

For fine-grained control, use `mixins.telemetry.datadog()` directly:

```starlark
workload.container("primary", mixins = [
    mixins.telemetry.datadog(),
])
```

### Key Environment Variables

Set automatically by the platform, but can be overridden:

| Variable | Default | Purpose |
|----------|---------|---------|
| `DD_SERVICE` | From pod label | Service name for APM |
| `DD_ENV` | From pod label | Environment tag |
| `DD_VERSION` | From pod label | Version tag |
| `DD_AGENT_HOST` | `$(HOST_IP)` | DD agent address |
| `DD_PROFILING_ENABLED` | `true` | Continuous profiling |
| `DD_TRACE_SAMPLE_RATE` | `1.0` | Trace sampling rate |
| `DD_TRACE_RATE_LIMIT` | `100000` | Max traces/second |
| `DD_TRACE_PROPAGATION_STYLE_EXTRACT` | `datadog,b3multi` | Inbound trace formats |
| `DD_TRACE_PROPAGATION_STYLE_INJECT` | `datadog,b3multi` | Outbound trace formats |
| `DD_TRACE_HEADER_TAGS` | `x-hopper-tenant-id:app-tenant` | Header-to-tag mapping |

### Custom DD_SERVICE Name

Override the default service name (from `telemetry_name`) per workload:

```starlark
mixins.core.env_var(
    key = "DD_SERVICE_NAME",
    value = "houston-notification-flights",
),
```

## Code Instrumentation

### helpers-stable Libraries

Hopper services use shared libraries from `helpers-stable` for DD integration:

| Library | Purpose |
|---------|---------|
| `helpers-datadog` | DogStatsD metrics (StatsReceiver → DD) |
| `helpers-opentracing` | OpenTracing spans, tags, context propagation |
| `helpers-opentracing-http` | HTTP-specific tracing (header injection/extraction) |
| `helpers-server` | `DataDogOpenTracing` trait for DD tracer setup |
| `helpers-opentelemetry` | OTel instrumentation hooks |

### Custom Tracing

```scala
// Using Tracing mixin
class MyService extends Tracing {
  def myOperation(): Future[Result] =
    trace("myOperation", tags = Map("key" -> "value")) {
      // async operation
    }
}

// Direct OpenTracing API
OpenTracing.letSpan("operation.name")(TagValue(...)) {
  // Future[Result]
}
```

### Custom Metrics

Services emit custom metrics via Finagle's `StatsReceiver`, filtered by an allowlist:

```scala
// In code
val stats: StatsReceiver = ???
val counter = stats.scope("my_feature").counter("requests")
counter.incr()
```

```
# src/main/resources/datadog-metric-allowlist
^my_feature\..*$
^another_scope\..*$
```

Only metrics matching allowlist patterns are sent to DD. Configure via `ddMetricAllowlistFile` flag.

### Log Trace Correlation

Logs automatically include trace context via logback MDC:

```xml
<pattern>%d{yyyy-MM-dd'T'HH:mm:ss.SSS} [%thread] %-5level [%X{xRequestId:-_}:%X{spanId:-_}] %logger{36} - %msg%n</pattern>
```

## Backstage Integration

Register DD links in `.backstage/component/*.yml`:

```yaml
metadata:
  annotations:
    datadoghq.com/site: datadoghq.com
    datadoghq.com/dashboard-url: https://app.datadoghq.com/apm/service/{service-name}
  links:
    - url: https://app.datadoghq.com/apm/service/{service-name}
      title: DataDog APM
```

## Span Metrics Configuration

To enable span-based metrics for a service, add it to the appropriate list in `platform/datadog/`:

- **HTTP services**: `http-server-span-metrics.tf` → `local.http_services`
- **gRPC services**: `grpc-server-span-metrics.tf` → `local.grpc_services`

## Adding Monitoring to a New Service

1. **Create directory** in Arecibo: `applications/{service}/`
2. **Add `main.tf`** referencing the Datadog provider
3. **Add `local-variables.tf`** with notification endpoints (use `notification-users` module)
4. **Add `monitors.tf`** using shared modules (`http-monitors`, `jvm-monitors`, etc.)
5. **Add `slos.tf`** if SLOs are needed
6. **Add `HOPPEROWNERS`** for team ownership
7. **PR to Arecibo** — Atlantis will plan/apply the Terraform

## References

- [Datadog Ops Skill](hopper-developer:datadog-ops) — Investigating and debugging with Datadog
- [Deployment Skill](hopper-developer:deployment) — Deployment mixins and predefs
- [Atlantis Skill](hopper-developer:atlantis) — Terraform PR workflow for Arecibo
