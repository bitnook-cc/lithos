---
name: incident-management
description: >-
  Use during alert triage or incident response to surface institutional
  knowledge and route incidents. Resolves service ownership to a Slack channel
  or on-call group, identifies recent deploy authors to @mention, and routes
  cross-team issues to all affected parties. Triggers: "who owns", "owner
  channel", "escalate", "notify the team", "service ownership", "who deployed",
  "who merged", "recent deploy author", "on-call", "incident routing".
---

# Incident Management

## Owner Slack Channel

Resolve a service name to the owning team's Slack channel. Stop at the first step that yields a result.

### Step 1 — Use `hopper-sd`

The `hopper-sd` CLI is the fastest way to resolve ownership and Slack channels. It queries the service-directory index and Backstage metadata in one call.

```bash
# Get the Slack channel(s) for a service (with vertical fallback)
hopper-sd repo slack {service}

# Get the owning vertical/team
hopper-sd repo owner {service}

# If the Datadog service name doesn't match the repo name, search first
hopper-sd repo search "{service}"
```

`hopper-sd repo slack` returns Slack channel names. Use Slack API to resolve to channel IDs.

### Step 2 (fallback) — Check `github-config`

If `hopper-sd` doesn't have the service, check `github-config` directly — it is the source of truth for repo metadata including Slack channels, verticals, and ownership.

```bash
gh api "repos/hopper-org/github-config/contents/repos/{repo}/{repo}.tf" --jq '.content' | base64 -d
```

Not all repos use `{repo}.tf` as the filename. If not found, list the folder for other `.tf` files:

```bash
gh api "repos/hopper-org/github-config/contents/repos/{repo}" --jq '.[].name'
```

Use `default_slack_channel` if set. Note the `vertical` field for the next step.

### Step 3 (fallback) — Look up the vertical's default channel

Use the `vertical` from `github-config` (step 2):

```bash
gh api "repos/hopper-org/backstage-base/contents/.backstage/verticals/{vertical}.yml" --jq '.content' | base64 -d
```

Use `hopper.com/default-slack-channel` from the annotations. If not set, fall back to `hopper.com/compliance-slack-channel`.

## Who to @mention

If the alert correlates with a recent deploy, identify the PR author to @mention.

```bash
# Find recently merged PRs (within last 24h)
gh pr list --repo hopper-org/{repo} --state merged --limit 5 --json number,title,author,mergedAt

# Get details on a specific PR (author, reviewers, merge commit)
gh pr view {number} --repo hopper-org/{repo} --json author,mergedBy,reviews
```

Cross-reference the PR merge time with the alert onset. If the timing correlates, @mention the PR author in the triage summary with the PR link. Only consider authors with `_hopper` suffixed GitHub usernames — other accounts are bots or service accounts.

### Team Slack handle

Search `slack-handles.csv` (in this skill's directory) for a handle matching the service owner. The file has `handle|usergroup_id|name` columns. Match against the vertical, team name, or service domain.

```bash
grep -i "{keyword}" <skill-dir>/slack-handles.csv
```

To @mention a user group in Slack, use `<!subteam^{usergroup_id}>`.

### Top contributors as fallback

If no recent deploy correlates and no on-call handle matches:

```bash
gh api "repos/hopper-org/{repo}/commits?per_page=100" --jq '[.[].author.login] | group_by(.) | map({user: .[0], commits: length}) | sort_by(-.commits) | .[0:5]'
```

### Resolving GitHub → Slack

GitHub usernames at Hopper use the format `{name}_hopper`. Strip the `_hopper` suffix before searching Slack:

```bash
# GitHub username "jsmith_hopper" → search Slack for "jsmith"
slack_search_users {name-without-hopper-suffix}
```

## PagerDuty Escalation (Information Only)

Surface PagerDuty escalation information in the triage summary so responders can page manually if needed. Do not trigger pages automatically — paging decisions must be made by humans or deterministic monitor configuration, not by the agent.

Escalation policies are managed in the PagerDuty UI (not IaC), so always query at runtime.

### Find the escalation policy

Search by service or team name:

```
list_escalation_policies query="{service or team name}"
```

If no exact match, try broader terms (e.g. "commerce" instead of "commerce-stays-packages", or "flights" instead of "flights-travel-agency").

### Check who is on-call

Once you have the escalation policy ID:

```
list_oncalls escalation_policy_ids=["{policy_id}"]
```

This returns the current on-call person at each escalation level. Include this information in the triage summary.

## Mitigation Playbooks

Surface relevant runbooks and mitigation steps so responders can act immediately. Runbooks are scattered across Confluence spaces with inconsistent naming, so search broadly.

### Check the Datadog monitor first

If you have the monitor context, check the monitor description for a runbook URL. Some monitors include a direct link. If present, fetch and summarize the key mitigation steps.

### Search Confluence

When no runbook is linked in the monitor (or the monitor context is unavailable, e.g. in an incident channel), search Confluence using CQL:

```
searchConfluenceUsingCql cql='title ~ "{service}" AND title ~ "runbook" AND type = page'
```

If no results, broaden the search — teams use different naming conventions:

```
# Try alternative terms
title ~ "{service}" AND title ~ "on-call" AND type = page
title ~ "{service}" AND title ~ "incident response" AND type = page
title ~ "{service}" AND title ~ "SOP" AND type = page

# Try the team/vertical name instead of the service name
title ~ "{team}" AND title ~ "runbook" AND type = page

# Full-text search as a last resort
text ~ "{service} runbook" AND type = page
```

### Known Confluence spaces for runbooks

| Space | Key | Teams |
|-------|-----|-------|
| Platform | PLATFORM | Core platform, infra, data, ML |
| Commerce | Comm | Checkout, stays, air, cars, foundations |
| Travel Tech | TT | Distribution, fulfillment, supply |
| Hotels | H | Hotels foundation, marketplace |
| Fraud Prevention | FP | Fraud dev, fraud ops |
| Cars | GROUND | Cars agency, cars supply |
| Homes | HOME | Homes supply, homes booking |
| Payments | PAYMENTS | Payments foundation, fraud |
| APAC Cloud | AC | HTS APAC portals |
| Virtual Interlining | VI | VI team |
| CX-Product | CXPROD | CX AI, CX product |

Use the space key to narrow searches when the service team is known:

```
searchConfluenceUsingCql cql='title ~ "runbook" AND type = page AND space = "{SPACE_KEY}"'
```

### What to surface

When you find a runbook, extract and present:
- Known failure modes and their fixes
- Escalation steps specific to the service
- Dashboard and log links
- Commands to run for diagnosis or mitigation

Link to the full runbook page so the responder can read the complete document.
