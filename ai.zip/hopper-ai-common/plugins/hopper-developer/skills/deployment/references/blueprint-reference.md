# Blueprint Reference

Blueprints define site-specific Kubernetes resources for an application.

## Bundle

Aggregates all blueprints for an application into deployable units per site:

```starlark
blueprint.bundle(
    name = "bundle",
    blueprints = [":configmap", ":workload", ":routing"],
    visibility = ["//deployment:__pkg__"],
)
```

## Workload

Defines the Kubernetes workload (Deployment, Job, CronJob). Container-specific mixins are grouped inside `workload.container()`:

```starlark
blueprint.workload(
    name = "workload",
    core = mixins.core.deployment_workload(),
    mixins = [
        mixins.scheduling.arch.arm64(),
        mixins.core.deployment_strategy(max_unavailable = 0),
        mixins.core.workload_scale(
            max_replicas = 4,
            min_replicas = 1,
            overrides = {
                (DESCRIPTORS.env["production"],): mixins.override(max_replicas = 16, min_replicas = 4),
            },
        ),
        workload.container(
            "primary",
            mixins.core.exposes_ports(),
            mixins.runtime.jvm.container(
                image_name = "my-service-server",
                main_class = "com.hopper.myservice.Server",
            ),
            mixins.predef.helpers_hopper_server(),
            mixins.core.volume_mounts(blueprint_paths = {":configmap": "/app/conf"}),
            mixins.runtime.jvm.container_resources(
                cpu = "100m",
                memory = "2Gi",
                overrides = {
                    (DESCRIPTORS.env["production"],): mixins.override(cpu = "300m", memory = "4Gi"),
                },
            ),
        ),
        workload.sidecar("proxy", ...),
        workload.init_container("migration", ...),
    ],
)
```

Overrides go **inside individual mixins** using `mixins.override(...)` (not `struct()`). Override keys are tuples of descriptors.

**Core types:**
- `mixins.core.deployment_workload()` — long-running service
- `mixins.core.deployment_workload(scaled_down = True)` — deploy with 0 replicas (useful for pre-provisioning)
- `mixins.core.stateful_set_workload()` — StatefulSet with persistent storage
- `mixins.core.job_workload()` — one-off job
- `mixins.core.cronjob_workload()` — scheduled job

## ConfigMap

Per-environment configuration files are defined as separate targets in `deployment/configs/BUILD`:

```starlark
load("@rules_hopper//deploy:configmap.bzl", "configmap")
load("//deployment:vars.bzl", "DEPLOY_PLAN")

DESCRIPTORS = DEPLOY_PLAN.universe.sitemap.descriptors

configmap.file(
    name = "application.conf",
    srcs = {
        (env_descr, realm_descr): "app-{env}-{realm}.conf".format(env = env, realm = realm)
        for env, env_descr in DESCRIPTORS.env.items()
        for realm, realm_descr in DESCRIPTORS.realm.items()
    },
    visibility = ["//deployment/workloads:__subpackages__"],
)
```

Then referenced from the workload's configmap:

```starlark
blueprint.configmap(
    name = "configmap",
    configurations = [
        "@rules_hopper//deploy/predef/configmaps/jvm:platform.conf",
        "//deployment/configs:application.conf",
    ],
)
```

Keys are tuples of descriptors from `DEPLOY_PLAN.universe.sitemap.descriptors`. The most specific match wins.

## External Secrets

Secrets pulled from GCP Secret Manager. `data` is a **dict** (secret name → `external_secret.data()`):

```starlark
load("@rules_hopper//deploy:external_secret.bzl", "external_secret")

blueprint.external_secret(
    name = "secrets",
    data = {
        "my-api-key": external_secret.data(
            remote_ref = "my-api-key",
            remote_ref_version = "latest",
        ),
    },
)
```

Reference secrets from env vars:

```starlark
mixins.core.env_var_refs(
    env_var_ref = ":secrets",
    env_vars = {"API_KEY": "my-api-key"},  # env var name → secret key
)
```

## Routing

Network routing configuration:

```starlark
blueprint.routing(
    name = "routing",
    routes = [
        routing.service.mesh(),                    # Internal mesh traffic
        routing.service.ea_proxy(),                # EA Proxy ingress
        routing.service.ea_proxy(opt_in = [        # EA Proxy with opt-in per site
            DESCRIPTORS.env["development"],
            DESCRIPTORS.env["staging"],
            (DESCRIPTORS.env["production"], DESCRIPTORS.realm["common"]),
        ]),
        routing.service.inet_ingress(),            # Internet-facing
        routing.service.xgcp_egress(),             # External routing
    ],
)
```

## Configurator Types

Control how blueprints apply across sites:

### Override (default)

Apply to all sites with optional per-site overrides:

```starlark
overrides = {
    (DESCRIPTORS.env["production"],): mixins.override(replicas = 3),
    (DESCRIPTORS.env["staging"],): mixins.override(replicas = 1),
}
```

### Opt-In

Only apply to sites matching descriptors:

```starlark
opt_in = [
    DESCRIPTORS.env["production"],
    (DESCRIPTORS.env["staging"], DESCRIPTORS.realm["common"]),
]
```

### Opt-Out

Apply to all sites except those matching:

```starlark
opt_out = [DESCRIPTORS.env["development"]]
```

### Universal

Apply to all sites with no variation. Used when no parameters are needed.

## Environment Variables

```starlark
# Single env var with per-environment overrides
mixins.core.env_var(
    key = "POOL_SIZE",
    overrides = {
        (DESCRIPTORS.env["production"],): mixins.override(value = "90"),
        (DESCRIPTORS.env["development"],): mixins.override(value = "32"),
    },
)

# From secrets (ExternalSecret references)
mixins.core.env_var_refs(
    env_var_ref = ":secrets",
    env_vars = {"DB_PASSWORD": "db-password"},
)
```

All env var mixins support `overrides` and `opt_in` for per-site configuration.

## Container Resources

Two variants depending on the runtime:

```starlark
# JVM services — shorthand cpu/memory
mixins.runtime.jvm.container_resources(
    cpu = "100m",
    memory = "2Gi",
    overrides = {
        (DESCRIPTORS.env["production"],): mixins.override(cpu = "300m", memory = "4Gi"),
    },
)

# Non-JVM services — explicit request/limit
mixins.core.container_resources(
    cpu_request = "100m",
    memory_request = "1Gi",
    overrides = {
        (DESCRIPTORS.env["production"],): mixins.override(cpu_request = "1000m", memory_request = "2Gi"),
    },
)
```

## Predefs

Pre-built mixin bundles that consolidate common configurations:

```starlark
# Full Hopper JVM server (probes, GC, logging, telemetry)
mixins.predef.helpers_hopper_server()
mixins.predef.helpers_hopper_server(logback = "/app/conf/logback.xml")

# Hopper app (adds app-specific defaults on top of server)
mixins.predef.helpers_hopper_app(...)

# Database migrator
mixins.predef.db_migrator(...)
```

## Selector Labels

For new repos, use standard selectors:

```starlark
mixins.core.standard_selectors()
```

Legacy repos may use `mixins.legacy.hopper_service_selectors()` or `mixins.legacy.finagle_project_selectors()`.

## Probes

Health check configuration:

```starlark
probes.http_get(path = "/health", port = 8080)
probes.grpc(port = 50051)
probes.tcp_socket(port = 8080)
probes.exec(command = ["check", "--health"])
```
