# Monorepo Deployments

How to deploy multiple independent services from a single repository.

## When to Use

Use this pattern when a single repo contains multiple independently deployable services that each need their own Kubernetes namespace, Harness pipeline, and release versioning. Example: [b2bportal](https://github.com/hopper-org/b2bportal) deploys 20+ partner-specific services from one repo.

## Directory Structure

Instead of a single `deployment/` directory, each sub-project gets its own directory under `deployment/`:

```
deployment/
  BUILD                          # empty (no top-level plan)
  {sub_project_a}/
    vars.bzl                     # its own DEPLOY_PLAN
    BUILD                        # its own Harness project, pipeline, dist_tag, dist_run
    workloads/
      {workload}/
        BUILD
  {sub_project_b}/
    vars.bzl
    BUILD
    workloads/
      ...
```

Each sub-project is a fully independent deployment unit with its own plan, pipeline, and release version.

## Deploy Plan (per sub-project)

Each sub-project defines its own `plan.make()` in its `vars.bzl`:

```starlark
# deployment/b2bportal_demo/vars.bzl
load("@rules_hopper//deploy:plan.bzl", "plan")
load("@rules_hopper//sites:vars.bzl", "DESCRIPTORS", "SITES")

DEPLOY_PLAN = plan.make(
    kube_namespace = "b2bportal-demo",
    roadie_system = Label("//.backstage:roadie_system"),
    default_version = "0.0.0-SNAPSHOT",  # overridden per environment
    default_sites = [
        SITES.env["development"].realm["common"].cluster["core-cluster"],
        SITES.env["staging"].realm["common"].cluster["core-cluster"],
    ],
    armario = plan.application(
        kube_name = "armario",
        telemetry_name = "armario",
        kube_bundle = "//deployment/b2bportal_demo/workloads/armario:bundle",
        overrides = {
            DESCRIPTORS.env["development"]: plan.override(version = "v1.10853.0"),
            DESCRIPTORS.env["staging"]: plan.override(version = "v1.10853.0"),
        },
    ),
    util = plan.application(
        kube_name = "util",
        telemetry_name = "util",
        kube_bundle = "//deployment/b2bportal_demo/workloads/util:bundle",
        overrides = {
            DESCRIPTORS.env["development"]: plan.override(version = "0.7.0"),
            DESCRIPTORS.env["staging"]: plan.override(version = "0.7.0"),
        },
    ),
)
```

Key differences from single-service repos:
- `kube_bundle` paths point to `//deployment/{sub_project}/workloads/...` (not `//deployment/workloads/...`)
- Each sub-project can have different `default_sites`
- Application versions can be overridden per environment via `plan.override(version = ...)`

## BUILD File (per sub-project)

Each sub-project has its own Harness project, pipeline, and release targets:

```starlark
# deployment/b2bportal_demo/BUILD
load("@rules_hopper//deploy:release.bzl", "dist_tag", "release_to_git")
load("@rules_hopper//harness:harness.bzl", "harness")
load("@rules_hopper//utils:version.bzl", "release_me_version")
load("//deployment/b2bportal_demo:vars.bzl", "DEPLOY_PLAN")

harness = harness.for_deploy_plan(DEPLOY_PLAN)

release_me_version(
    name = "deployment_version",
    path = "deployment/b2bportal-demo",   # matches release-me-config.json package name
)

dist_tag(
    name = "dist_tag",
    deployment_name = "b2bportal-demo",   # scopes the rendered tag per sub-project
    deployment_version = ":deployment_version",
    service_version = None,               # version tracked manually in vars.bzl overrides
)

release_to_git(
    name = "dist_run",
    deploy_plan = DEPLOY_PLAN,
    dist_tag = ":dist_tag",
)

harness.project(
    name = "project",
    harness_name = "b2bportal-demo",
    organization = "@rules_hopper//harness/predef/organization:b2b",
    repo_name = "b2bportal",
)

harness.pipelines.standard_pipeline(
    name = "default_pipeline",
    deployment_groups = [
        harness.pipelines.deployment_group(
            name = "services",
            applications = ["armario", "util"],
        ),
    ],
    project = ":project",
    version = ":dist_tag",
)
```

Notable:
- `deployment_name` on `dist_tag` scopes the rendered tag to this sub-project
- `release_me_version` `path` must match the package name in `release-me-config.json`
- `service_version = None` when service versions are tracked manually (per-environment overrides in `vars.bzl`)

## Workload BUILD Files

Workloads load from their sub-project's `vars.bzl`:

```starlark
# deployment/b2bportal_demo/workloads/armario/BUILD
load("//deployment/b2bportal_demo:vars.bzl", "DEPLOY_PLAN")

APPLICATION = DEPLOY_PLAN.application["armario"]
```

## release-me Configuration

Each sub-project is a separate package in `release-me-config.json`. The `paths` array controls which file changes trigger a new version for that package:

```json
{
  "packages": {
    "deployment/b2bportal-demo": {
      "paths": [
        "deployment/b2bportal_demo",
        ".backstage",
        "MODULE.bazel",
        "BUILD",
        "deployment/BUILD"
      ],
      "initial-version": "2.0.0"
    }
  }
}
```

The `.release-me-manifest.json` tracks versions per package:

```json
{
  "deployment/b2bportal-demo": "2.3.1",
  "deployment/b2bportal-jetblue": "2.5.0"
}
```

## GitHub Actions (CI/CD)

GitHub Actions use a **matrix strategy** to build, test, and release each sub-project independently:

### PR Tests (bazel-tests.yml)

```yaml
strategy:
  matrix:
    deployment:
      - { "package": "deployment/b2bportal-demo", "target": "b2bportal_demo" }
      - { "package": "deployment/b2bportal-jetblue", "target": "b2bportal_jetblue" }
      # ... one entry per sub-project
steps:
  - uses: hopper-org/.github/actions/cd-test@main
    if: fromJson(needs.detect.outputs.changes)[matrix.deployment.package].test-candidate
    with:
      targets: //deployment/${{ matrix.deployment.target }}/...

  - uses: hopper-org/.github/actions/cd-dyff@main
    if: fromJson(needs.detect.outputs.changes)[matrix.deployment.package].test-candidate
    with:
      workloads-dir: deployment/${{ matrix.deployment.target }}/workloads
```

The `detect` job determines which packages have changed files, so only affected sub-projects are tested.

### Release (release.yml)

```yaml
strategy:
  max-parallel: 5
  matrix:
    deployment:
      - { "package": "deployment/b2bportal-demo", "target": "b2bportal_demo" }
      # ...
steps:
  - uses: hopper-org/.github/actions/cd-release@main
    if: fromJSON(needs.release-me.outputs.release).packages[matrix.deployment.package].is-release
    with:
      dist-target: "//deployment/${{ matrix.deployment.target }}:dist_run"
      harness-bazel-query-target: //deployment/${{ matrix.deployment.target }}/...
      harness-pipelines: //deployment/${{ matrix.deployment.target }}:default_pipeline
```

Each sub-project only releases when release-me detects a version bump for that specific package.

## Adding a New Sub-Project

1. Create `deployment/{new_sub_project}/vars.bzl` with a new `plan.make()`
2. Create `deployment/{new_sub_project}/BUILD` with Harness project, pipeline, dist_tag, dist_run
3. Create `deployment/{new_sub_project}/workloads/{workload}/BUILD` for each workload
4. Add a new package entry to `release-me-config.json`
5. Add a new entry to `.release-me-manifest.json`
6. Add the new sub-project to the matrix in both `bazel-tests.yml` and `release.yml`
