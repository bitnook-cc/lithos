---
name: deployment
description: >-
  Use when working with Hopper's Bazel-based deployment system (rules_hopper),
  defining Kubernetes workloads, configuring Harness CI/CD pipelines, managing
  multi-environment site configuration, or troubleshooting deployment issues.
---

# Deployment — rules_hopper & Harness CI/CD

## Overview

Hopper services define their Kubernetes deployments and CI/CD pipelines as code using Bazel rules from `@rules_hopper`. The deployment system has three layers:

1. **Plan** — what applications exist and where they deploy
2. **Blueprint** — what each application looks like (workloads, config, routing)
3. **Harness** — how the deployment pipeline executes

## Directory Structure

A typical service's deployment directory:

```
deployment/
  vars.bzl              # DEPLOY_PLAN definition (applications + sites)
  BUILD                 # Harness project, pipelines, release targets
  configs/
    BUILD               # ConfigMaps per environment
  workloads/
    {workload}/
      BUILD             # Workload blueprint, bundle, routing
```

## Prerequisites

- **Backstage/Roadie** — every repo needs a `roadie_system()` in `.backstage/BUILD` (required by the Bazel API)
- **LongBeach** — shared K8s objects (ServiceAccount, Namespace) are created once per repo, not per workload
- **renovate-bot** — automatically updates the `rules_hopper` version in the repo (not dependabot)

## Core Concepts

### Deploy Plan (`vars.bzl`)

The plan defines all applications in the service and where they deploy:

```starlark
load("@rules_hopper//deploy:plan.bzl", "plan")
load("@rules_hopper//sites:vars.bzl", "SITES")

DEPLOY_PLAN = plan.make(
    kube_namespace = "my-service",
    roadie_system = Label("//.backstage:roadie_system"),
    default_version = Label("//deployment:service_version"),
    default_sites = [
        SITES.env["development"].realm["common"].cluster["core-cluster"],
        SITES.env["staging"].realm["common"].cluster["core-cluster"],
        SITES.env["production"].realm["common"].cluster["core-cluster"],
    ],
    unit = plan.application(
        telemetry_name = "my-service",
        kube_name = "unit",
        kube_bundle = "//deployment/workloads/unit:bundle",
    ),
)
```

**Key fields:**
- `kube_namespace` — Kubernetes namespace (usually the service name)
- `roadie_system` — Label to the `roadie_system()` target in `.backstage/BUILD`
- `default_version` — Label to the `release_me_version()` target in `deployment/BUILD`
- `default_sites` — explicit list of site paths (environment → realm → cluster)
- Applications are declared as **keyword arguments** (not a dict), each with `kube_bundle` pointing to its workload bundle

### Sites & Descriptors

Sites represent deployment targets organized as environment > realm > cluster:

```starlark
SITES.env["production"].realm["common"].cluster["core-cluster"]
```

Descriptors are metadata attached to sites (environment, realm, cluster, region, etc.) used for per-site configuration overrides.

### Blueprint

Blueprints define what gets deployed for each application. See [Blueprint Reference](references/blueprint-reference.md).

```starlark
load("@rules_hopper//deploy:application.bzl", "ports")
load("@rules_hopper//deploy:blueprint.bzl", "blueprint")
load("@rules_hopper//deploy:routing.bzl", "routing")
load("@rules_hopper//deploy:workload.bzl", "mixins", "workload")
load("//deployment:vars.bzl", "DEPLOY_PLAN")

APPLICATION = DEPLOY_PLAN.application["unit"]
DESCRIPTORS = APPLICATION.sitemap.descriptors

blueprint = blueprint.for_application(APPLICATION, ports = [ports.well_known.hopper_http()])

blueprint.bundle(name = "bundle", blueprints = [":configmap", ":workload", ":routing"])
blueprint.configmap(name = "configmap", configurations = [...])
blueprint.workload(name = "workload", core = mixins.core.deployment_workload(), mixins = [...])
blueprint.routing(name = "routing", routes = [...])
```

Note: `blueprint` shadows the import — all repos use `blueprint.workload(...)`, not `bp.workload(...)`.

### Workloads & Mixins

Workloads use a composable mixin system. Container-specific mixins are grouped inside `workload.container()`:

```starlark
blueprint.workload(
    name = "workload",
    core = mixins.core.deployment_workload(),
    mixins = [
        mixins.scheduling.arch.arm64(),
        mixins.core.workload_scale(
            max_replicas = 4,
            min_replicas = 1,
            overrides = {
                (DESCRIPTORS.env["production"],): mixins.override(max_replicas = 16, min_replicas = 4),
            },
        ),
        workload.container(
            "primary",
            mixins.core.exposes_ports(),
            mixins.runtime.jvm.container(
                image_name = "my-service-server",
                main_class = "com.hopper.myservice.Server",
            ),
            mixins.predef.helpers_hopper_server(),
            mixins.core.volume_mounts(blueprint_paths = {":configmap": "/app/conf"}),
            mixins.runtime.jvm.container_resources(
                cpu = "100m",
                memory = "2Gi",
                overrides = {
                    (DESCRIPTORS.env["production"],): mixins.override(cpu = "300m", memory = "4Gi"),
                },
            ),
        ),
    ],
)
```

**Core types:** `deployment_workload()`, `stateful_set_workload()`, `job_workload()`, `cronjob_workload()`

### Site-Specific Configuration

Use configurator types to vary config per environment:

| Type | Behavior |
|------|----------|
| `override` | Apply defaults + per-site overrides via descriptor matching |
| `opt-in` | Only apply to sites matching descriptors |
| `opt-out` | Apply to all sites except those matching descriptors |
| `universal` | Apply to all sites |

```starlark
# Override CPU per environment — overrides go inside individual mixins
mixins.runtime.jvm.container_resources(
    cpu = "100m",
    memory = "2Gi",
    overrides = {
        (DESCRIPTORS.env["production"],): mixins.override(cpu = "300m", memory = "4Gi"),
        (DESCRIPTORS.env["staging"], DESCRIPTORS.realm["common"]): mixins.override(cpu = "250m"),
    },
)
```

Override keys are tuples of descriptors. Use `mixins.override(...)` for the override values (not `struct()`).

### Routing

```starlark
blueprint.routing(
    name = "routing",
    routes = [
        routing.service.mesh(),           # Internal mesh VirtualService
        routing.service.ea_proxy(),       # EA Proxy ingress
        routing.service.inet_ingress(),   # Internet-facing ingress
    ],
)
```

## Harness CI/CD

### Project Setup

```starlark
harness = harness.for_deploy_plan(DEPLOY_PLAN)

harness.project(
    name = "project",
    harness_name = "my-service",
    organization = "@rules_hopper//harness/predef/organization:payment",
    repo_name = "my-service",
)
```

### Standard Pipeline

```starlark
harness.pipelines.standard_pipeline(
    name = "default_pipeline",
    deployment_groups = [
        harness.pipelines.deployment_group(
            name = "services",
            applications = [
                "unit",
            ],
        ),
    ],
    project = ":project",
    version = ":dist_tag",
)
```

`applications` is a list of application **names** (matching the keyword args in `plan.make`).

**Pipeline execution order:**
1. Pre-production — deploy to all realms in parallel
2. Approval gate — manual approval for production
3. Production — deploy to common realm first, then other realms
4. Cleanup — remove temporary resources per site

### Job Pipelines

For migrations or batch jobs:

```starlark
harness.pipelines.standard_pipeline(
    name = "db_migrator_pipeline",
    deployment_groups = [
        harness.pipelines.job_group(
            name = "db_migrator_jobs",
            applications = [
                "db_migrator",
            ],
            wait_for = "2h",
        ),
    ],
    harness_name = "DB Migrator Job Pipeline",
    project = ":project",
    version = ":dist_tag",
)
```

### Release & Versioning

```starlark
load("@rules_hopper//deploy:release.bzl", "dist_tag", "release_to_git")
load("@rules_hopper//utils:version.bzl", "release_me_version")

release_me_version(name = "service_version", path = "service")
release_me_version(name = "deployment_version", path = "deployment")

dist_tag(
    name = "dist_tag",
    deployment_version = ":deployment_version",
    service_version = ":service_version",
)

release_to_git(
    name = "dist_run",
    deploy_plan = DEPLOY_PLAN,
    dist_tag = ":dist_tag",
)
```

Versions come from release-me. See the [release-me skill](hopper-developer:release-me) for config and conventional commit mapping.

### `-rendered` Tags

Services deployed via Harness have `-rendered` tags created by the `hopper-org/.github/actions/cd-release` GitHub Action. These tags combine all package versions into a single tag name:

```
v{service_version}_v{deployment_version}-rendered
```

Example: `v1.38.1_v1.18.4-rendered` → service is `1.38.1`, deployment is `1.18.4`.

**Finding the current deployed version:**

```
mcp__github__list_tags
  owner: "hopper-org"
  repo: "{repo}"
  perPage: 1
```

The latest `-rendered` tag shows the current versions. To read the full manifest:

```
mcp__github__get_file_contents
  owner: "hopper-org"
  repo: "{repo}"
  path: ".release-me-manifest.json"
  ref: "{rendered-tag-name}"
```

This returns the manifest with actual versions (e.g., `{"service": "1.38.1", "deployment": "1.18.4"}`).

### `/dist` Folder on Rendered Tags

The detached commit at each `-rendered` tag contains a `/dist` folder with fully rendered Kubernetes manifests and Harness pipeline definitions. This is useful for inspecting exactly what was deployed.

```
dist/
  deployment/
    workloads/
      {workload}/                          # e.g., unit, freshen
        bundle/
          env={environment}/               # development, staging, production
            realm={realm}/                 # e.g., common
              cluster={cluster}_kustomized.yml   # rendered K8s YAML
  pipelines/
    {pipeline_name}.json                   # e.g., air-houston-default_pipeline.json
```

**Reading rendered manifests:**

```
mcp__github__get_file_contents
  owner: "hopper-org"
  repo: "{repo}"
  path: "dist/deployment/workloads"
  ref: "{rendered-tag-name}"
```

- `dist/deployment/workloads/` — contains one directory per workload, with rendered K8s manifests per environment/realm/cluster combination
- `dist/pipelines/` — contains Harness pipeline JSON files, one per pipeline defined in the `BUILD` file

## Building & Testing Locally

### Build All Deployment Targets

```bash
bazel build //deployment/...
```

This renders all K8s manifests, configmaps, pipelines, and bundles for every workload and site combination.

### Test All Deployment Targets

```bash
bazel test //deployment/...
```

Runs OPA/conftest policy tests against the rendered manifests (e.g., pod probes, K8s name validation, volume mounts, job requirements).

### Build a Specific Workload Bundle

```bash
# Build one workload's bundle
bazel build //deployment/workloads/unit:bundle

# Find the rendered output files
bazel cquery --output=files //deployment/workloads/unit:bundle
```

### Query All Bundle Targets

```bash
bazel query 'kind("bundle", //deployment/workloads/...)'
```

### Format Bazel Files

```bash
# Check formatting
bazel run @rules_hopper//tools/buildifier:test

# Auto-format
bazel run @rules_hopper//tools/buildifier:format
```

### Preview K8s Manifest Diff (dyff)

Compare rendered manifests between two branches locally:

```bash
# Build bundles on the current branch
bazel build $(bazel query 'kind("bundle", //deployment/workloads/...)')
rsync -aRL $(bazel cquery --output=files 'kind("bundle", //deployment/workloads/...)') __current/

# Checkout base branch, build, and compare
git stash && git checkout master
bazel build $(bazel query 'kind("bundle", //deployment/workloads/...)')
rsync -aRL $(bazel cquery --output=files 'kind("bundle", //deployment/workloads/...)') __old/
git checkout - && git stash pop

bazel run @rules_hopper//tools/dyff:dyff_all __old/bazel-out/*/bin/deployment/workloads __current/bazel-out/*/bin/deployment/workloads
```

### Note on `dist_run`

The `//deployment:dist_run` target (`release_to_git`) is **CI-only** — it commits the rendered `/dist` folder and pushes the `-rendered` tag. It checks for `$CI == "true"` and will refuse to run locally. To inspect what would be released, build the individual bundle and pipeline targets instead.

## End-to-End Flow

1. Developer merges PR to master
2. release-me bumps version and creates git tag
3. GitHub Actions builds and publishes artifacts
4. Harness pipeline triggers via CD release action
5. Pipeline deploys to pre-production environments
6. Manual approval gate for production
7. Pipeline deploys to production
8. Automatic rollback on failure

## Common Ports

```starlark
ports.well_known.hopper_http()   # Standard HTTP port
ports.well_known.hopper_grpc()   # Standard gRPC port
ports.well_known.hopper_admin()  # Admin/health port
ports.custom(name, number, protocol)  # Custom port
```

## References

- [Blueprint Reference](references/blueprint-reference.md) — Workloads, configmaps, routing, external secrets
- [Harness Pipelines](references/harness-pipelines.md) — Pipeline stages, steps, approval, and failure strategies
- [Monorepo Deployments](references/monorepo.md) — Multiple independent services deployed from a single repository
