---
name: backstage
description: "Use when creating or updating a .backstage directory in a Hopper repo, when onboarding a new repo to Backstage, or when backstage catalog metadata is outdated or missing."
---

# Backstage Setup

## Overview

Create or update `.backstage` directories in Hopper repos. Fetches defaults from `hopper-org/github-config` and generates Backstage catalog entities.

## Workflow

```dot
digraph backstage {
    "Detect repo context" -> "Fetch defaults from github-config";
    "Fetch defaults from github-config" -> ".backstage exists?" [shape=diamond];
    ".backstage exists?" -> "Update mode" [label="yes"];
    ".backstage exists?" -> "Create mode" [label="no"];
    "Create mode" -> "Ask user to confirm fields";
    "Update mode" -> "Diff existing vs github-config";
    "Diff existing vs github-config" -> "Flag mismatches + offer to reconcile";
    "Flag mismatches + offer to reconcile" -> "Offer to add new components";
    "Ask user to confirm fields" -> "Generate files";
    "Offer to add new components" -> "Generate files";
}
```

## Step 1: Detect Context

Determine the repo name and org slug:

```bash
repo_name=$(basename "$(git rev-parse --show-toplevel)")
org_slug="hopper-org/$repo_name"
```

Check if `.backstage/` already exists to determine **create** vs **update** mode.

## Step 2: Fetch Defaults from github-config

Use `gh api` to read the repo's terraform file from `hopper-org/github-config` (default branch, not a local fork):

```bash
gh api "repos/hopper-org/github-config/contents/repos/{repo_name}/{repo_name}.tf" --jq '.content' | base64 -d
```

Extract these fields from the terraform file:

| Terraform field | Backstage field | Example |
|---|---|---|
| `description` | `metadata.description` | `"Shared skills and config for AI agents at Hopper."` |
| `tier` | `spec.lifecycle` | `tier-5` |
| `vertical` | `spec.owner` | `org-vt-core_platform` → `org-vt-core_platform` |

If the file doesn't exist or fields are missing, fall back to asking the user.

## Step 3: Create Mode

First, ask the user what entities they need:
- **System only** — the repo defines a system but no components yet
- **Components only** — components belonging to a system defined elsewhere
- **Both** — system and components in the same repo

### Common Fields

Ask the user to confirm or provide, using defaults from github-config:

- **Description** (default: from github-config)
- **Lifecycle/tier** (default: from github-config)
- **Owner** (default: vertical from github-config)
- **Domain** (e.g. `platform`, `air`, `lodging`, `fintech`)
- **Links** (Slack channel, Datadog dashboard, Jira board)

### System Fields (if creating a system)

- **System name** (default: repo name)
- **Annotations**: `github.com/project-slug` is auto-filled. Optionally ask for:
  - `pagerduty.com/service-id`

### Component Fields (if creating components)

- **Component name** (default: repo name)
- **Type**: `micro-service`, `library`, `job`, `website`, etc.
- **System** (ask user — must match an existing Backstage system or be skipped)
- **Tags** (e.g. language, protocols: `scala`, `python`, `terraform`, `http`, `grpc`)
- **Annotations**: `github.com/project-slug` is auto-filled. Optionally ask for:
  - `pagerduty.com/integration-key`
  - `datadoghq.com/dashboard-url`
- **Additional components** — ask if the repo has more than one deployable component

### Generated Files

**`catalog-info.yml`** — Location entity pointing to the relevant files:

```yaml
apiVersion: backstage.io/v1alpha1
kind: Location
metadata:
  name: {repo-name}
spec:
  type: url
  targets:
    - ./systems.yml      # if creating a system
    - ./components.yml   # if creating components
```

**`systems.yml`** (if creating a system):

```yaml
---
apiVersion: backstage.io/v1alpha1
kind: System
metadata:
  name: {system-name}
  description: {description}
  links:
    - url: {slack-url}
      title: Owner Slack Channel
      icon: chat
  annotations:
    github.com/project-slug: hopper-org/{repo-name}
spec:
  owner: {owner}
  domain: {domain}
  lifecycle: {tier}
```

**`components.yml`** (if creating components):

```yaml
---
apiVersion: backstage.io/v1alpha1
kind: Component
metadata:
  name: {component-name}
  description: {description}
  annotations:
    github.com/project-slug: hopper-org/{repo-name}
  tags:
    - {tag}
spec:
  type: {type}
  lifecycle: {tier}
  owner: {owner}
  system: {system}
```

## Step 4: Update Mode

When `.backstage/` already exists:

1. **Read existing files** — parse `catalog-info.yml`, `components.yml`, and/or `systems.yml`
2. **Fetch current values from github-config** — same as Step 2
3. **Compare and flag mismatches**:
   - Tier/lifecycle changed
   - Owner/vertical changed
   - Description changed
   - Missing annotations or tags
4. **Present diff to user** — show what's outdated and offer to reconcile
5. **Offer to add new entities** — ask if any new components or systems need to be added

## Common Mistakes

- **Wrong owner format**: Use the full vertical string from github-config (e.g. `org-vt-core_platform`), not the team name
- **Missing system reference**: Every component should reference a system if one exists. Check with the user rather than omitting
- **Forgetting `github.com/project-slug`**: This annotation is required for GitHub integration in Backstage
