# /// script
# requires-python = ">=3.11"
# dependencies = ["google-cloud-bigquery", "httpx"]
# ///
"""CLI for debugging state machine sessions.

Usage: uv run state-machine.py <command> [options]

All output is compact and agent-friendly. Read this script's source
to understand the queries and write custom ones when needed.
"""

from __future__ import annotations

import argparse
import asyncio
import re
import sys
from datetime import datetime
from typing import Any

from google.cloud import bigquery
import httpx

# ─── Client Resolution ───────────────────────────────────────────────

# clientId -> Spanner database name (underscored).
# Sourced from Orange's config files:
#   - base.conf:       https://github.com/hopper-org/Orange/blob/master/orange-zest/src/main/resources/base.conf
#   - production.conf: https://github.com/hopper-org/Orange/blob/master/orange-zest/src/main/resources/production.conf
# The clientId is defined in the config, the database name comes from the
# Spanner CDC deployment configs:
#   https://github.com/hopper-org/Orange/tree/master/deployment/spanner_extract_instances
# Dataset naming per env is in builder.bzl:
#   staging:    orange_shared_{db}_private    (instance = "orange-shared")
#   production: orange_{db}_{db}_private      (instance = "orange-{db}")
#
# BQ table: gcp-hopper-etldata-{env}.{dataset}.session_history_history
# Partitioned on __timestamp (DAY), clustered by (client_id, state_id, __timestamp).
# Columns:
#   session_id          BYTES     opaque 32-byte composite, display as TO_BASE64()
#   client_id           STRING    same as clientId
#   state_id            STRING    abbreviated step name (e.g. iqc, brq, done!)
#   previous_state_id   STRING    previous step
#   state_output        BYTES     JSON, cast with CAST(state_output AS STRING)
#   success             BOOL      step outcome
#   ts                  TIMESTAMP step timestamp
#   __timestamp         TIMESTAMP partition column — always filter on this too
CLIENT_DB: dict[str, str] = {
    "brooklynAncillary": "air_ancillary",
    "brooklynAirBooking": "air_booking",
    "airFoExtRegister": "air_fo_ext_register",
    "airFoExtRespHandler": "air_fo_ext_resp_handler",
    "airFoVoid": "air_fo_void",
    "brooklynPostBookingSales": "air_post_booking_sales",
    "brooklynPostTicketing": "air_post_ticketing",
    "airPriceFreezeHold": "air_price_freeze_hold",
    "brooklynRouting": "air_routing",
    "brooklynScheduleChange": "air_schedule_change",
    "brooklynSelfServe": "air_self_serve",
    "flightsScheduleChangeAction": "air_skch_action",
    "brooklynUserContact": "air_user_contact",
    "brooklynUserOutreach": "air_user_outreach",
    "bogotaBooking": "bogota_booking",
    "bogotaCancelBooking": "bogota_cancel_bkng",
    "braavosPayment": "braavos_payment",
    "flightsFacadeSeatsBooking": "facade_seats_book",
    "fareLockPurchase": "fare_lock_purchase",
    "fareLockRefund": "fare_lock_refund",
    "flightsBooking": "flights_booking",
    "flightsCancelBookingWithQuote": "flights_cancel_bkng_wq",
    "flightsCancelBooking": "flights_cancel_booking",
    "flightsExchangeBook": "flights_exchange_book",
    "flightsFacadeBooking": "flights_facade_booking",
    "flightsFacadeCancel": "flights_facade_cancel",
    "flightsFacadeExchangeShop": "flights_facade_exch_shp",
    "flightsFacadeExchangeBooking": "flights_facade_exchange_book",
    "flightsFacadeFoVoid": "flights_facade_fo_void",
    "flightsFacadeSkch": "flights_facade_skch",
    "flightsRefundsProcess": "flights_refunds_process",
    "fortworthSeatsChange": "fortworth_seats_change",
    "fortworthSeatsPurchase": "fortworth_seats_purchase",
    "giftCardsRedemption": "gift_cards_redemption",
    "groundCancellation": "ground_cancellation",
    "groundPriceFreezePurchase": "ground_price_freeze_purchase",
    "groundPriceFreezeRefund": "ground_price_freeze_refund",
    "hillValleyExchange": "hillvalley_exchange",
    "holdTheRoomExercise": "hold_the_room_exercise",
    "indianapolisBooking": "indianapolis_booking",
    "insurancePurchase": "insurance_purchase",
    "lodgingDeferredPayments": "lodging_installments_payment",
    "lodgingPriceFreezeCancel": "lodging_price_freeze_cancel",
    "lodgingPriceFreezePurchase": "lodging_price_freeze_purchase",
    "londonBooking": "london_booking",
    "londonCancelBooking": "london_cancel_bkng",
    "madridBooking": "madrid_booking",
    "madridCancelBooking": "madrid_cancel_booking",
    "madridExchangeBooking": "madrid_exch_book",
    "madridExchangeEligibility": "madrid_exch_elig",
    "madridExchangeShopping": "madrid_exch_shop",
    "madridExtLOPnr": "madrid_extlopnr",
    "madridSeatsBooking": "madrid_seats_book",
    "midwayPFAncillaryExercise": "midway_pf_anc_exer",
    "midwayPFAncillaryPurchase": "midway_pf_ancillary_purchase",
    "midwayPriceFreezeAddon": "midway_price_freeze_addon",
    "midwayPriceFreezePurchase": "midway_price_freeze_purchase",
    "midwayPriceFreezeQuote": "midway_price_freeze_quote",
    "midwayPriceFreezeRefund": "midway_price_freeze_refund",
    "oklahomaFulfillment": "oklahoma_fulfillment",
    "oklahomaQuote": "oklahoma_quote",
    "parisBooking": "paris_booking",
    "parisCancellation": "paris_cancellation",
    "brooklynPaymentDispute": "payment_dispute",
    "sofiaExchange": "sofia_exchange",
    "southlakeBooking": "southlake_booking",
    "southlakeCancelBkng": "southlake_cancel_bkng",
    "southlakeExchangeBooking": "southlake_exch_booking",
    "southlakeExchangeEligibility": "southlake_exch_elig",
    "southlakeExchangeShopping": "southlake_exch_shop",
    "southlakeExtLOPnr": "southlake_extlopnr",
    "southlakeSeatsBooking": "southlake_seats_book",
    "thebesBooking": "thebes_booking",
    "thebesTicketError": "thebes_ticket_error",
    "victoriaAddOn": "victoria_addon",
}

# clientId -> Trenton API session type (used in /api/v1/{type}/states).
# These names come from helpers-dashboard's SessionDefinitions classes in:
#   https://github.com/hopper-org/Helpers/tree/master/helpers-dashboard/src/main/scala/com/hopper/common/dashboard/sessions/
# Each class defines a `stateMachineTypePrefix` (e.g., "/booking") but the
# actual Trenton API path doesn't always match — some use different names
# (e.g., facade machines use "facadeBookings" not "booking").
# This mapping was verified by testing each session type against the staging
# Trenton API.  Not every clientId has a Trenton entry — only machines
# registered in the dashboard are listed.
CLIENT_TRENTON: dict[str, str] = {
    "brooklynAirBooking": "booking",
    "brooklynPostTicketing": "postTicketing",
    "brooklynRouting": "routings",
    "brooklynScheduleChange": "scheduleChange",
    "brooklynSelfServe": "selfServe",
    "brooklynUserContact": "userContact",
    "flightsBooking": "flights",
    "flightsCancelBooking": "flightsCancellation",
    "flightsCancelBookingWithQuote": "flightsCancellationWithQuote",
    "flightsExchangeBook": "flightsExchangeBooking",
    "flightsRefundsProcess": "flightsRefunds",
    "flightsFacadeBooking": "facadeBookings",
    "flightsFacadeCancel": "facadeCancelBooking",
    "flightsFacadeExchangeBooking": "facadeExchangeBooking",
    "flightsFacadeExchangeShop": "facadeExchangeShopping",
    "flightsFacadeSeatsBooking": "facadeSeatsBooking",
    "flightsFacadeSkch": "flightsNdcScheduleChange",
    "flightsFacadeFoVoid": "flightsFacadeFareOptimizationVoid",
    "airFoVoid": "flightsFareOptimizationVoid",
    "airFoExtRegister": "flightsFareOptimizationRegister",
    "airFoExtRespHandler": "flightsFareOptimizationResponse",
    "southlakeBooking": "sabreBookings",
    "southlakeCancelBkng": "southlakeCancelBooking",
    "southlakeExchangeBooking": "southlakeExchangeBooking",
    "southlakeExchangeEligibility": "sabreExchElig",
    "southlakeExchangeShopping": "sabreExchShop",
    "southlakeSeatsBooking": "southlakeSeatsBooking",
    "madridBooking": "amadeusBookings",
    "madridCancelBooking": "amadeusCancelBooking",
    "madridExchangeBooking": "madridExchangeBooking",
    "madridExchangeEligibility": "amadeusExchElig",
    "madridExchangeShopping": "amadeusExchShop",
    "madridSeatsBooking": "madridSeatsBooking",
    "londonBooking": "travelfusionBookings",
    "londonCancelBooking": "travelfusionCancelBooking",
    "thebesBooking": "thebesBookings",
    "fortworthSeatsChange": "seatsChange",
    "fortworthSeatsPurchase": "seats",
    "parisBooking": "lodgingBooking",
    "parisCancellation": "lodgingCancellations",
    "lodgingPriceFreezeCancel": "lodgingPriceFreezeCancel",
    "lodgingPriceFreezePurchase": "lodgingPriceFreeze",
    "groundCancellation": "groundCancellation",
    "oklahomaFulfillment": "oklahomaFulfillment",
    "oklahomaQuote": "oklahomaQuote",
    "victoriaAddOn": "addOn",
}

# Regex to extract secure-logs conversation ID from state_output JSON.
# Different machines store it under different keys:
#   - brooklynAirBooking, flightsFacade*: "conversationId" (camelCase)
#   - oklahomaQuote: "conversation_id" (snake_case)
#   - some machines: "traceId" (used as ConversationId in the dashboard)
# The mapping from state_output field to SecureLogs.ConversationId is
# defined per-machine in helpers-dashboard's SessionService implementations.
_CONVERSATION_ID_RE = (
    r'"(?:traceId|conversationId|conversation_id)"\s*:\s*"?'
    r"([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})"
)


def _resolve_table(client_id: str, env: str) -> str:
    db = CLIENT_DB.get(client_id)
    if db is None:
        if client_id.startswith("orange_"):
            return f"gcp-hopper-etldata-{env}.{client_id}.session_history_history"
        print(f"Unknown clientId: {client_id}", file=sys.stderr)
        sys.exit(1)
    if env == "production":
        dataset = f"orange_{db}_{db}_private"
    else:
        dataset = f"orange_shared_{db}_private"
    return f"gcp-hopper-etldata-{env}.{dataset}.session_history_history"


def _parse_ts_range(ts: str) -> tuple[str, str]:
    """Parse truncated ISO 8601 into (start, end) SQL timestamp strings.

    Supports: 2023-01-03, 2023-01-03T22, 2023-01-03T22:30, 2023-01-03T22:30:45
    """
    from datetime import timedelta

    patterns = [
        (r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}$", "%Y-%m-%dT%H:%M:%S", timedelta(seconds=1)),
        (r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$", "%Y-%m-%dT%H:%M", timedelta(minutes=1)),
        (r"^\d{4}-\d{2}-\d{2}T\d{2}$", "%Y-%m-%dT%H", timedelta(hours=1)),
        (r"^\d{4}-\d{2}-\d{2}$", "%Y-%m-%d", timedelta(days=1)),
    ]
    for regex, fmt, delta in patterns:
        if re.match(regex, ts):
            dt = datetime.strptime(ts, fmt)
            end = dt + delta
            return dt.strftime("%Y-%m-%d %H:%M:%S"), end.strftime("%Y-%m-%d %H:%M:%S")
    print(f"Unsupported timestamp format: {ts}", file=sys.stderr)
    sys.exit(1)


def _time_filter(hours: int) -> str:
    interval = f"TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL {hours} HOUR)"
    return f"__timestamp > {interval} AND ts > {interval}"


def _ts_range_filter(ts: str) -> str:
    """BQ filter for session_history tables using a truncated ISO 8601 timestamp."""
    start, end = _parse_ts_range(ts)
    return (
        f'__timestamp >= "{start}" AND __timestamp < "{end}" '
        f'AND ts >= "{start}" AND ts < "{end}"'
    )


def _run_query(sql: str) -> list[dict[str, Any]]:
    client = bigquery.Client()
    return [dict(row) for row in client.query(sql).result()]


def _fmt_ts(ts: Any) -> str:
    if isinstance(ts, datetime):
        return ts.strftime("%Y-%m-%d %H:%M:%S")
    return str(ts)


# ─── Commands ─────────────────────────────────────────────────────────


def cmd_list_clients(args: argparse.Namespace) -> None:
    """List available state machine clients by querying BQ datasets."""
    project = f"gcp-hopper-etldata-{args.env}"
    client = bigquery.Client(project=project)
    reverse = {
        (f"orange_shared_{db}_private" if args.env != "production" else f"orange_{db}_{db}_private"): cid
        for cid, db in CLIENT_DB.items()
    }
    prefix = "orange_shared_" if args.env != "production" else "orange_"
    for ds in sorted(client.list_datasets(), key=lambda d: d.dataset_id):
        did = ds.dataset_id
        if did.startswith(prefix) and did.endswith("_private"):
            cid = reverse.get(did, "?")
            if not args.filter or args.filter.lower() in did.lower() or args.filter.lower() in cid.lower():
                print(cid)


def cmd_get_session_steps(args: argparse.Namespace) -> None:
    """Get all steps for a session."""
    table = _resolve_table(args.client_id, args.env)
    output_col = "NULL AS state_output"
    if args.output_steps:
        ids = ", ".join(f"'{s}'" for s in args.output_steps)
        output_col = (
            f"IF(state_id IN ({ids}), "
            f"SUBSTR(CAST(state_output AS STRING), 1, 2000), "
            f"NULL) AS state_output"
        )
    ts_filter = f"AND {_ts_range_filter(args.timestamp)}" if args.timestamp else ""
    sql = f"""
        SELECT state_id, previous_state_id, success, {output_col},
               REGEXP_EXTRACT(CAST(state_output AS STRING),
                   r'{_CONVERSATION_ID_RE}') AS _conv_id, ts
        FROM `{table}`
        WHERE session_id = FROM_BASE64("{args.session_id}") {ts_filter}
        ORDER BY ts
    """
    rows = _run_query(sql)
    conv_id = None
    for row in rows:
        if row.get("_conv_id") and conv_id is None:
            conv_id = row["_conv_id"]
        status = "OK" if row["success"] else "FAIL"
        line = f"{_fmt_ts(row['ts'])}  {row['state_id']:30s}  {status}"
        if row.get("state_output"):
            line += f"\n    {row['state_output'][:500]}"
        print(line)
    if conv_id:
        print(f"\nconversation_id: {conv_id}")


def cmd_get_failing_steps(args: argparse.Namespace) -> None:
    """Get failing steps for a session with output."""
    table = _resolve_table(args.client_id, args.env)
    ts_filter = f"AND {_ts_range_filter(args.timestamp)}" if args.timestamp else ""
    sql = f"""
        SELECT state_id, previous_state_id,
               SUBSTR(CAST(state_output AS STRING), 1, 2000) AS state_output, ts
        FROM `{table}`
        WHERE session_id = FROM_BASE64("{args.session_id}") AND success = FALSE {ts_filter}
        ORDER BY ts
    """
    for row in _run_query(sql):
        print(f"{_fmt_ts(row['ts'])}  {row['state_id']}")
        if row.get("state_output"):
            print(f"    {row['state_output'][:1000]}")


def cmd_get_output(args: argparse.Namespace) -> None:
    """Print raw state_output for a specific step. Pipe-friendly."""
    table = _resolve_table(args.client_id, args.env)
    ts_filter = f"AND {_ts_range_filter(args.timestamp)}" if args.timestamp else ""
    sql = f"""
        SELECT CAST(state_output AS STRING) AS state_output
        FROM `{table}`
        WHERE session_id = FROM_BASE64("{args.session_id}")
          AND state_id = "{args.state_id}" {ts_filter}
        ORDER BY ts DESC LIMIT 1
    """
    rows = _run_query(sql)
    if not rows:
        print("Step not found.", file=sys.stderr)
        sys.exit(1)
    print(rows[0]["state_output"] or "")


def cmd_search_recent(args: argparse.Namespace) -> None:
    """List recent sessions with their latest step."""
    table = _resolve_table(args.client_id, args.env)
    sql = f"""
        WITH ranked AS (
            SELECT TO_BASE64(session_id) AS session_id, state_id, success, ts,
                   ROW_NUMBER() OVER (PARTITION BY session_id ORDER BY ts DESC) AS rn
            FROM `{table}`
            WHERE {_time_filter(args.hours)}
        )
        SELECT session_id, state_id, success, ts
        FROM ranked WHERE rn = 1
        ORDER BY ts DESC LIMIT {args.limit}
    """
    for row in _run_query(sql):
        status = "OK" if row["success"] else "FAIL"
        print(f"{_fmt_ts(row['ts'])}  {status:4s}  {row['state_id']:20s}  {row['session_id']}")


def cmd_search_failed(args: argparse.Namespace) -> None:
    """Find sessions that completed with failure."""
    table = _resolve_table(args.client_id, args.env)
    sql = f"""
        SELECT TO_BASE64(session_id) AS session_id, state_id,
               SUBSTR(CAST(state_output AS STRING), 1, 500) AS state_output, ts
        FROM `{table}`
        WHERE state_id = 'done!' AND success = FALSE AND {_time_filter(args.hours)}
        ORDER BY ts DESC LIMIT {args.limit}
    """
    for row in _run_query(sql):
        print(f"{_fmt_ts(row['ts'])}  {row['session_id']}")
        if row.get("state_output"):
            print(f"    {row['state_output'][:300]}")


def cmd_search_keyword(args: argparse.Namespace) -> None:
    """Search state_output for a keyword."""
    table = _resolve_table(args.client_id, args.env)
    safe = args.keyword.replace("'", "\\'")
    sql = f"""
        SELECT TO_BASE64(session_id) AS session_id, state_id, success,
               SUBSTR(CAST(state_output AS STRING), 1, 500) AS state_output, ts
        FROM `{table}`
        WHERE CAST(state_output AS STRING) LIKE '%{safe}%'
            AND {_time_filter(args.hours)}
        ORDER BY ts DESC LIMIT {args.limit}
    """
    for row in _run_query(sql):
        status = "OK" if row["success"] else "FAIL"
        print(f"{_fmt_ts(row['ts'])}  {status:4s}  {row['state_id']:20s}  {row['session_id']}")


def cmd_secure_logs(args: argparse.Namespace) -> None:
    """Get secure-logs entries for a conversation ID."""
    project = f"gcp-hopper-etldata-{args.env}"
    table = f"{project}.secure_logs_private.statements"
    sql = f"""
        SELECT statement_id, timestamp, third_party_service, action, producer
        FROM `{table}`
        WHERE conversation_id = "{args.conversation_id}"
        ORDER BY timestamp LIMIT {args.limit}
    """
    for row in _run_query(sql):
        svc = row.get("third_party_service") or "?"
        action = row.get("action") or "?"
        producer = row.get("producer") or "?"
        print(f"{_fmt_ts(row['timestamp'])}  {svc:25s}  {action:30s}  producer={producer}")


def cmd_machine_info(args: argparse.Namespace) -> None:
    """Get step names and optionally transitions from Trenton."""
    session_type = CLIENT_TRENTON.get(args.client_id, args.client_id)
    base_url = "http://server.trenton.svc.cluster.local:7070"

    async def fetch() -> None:
        async with httpx.AsyncClient(timeout=10.0) as client:
            try:
                resp = await client.get(f"{base_url}/api/v1/{session_type}/states")
                resp.raise_for_status()
                states = resp.json()
            except httpx.ConnectError:
                print("Cannot reach Trenton. Start the proxy with: hopctl proxy", file=sys.stderr)
                sys.exit(1)
            except httpx.HTTPStatusError as e:
                print(f"Trenton returned {e.response.status_code} for {session_type!r}", file=sys.stderr)
                sys.exit(1)

            print(f"{'ID':15s} {'Type':10s} Display Name")
            print("-" * 60)
            for s in states:
                print(f"{s['id']:15s} {s.get('stateType', '?'):10s} {s.get('displayName', '?')}")

            if args.transitions:
                resp = await client.get(f"{base_url}/api/v1/{session_type}/transitions")
                resp.raise_for_status()
                transitions = resp.json()
                print(f"\nTransitions:")
                if isinstance(transitions, dict):
                    for src, targets in transitions.items():
                        if isinstance(targets, list):
                            for t in targets:
                                print(f"  {src} -> {t}")
                        else:
                            print(f"  {src} -> {targets}")

    asyncio.run(fetch())


def cmd_dashboard_url(args: argparse.Namespace) -> None:
    """Print dashboard base URL for a client."""
    session_type = CLIENT_TRENTON.get(args.client_id)
    if session_type is None:
        print(f"No dashboard mapping for clientId: {args.client_id}", file=sys.stderr)
        print("Available clients with dashboard support:", file=sys.stderr)
        for cid in sorted(CLIENT_TRENTON):
            print(f"  {cid}", file=sys.stderr)
        sys.exit(1)
    print(f"https://dashboard-{args.env}.portal.hopper.com/#/{session_type}")


# ─── CLI ──────────────────────────────────────────────────────────────


def main() -> None:
    parser = argparse.ArgumentParser(description="Debug state machine sessions")
    parser.add_argument("--env", default="staging", help="Environment (default: staging)")
    sub = parser.add_subparsers(dest="command", required=True)

    # list-clients
    p = sub.add_parser("list-clients", help="List available Orange clients")
    p.add_argument("--filter", help="Filter by name substring")

    _TS_HELP = "Truncated ISO 8601 timestamp to narrow BQ scan (e.g. 2023-01-03, 2023-01-03T22)"

    # get-session-steps
    p = sub.add_parser("get-session-steps", help="Get all steps for a session")
    p.add_argument("client_id")
    p.add_argument("session_id", help="Base64-encoded session ID")
    p.add_argument("--output-steps", nargs="*", help="State IDs to include output for (e.g. done! iqc)")
    p.add_argument("--timestamp", help=_TS_HELP)

    # get-failing-steps
    p = sub.add_parser("get-failing-steps", help="Get failing steps with output")
    p.add_argument("client_id")
    p.add_argument("session_id", help="Base64-encoded session ID")
    p.add_argument("--timestamp", help=_TS_HELP)

    # get-output
    p = sub.add_parser("get-output", help="Print raw state_output for a step (pipe-friendly)")
    p.add_argument("client_id")
    p.add_argument("session_id", help="Base64-encoded session ID")
    p.add_argument("state_id", help="Step ID (e.g. done!, brq)")
    p.add_argument("--timestamp", help=_TS_HELP)

    # search-recent
    p = sub.add_parser("search-recent", help="List recent sessions")
    p.add_argument("client_id")
    p.add_argument("--hours", type=int, default=24)
    p.add_argument("--limit", type=int, default=20)

    # search-failed
    p = sub.add_parser("search-failed", help="Find failed sessions")
    p.add_argument("client_id")
    p.add_argument("--hours", type=int, default=24)
    p.add_argument("--limit", type=int, default=50)

    # search-keyword
    p = sub.add_parser("search-keyword", help="Search state_output for a keyword")
    p.add_argument("client_id")
    p.add_argument("keyword")
    p.add_argument("--hours", type=int, default=24)
    p.add_argument("--limit", type=int, default=50)

    # secure-logs
    p = sub.add_parser("secure-logs", help="Get secure-logs for a conversation ID")
    p.add_argument("conversation_id")
    p.add_argument("--limit", type=int, default=50)

    # dashboard-url
    p = sub.add_parser("dashboard-url", help="Print dashboard base URL for a client")
    p.add_argument("client_id")

    # machine-info
    p = sub.add_parser("machine-info", help="Get step names from Trenton")
    p.add_argument("client_id")
    p.add_argument("--transitions", action="store_true", help="Include state transitions")

    args = parser.parse_args()
    commands = {
        "list-clients": cmd_list_clients,
        "get-session-steps": cmd_get_session_steps,
        "get-failing-steps": cmd_get_failing_steps,
        "get-output": cmd_get_output,
        "search-recent": cmd_search_recent,
        "search-failed": cmd_search_failed,
        "search-keyword": cmd_search_keyword,
        "secure-logs": cmd_secure_logs,
        "dashboard-url": cmd_dashboard_url,
        "machine-info": cmd_machine_info,
    }
    commands[args.command](args)


if __name__ == "__main__":
    main()


# ─── Tests ───────────────────────────────────────────────────────────
# Run with: uv run --with-requirements state-machine.py --with pytest -- pytest state-machine.py -v


def test_resolve_table_staging():
    t = _resolve_table("brooklynAirBooking", "staging")
    assert t == "gcp-hopper-etldata-staging.orange_shared_air_booking_private.session_history_history"


def test_resolve_table_production():
    t = _resolve_table("brooklynAirBooking", "production")
    assert t == "gcp-hopper-etldata-production.orange_air_booking_air_booking_private.session_history_history"


def test_resolve_table_raw_dataset():
    t = _resolve_table("orange_custom_dataset", "staging")
    assert t == "gcp-hopper-etldata-staging.orange_custom_dataset.session_history_history"


def test_parse_ts_range_day():
    start, end = _parse_ts_range("2023-01-03")
    assert start == "2023-01-03 00:00:00"
    assert end == "2023-01-04 00:00:00"


def test_parse_ts_range_hour():
    start, end = _parse_ts_range("2023-01-03T22")
    assert start == "2023-01-03 22:00:00"
    assert end == "2023-01-03 23:00:00"


def test_parse_ts_range_minute():
    start, end = _parse_ts_range("2023-01-03T22:30")
    assert start == "2023-01-03 22:30:00"
    assert end == "2023-01-03 22:31:00"


def test_parse_ts_range_second():
    start, end = _parse_ts_range("2023-01-03T22:30:45")
    assert start == "2023-01-03 22:30:45"
    assert end == "2023-01-03 22:30:46"


def test_parse_ts_range_hour_boundary():
    start, end = _parse_ts_range("2023-01-03T23")
    assert start == "2023-01-03 23:00:00"
    assert end == "2023-01-04 00:00:00"


def test_ts_range_filter():
    f = _ts_range_filter("2023-06-15T14")
    assert '__timestamp >= "2023-06-15 14:00:00"' in f
    assert '__timestamp < "2023-06-15 15:00:00"' in f
    assert 'ts >= "2023-06-15 14:00:00"' in f
    assert 'ts < "2023-06-15 15:00:00"' in f


def test_time_filter():
    f = _time_filter(24)
    assert "__timestamp >" in f
    assert "ts >" in f
    assert "INTERVAL 24 HOUR" in f


def test_client_db_has_entries():
    assert len(CLIENT_DB) > 50
    assert "brooklynAirBooking" in CLIENT_DB
    assert CLIENT_DB["brooklynAirBooking"] == "air_booking"


def test_client_trenton_has_entries():
    assert len(CLIENT_TRENTON) > 40
    assert CLIENT_TRENTON["brooklynAirBooking"] == "booking"
    assert CLIENT_TRENTON["flightsFacadeBooking"] == "facadeBookings"


def test_dashboard_url_known_client():
    args = argparse.Namespace(client_id="brooklynAirBooking", env="staging")
    import io, contextlib
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        cmd_dashboard_url(args)
    assert buf.getvalue().strip() == "https://dashboard-staging.portal.hopper.com/#/booking"


def test_conversation_id_regex():
    sample = '{"conversationId":"a1b2c3d4-e5f6-7890-abcd-ef1234567890","other":"val"}'
    match = re.search(_CONVERSATION_ID_RE, sample)
    assert match is not None
    assert match.group(1) == "a1b2c3d4-e5f6-7890-abcd-ef1234567890"


def test_conversation_id_regex_snake_case():
    sample = '{"conversation_id":"a1b2c3d4-e5f6-7890-abcd-ef1234567890"}'
    match = re.search(_CONVERSATION_ID_RE, sample)
    assert match is not None


def test_conversation_id_regex_trace_id():
    sample = '{"traceId":"a1b2c3d4-e5f6-7890-abcd-ef1234567890"}'
    match = re.search(_CONVERSATION_ID_RE, sample)
    assert match is not None
