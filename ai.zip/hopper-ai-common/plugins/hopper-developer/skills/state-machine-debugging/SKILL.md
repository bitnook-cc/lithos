---
name: state-machine-debugging
description: >-
  Use when debugging state machine sessions, investigating booking/quote/fulfillment
  failures, or tracing state machine step outcomes.
  Triggers: "state machine session", "quote machine", "fulfillment machine",
  "session history", "booking failed at step", "orange session".
---

# Debug State Machine Sessions

## Overview

Hopper uses a centralized state machine persistence service (Spanner-backed). Every state machine execution is a **session** with ordered **steps**, each producing a state output (JSON bytes). 60+ client machines across all domains use it.

## CLI Tool

The `state-machine.py` script in this skill directory provides all common queries. Run with `uv run <path-to-this-skill-dir>/state-machine.py`.

All commands accept `--env` (default: `staging`). Production BQ access requires additional permissions that most developers don't have — use staging unless explicitly asked for production data.

### List available clients
```bash
uv run state-machine.py list-clients
uv run state-machine.py list-clients --filter booking
```
```
brooklynAirBooking
bogotaBooking
flightsBooking
```

### Search recent sessions
```bash
uv run state-machine.py search-recent brooklynAirBooking --hours 24 --limit 20
```
```
2026-03-20 17:23:11  OK    done!                 p9KRdjtTS72+sUSHVUtU0FaTN+m7...
2026-03-20 17:19:47  OK    done!                 p9KRdjtTS72+sUSHVUtU0PMg8YRO...
2026-03-20 17:05:32  FAIL  brq                   p9KRdjtTS72+sUSHVUtU0Lr3FAH2...
```

### Find failed sessions
```bash
uv run state-machine.py search-failed brooklynAirBooking --hours 24
```

### Get all steps for a session

**Large output warning**: Sessions can have 80+ steps. Use `--output-steps` to selectively include state_output only for steps you care about — without it, output is one line per step.

```bash
uv run state-machine.py get-session-steps brooklynAirBooking "BASE64_SESSION_ID"
# Include state_output for specific steps only:
uv run state-machine.py get-session-steps brooklynAirBooking "BASE64_SESSION_ID" --output-steps done! iqc
```
```
2026-03-20 17:21:35  mktc                            OK
2026-03-20 17:21:36  pcr                             OK
2026-03-20 17:21:36  cie                             OK
...
2026-03-20 17:22:40  fbs                             OK
2026-03-20 17:23:11  done!                           OK

conversation_id: 0cc64bf9-9d7f-4975-9216-46555f497d69
```

Returns step list and prints `conversation_id` if found (for [secure-log-debugging](hopper-developer:secure-log-debugging) lookup).

### Get failing steps with output

**Large output warning**: Each failing step includes up to 2000 chars of state_output (JSON).

```bash
uv run state-machine.py get-failing-steps brooklynAirBooking "BASE64_SESSION_ID"
```
```
2026-03-20 17:05:32  brq
    {"Result":"Fail","errors":[{"code":"PROVIDER_ERROR","message":"..."}]}
```

### Get raw state_output for a step (pipe-friendly)
```bash
uv run state-machine.py get-output brooklynAirBooking "BASE64_SESSION_ID" "done!"
# Pipe to jq:
uv run state-machine.py get-output brooklynAirBooking "BASE64_SESSION_ID" "done!" 2>/dev/null | jq .
```

### Search state_output by keyword
```bash
uv run state-machine.py search-keyword brooklynAirBooking "ERROR_MESSAGE" --hours 48
```

### Look up secure-logs (external API calls)
```bash
uv run state-machine.py secure-logs "CONVERSATION_UUID" --limit 50
```

### Get dashboard URL
```bash
uv run state-machine.py dashboard-url brooklynAirBooking
```
```
https://dashboard-staging.portal.hopper.com/#/booking
```

### Get step names from Trenton (requires `hopctl proxy`)
```bash
uv run state-machine.py machine-info brooklynAirBooking
uv run state-machine.py machine-info brooklynAirBooking --transitions
```

## Key Concepts

- **clientId**: Identifies which state machine (e.g., `oklahomaQuote`, `brooklynAirBooking`)
- **session_id**: BYTES column — displayed as base64, use `FROM_BASE64("...")` in SQL
- **state_id**: Abbreviated step name (e.g., `iqc`, `brq`, `done!`). Nested steps use `|` separator
- **state_output**: JSON bytes — `{"Result": "Ok", "value": {...}}` or `{"Result": "Fail", "errors": [...]}`
- **conversation_id**: UUID linking sessions to secure-logs (external API call records)

## Custom Queries

Read `state-machine.py` to understand the query patterns and table resolution logic, then write custom Python scripts or `bq` queries as needed. Key details:

- **Table**: `gcp-hopper-etldata-{env}.{dataset}.session_history_history`
- **Staging dataset**: `orange_shared_{db}_private`
- **Production dataset**: `orange_{db}_{db}_private`
- **Partition**: `__timestamp` (DAY) — always filter on `__timestamp >` alongside `ts >` for performance
- **Clustering**: `client_id, state_id, __timestamp`

The `CLIENT_DB` and `CLIENT_TRENTON` mappings are in `state-machine.py` with provenance comments.

## Dashboard (Browser)

`https://dashboard-{env}.portal.hopper.com/#/{sessionType}`

The `{sessionType}` is the Trenton session type (see `CLIENT_TRENTON` in `state-machine.py`), not the clientId.

## Debugging Checklist

1. **Get session ID** — from logs, Dashboard, Datadog, or `search-recent`/`search-failed`
2. **Check `done!` state** — did the session complete? Was it successful?
3. **Find the failing step** — `get-failing-steps` shows failures with output
4. **Read the step output** — use `--output-steps` to fetch specific step data
5. **Check secure-logs** — use the `conversation_id` from step output
6. **Resolve step names** — `machine-info` maps abbreviations to display names
7. **Check retry behavior** — look for repeated step IDs with different timestamps
