---
name: gcp
description: >-
  Use when needing to identify which GCP project a Hopper service runs in,
  understanding GCP project naming conventions, finding the right project for
  an environment or realm, or understanding how Hopper's GCP infrastructure
  is organized across projects.
---

# GCP — Hopper's Google Cloud Platform Landscape

## Overview

Hopper runs on GCP. Services, data pipelines, and infrastructure are spread across many GCP projects organized by environment, realm, and function. This skill helps you find the right project for your work.

## Projects Developers Use

### Core App Projects

Where most services run (GKE clusters, Spanner, BigQuery, etc.):

| Environment | Project |
|-------------|---------|
| Development | `gcp-hopper-app-development` |
| Staging | `gcp-hopper-app-staging` |
| Production | `gcp-hopper-app-production` |

**Gotcha:** Development is `gcp-hopper-app-development` — not `dev`. Staging and production are also spelled out in full.

### CI/CD

| Project | Purpose |
|---------|---------|
| `gcp-hopper-cicd` | Build pipelines, container registry (GAR), Atlantis, Harness |

### ETL / Data Projects

| Project | Purpose |
|---------|---------|
| `gcp-hopper-etl-{development,staging,production}` | ETL pipeline infrastructure |
| `gcp-hopper-etldata-{development,staging,production}` | ETL data storage |
| `gcp-hopper-etldata-backup` | ETL data backups |
| `gcp-hopper-bi-data` | General BI data |
| `gcp-hopper-air-data` | Flights domain data |
| `gcp-hopper-hotels-data` | Hotels domain data |
| `gcp-hopper-flyte` | Flyte workflow orchestration |
| `gcp-hopper-ds-research` | Playground for data/ML related work |

### Other Projects You May Encounter

| Project | Purpose |
|---------|---------|
| `gcp-hopper-infra-mgmt` | Shared VPC host, DNS, centralized networking |
| `gcp-hopper-observability` | Centralized monitoring |
| `gcp-hopper-sandbox` | Sandbox for experimentation |

## Naming Conventions

| Pattern | Example | Used by |
|---------|---------|---------|
| `gcp-hopper-{domain}-{environment}` | `gcp-hopper-app-production` | Most projects |
| `hopper-{realm}-{resource}-{environment}` | `hopper-partner-app-production` | Realm-specific projects |
| `h4r-{realm}-{domain}-bi-{env}` | `h4r-common-platform-bi-prd` | Business Intelligence |

Environment abbreviations are inconsistent across project families — some use `production`/`staging`/`development`, others use `prd`/`stg`/`dev`.

## Realms

Hopper uses a multi-realm architecture. Most developers work in `common`:

| Realm | Description |
|-------|-------------|
| `common` (hopper-app) | Main consumer app — where most services live. This is where you work. |
| `partner` | Partners needing cross-realm access (e.g. hotel chains managing bookings across tenants) |
| `gdata` | Cross-realm data analysis |
| `unreal` | Experimentation |

Each realm has its own GCP projects and GKE clusters. Most developers only touch `common`.

## Where to Find Things

| What you need | Where to look |
|---------------|---------------|
| Application logs | **Datadog** — not GCP Cloud Logging. App logs flow through a pipeline to Datadog. See [datadog-ops](hopper-developer:datadog-ops). |
| Infrastructure as code | **Olympus** repo — Terraform for GCP resources. See [olympus](hopper-developer:olympus). |
| Kubernetes resources | **GKE clusters** — use MCP tool or kubectl. See [gke](hopper-developer:gke). |
| Container images | **GAR** in `gcp-hopper-cicd` (`gcr.io/gcp-hopper-cicd/hopper.com/{image}`) |
| Deployment config | **rules_hopper** in your repo's `deployment/` directory. See [deployment](hopper-developer:deployment). |

## Observability

**Metrics:** GCP Cloud Monitoring is the source of truth. All GCP metrics are also sent to Datadog. If you lack GCP access (e.g., `monitoring.timeSeries.list` permission), use Datadog instead. See [datadog-ops](hopper-developer:datadog-ops).

**Logs:** Always use Datadog. Application logs flow from GCP Cloud Logging → Pub/Sub → PII scrubbing → Datadog. Cloud Logging is not used for operational queries. See [datadog-ops](hopper-developer:datadog-ops).

**Traces:** Only available in Datadog. GCP Cloud Trace is not used at Hopper. See [datadog-ops](hopper-developer:datadog-ops).

## Infrastructure Management

GCP resources for your service are managed in the **Olympus** repo under `apps/{service}/{realm}/{env}/`. See the [olympus skill](hopper-developer:olympus) for the full self-service workflow (creating service accounts, Spanner databases, BigQuery datasets, etc.).

## GCP MCP Servers (Local Setup)

GCP MCP servers (BigQuery, GKE, Cloud Run, etc.) must be installed in your **local** user settings — they require OAuth authentication which doesn't work when distributed via plugins.

See the [GCP MCP servers documentation](https://cloud.google.com/products/mcp-servers) for the full list of available servers and their configurations.

To add a GCP MCP server, add entries to your `~/.claude/settings.json` (or use `/settings` in Claude Code). Example for BigQuery:

```json
{
  "mcpServers": {
    "gcp-bigquery": {
      "type": "http",
      "url": "https://bigquery.googleapis.com/mcp",
      "headers": { "x-goog-user-project": "gcp-hopper-app-development" },
      "oauth": {
        "clientId": "724366815810-qoa2kq5ff48mcde309eahm7rn84srf9j.apps.googleusercontent.com"
      }
    }
  }
}
```

All GCP MCP servers use the same OAuth credentials. Always set `x-goog-user-project` to `gcp-hopper-app-development` — the dev project has permissions to query resources across all environments including production.

## Cross-References

- [gke](hopper-developer:gke) — Connecting to clusters and debugging workloads
- [olympus](hopper-developer:olympus) — Terraform IaC for GCP resources
- [datadog-ops](hopper-developer:datadog-ops) — Searching logs, metrics, and traces
- [deployment](hopper-developer:deployment) — Kubernetes deployment definitions
