# hopper-developer

Language-agnostic developer tooling for Hopper services.

This plugin is concerned with concrete facts about the Hopper development ecosystem — infrastructure, deployment, observability, and CI/CD. Skills in this plugin are language-agnostic and describe how things work, not how you should work.

For opinionated development workflows (e.g., pre-PR checklists, testing conventions), see the [hopper-developer-workflow](../hopper-developer-workflow/) plugin.

## Skills

| Skill | Purpose |
|---|---|
| `atlantis` | Terraform IaC CI with Atlantis (Olympus, Arecibo, github-config) |
| `backstage` | Backstage catalog setup and onboarding |
| `datadog-config` | Datadog monitors, SLOs, dashboards in Arecibo |
| `datadog-ops` | Production debugging with Datadog logs, metrics, traces |
| `deployment` | Bazel rules_hopper, Kubernetes workloads, Harness CI/CD |
| `gcp` | GCP project identification and naming conventions |
| `github-actions` | GitHub Actions workflows and CI/CD pipelines |
| `gke` | GKE cluster debugging — pods, deployments, logs, events |
| `olympus` | GCP infrastructure in Olympus (Terraform) |
| `secure-log-debugging` | Debug secure-logs — decode HTTP request/response payloads to external providers |
| `state-machine-debugging` | Debug Orange state machine sessions — BQ queries, step resolution, Trenton API |
| `release-me` | Conventional-commit release versioning |
| `service-discovery` | Find Hopper services, libraries, and repositories |

## Install

```
/plugin marketplace add hopper-org/hopper-ai-common
/plugin install hopper-developer@hopper-ai-common
```
