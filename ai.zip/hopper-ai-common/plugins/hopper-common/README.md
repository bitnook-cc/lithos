# hopper-common

Shared MCP server configs for common tools — Slack, Atlassian, and more.

## MCP Servers

| Server | Service | Auth |
|---|---|---|
| `slack` | Slack | OAuth |
| `atlassian` | Atlassian (Jira, Confluence) | Browser |

## Install

```
/plugin marketplace add hopper-org/hopper-ai-common
/plugin install hopper-common@hopper-ai-common
```
