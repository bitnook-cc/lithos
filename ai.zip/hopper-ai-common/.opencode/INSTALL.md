# Installing hopper-ai-common for OpenCode

## Prerequisites

- [OpenCode.ai](https://opencode.ai) installed
- Git installed

## Installation

### 1. Clone the repo

```bash
git clone --branch opencode git@github.com:hopper-org/hopper-ai-common.git ~/.config/opencode/hopper-ai-common
```

### 2. Register the plugin

Create a symlink so OpenCode discovers the plugin:

```bash
mkdir -p ~/.config/opencode/plugins
ln -sf ~/.config/opencode/hopper-ai-common/.opencode/plugins/hopper-ai-common.js ~/.config/opencode/plugins/hopper-ai-common.js
```

### 3. Symlink skills

Create symlinks so OpenCode's native skill tool discovers the skills:

```bash
mkdir -p ~/.config/opencode/skills
for plugin_dir in ~/.config/opencode/hopper-ai-common/.opencode/skills/*/; do
  ln -sf "$plugin_dir" ~/.config/opencode/skills/
done
```

### 4. Install the attribution git hook (recommended)

This hook automatically adds a `Co-Authored-By` trailer to commits made during OpenCode sessions, attributing the AI model used.

**Option A — Global hook (applies to all repos):**

```bash
mkdir -p ~/.git-hooks
ln -sf ~/.config/opencode/hopper-ai-common/.opencode/hooks/prepare-commit-msg ~/.git-hooks/prepare-commit-msg
git config --global core.hooksPath ~/.git-hooks
```

> **Note:** If you already use `core.hooksPath`, copy the hook into your existing hooks directory instead.

**Option B — Per-repo hook:**

```bash
cd /path/to/your/repo
ln -sf ~/.config/opencode/hopper-ai-common/.opencode/hooks/prepare-commit-msg .git/hooks/prepare-commit-msg
```

Commits made during an OpenCode session will include a trailer like:

```
Co-Authored-By: OpenCode google-vertex-anthropic/claude-opus-4-6 <noreply@opencode.ai>
```

### 5. Restart OpenCode

Restart OpenCode. The plugin will inject Hopper skill context automatically.

## Usage

### List available skills

```
use skill tool to list skills
```

### Load a specific skill

```
use skill tool to load hopper-developer/type-discovery
```

## Updating

```bash
cd ~/.config/opencode/hopper-ai-common
git pull
```

## Troubleshooting

### Plugin not loading

1. Check plugin symlink: `ls -l ~/.config/opencode/plugins/hopper-ai-common.js`
2. Check source exists: `ls ~/.config/opencode/hopper-ai-common/.opencode/plugins/hopper-ai-common.js`

### Skills not found

1. Check skills symlinks: `ls -l ~/.config/opencode/skills/hopper-*/`
2. Verify they point to: `~/.config/opencode/hopper-ai-common/.opencode/skills/<plugin>/`
3. Use `skill` tool to list what's discovered
