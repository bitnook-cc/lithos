/**
 * hopper-ai-common plugin for OpenCode.ai
 *
 * Skills are discovered via OpenCode's native skill tool from symlinked directory.
 * This plugin injects a system prompt reminder about available Hopper skills.
 */

import path from "path";
import fs from "fs";
import os from "os";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

export const HopperAiCommonPlugin = async ({ client, directory }) => {
  const homeDir = os.homedir();
  const skillsDir = path.resolve(__dirname, "../skills");
  const envConfigDir = process.env.OPENCODE_CONFIG_DIR
    ? path.resolve(
        process.env.OPENCODE_CONFIG_DIR.startsWith("~/")
          ? path.join(homeDir, process.env.OPENCODE_CONFIG_DIR.slice(2))
          : process.env.OPENCODE_CONFIG_DIR,
      )
    : null;
  const configDir = envConfigDir || path.join(homeDir, ".config/opencode");

  // Discover available skill names (leaf directory names only, matching
  // what OpenCode's native skill tool reports)
  const getSkillNames = () => {
    if (!fs.existsSync(skillsDir)) return [];
    const names = [];
    for (const entry of fs.readdirSync(skillsDir, { withFileTypes: true })) {
      if (!entry.isDirectory()) continue;
      const entryPath = path.join(skillsDir, entry.name);
      // Direct skill (has SKILL.md)
      if (fs.existsSync(path.join(entryPath, "SKILL.md"))) {
        names.push(entry.name);
        continue;
      }
      // Plugin group — collect child skill directories
      for (const child of fs.readdirSync(entryPath, { withFileTypes: true })) {
        if (
          child.isDirectory() &&
          fs.existsSync(path.join(entryPath, child.name, "SKILL.md"))
        ) {
          names.push(child.name);
        }
      }
    }
    return names;
  };

  return {
    "shell.env": async (input, output) => {
      output.env.OPENCODE_AUTHOR_NAME = "OpenCode";
      output.env.OPENCODE_AUTHOR_EMAIL = "noreply@opencode.ai";

      if (!input.sessionID) return;

      const messages = await client.session.messages({
        path: { id: input.sessionID },
      });

      // Find the most recent assistant message with model info
      const lastAssistant = messages.data
        ?.map((m) => m.info)
        .reverse()
        .find((m) => m.role === "assistant" && "modelID" in m && m.modelID);

      if (lastAssistant && "modelID" in lastAssistant) {
        const providerID =
          "providerID" in lastAssistant ? lastAssistant.providerID : "";
        output.env.OPENCODE_MODEL = providerID
          ? `${providerID}/${lastAssistant.modelID}`
          : lastAssistant.modelID;
      }
    },

    "experimental.chat.system.transform": async (_input, output) => {
      const skills = getSkillNames();
      if (skills.length === 0) return;

      const bootstrap = `<hopper-ai-common>
You have access to Hopper-specific skills via the skill tool.

**Available skills:** ${skills.join(", ")}

Use OpenCode's native \`skill\` tool to load a skill when it applies to your task:
- \`skill ${skills[0]}\` to load a skill

**Tool mapping from Claude Code references in skills:**
- \`TodoWrite\` → your \`update_plan\` tool
- \`Task\` tool with subagents → your subagent system (@mention)
- \`Skill\`, \`Read\`, \`Write\`, \`Edit\`, \`Bash\`, \`Glob\`, \`Grep\` → your native tools (same names)

**Skills location:** \`${configDir}/skills/\`
</hopper-ai-common>`;

      (output.system ||= []).push(bootstrap);
    },
  };
};
