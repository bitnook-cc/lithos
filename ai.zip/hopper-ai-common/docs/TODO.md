# TODO

## hopper-developer plugin

### Skills to create

- **service-creation** — End-to-end guide for creating a new Hopper service. Includes: namespace creation (LongBeach GitHub Actions workflow), Olympus app bootstrapping (service accounts, infrastructure), Backstage onboarding, deployment setup (rules_hopper), Harness pipeline, release-me config. Ties together existing skills into a single workflow.
