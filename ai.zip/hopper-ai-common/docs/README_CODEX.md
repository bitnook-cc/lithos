# hopper-ai-common

Shared skills and config for AI agents at Hopper.

## Structure

This branch uses the [Codex](https://developers.openai.com/codex/skills) flat skills format:

```
.agents/
  skills/                     # All skills (flattened from plugins)
    atlantis/SKILL.md
    backstage/SKILL.md
    datadog-config/SKILL.md
    datadog-ops/SKILL.md
    deployment/SKILL.md
    github-actions/SKILL.md
    olympus/SKILL.md
    openapi/SKILL.md
    release-me/SKILL.md
    type-discovery/SKILL.md
.codex/
  config.toml                 # MCP server configs (merged from plugins)
```

> **Note:** This branch is auto-generated from `master` (Claude Code format). All contributions should go to `master`.

## Scope

Skills in this repo should be scoped to an **employee role** (e.g., developer, SRE, product) or **business unit** (e.g., flights, hotels) — not to a single repository. Repo-specific knowledge (build commands, project layout, coding conventions, test strategies) belongs in the repo itself.

## Usage

Codex discovers skills from these locations ([docs](https://developers.openai.com/codex/skills)):

| Scope | Location |
|-------|----------|
| Repo | `.agents/skills/` (current or parent directories) |
| User | `~/.agents/skills/` |
| Admin | `/etc/codex/skills/` |

Copy the `.agents/skills/` directory into your project root or home directory:

```bash
# Project-level (team skills)
cp -r .agents/skills/ /path/to/your/project/.agents/skills/

# User-level (personal skills across repos)
cp -r .agents/skills/ ~/.agents/skills/
```

Codex auto-detects skills on startup. Restart if updates don't appear immediately.

## MCP Servers

MCP server configs are in `.codex/config.toml`. Remote HTTP servers cannot be added via `codex mcp add` (that's for STDIO servers only), so merge the config into your global Codex config:

```bash
# Copy the MCP config to your global Codex config
cat .codex/config.toml >> ~/.codex/config.toml
```

Then authenticate OAuth servers ([docs](https://developers.openai.com/codex/mcp/)):

```bash
codex mcp login slack
codex mcp login atlassian
codex mcp login datadog
codex mcp login gcp-bigquery
# ... repeat for other GCP servers as needed
```

### GitHub token

The `github` MCP server uses a bearer token. Add this to your `.zshrc`:

```bash
export GITHUB_TOKEN=$(gh auth token)
```

### PagerDuty API token

The `pagerduty` MCP server requires a [PagerDuty User API token](https://support.pagerduty.com/main/docs/pagerduty-mcp-server-integration-guide#generate-your-pagerduty-api-token). Generate one from **My Profile → User Settings → API Access** in PagerDuty, then add it to your `.zshrc`:

```bash
export PAGERDUTY_API_TOKEN=your-pagerduty-api-token-here
```

## Contributing

All contributions should go to the `master` branch (Claude Code format). Tool-specific branches are auto-generated on merge via GitHub Actions:

| Branch | Tool | Format |
|--------|------|--------|
| `master` / `claude` | Claude Code | `.claude-plugin/` + `plugins/` |
| `cursor` | Cursor | `.cursor-plugin/` + `plugins/` |
| `gemini` | Gemini CLI | `gemini-extension.json` per plugin |
| `opencode` | OpenCode | `.opencode/skills/` + `opencode.json` |
| **`codex`** | **Codex** | **`.agents/skills/` + `.codex/config.toml`** |

See [AGENTS.md](AGENTS.md) on `master` for the full contributor guide.
