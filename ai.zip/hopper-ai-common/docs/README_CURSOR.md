# hopper-ai-common

Shared skills and config for AI agents at Hopper.

## Structure

This repo follows the [cursor/plugin-template](https://github.com/cursor/plugin-template) directory structure:

```
plugins/
  hopper-developer/         # Plugin for Hopper developers
    .cursor-plugin/
      plugin.json           # Plugin manifest
    .mcp.json               # MCP server configs (GitHub, Datadog, GCP)
    skills/                 # Skills available to Cursor
      atlantis/
      backstage/
      datadog-config/
      datadog-ops/
      deployment/
      github-actions/
      olympus/
      release-me/
  hopper-scala/               # Scala-specific skills
    .cursor-plugin/
      plugin.json           # Plugin manifest
    skills/
      helpers-http-server/
      helpers-play-json/
      type-discovery/
  hopper-common/            # Plugin for shared MCP configs
    .cursor-plugin/
      plugin.json           # Plugin manifest
    .mcp.json               # MCP server configs (Slack, Atlassian)
```

> **Note:** This branch is auto-generated from `master` (Claude Code format). All contributions should go to `master`.

## Scope

Skills in this repo should be scoped to an **employee role** (e.g., developer, SRE, product) or **business unit** (e.g., flights, hotels) — not to a single repository. Repo-specific knowledge (build commands, project layout, coding conventions, test strategies) belongs in the repo itself.

## Usage

For Teams/Enterprise plans, admins can import this marketplace via **Dashboard → Settings → Plugins → Import** using the GitHub URL:

```
https://github.com/hopper-org/hopper-ai-common (branch: cursor)
```

Developers can then find and install plugins from the marketplace panel in Cursor.

## MCP Servers

MCP servers from `.mcp.json` are configured automatically when you install a plugin. OAuth servers (Slack, Atlassian, GCP) will prompt you to authenticate on first use.

To manage MCP servers after installation, go to **Settings** (`Cmd+Shift+J`) → **Features** → **Model Context Protocol**.

### hopper-developer

| Server | Service | Auth |
|--------|---------|------|
| `github` | GitHub Copilot | `GITHUB_TOKEN` env var |
| `datadog` | Datadog | Browser |
| `pagerduty` | PagerDuty | `PAGERDUTY_API_TOKEN` env var |
| `gcp-bigquery` | BigQuery | GCP OAuth |
| `gcp-cloud-run` | Cloud Run | GCP OAuth |
| `gcp-cloudsql` | Cloud SQL | GCP OAuth |
| `gcp-compute` | Compute Engine | GCP OAuth |
| `gcp-gke` | GKE | GCP OAuth |
| `gcp-monitoring` | Cloud Monitoring | GCP OAuth |
| `gcp-resource-manager` | Resource Manager | GCP OAuth |
| `gcp-spanner` | Spanner | GCP OAuth |
| `gcp-vertex-ai` | Vertex AI | GCP OAuth |

### hopper-common

| Server | Service | Auth |
|--------|---------|------|
| `slack` | Slack | OAuth |
| `atlassian` | Atlassian (Jira, Confluence) | Browser |

### GitHub token

The `github` MCP server requires `GITHUB_TOKEN` to be set. Add this to your `.zshrc`:

```bash
export GITHUB_TOKEN=$(gh auth token)
```

### PagerDuty API token

The `pagerduty` MCP server requires a [PagerDuty User API token](https://support.pagerduty.com/main/docs/pagerduty-mcp-server-integration-guide#generate-your-pagerduty-api-token). Generate one from **My Profile → User Settings → API Access** in PagerDuty, then add it to your `.zshrc`:

```bash
export PAGERDUTY_API_TOKEN=your-pagerduty-api-token-here
```

## Contributing

All contributions should go to the `master` branch (Claude Code format). Tool-specific branches are auto-generated on merge via GitHub Actions:

| Branch | Tool | Format |
|--------|------|--------|
| `master` / `claude` | Claude Code | `.claude-plugin/` + `plugins/` |
| **`cursor`** | **Cursor** | **`.cursor-plugin/` + `plugins/`** |
| `gemini` | Gemini CLI | `gemini-extension.json` per plugin |
| `opencode` | OpenCode | `.opencode/skills/` + `opencode.json` |
| `codex` | Codex | `.agents/skills/` + `.codex/config.toml` |

See [AGENTS.md](AGENTS.md) on `master` for the full contributor guide.
