# hopper-ai-common

Shared skills and config for AI agents at Hopper.

## Structure

This branch uses the [Gemini CLI](https://geminicli.com/docs/extensions/writing-extensions/) extension format. Each plugin is a standalone extension with its own `gemini-extension.json`:

```
plugins/
  hopper-developer/             # Extension: shared skills for Hopper developers
    gemini-extension.json       # Extension manifest (name, MCP servers)
    skills/                     # Skills available to Gemini CLI
      atlantis/SKILL.md
      backstage/SKILL.md
      datadog-config/SKILL.md
      datadog-ops/SKILL.md
      deployment/SKILL.md
      github-actions/SKILL.md
      olympus/SKILL.md
      openapi/SKILL.md
      release-me/SKILL.md
      type-discovery/SKILL.md
  hopper-common/                # Extension: shared MCP server configs
    gemini-extension.json       # Extension manifest (name, MCP servers)
```

> **Note:** This branch is auto-generated from `master` (Claude Code format). All contributions should go to `master`.

## Scope

Skills in this repo should be scoped to an **employee role** (e.g., developer, SRE, product) or **business unit** (e.g., flights, hotels) — not to a single repository. Repo-specific knowledge (build commands, project layout, coding conventions, test strategies) belongs in the repo itself.

## Usage

Clone this repo and install each extension from its local path ([docs](https://geminicli.com/docs/extensions/reference/#install-an-extension)):

```bash
git clone --branch gemini https://github.com/hopper-org/hopper-ai-common.git
cd hopper-ai-common

gemini extensions install ./plugins/hopper-developer
gemini extensions install ./plugins/hopper-common
```

Restart Gemini CLI to activate the extensions.

## MCP Servers

MCP servers are configured in each extension's `gemini-extension.json` and are activated automatically when you install the extension. You can override any server in your `~/.gemini/settings.json` ([docs](https://geminicli.com/docs/extensions/reference)).

### hopper-developer

| Server | Service | Auth |
|--------|---------|------|
| `github` | GitHub Copilot | `GITHUB_TOKEN` env var |
| `datadog` | Datadog | Browser |
| `pagerduty` | PagerDuty | `PAGERDUTY_API_TOKEN` env var |
| `gcp-bigquery` | BigQuery | GCP OAuth |
| `gcp-cloud-run` | Cloud Run | GCP OAuth |
| `gcp-cloudsql` | Cloud SQL | GCP OAuth |
| `gcp-compute` | Compute Engine | GCP OAuth |
| `gcp-gke` | GKE | GCP OAuth |
| `gcp-monitoring` | Cloud Monitoring | GCP OAuth |
| `gcp-resource-manager` | Resource Manager | GCP OAuth |
| `gcp-spanner` | Spanner | GCP OAuth |
| `gcp-vertex-ai` | Vertex AI | GCP OAuth |

### hopper-common

| Server | Service | Auth |
|--------|---------|------|
| `slack` | Slack | OAuth |
| `atlassian` | Atlassian (Jira, Confluence) | Browser |

### GitHub token

The `github` MCP server requires `GITHUB_TOKEN` to be set. Add this to your `.zshrc`:

```bash
export GITHUB_TOKEN=$(gh auth token)
```

### PagerDuty API token

The `pagerduty` MCP server requires a [PagerDuty User API token](https://support.pagerduty.com/main/docs/pagerduty-mcp-server-integration-guide#generate-your-pagerduty-api-token). Generate one from **My Profile → User Settings → API Access** in PagerDuty, then add it to your `.zshrc`:

```bash
export PAGERDUTY_API_TOKEN=your-pagerduty-api-token-here
```

## Contributing

All contributions should go to the `master` branch (Claude Code format). Tool-specific branches are auto-generated on merge via GitHub Actions:

| Branch | Tool | Format |
|--------|------|--------|
| `master` / `claude` | Claude Code | `.claude-plugin/` + `plugins/` |
| `cursor` | Cursor | `.cursor-plugin/` + `plugins/` |
| **`gemini`** | **Gemini CLI** | **`gemini-extension.json` per plugin** |
| `opencode` | OpenCode | `.opencode/skills/` + `opencode.json` |
| `codex` | Codex | `.agents/skills/` + `.codex/config.toml` |

See [AGENTS.md](AGENTS.md) on `master` for the full contributor guide.
