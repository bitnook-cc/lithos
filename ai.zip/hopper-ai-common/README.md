# hopper-ai-common

Shared skills and config for AI agents at Hopper.

## Structure

This repo follows the [claude-plugins-official](https://github.com/anthropics/claude-plugins-official) directory structure:

```
plugins/
  hopper-developer/         # Plugin for Hopper developers
    .claude-plugin/
      plugin.json           # Plugin manifest
    .mcp.json               # MCP server configs (GitHub, Datadog, GCP)
    skills/                 # Skills available to Claude Code
      atlantis/
      backstage/
      datadog-config/
      datadog-ops/
      deployment/
      github-actions/
      olympus/
      release-me/
  hopper-scala/               # Scala-specific skills
    .claude-plugin/
      plugin.json           # Plugin manifest
    skills/
      helpers-http-server/
      helpers-play-json/
      type-discovery/
  hopper-common/            # Plugin for shared MCP configs
    .claude-plugin/
      plugin.json           # Plugin manifest
    .mcp.json               # MCP server configs (Slack, Atlassian)
  hopper-developer-workflow/  # Opinionated dev workflow (pre-PR checklist)
    .claude-plugin/
      plugin.json           # Plugin manifest
    skills/
      pull-requests/
```

> **Multi-tool support:** The `master` branch uses Claude Code format. Other branches (`cursor`, etc.) are auto-generated — see [Contributing](#contributing).

## Scope

Skills in this repo should be scoped to an **employee role** (e.g., developer, SRE, product) or **business unit** (e.g., flights, hotels) — not to a single repository. Repo-specific knowledge (build commands, project layout, coding conventions, test strategies) belongs in the repo itself, typically in its own `CLAUDE.md` or `AGENTS.md`.

If you find yourself writing instructions that only apply to one repo, put them there instead.

## Usage

Add the marketplace and install the plugins in Claude Code:

```
/plugin marketplace add hopper-org/hopper-ai-common
/plugin install hopper-developer@hopper-ai-common
/plugin install hopper-scala@hopper-ai-common
/plugin install hopper-common@hopper-ai-common
```

## MCP Servers

### hopper-developer

| Server | Service | Auth |
|--------|---------|------|
| `github` | GitHub Copilot | `GITHUB_TOKEN` env var |
| `datadog` | Datadog | Browser |
| `pagerduty` | PagerDuty | `PAGERDUTY_API_TOKEN` env var |
| `gcp-bigquery` | BigQuery | GCP OAuth |
| `gcp-cloud-run` | Cloud Run | GCP OAuth |
| `gcp-cloudsql` | Cloud SQL | GCP OAuth |
| `gcp-compute` | Compute Engine | GCP OAuth |
| `gcp-gke` | GKE | GCP OAuth |
| `gcp-monitoring` | Cloud Monitoring | GCP OAuth |
| `gcp-resource-manager` | Resource Manager | GCP OAuth |
| `gcp-spanner` | Spanner | GCP OAuth |
| `gcp-vertex-ai` | Vertex AI | GCP OAuth |

### hopper-common

| Server | Service | Auth |
|--------|---------|------|
| `slack` | Slack | OAuth |
| `atlassian` | Atlassian (Jira, Confluence) | Browser |

### GitHub token

The `github` MCP server requires `GITHUB_TOKEN` to be set. Add this to your `.zshrc`:

```bash
export GITHUB_TOKEN=$(gh auth token)
```

### PagerDuty API token

The `pagerduty` MCP server requires a [PagerDuty User API token](https://support.pagerduty.com/main/docs/pagerduty-mcp-server-integration-guide#generate-your-pagerduty-api-token). Generate one from **My Profile → User Settings → API Access** in PagerDuty, then add it to your `.zshrc`:

```bash
export PAGERDUTY_API_TOKEN=your-pagerduty-api-token-here
```

### CI usage

In CI (e.g., GitHub Actions), you can override the plugin's MCP config by passing `--mcp-config` with API key auth:

```json
{
  "mcpServers": {
    "datadog": {
      "type": "http",
      "url": "https://mcp.us5.datadoghq.com/api/unstable/mcp-server/mcp",
      "headers": {
        "DD-API-KEY": "$DD_API_KEY",
        "DD-APPLICATION-KEY": "$DD_APP_KEY"
      }
    }
  }
}
```

## Contributing

All contributions go to `master` (Claude Code format). Tool-specific branches are auto-generated on merge via GitHub Actions:

| Branch | Tool | Format |
|--------|------|--------|
| `master` / `claude` | Claude Code | `.claude-plugin/` + `plugins/` |
| `cursor` | Cursor | `.cursor-plugin/` + `plugins/` |
| `gemini` | Gemini CLI | `gemini-extension.json` per plugin |
| `opencode` | OpenCode | `.opencode/skills/` + `opencode.json` |
| `codex` | Codex | `.agents/skills/` + `.codex/config.toml` |

See [AGENTS.md](AGENTS.md) for the full contributor guide.
