# Home-manager module for hopper-ai-common OpenCode integration.
#
# Automatically discovers plugins and skills from the repository source tree,
# converts MCP server configurations from Claude Code format to OpenCode format,
# and injects them into the programs.opencode home-manager module.
#
# Usage (in your home-manager config):
#
#   imports = [ inputs.hopper-ai-common.homeManagerModules.opencode ];
#
#   programs.hopper-ai.opencode = {
#     enable = true;
#     plugins = [ "hopper-developer" "hopper-scala" "hopper-common" ];
#   };
self:
{
  lib,
  config,
  ...
}:
let
  inherit (lib)
    mkEnableOption
    mkIf
    mkOption
    types
    ;

  cfg = config.programs.hopper-ai.opencode;

  # ---------------------------------------------------------------------------
  # Auto-discovery helpers
  # ---------------------------------------------------------------------------

  # Discover all plugin directories under plugins/
  pluginEntries = builtins.readDir "${self}/plugins";
  availablePlugins = builtins.filter (name: pluginEntries.${name} == "directory") (
    builtins.attrNames pluginEntries
  );

  # Discover skill directories for a given plugin.
  # Returns an attrset: { "<plugin>/<skill>" = <store-path>; ... }
  discoverSkills =
    pluginName:
    let
      skillsDir = "${self}/plugins/${pluginName}/skills";
      hasSkills = builtins.pathExists skillsDir;
      entries = if hasSkills then builtins.readDir skillsDir else { };
      skillNames = builtins.filter (
        name: entries.${name} == "directory" && builtins.pathExists "${skillsDir}/${name}/SKILL.md"
      ) (builtins.attrNames entries);
    in
    builtins.listToAttrs (
      map (skill: {
        name = "${pluginName}/${skill}";
        value = "${self}/plugins/${pluginName}/skills/${skill}";
      }) skillNames
    );

  # ---------------------------------------------------------------------------
  # MCP server conversion (Claude Code format -> OpenCode format)
  # ---------------------------------------------------------------------------

  # Read OAuth overrides from the repo (scripts/mcp-overrides/opencode.json)
  oauthOverridesFile = "${self}/scripts/mcp-overrides/opencode.json";
  oauthOverrides =
    if builtins.pathExists oauthOverridesFile then
      builtins.fromJSON (builtins.readFile oauthOverridesFile)
    else
      { };

  # Convert environment variable syntax in header values: ${VAR} -> {env:VAR}
  # Uses builtins.match to extract variable names from actual values, then
  # applies builtins.replaceStrings with the concrete patterns found.
  convertHeaders =
    headers:
    let
      values = builtins.attrValues headers;
      extractVar =
        v:
        let
          m = builtins.match ".*[$][{]([^}]+)[}].*" v;
        in
        if m != null then builtins.head m else null;
      vars = builtins.filter (v: v != null) (map extractVar values);
      from = map (v: "\${${v}}") vars;
      to = map (v: "{env:${v}}") vars;
    in
    builtins.mapAttrs (_: builtins.replaceStrings from to) headers;

  # Transform a single MCP server entry from Claude to OpenCode format
  transformServer =
    serverName: server:
    let
      # Type mapping: stdio -> local, http/sse -> remote
      mappedType = if server.type or "" == "stdio" then "local" else "remote";

      # Transform headers: convert env var syntax
      transformedHeaders = if server ? headers then { headers = convertHeaders server.headers; } else { };

      # OAuth: apply overrides if available, otherwise strip callbackPort.
      # The overrides file has structure { "server": { "oauth": { ... } } },
      # so oauthOverrides.${serverName} is already { oauth = { ... }; }.
      transformedOAuth =
        if oauthOverrides ? ${serverName} then
          oauthOverrides.${serverName}
        else if server ? oauth then
          { oauth = removeAttrs server.oauth [ "callbackPort" ]; }
        else
          { };
    in
    {
      enabled = true;
      type = mappedType;
    }
    // (lib.optionalAttrs (server ? url) { inherit (server) url; })
    // (lib.optionalAttrs (server ? command) { inherit (server) command; })
    // (lib.optionalAttrs (server ? args) { inherit (server) args; })
    // transformedHeaders
    // transformedOAuth;

  # Read and transform MCP servers for a given plugin.
  # Returns an attrset: { "<server-name>" = { ... }; ... }
  discoverMcp =
    pluginName:
    let
      mcpFile = "${self}/plugins/${pluginName}/.mcp.json";
      hasMcp = builtins.pathExists mcpFile;
      mcpJson = if hasMcp then builtins.fromJSON (builtins.readFile mcpFile) else { };
      servers = mcpJson.mcpServers or { };
    in
    builtins.mapAttrs transformServer servers;

  # ---------------------------------------------------------------------------
  # Aggregation across selected plugins
  # ---------------------------------------------------------------------------

  allSkills = builtins.foldl' (acc: plugin: acc // discoverSkills plugin) { } cfg.plugins;
  allMcpServers = builtins.foldl' (acc: plugin: acc // discoverMcp plugin) { } cfg.plugins;

in
{
  options.programs.hopper-ai.opencode = {
    enable = mkEnableOption "hopper-ai-common OpenCode integration";

    plugins = mkOption {
      type = types.listOf (types.enum availablePlugins);
      default = availablePlugins;
      description = ''
        Which hopper-ai-common plugins to install.
        Available: ${builtins.concatStringsSep ", " availablePlugins}.
        Defaults to all available plugins.
      '';
    };

    installPlugin = mkOption {
      type = types.bool;
      default = true;
      description = ''
        Whether to install the hopper-ai-common JavaScript plugin that
        injects a system prompt listing available Hopper skills.
      '';
    };
  };

  config = mkIf cfg.enable {
    programs.opencode = {
      settings.mcp = allMcpServers;
      skills = allSkills;
    };

    xdg.configFile = mkIf cfg.installPlugin {
      "opencode/plugins/hopper-ai-common.js" = {
        source = "${self}/.opencode/plugins/hopper-ai-common.js";
      };
    };
  };
}
