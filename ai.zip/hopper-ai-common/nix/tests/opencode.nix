# Tests for the hopper-ai-common OpenCode home-manager module.
#
# Evaluates the module through home-manager's module system and asserts that
# plugin/skill auto-discovery and MCP server conversion produce correct results.
{
  self,
  pkgs,
  home-manager,
}:
let
  jq = "${pkgs.jq}/bin/jq";

  # Evaluate the home-manager module with the given plugin selection.
  evalModule =
    {
      plugins ? null,
    }:
    (home-manager.lib.homeManagerConfiguration {
      inherit pkgs;
      modules = [
        self.homeModules.opencode
        {
          home.username = "test";
          home.homeDirectory = if pkgs.stdenv.isDarwin then "/Users/test" else "/home/test";
          home.stateVersion = "25.11";
          programs.opencode.enable = true;
          programs.hopper-ai.opencode = {
            enable = true;
          }
          // (if plugins != null then { inherit plugins; } else { });
        }
      ];
    }).config;

  allPluginsConfig = builtins.toJSON (evalModule { }).programs.opencode;
  subsetConfig = builtins.toJSON (evalModule { plugins = [ "hopper-developer" ]; }).programs.opencode;
in
{
  # Verify module evaluates with all plugins and produces correct output.
  opencode-all-plugins = pkgs.runCommand "check-opencode-all-plugins" { } ''
    config='${allPluginsConfig}'

    # Skills were discovered (non-empty)
    count=$(echo "$config" | ${jq} '.skills | keys | length')
    test "$count" -gt 0 || { echo "FAIL: no skills discovered (got $count)"; exit 1; }
    echo "PASS: discovered $count skills"

    # All expected MCP servers are present
    for server in github datadog slack atlassian; do
      echo "$config" | ${jq} -e ".settings.mcp.$server" > /dev/null \
        || { echo "FAIL: MCP server '$server' not found"; exit 1; }
      echo "PASS: MCP server '$server' present"
    done

    # No unconverted "http" or "sse" types remain
    bad=$(echo "$config" | ${jq} '[.settings.mcp[].type] | map(select(. == "http" or . == "sse")) | length')
    test "$bad" = "0" || { echo "FAIL: $bad unconverted type(s) found"; exit 1; }
    echo "PASS: all MCP types converted"

    # Env var syntax converted in github headers: {env:...} not ''${...}
    auth=$(echo "$config" | ${jq} -r '.settings.mcp.github.headers.Authorization')
    case "$auth" in
      *'{env:'*) echo "PASS: env var syntax converted ($auth)" ;;
      *) echo "FAIL: env var not converted: $auth"; exit 1 ;;
    esac

    # Slack OAuth override applied (no callbackPort, has clientSecret)
    echo "$config" | ${jq} -e '.settings.mcp.slack.oauth.clientSecret' > /dev/null \
      || { echo "FAIL: Slack OAuth override not applied"; exit 1; }
    if echo "$config" | ${jq} -e '.settings.mcp.slack.oauth.callbackPort' > /dev/null 2>&1; then
      echo "FAIL: callbackPort should have been stripped from Slack OAuth"
      exit 1
    fi
    echo "PASS: Slack OAuth override applied correctly"

    echo "All checks passed"
    touch $out
  '';

  # Verify plugin selection filters skills and MCP servers correctly.
  opencode-plugin-selection = pkgs.runCommand "check-opencode-plugin-selection" { } ''
    config='${subsetConfig}'

    # hopper-developer skills should be present
    echo "$config" | ${jq} -e '.skills["hopper-developer/atlantis"]' > /dev/null \
      || { echo "FAIL: hopper-developer/atlantis skill not found"; exit 1; }
    echo "PASS: hopper-developer skills present"

    # hopper-developer MCP servers should be present
    echo "$config" | ${jq} -e '.settings.mcp.github' > /dev/null \
      || { echo "FAIL: github MCP server not found"; exit 1; }
    echo "PASS: hopper-developer MCP servers present"

    # hopper-common MCP servers should NOT be present
    if echo "$config" | ${jq} -e '.settings.mcp.slack' > /dev/null 2>&1; then
      echo "FAIL: slack MCP should not be present with only hopper-developer"
      exit 1
    fi
    echo "PASS: hopper-common MCP servers correctly excluded"

    # No skills from other plugins should be present
    other=$(echo "$config" | ${jq} '[.skills | keys[] | select(startswith("hopper-developer/") | not)] | length')
    test "$other" = "0" \
      || { echo "FAIL: found $other skill(s) from non-selected plugins"; exit 1; }
    echo "PASS: only selected plugin skills present"

    echo "All checks passed"
    touch $out
  '';
}
