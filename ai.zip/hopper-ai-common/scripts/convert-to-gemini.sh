#!/usr/bin/env bash
# Converts the Claude Code plugin format to Gemini CLI extension format in-place.
# Each plugin becomes a standalone Gemini extension with its own gemini-extension.json.
# Intended to run on a clean working tree (e.g. in CI after checkout).
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$REPO_ROOT"

for plugin_dir in plugins/*/; do
  plugin_name="$(basename "$plugin_dir")"

  # Start building gemini-extension.json from plugin.json metadata
  plugin_json="$plugin_dir/.claude-plugin/plugin.json"
  if [ ! -f "$plugin_json" ]; then
    continue
  fi

  # Build gemini-extension.json with name, version, description
  manifest=$(jq '{
    name: .name,
    version: (.version // "1.0.0"),
    description: (.description // "")
  }' "$plugin_json")

  # Inline MCP servers from .mcp.json if present
  # Strip Claude-specific fields: "type" and "oauth" (Gemini uses url-only format)
  mcp_file="$plugin_dir/.mcp.json"
  if [ -f "$mcp_file" ] && command -v jq &>/dev/null; then
    servers=$(jq '.mcpServers // {} | to_entries | map(
      .value = (.value | del(.type, .oauth))
    ) | from_entries' "$mcp_file")
    manifest=$(echo "$manifest" | jq --argjson s "$servers" '. + {mcpServers: $s}')
    rm "$mcp_file"
  fi

  # Write gemini-extension.json
  echo "$manifest" | jq '.' > "$plugin_dir/gemini-extension.json"

  # Remove Claude plugin metadata
  rm -rf "$plugin_dir/.claude-plugin"
done

# Remove top-level Claude marketplace manifest
rm -rf .claude-plugin

# Point README.md symlink to Gemini version
if [ -L "README.md" ] && [ -f "docs/README_GEMINI.md" ]; then
  ln -sf docs/README_GEMINI.md README.md
fi

echo "Conversion to Gemini CLI format complete."
