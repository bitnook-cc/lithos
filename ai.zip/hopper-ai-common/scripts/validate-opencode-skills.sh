#!/usr/bin/env bash
# Validates that OpenCode discovers all converted skills.
#
# 1. Enumerates expected skills from .opencode/skills/ on the filesystem
# 2. Asks OpenCode (via LLM) to list the skills it sees
# 3. Compares: every filesystem skill must appear in the LLM output
#
# Also implicitly validates that the plugin
# (.opencode/plugins/hopper-ai-common.js) loads without errors,
# since it injects skill names into the system prompt at startup.
#
# Usage: validate-opencode-skills.sh <converted-dir> <model>
#   converted-dir: path where .opencode/skills/ lives (post-conversion)
#   model:         model ID for opencode run
#                  (e.g. google-vertex-anthropic/claude-haiku-4-5@20251001)
#
# When $GITHUB_STEP_SUMMARY is set, results are also written there.
set -euo pipefail

if [[ $# -lt 2 ]]; then
  echo "Usage: $0 <converted-dir> <model>"
  exit 1
fi

converted_dir="$1"
model="$2"

cd "$converted_dir"

# --- 1. Build the expected skill list from the filesystem ---
# Mirrors the plugin's getSkillNames() logic: leaf directory names
# that contain a SKILL.md, whether direct children or nested under
# a plugin-group folder.

expected=()
for entry in .opencode/skills/*/; do
  [[ -d "$entry" ]] || continue
  if [[ -f "$entry/SKILL.md" ]]; then
    expected+=("$(basename "$entry")")
  else
    for child in "$entry"/*/; do
      [[ -f "$child/SKILL.md" ]] && expected+=("$(basename "$child")")
    done
  fi
done

if [[ ${#expected[@]} -eq 0 ]]; then
  echo "ERROR: No skills found on filesystem under .opencode/skills/"
  exit 1
fi

printf '%s\n' "${expected[@]}" | sort > /tmp/expected-skills.txt
echo "Expected skills (${#expected[@]}):"
cat /tmp/expected-skills.txt

# --- 2. Ask OpenCode to list the skills it sees ---
# Use --format json to get structured NDJSON, then extract only the
# model's text response (type=="text").

echo ""
echo "Querying OpenCode with model: $model"

opencode run \
  "List the names of skills from the <available_skills> section verbatim, one per line, no other text, no alteration to the names." \
  --model "$model" \
  --format json \
  > /tmp/skills-raw.json 2>/dev/null || true

jq -r 'select(.type == "text") | .part.text' /tmp/skills-raw.json \
  > /tmp/skills-llm-raw.txt

echo ""
echo "LLM response:"
cat /tmp/skills-llm-raw.txt

# --- 3. Compare: every expected skill must appear in the LLM output ---

missing=()
for skill in "${expected[@]}"; do
  if ! grep -qi "$skill" /tmp/skills-llm-raw.txt; then
    missing+=("$skill")
  fi
done

echo ""
if [[ ${#missing[@]} -eq 0 ]]; then
  echo "All ${#expected[@]} skills discovered successfully."
else
  echo "ERROR: ${#missing[@]} skill(s) not discovered: ${missing[*]}"
fi

# --- 4. Write to job summary (GHA only) ---

if [[ -n "${GITHUB_STEP_SUMMARY:-}" ]]; then
  {
    echo "### Skill Discovery"
    echo ""
    echo "**Expected skills (${#expected[@]}):** ${expected[*]}"
    echo ""
    if [[ ${#missing[@]} -gt 0 ]]; then
      echo "> **Missing skills (${#missing[@]}):** ${missing[*]}"
    else
      echo "All ${#expected[@]} skills discovered successfully."
    fi
    echo ""
    echo "<details>"
    echo "<summary>LLM response</summary>"
    echo ""
    cat /tmp/skills-llm-raw.txt
    echo ""
    echo "</details>"
  } >> "$GITHUB_STEP_SUMMARY"
fi

# --- 5. Exit ---

if [[ ${#missing[@]} -gt 0 ]]; then
  echo ""
  echo "Raw JSON output:"
  cat /tmp/skills-raw.json
  exit 1
fi
