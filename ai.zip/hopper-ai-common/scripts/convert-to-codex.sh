#!/usr/bin/env bash
# Converts the Claude Code plugin format to Codex format in-place.
# Intended to run on a clean working tree (e.g. in CI after checkout).
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$REPO_ROOT"

# 1. Flatten all skills from plugins/*/skills/ into .agents/skills/
mkdir -p .agents/skills
for skill_dir in plugins/*/skills/*/; do
  skill_name="$(basename "$skill_dir")"
  if [ -f "$skill_dir/SKILL.md" ]; then
    cp -r "$skill_dir" ".agents/skills/$skill_name"
  fi
done

# 2. Merge all .mcp.json files into .codex/config.toml
#    Codex uses TOML format with [mcp_servers.<name>] sections
#    OAuth is handled at runtime via `codex mcp login`, so client IDs are dropped
mkdir -p .codex
config_toml=".codex/config.toml"
: > "$config_toml"

if command -v jq &>/dev/null; then
  for mcp_file in plugins/*/.mcp.json; do
    if [ -f "$mcp_file" ]; then
      jq -r '.mcpServers // {} | to_entries[] | @json' "$mcp_file" | while read -r entry; do
        name=$(echo "$entry" | jq -r '.key')
        url=$(echo "$entry" | jq -r '.value.url')

        echo "" >> "$config_toml"
        echo "[mcp_servers.\"$name\"]" >> "$config_toml"
        echo "url = \"$url\"" >> "$config_toml"

        # Convert Authorization Bearer header to bearer_token_env_var
        bearer_header=$(echo "$entry" | jq -r '.value.headers.Authorization // empty')
        if [[ "$bearer_header" == *'${GITHUB_TOKEN}'* ]]; then
          echo 'bearer_token_env_var = "GITHUB_TOKEN"' >> "$config_toml"
        fi

        # Convert other headers to http_headers (skip Authorization if handled above)
        other_headers=$(echo "$entry" | jq -r '
          .value.headers // {} | to_entries
          | map(select(.key != "Authorization"))
          | map("\"" + .key + "\" = \"" + .value + "\"")
          | join(", ")
        ')
        if [ -n "$other_headers" ]; then
          echo "http_headers = { $other_headers }" >> "$config_toml"
        fi
      done
    fi
  done
fi

# 3. Remove Claude plugin structure (not used by Codex)
rm -rf .claude-plugin plugins

# 4. Point README.md symlink to Codex version
if [ -L "README.md" ] && [ -f "docs/README_CODEX.md" ]; then
  ln -sf docs/README_CODEX.md README.md
fi

echo "Conversion to Codex format complete."
