#!/usr/bin/env bash
# Converts the Claude Code plugin format to OpenCode format in-place.
# Intended to run on a clean working tree (e.g. in CI after checkout).
#
# This script:
# - Copies skills from plugins/*/skills/ into .opencode/skills/<plugin>/
# - Merges all .mcp.json files into opencode.json with proper OpenCode formatting
# - Converts type mappings: stdio→local, sse/http→remote
# - Transforms environment variable syntax: ${VAR} → {env:VAR}
# - Applies tool-specific OAuth overrides from mcp-overrides/opencode.json
# - Removes Claude-specific structure
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$REPO_ROOT"

# Source shared MCP utilities
# shellcheck source=./scripts/mcp-utils.sh
source "$(dirname "$0")/mcp-utils.sh"

# 1. Copy skills from plugins/*/skills/ into .opencode/skills/<plugin>/
mkdir -p .opencode/skills
for plugin_dir in plugins/*/; do
  plugin_name="$(basename "$plugin_dir")"
  if [[ -d "$plugin_dir/skills" ]]; then
    for skill_dir in "$plugin_dir"/skills/*/; do
      [[ -f "$skill_dir/SKILL.md" ]] || continue
      mkdir -p ".opencode/skills/$plugin_name"
      cp -r "$skill_dir" ".opencode/skills/$plugin_name/"
    done
  fi
done

# 2. Merge all .mcp.json files into opencode.json
#    Convert Claude format to OpenCode format:
#    - "type": "stdio" → "type": "local"
#    - "type": "sse" or "http" → "type": "remote"
#    - Transform headers: ${VAR} → {env:VAR}
#    - Strip callbackPort from oauth blocks
#    - Apply OAuth overrides from mcp-overrides/opencode.json
if command -v jq &> /dev/null; then
  # Load OAuth overrides for this tool
  oauth_overrides=$(load_mcp_oauth_overrides "opencode")
  
  # Start with schema and empty mcp object
  merged='{"$schema":"https://opencode.ai/config.json","enabled_providers":["google-vertex","github-copilot","google-vertex-anthropic"],"share":"disabled","mcp":{}}'
  
  # Process each .mcp.json file
  for mcp_file in plugins/*/.mcp.json; do
    if [[ -f "$mcp_file" ]]; then
      # Write overrides to a temporary file for jq slurp
      overrides_file=$(mktemp -t opencode-mcp-overrides.XXXXXX 2>/dev/null || mktemp)
      echo "$oauth_overrides" > "$overrides_file"
      
      # Use a jq filter that properly handles regex, type mapping, and OAuth overrides
      # shellcheck disable=SC2016
      servers=$(jq \
        --slurpfile overrides_obj "$overrides_file" '
        # Process the MCP servers from the file
        (.mcpServers // {}) | 
        to_entries | 
        map(
          # All transforms inside a single |= to avoid scoping issues with del
          .value |= (
            # Map type: stdio→local, sse/http→remote
            (if .type == "stdio" then .type = "local"
             elif .type == "sse" or .type == "http" then .type = "remote"
             else . end) |
            # Transform environment variables in headers: ${VAR} → {env:VAR}
            (if .headers then
              .headers |= map_values(gsub("\\$\\{(?<var>[^}]+)\\}"; "{env:\(.var)}"))
            else . end) |
            # Strip callbackPort from oauth blocks
            (if .oauth then del(.oauth.callbackPort) else . end)
          )
        ) | 
        from_entries |
        # Apply OAuth overrides: replace oauth block for servers in overrides
        . as $servers |
        reduce ($overrides_obj[0] | keys[]) as $server ($servers;
          if .[$server] then
            .[$server].oauth = $overrides_obj[0][$server].oauth
          else . end
        )
      ' "$mcp_file")
      
      # Clean up temp file
      rm -f "$overrides_file"
      
      merged=$(echo "$merged" | jq --argjson s "$servers" '.mcp += $s')
    fi
  done
  
  echo "$merged" | jq '.' > opencode.json
fi

# 3. Remove Claude plugin structure (not used by OpenCode)
rm -rf .claude-plugin plugins

# 4. Point README.md symlink to OpenCode version
if [[ -L "README.md" ]] && [[ -f "docs/README_OPENCODE.md" ]]; then
  ln -sf docs/README_OPENCODE.md README.md
fi

echo "Conversion to OpenCode format complete."
