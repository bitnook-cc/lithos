#!/usr/bin/env bash
# Validates the converted OpenCode configuration against the source plugins.
#
# 1. Checks opencode.json has required fields ($schema, mcp)
# 2. Runs "opencode mcp list" to confirm OpenCode loaded the config
# 3. Compares the server list against source plugins/*/.mcp.json
#    — every source server must appear in the opencode mcp list output
#
# Also implicitly validates the entire opencode.json config (schema,
# providers, plugins, etc.); MCP servers are the part that changes
# across PRs.
#
# Usage: validate-opencode-config.sh <converted-dir> <source-dir>
#   converted-dir: path where opencode.json lives (post-conversion)
#   source-dir:    path to the original checkout (plugins/*/.mcp.json)
#
# When $GITHUB_STEP_SUMMARY is set, results are also written there.
set -euo pipefail

if [[ $# -lt 2 ]]; then
  echo "Usage: $0 <converted-dir> <source-dir>"
  exit 1
fi

converted_dir="$1"
source_dir="$2"

cd "$converted_dir"

# --- 1. Check opencode.json structure ---

if [[ ! -f opencode.json ]]; then
  echo "ERROR: opencode.json not found in $converted_dir"
  exit 1
fi

if ! jq -e '."$schema"' opencode.json > /dev/null 2>&1; then
  echo "ERROR: Missing required \$schema field in opencode.json"
  exit 1
fi

if ! jq -e '.mcp' opencode.json > /dev/null 2>&1; then
  echo "ERROR: Missing required mcp field in opencode.json"
  exit 1
fi

echo "opencode.json structure OK"

# --- 2. Run opencode mcp list ---
# Servers won't connect in CI (no auth), so we allow non-zero exit.
# We only care that OpenCode recognizes the servers.

if opencode mcp list > /tmp/mcp-list.txt 2>&1; then
  true  # all servers connected (unlikely in CI)
fi

# Print to console (with colors)
cat /tmp/mcp-list.txt

# Strip ANSI escape codes for parsing
sed 's/\x1B\[[0-9;]*[mK]//g' /tmp/mcp-list.txt > /tmp/mcp-list-clean.txt

# --- 3. Build expected server list from source plugins ---

jq -r '.mcpServers | keys[]' "$source_dir"/plugins/*/.mcp.json 2>/dev/null \
  | sort -u > /tmp/expected-mcp-servers.txt

expected_count=$(wc -l < /tmp/expected-mcp-servers.txt | tr -d ' ')

if [[ "$expected_count" -eq 0 ]]; then
  echo "ERROR: No MCP servers found in source plugins/*/.mcp.json"
  exit 1
fi

echo ""
echo "Expected MCP servers ($expected_count):"
cat /tmp/expected-mcp-servers.txt

# --- 4. Extract actual server names from opencode mcp list ---
# Output lines look like (after ANSI strip):
#   ●  ✓ servername connected
#   ●  ⚠ servername needs authentication
#   ●  ✗ servername failed
# We match lines containing a known status keyword and extract the
# word immediately before it (which is always the server name).

awk '/connected|needs authentication|failed/ {
  for (i = 1; i <= NF; i++) {
    if ($i == "connected" || $i == "needs" || $i == "failed") {
      print $(i-1)
      break
    }
  }
}' /tmp/mcp-list-clean.txt | sort -u > /tmp/actual-mcp-servers.txt

actual_count=$(wc -l < /tmp/actual-mcp-servers.txt | tr -d ' ')

echo ""
echo "Actual MCP servers ($actual_count):"
cat /tmp/actual-mcp-servers.txt

# --- 5. Compare: every expected server must appear in actual ---

missing=()
while IFS= read -r server; do
  if ! grep -qx "$server" /tmp/actual-mcp-servers.txt; then
    missing+=("$server")
  fi
done < /tmp/expected-mcp-servers.txt

echo ""
if [[ ${#missing[@]} -eq 0 ]]; then
  echo "All $expected_count MCP servers discovered successfully."
else
  echo "ERROR: ${#missing[@]} MCP server(s) not discovered: ${missing[*]}"
fi

# --- 6. Write to job summary (GHA only) ---

if [[ -n "${GITHUB_STEP_SUMMARY:-}" ]]; then
  {
    echo "### Configuration Validation"
    echo ""
    echo "**Expected MCP servers ($expected_count):** $(paste -sd', ' /tmp/expected-mcp-servers.txt)"
    echo ""
    echo "**Discovered MCP servers ($actual_count):** $(paste -sd', ' /tmp/actual-mcp-servers.txt)"
    echo ""
    if [[ ${#missing[@]} -gt 0 ]]; then
      echo "> **Missing servers (${#missing[@]}):** ${missing[*]}"
    else
      echo "All $expected_count MCP servers discovered successfully."
    fi
    echo ""
    echo "<details>"
    echo "<summary><code>opencode mcp list</code> output</summary>"
    echo ""
    echo '```'
    cat /tmp/mcp-list-clean.txt
    echo '```'
    echo ""
    echo "</details>"
  } >> "$GITHUB_STEP_SUMMARY"
fi

# --- 7. Exit ---

if [[ ${#missing[@]} -gt 0 ]]; then
  exit 1
fi
