#!/usr/bin/env bash
# Converts the Claude Code plugin format to Cursor plugin format in-place.
# Intended to run on a clean working tree (e.g. in CI after checkout).
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$REPO_ROOT"

# 1. Rename .claude-plugin/ directories to .cursor-plugin/
find . -type d -name '.claude-plugin' | while read -r dir; do
  target="$(dirname "$dir")/.cursor-plugin"
  mv "$dir" "$target"
done

# 2. Strip Claude-specific fields from marketplace.json
if command -v jq &>/dev/null; then
  marketplace=".cursor-plugin/marketplace.json"
  if [ -f "$marketplace" ]; then
    jq 'del(."$schema") | .plugins = [.plugins[] | del(.category)]' "$marketplace" > "$marketplace.tmp"
    mv "$marketplace.tmp" "$marketplace"
  fi
fi

# 3. Convert Slack MCP config from Claude format to Cursor format
#    Claude:  { "type": "http", "url": "...", "oauth": { "clientId": "...", "callbackPort": ... } }
#    Cursor:  { "url": "...", "auth": { "CLIENT_ID": "..." } }
CURSOR_SLACK_CLIENT_ID="3660753192626.8903469228982"
if command -v jq &>/dev/null; then
  for mcp_file in plugins/*/.mcp.json; do
    if [ -f "$mcp_file" ] && jq -e '.mcpServers.slack' "$mcp_file" &>/dev/null; then
      jq --arg cid "$CURSOR_SLACK_CLIENT_ID" '
        .mcpServers.slack = {
          url: .mcpServers.slack.url,
          auth: { CLIENT_ID: $cid }
        }
      ' "$mcp_file" > "$mcp_file.tmp"
      mv "$mcp_file.tmp" "$mcp_file"
    fi
  done
fi

# 4. Point README.md symlink to Cursor version
if [ -L "README.md" ] && [ -f "docs/README_CURSOR.md" ]; then
  ln -sf docs/README_CURSOR.md README.md
fi

echo "Conversion to Cursor format complete."
