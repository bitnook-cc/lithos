#!/usr/bin/env bash
# Shared utilities for MCP server conversion across multiple tool formats.
# Provides functions to load and apply tool-specific OAuth overrides.

set -euo pipefail

# Load OAuth overrides from tool-specific override file.
# 
# Usage: load_mcp_oauth_overrides "opencode"
#
# Returns: JSON object with structure { "serverName": { "oauth": {...} }, ... }
#          Returns {} if override file doesn't exist
#
# Arguments:
#   $1: tool_name - name of the tool (e.g., "opencode", "cursor", "codex", "gemini")
load_mcp_oauth_overrides() {
  local tool_name="$1"
  local overrides_file
  
  # Get the directory where this script is located (handles sourcing correctly)
  overrides_file="$(dirname "${BASH_SOURCE[0]}")/mcp-overrides/${tool_name}.json"
  
  if [[ -f "$overrides_file" ]]; then
    cat "$overrides_file"
  else
    echo "{}"
  fi
}
