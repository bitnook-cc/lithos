## What
<!-- Brief description of the change -->

## Type
- [ ] New plugin
- [ ] New skill
- [ ] Skill modification
- [ ] MCP server configuration
- [ ] Other

## Checklist

### All changes
- [ ] PR title uses conventional commits (`feat:`, `fix:`, `chore:`, etc.)
- [ ] Changes are scoped to a role/business unit, not a single repo

### New plugin
- [ ] Added plugin directory with `plugin.json` and `.mcp.json` or `skills/`
- [ ] Added entry to `/.claude-plugin/marketplace.json`
- [ ] Added package to `release-me-config.json`
- [ ] Added CODEOWNERS entry for the plugin directory

### New or modified skill
- [ ] `SKILL.md` has trigger-based description ("Use when...")
- [ ] Tested by at least 2 people in different contexts
- [ ] Skill is focused on one concern (not a catch-all)
- [ ] Large reference material is in `references/` subdirectory, not inlined
- [ ] Considered context impact — description is concise and specific
