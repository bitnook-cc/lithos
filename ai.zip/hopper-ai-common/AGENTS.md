# AGENTS.md

This document describes the structure and contribution guidelines for `hopper-ai-common`, a Claude Code plugin repository providing shared skills for Hopper developers.

For full documentation on the Claude Code plugins system, see the [Plugins Reference](https://code.claude.com/docs/en/plugins-reference).

## Repository Structure

```
plugins/
  hopper-developer/               # Plugin: shared skills for Hopper developers
    .claude-plugin/
      plugin.json                  # Plugin manifest (name, description, author)
    .mcp.json                      # MCP server configs (GitHub, Datadog)
    skills/                        # Skills (Claude auto-invokes based on context)
      atlantis/SKILL.md            # Atlantis CI for Terraform workflows
      backstage/SKILL.md           # Backstage catalog onboarding
      datadog-config/SKILL.md      # Datadog monitors, SLOs & instrumentation (Arecibo)
      datadog-ops/SKILL.md         # Datadog investigation & debugging
      deployment/SKILL.md          # rules_hopper & Harness CI/CD
      github-actions/SKILL.md      # GitHub Actions workflows & CI/CD
      olympus/SKILL.md             # GCP infrastructure as code (Olympus)
      release-me/SKILL.md          # Semantic versioning & release automation
      service-discovery/SKILL.md   # Hopper service/lib/repo discovery
  hopper-scala/                    # Plugin: Scala-specific skills
    .claude-plugin/
      plugin.json                  # Plugin manifest (name, description, author)
    skills/
      helpers-http-server/SKILL.md # Finatra HTTP controller patterns
      helpers-play-json/SKILL.md   # Play JSON serialization patterns
      state-machines/SKILL.md      # State machine patterns
      type-discovery/SKILL.md      # Scala type resolution across repos
  hopper-flights/                  # Plugin: Flights team skills
    .claude-plugin/
      plugin.json                  # Plugin manifest (name, description, author)
  hopper-common/                   # Plugin: shared MCP server configs
    .claude-plugin/
      plugin.json                  # Plugin manifest (name, description, author)
    .mcp.json                      # MCP server configs (Slack, Atlassian)
.claude-plugin/
  marketplace.json                 # Top-level marketplace manifest
```

## How Skills Work

Each skill is a Markdown file (`SKILL.md`) with YAML frontmatter:

```yaml
---
name: skill-name
description: "When to trigger this skill — Claude uses this to decide relevance."
---
```

The `description` field is critical — it tells Claude when to activate the skill. Write it as a trigger condition, not a summary. Include concrete scenarios, tool names, and repo names that should activate it.

The body of the skill contains instructions, examples, and reference material that Claude receives when the skill is triggered.

### References

Skills can include supplementary files in a `references/` subdirectory alongside the `SKILL.md`. Reference these from the skill body using relative links:

```markdown
See [Blueprint Reference](references/blueprint-reference.md) for details.
```

### Skill Cross-References

When referencing another skill from within a skill file, use qualified names — not relative file paths.

**Correct:**
```markdown
See the [release-me skill](hopper-developer:release-me) for details.
```

**Wrong:**
```markdown
See the [release-me skill](../release-me/SKILL.md) for details.
```

Format: `plugin-name:skill-name` (e.g., `hopper-developer:release-me`, `hopper-developer:deployment`).

## Scope

Skills in this repo must be scoped to an **employee role** (e.g., developer, SRE, product) or **business unit** (e.g., flights, hotels) — not to a single repository.

Repo-specific knowledge does not belong here. Things like build commands, project layout, module structure, coding conventions, and test strategies should be encoded in the repo itself (via `CLAUDE.md`, `AGENTS.md`, or similar). A skill in this plugin should provide guidance that applies broadly across multiple repos or teams.

**Rule of thumb:** if the instruction only makes sense inside one repo, it belongs in that repo's `CLAUDE.md` or `AGENTS.md`, not in a shared skill here.

## Multi-Tool Branches

The `master` branch is the source of truth and uses Claude Code format. On merge to master, GitHub Actions workflows convert the codebase and push to tool-specific branches:

| Branch | Tool | Format | Workflow |
|--------|------|--------|----------|
| `master` / `claude` | Claude Code | `.claude-plugin/` + `plugins/` | Source of truth |
| `cursor` | Cursor | `.cursor-plugin/` + `plugins/` | `sync-cursor.yml` |
| `gemini` | Gemini CLI | `gemini-extension.json` per plugin | `sync-gemini.yml` |
| `opencode` | OpenCode | `.opencode/skills/` + `opencode.json` | `sync-opencode.yml` |
| `codex` | Codex | `.agents/skills/` | `sync-codex.yml` |

Conversion scripts live in `scripts/` (e.g., `convert-to-cursor.sh`). Each README variant lives in `docs/` (e.g., `docs/README_CURSOR.md`), and `README.md` is a symlink swapped per branch.

**Do not commit directly to tool-specific branches** — they are overwritten on every merge to master.

## Contributing

For governance guidelines, plugin types, quality requirements, and the PR process, see [CONTRIBUTING.md](CONTRIBUTING.md).

The sections below cover the technical details of adding plugins and skills.

### Adding a New Plugin

Every plugin requires these files — **all three are mandatory**:

1. **`plugins/<plugin-name>/.claude-plugin/plugin.json`** — plugin metadata:
   ```json
   {
     "name": "<plugin-name>",
     "description": "Short description",
     "author": { "name": "Hopper" }
   }
   ```

2. **`.claude-plugin/marketplace.json`** — add an entry to the `plugins` array:
   ```json
   {
     "name": "<plugin-name>",
     "description": "Short description",
     "source": "./plugins/<plugin-name>",
     "category": "development"
   }
   ```

3. **`plugins/<plugin-name>/.mcp.json`** and/or **`plugins/<plugin-name>/skills/`** — the plugin must provide at least one of MCP server configs or skills.

### Adding a New Skill

1. Create a directory under `plugins/<plugin-name>/skills/{skill-name}/`
2. Add a `SKILL.md` with frontmatter (`name` and `description`)
3. Optionally add a `references/` subdirectory for supplementary docs
4. Test by installing the plugin locally: `/plugin install hopper-developer@hopper-ai-common`

### Writing Effective Skills

For comprehensive guidance on writing high-quality skills, install the [obra/superpowers](https://github.com/obra/superpowers) plugin and use the `writing-skills` skill:

```
/plugin marketplace add obra/superpowers
/plugin install superpowers@superpowers
```

The `writing-skills` skill covers best practices for description triggers, body structure, reference organization, and common pitfalls. Use it when authoring or reviewing skills.

If `obra/superpowers:writing-skills` is not available, follow these baseline guidelines:

- **Description**: Focus on _when_ the skill should trigger, not _what_ it does. Include specific keywords, repo names, tool names, and scenarios.
- **Body**: Be prescriptive. Include exact commands, code snippets, and tool invocations rather than abstract guidance.
- **MCP tool examples**: Show the exact MCP tool name and parameters — Claude uses these directly.
- **Safety**: Call out destructive or irreversible actions explicitly (e.g., "never run `terraform apply` locally").
- **Cross-references**: Link related skills using qualified names (e.g., `hopper-developer:release-me`).

### Modifying Existing Skills

- Keep skills focused on a single domain. If a skill is growing too large, split it.
- Update the `description` frontmatter if the skill's scope changes.
- Move detailed reference material to `references/` files to keep the main skill concise.

### Versioning

This repo uses [release-me](plugins/hopper-developer/skills/release-me/SKILL.md) for versioning. Each plugin is independently versioned — see `release-me-config.json` for the list of tracked packages.

- PR titles must follow [Conventional Commits](https://www.conventionalcommits.org/): `feat:`, `fix:`, `docs:`, etc.
- `feat:` bumps MINOR, `fix:` bumps PATCH, `docs:` produces no release.
- Versions are computed from git history, not from manifest files.

### Code Review

- Verify skill `description` accurately reflects trigger conditions
- Check that MCP tool invocations use correct tool names and parameters
- Ensure safety warnings are present for destructive operations
- Confirm cross-references between skills are valid
