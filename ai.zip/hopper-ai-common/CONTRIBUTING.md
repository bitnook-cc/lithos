# Contributing to hopper-ai-common

This repo hosts shared AI agent plugins for Hopper. Contributions are welcome, but quality matters — a bad skill is worse than no skill.

For the technical reference on repo structure, skill format, and cross-references, see [AGENTS.md](AGENTS.md).

## Plugin Types

There are two types of plugins:

### Core plugins

Owned by the platform team (`@hopper-org/org-vt-core_platform`). All changes require platform team review.

Current core plugins: `hopper-developer`, `hopper-scala`, `hopper-common`.

### Team plugins

Owned by the creating team. Teams self-govern their plugin content (skills, MCP configs). Platform team reviews only structural changes: marketplace.json, release-me config, CODEOWNERS entries.

## Creating a New Team Plugin

1. **Create plugin directory** with required structure:
   ```
   plugins/<plugin-name>/
     .claude-plugin/
       plugin.json        # { "name": "...", "description": "...", "author": { "name": "Hopper" } }
     skills/              # and/or .mcp.json — at least one is required
       <skill-name>/
         SKILL.md
   ```

2. **Add marketplace entry** — add your plugin to `/.claude-plugin/marketplace.json` in the `plugins` array.

3. **Add release-me package** — add your plugin to `release-me-config.json`:
   ```json
   "<plugin-name>": {
     "paths": ["plugins/<plugin-name>"],
     "initial-version": "0.1.0"
   }
   ```

4. **Add CODEOWNERS entry** — add a line to `CODEOWNERS`:
   ```
   /plugins/<plugin-name>/ @hopper-org/<your-team-handle>
   ```

5. **Submit a single PR** with all of the above. This PR requires platform team approval (since it touches shared config files).

## Adding Skills

See [AGENTS.md](AGENTS.md) for the technical skill format (frontmatter, references, cross-references).

### Quality Requirements

Before submitting a skill, verify:

- **Tested by at least 2 people** in different contexts (different repos, different tasks). A skill that works for one person in one scenario may fail or mislead in others.
- **Trigger-based description** — the `description` field must start with "Use when" and list concrete scenarios. Claude uses this to decide relevance; vague descriptions cause false activations.
- **Focused scope** — one skill per concern. If your skill covers multiple unrelated topics, split it.
- **Context budget** — every skill description is loaded into agent context for every conversation. Keep descriptions concise and specific. Bloated or vague descriptions waste tokens and degrade performance for everyone.
- **Reference material in `references/`** — large docs, examples, and templates go in a `references/` subdirectory, not inlined in SKILL.md. The skill body should be instructions, not a wall of text.

### What Doesn't Belong Here

- **Repo-specific instructions** — build commands, project layout, coding conventions belong in that repo's `CLAUDE.md` or `AGENTS.md`
- **Untested or experimental skills** — test before contributing
- **Personal workflow preferences** — skills should work for a team, not just one person

## PR Process

- PR titles must use [Conventional Commits](https://www.conventionalcommits.org/) (`feat:`, `fix:`, `chore:`, etc.) — enforced by CI
- Fill out the PR template checklist
- Core plugin changes require `@hopper-org/org-vt-core_platform` approval
- Team plugin content changes require only team approval
- Structural changes (marketplace.json, release-me config, CODEOWNERS, workflows) always require platform team approval

## Versioning

Each plugin is independently versioned via [release-me](plugins/hopper-developer/skills/release-me/SKILL.md). `feat:` bumps MINOR, `fix:` bumps PATCH, `docs:` produces no release. Versions are computed from git history.
